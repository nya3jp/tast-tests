(function(_ds){var window=this;var Qca=class{constructor(){this.j=0;this.g=[];this.oa=[];this.ea=this.v=0}get h(){return this.v}set h(a){0>a?a=0:a>this.g.length-1&&(a=this.g.length-1);this.v=a}set m(a){0<a&&(a=0);this.ea=a}get m(){return this.ea}};var r2=function(a,b){a.target.dispatchEvent(new CustomEvent("scroll-nav",{bubbles:!0,composed:!0,detail:b}))},Rca=function(a){return(0,_ds.O)`
      <style>
        .overflow-cover {
          background-color: white;
          height: 100%;
          position: absolute;
          top: 0;
          z-index: 100;
        }

        .overflow-cover.left-overflow {
          left: -360px;
          width: 360px;
        }

        .overflow-cover.right-overflow {
          right: -710px;
          width: 700px;
        }

        button.scroll-button {
          background-color: white;
          border: none;
          color: var(--scroll-button-color);
          cursor: pointer;
          display: none;
          font-family: 'Material Icons';
          /* Make these buttons take up the same vertical space as a normal full
          line of text. (since they will be sitting next to text). */
          font-size: var(--scroll-button-font-size);
          height: 100%;
          padding: 0;
          position: absolute;
          top: 0;
          z-index: 101;
        }

        button.scroll-button:hover,
        button.scroll-button:focus {
            color: var(--scroll-button-hover-color);
            outline: none;
        }

        button.scroll-button.scroll-left {
          /* Pull the left scroll button slightly behind the content so that it
          doesn't sit too close to text. */
          left: -8px;
        }

        button.scroll-button.scroll-left::after {
          content: 'chevron_left';
        }

        button.scroll-button.scroll-right {
          /* Pull the right scroll button slightly ahead of content so that it
          doesn't sit too close to text. */
          right: -8px;
        }

        button.scroll-button.scroll-right::after {
          content: 'chevron_right';
        }

        button.scroll-button.visible {
          display: block;
        }
      </style>
      <div class="overflow-cover left-overflow"></div>
      <button class="scroll-button scroll-left ${0<a.h?"visible":""}"
              @click="${b=>{r2(b,"left")}}"
              aria-label="${"Scroll to previous navigation items"}">
      </button>
      <slot></slot>
      <button class="scroll-button scroll-right ${a.h<a.g.length-1?"visible":""}"
              @click="${b=>{r2(b,"right")}}"
              aria-label="${"Scroll to more navigation items"}">
      </button>
      <div class="overflow-cover right-overflow"></div>
    `},Sca=class{};var s2=function(a,b,c,d,e){const {width:f}=a.getBoundingClientRect();0===f&&32>d?window.requestAnimationFrame(()=>{s2(a,b,c,d+1,e)}):32<=d?c("Exceeded max paint retries."):b(f)},Tca=function(a){return new Promise((b,c)=>{s2(a,b,c,0,32)})};var u2=async function(a,b,c){a.state.m=-b[c];a.state.h=c;await t2(a,a.state)},Uca=async function(a){await t2(a,a.state);document.body.dispatchEvent(new CustomEvent("cloud-tabs-loaded"))},t2=async function(a,b){await Vca(a,b);a.render(Rca(b),a.Ma)},Vca=async function(a,b){return new Promise(c=>{a.Aa.style.setProperty("--scroll-offset",`${b.m}px`);window.setTimeout(()=>{c()},250)})},Wca=class extends _ds.oN{constructor(){super();this.Ka=new _ds.wx;this.element=this;this.Ta=Sca;this.render=_ds.vt;this.Fa=
a=>{let b=this.state.h;b+="right"===a.detail?1:-1;u2(this,this.state.g,b)};this.state=new Qca;this.Aa=this.element.querySelector(".devsite-tabs-wrapper");this.Aa.style.setProperty("--scroll-animation-duration","250ms");this.Ma=this.element.attachShadow({mode:"open"});Uca(this);this.element.querySelectorAll(".devsite-tabs-dropdown a").forEach(a=>{a.addEventListener("click",()=>{_ds.hN(this)})})}oa(a){super.oa(a);a.target instanceof Node&&_ds.vx(this.Ka,a.target)}connectedCallback(){super.connectedCallback();
this.element.addEventListener("scroll-nav",this.Fa)}disconnectedCallback(){super.disconnectedCallback();this.element.removeEventListener("scroll-nav",this.Fa)}async La(a){return a.hasAttribute("generated-tab-menu")}async xa(){try{const a=await Tca(this.Aa);if(this.state.j!==a){this.state.j=a;const b=Array.from(this.element.querySelectorAll("tab"));this.state.oa=b.map(c=>({element:c,Jj:c?c.offsetWidth:0}));this.state.g=_ds.pN(this.state.oa,this.state.j);await u2(this,this.state.g,0)}}catch(a){await u2(this,
this.state.g,0)}}};try{window.customElements.define("cloudx-tabs-nav",Wca)}catch(a){console.warn("devsite.app.tenants.cloud.static.components.CloudxTabsNav",a)};})(_ds_www);
