(function(_ds){var window=this;try{window.customElements.define("devsite-dynamic-content",_ds.gT)}catch(a){console.warn("devsite.app.customElement.DevsiteDynamicContent",a)};})(_ds_www);
