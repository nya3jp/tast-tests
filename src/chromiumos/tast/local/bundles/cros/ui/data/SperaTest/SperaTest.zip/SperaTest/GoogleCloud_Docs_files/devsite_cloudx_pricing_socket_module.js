(function(_ds){var window=this;try{window.customElements.define(_ds.xM(),_ds.CM)}catch(a){console.warn("Unrecognized DevSite custom element - CloudxPricingSocket",a)};})(_ds_www);
