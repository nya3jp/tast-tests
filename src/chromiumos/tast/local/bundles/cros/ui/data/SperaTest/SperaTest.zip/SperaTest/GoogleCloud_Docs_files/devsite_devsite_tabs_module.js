(function(_ds){var window=this;try{window.customElements.define("devsite-tabs",_ds.oN)}catch(a){console.warn("devsite.app.customElement.DevsiteTabs",a)};})(_ds_www);
