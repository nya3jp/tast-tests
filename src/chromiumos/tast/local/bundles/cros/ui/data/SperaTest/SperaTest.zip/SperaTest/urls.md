GoogleDocs
https://www.google.com/docs/about/

GoogleWorkspace
https://workspace.google.com/intl/en/ 

GoogleWorkspace_EnterpriseApplicationSoftware
https://workspace.google.com/intl/en/enterprise/

GoolgeNonprofits_YouTube
https://www.google.com/nonprofits/offerings/youtube-nonprofit-program/

GoolgeNonprofits_Stories
https://www.google.com/nonprofits/success-stories/

GoogleStore
https://store.google.com/?hl=en-US

GoogleStore_SmartHome
https://store.google.com/category/connected_home?hl=en-US

GoogleShopping
https://shopping.google.com/

GoogleShopping_Chromebook
https://www.google.com/search?q=chromebook&source=lnms&tbm=shop

GoogleNews
https://news.google.com/

GoogleNews_World
https://news.google.com/topics/CAAqKggKIiRDQkFTRlFvSUwyMHZNRGx1YlY4U0JXVnVMVWRDR2dKSFFpZ0FQAQ?hl=en-GB&gl=GB&ceid=GB%3Aen 

GoogleHelp
https://support.google.com/ 

GoogleHelp_Chromebook
https://support.google.com/chromebook 

GoogleFinance
https://www.google.com/finance/

GoogleFinance_GOOGL
https://www.google.com/finance/quote/GOOGL:NASDAQ

GoogleBook
https://www.google.com/books/edition/_/mIbTDwAAQBAJ?hl=en&gbpv=0

GoogleBooks_Classic
https://books.google.com/books?id=mIbTDwAAQBAJ&newbks=1&newbks_redir=0&printsec=frontcover&pg=PP1&dq=chromebook&hl=en#v=onepage&q=chromebook&f=false

GooglePlay
https://play.google.com/store/games

GooglePlay_Pass
https://play.google.com/about/play-pass/

GoogleCloud
https://cloud.google.com/

GoogleCloud_Docs
https://cloud.google.com/docs/
