/**
 * @fileoverview WombatTextAnimations animates text on Wombat template orderly from top to bottom.
 */

/**
 * @function WombatTextAnimations is the class for Dynamic Text Animations on Wombat Template
 * @param {!HTMLElement} scopeElement the element that the element watcher is attached to
 */
function WombatTextAnimations(scopeElement) {
  var allTextTags = scopeElement.querySelectorAll(
      'h1, h2, h3, h4, h5, h6, h7, p, a, .include-text-animation, [role="heading"]');

  function startTextAnimations() {
    allTextTags.forEach(function(element, i) {
      var newIndex = i+1;
      var animationClassName = 'text-animation-' + newIndex;
      if (!element.classList.contains('skip-text-animation')) {
        element.classList.add(animationClassName);
      }
    });
  }

  this.init = function() {
    startTextAnimations();
  };

  this.init();
}
