(function(_ds){var window=this;var BU=new Map([["arrowsOnHover","cloud-carousel--arrows-on-hover"],["bleedLeft","cloud-carousel--bleed-left"],["bleedRight","cloud-carousel--bleed-right"],["isSimple","cloud-carousel--simple"],["isThreeUp","cloud-carousel--3up"],["isMarginTight","cloud-carousel--margin-tight"],["isFeatured","cloud-carousel--featured"]]),CU="onpointermove"in window?"pointerenter":"mouseenter",EU=function(a){a.g=a.slideData.length?a.slideData.map((c,d)=>{const {carouselSlideDate:e,carouselSlideDescription:f,carouselSlideCtaLink:g,
carouselSlideCtaText:h,carouselSlideImage:k,carouselSlideLinkNewTab:l,carouselSlideLocation:p,carouselSlideTrackName:q=h,carouselSlideTrackMetadataEventDetail:y=g,carouselSlideTrackMetadataPosition:B,carouselSlideTrackType:A="carousel slide item",carouselSlideTrackMetadataChildHeadline:F=f,carouselSlideTrackMetadataChildIndex:G=d+1,carouselSlideTrackMetadataChildTotal:M=a.slideData.length}=c;c=e||p;var L={backgroundImage:`url(${k})`};const Q=l?"_blank":"_self",{qt:ta,wu:Y}=DU(a,d);d=(0,_ds.O)`
        <div class="${"cloud-carousel__slide-image"}"
            style="${(0,_ds.AD)(L)}"></div>`;L=(0,_ds.O)`
        <div class="${"cloud-carousel__slide-date"}">${e}</div>`;const fa=(0,_ds.O)`
        <div class="${"cloud-carousel__slide-location"}">${p}</div>`;L=(0,_ds.O)`
        <div class="${"cloud-body-text cloud-carousel__slide-metadata"}">
          <p class="${"cloud-body-text__title"}">
            ${e?L:""}
            ${p?fa:""}
          </p>
        </div>`;return(0,_ds.O)`
        <div
          aria-labelledby="${_ds.uD(a.hideNuggets?void 0:ta)}"
          class="${"cloud-carousel__slide"}"
          id="${Y}"
          role="tabpanel"
          tabindex="0"
        >
          ${k?d:""}
          <div class="${"cloud-carousel__slide-body"}">
            <h2 class="${"cloud-headline3"}">
              ${f}
            </h2>
            ${c?L:""}
            <a
              class="${"cloud-button cloud-button--flat"}"
              href="${g}"
              rel="noopener"
              target="${Q}"
              track-type="${A}"
              track-name="${q}"
              track-metadata-eventdetail="${y}"
              track-metadata-position="${null!=B?B:_ds.Oq}"
              track-metadata-child_headline="${F}"
              track-metadata-child_index="${G}"
              track-metadata-child_total="${M}">
              ${h}
              <i class="${"material-icons notranslate cloud-button__icon cloud-button__icon--external"}" aria-hidden="true">
                arrow_forward
              </i>
            </a>
          </div>
        </div>`}):[...a.querySelectorAll(".cloud-carousel__slide")];a.v=a.g.length-1;const b=a.querySelector(".cloud-carousel__slide");if(b){const c=_ds.bm(b,"margin").right;a.slideX=b.getBoundingClientRect().width+c}},GU=function(a){a.ea.listen(document.body,"devsite-sticky-resize",()=>{EU(a);FU(a);a.m()})},FU=function(a){for(const b of a.Ca)b.removeAttribute("visually-hidden")},HU=function(a){a.g.forEach((b,c)=>{if(b instanceof Element){var {qt:d,wu:e}=DU(a,c);a.hideNuggets||b.setAttribute("aria-labelledby",
`${d}`);b.setAttribute("role","tabpanel");"true"===a.tabbable?b.setAttribute("tabindex","0"):b.setAttribute("tabindex","-1");b.id=e}})},JU=async function(a){await DevsiteApp.whenReady();document.body.hasAttribute("touch")||(IU(a),_ds.Al(a.ea,a,[CU,"focusin"],()=>{clearInterval(a.Fa)}))},DU=function(a,b){return{qt:`${a.h}${"-control"}${b}`,wu:`${a.h}${"-slide"}${b}`}},KU=function(a){const b=a.slideX*a.position;return 0<a.touchMoveX?b+a.touchStartX-a.touchMoveX:b},IU=function(a){a.Fa=setInterval(()=>
void a.j(),3500)},LU=function(a){if(a.hideNuggets)return(0,_ds.O)``;const b=[];a.g.forEach((c,d)=>{c=d===a.position;const {qt:e,wu:f}=DU(a,d);b.push((0,_ds.O)`
          <button class="${"cloud-carousel__nugget"}"
            ?active="${c}"
            aria-controls="${f}"
            aria-label="${"Slide"} ${d+1}"
            aria-selected="${c}"
            data-index="${d}"
            id="${e}"
            role="tab"
            tabindex="${_ds.uD(c?void 0:"-1")}"
            @keydown=${a.Ea}
            @click=${()=>{FU(a);a.position=d}}>
          </button>`)});return(0,_ds.O)`
        <div
          aria-label="${"Choose slide to display"}"
          class="${"cloud-carousel__nuggets"}"
          role="tablist">
          ${b}
        </div>`},MU=function(a){const b=["cloud-carousel__controls"],c=0===a.position,d=a.position===a.v,e=`${a.h}${"-items"}`;a.hideNuggets&&b.push("cloud-carousel__controls--hide-nuggets");return(0,_ds.O)`
        <div class="${b.join(" ")}">
          <button
            aria-controls="${e}"
            aria-label="${"Previous slide"}"
            class="${"cloud-carousel__arrow left-arrow"}"
            @click=${a.ra}
            ?disabled=${c}
          >
            <i class="material-icons">keyboard_arrow_left</i>
          </button>
          <button
            aria-controls="${e}"
            aria-label="${"Next slide"}"
            class="${"cloud-carousel__arrow right-arrow"}"
            @click=${a.j}
            ?disabled=${d}
          >
            <i class="material-icons">keyboard_arrow_right</i>
          </button>
        </div>`},NU=function(a){return(0,_ds.O)`
        <div class="${"cloud-carousel__slide-deck-container"}">
          <div
            aria-live="${a.autoRotate?"off":"polite"}"
            class="${"cloud-carousel__slide-deck"}"
            id="${a.h}${"-items"}"
            style="${(0,_ds.AD)({transform:`translateX(-${KU(a)}px)`})}"
            @touchstart=${a.Ka}
            @touchmove=${a.La}
            @touchend=${a.Ga}
            @transitionend=${a.m}
          >
            ${a.g}
          </div>
        </div>`},OU=class extends _ds.Vt{static get properties(){return{autoRotate:{type:Boolean,Da:"auto-rotate"},arrowsOnHover:{type:Boolean,Da:"arrows-on-hover"},bleedLeft:{type:Boolean,Da:"bleed-left"},bleedRight:{type:Boolean,Da:"bleed-right"},bottomControls:{type:Boolean,Da:"bottom-controls"},hideNuggets:{type:Boolean,Da:"hide-nuggets"},isFeatured:{type:Boolean,Da:"is-featured"},isSimple:{type:Boolean,Da:"is-simple"},isThreeUp:{type:Boolean,Da:"is-three-up"},isMarginTight:{type:Boolean,Da:"is-margin-tight"},
tabbable:{type:String,Da:"tabbable"},position:{type:Number,Na:!0},label:{type:String},slideData:{type:Array,Da:"slide-data"},slideX:{type:Number,Na:!0},touchMoveX:{type:Number},touchStartX:{type:Number}}}constructor(){super();this.isMarginTight=this.isThreeUp=this.isSimple=this.isFeatured=this.hideNuggets=this.bottomControls=this.bleedRight=this.bleedLeft=this.arrowsOnHover=this.autoRotate=!1;this.position=0;this.tabbable="true";this.label="";this.slideData=[];this.touchStartX=this.touchMoveX=this.slideX=
0;this.ea=new _ds.x;this.h="";this.g=[];this.Ca=[];this.v=0;this.Fa=null;this.xa=this.Aa=!1}connectedCallback(){super.connectedCallback();var a=this.querySelector(".cloud-carousel");a&&(a.hasAttribute("aria-label")&&this.setAttribute("label",a.getAttribute("aria-label")),a.querySelector(".cloud-carousel__controls--hide-nuggets")&&(this.setAttribute("hide-nuggets",""),a.classList.remove("cloud-carousel__controls--hide-nuggets")),a.classList.contains("cloud-carousel--autorotate")&&(this.setAttribute("auto-rotate",
""),a.classList.remove("cloud-carousel--autorotate")),a.classList.contains("cloud-carousel--simple")&&(this.setAttribute("is-simple",""),a.classList.remove("cloud-carousel--simple")),a.classList.contains("cloud-carousel--3up")&&(this.setAttribute("is-three-up",""),a.classList.remove("cloud-carousel--3up")),a.classList.contains("cloud-carousel--margin-tight")&&(this.setAttribute("is-margin-tight",""),a.classList.remove("cloud-carousel--margin-tight")),a.classList.contains("cloud-carousel--arrows-on-hover")&&
(this.setAttribute("arrows-on-hover",""),a.classList.remove("cloud-carousel--arrows-on-hover")),a.classList.contains("cloud-carousel--bleed-left")&&(this.setAttribute("bleed-left",""),a.classList.remove("cloud-carousel--bleed-left")),a.classList.contains("cloud-carousel--bleed-right")&&(this.setAttribute("bleed-right",""),a.classList.remove("cloud-carousel--bleed-right")),a.classList.remove("cloud-carousel"));a=1;let b=`${"carousel"}${a}`;for(;document.getElementById(b);)b=`${"carousel"}${a++}`;this.h=
this.id=b;EU(this);GU(this);this.xa&&(FU(this),this.m())}disconnectedCallback(){super.disconnectedCallback();_ds.z(this.ea)}qb(){return this}cb(){this.Ca=[...this.querySelectorAll(".cloud-carousel__slide")];HU(this);this.m();this.autoRotate&&JU(this)}ra(){FU(this);this.position=Math.max(0,this.position-1)}j(){FU(this);this.position=Math.min(this.v,this.position+1);this.autoRotate&&this.position===this.v&&clearInterval(this.Fa)}Ea(a){switch(a.key){case "ArrowRight":this.j();break;case "ArrowLeft":this.ra()}this.querySelector(`[data-index="${this.position}"]`).focus()}Ka(a){a=
a.touches&&a.touches[0]&&a.touches[0].clientX;null!==a&&(FU(this),this.Aa=!0,this.touchMoveX=this.touchStartX=a)}La(a){a=a.touches&&a.touches[0]&&a.touches[0].clientX;null!==a&&(this.touchMoveX=a)}Ga(){const a=this.slideX*this.position,b=KU(this);Math.abs(a-b)>.2*this.slideX&&("right"===(a<b?"right":"left")?this.j():this.ra());this.Aa=!1;this.touchMoveX=this.touchStartX=0}m(){const a=this.querySelector(".cloud-carousel__slide-deck-container").getBoundingClientRect();this.Ca.forEach((b,c)=>{if(this.isThreeUp){c=
b.getBoundingClientRect();const d=c.right;c=c.left<a.right&&d>a.left}else c=this.position===c;c||b.setAttribute("visually-hidden","")})}render(){if(!this.xa)for(this.xa=!0;this.hd.firstChild;)this.hd.removeChild(this.hd.firstChild);const a=[];this.Aa&&a.push("cloud-carousel--no-transition");for(const [c,d]of BU)this[c]&&a.push(d);let b;b=this.bottomControls?(0,_ds.O)`${NU(this)} ${MU(this)}`:(0,_ds.O)`${MU(this)} ${NU(this)}`;return(0,_ds.O)`
        <div
          class="${a.join(" ")}"
          role="group"
          aria-roledescription="carousel"
          aria-label="${this.label}"
        >
          ${b}
          ${LU(this)}
        </div>`}updated(a){a.has("slideData")&&EU(this)}};try{window.customElements.define("cloudx-carousel",OU)}catch(a){console.warn("devsite.app.customElement.CloudxCarousel",a)};})(_ds_www);
