//javascript/closure/base.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Bootstrap for the Google JS Library (Closure).
 *
 * In uncompiled mode base.js will attempt to load Closure's deps file, unless
 * the global <code>CLOSURE_NO_DEPS</code> is set to true.  This allows projects
 * to include their own deps file(s) from different locations.
 *
 * Avoid including base.js more than once. This is strictly discouraged and not
 * supported. goog.require(...) won't work properly in that case.
 *
 * @provideGoog
 */


/**
 * @define {boolean} Overridden to true by the compiler.
 */
var COMPILED = false;


/**
 * Base namespace for the Closure library.  Checks to see goog is already
 * defined in the current scope before assigning to prevent clobbering if
 * base.js is loaded more than once.
 *
 * @const
 */
var goog = goog || {};

/**
 * Reference to the global object.
 * https://www.ecma-international.org/ecma-262/9.0/index.html#sec-global-object
 *
 * More info on this implementation here:
 * https://docs.google.com/document/d/1NAeW4Wk7I7FV0Y2tcUFvQdGMc89k2vdgSXInw8_nvCI/edit
 *
 * @const
 * @suppress {undefinedVars} self won't be referenced unless `this` is falsy.
 * @type {!Global}
 */
goog.global =
    // Check `this` first for backwards compatibility.
    // Valid unless running as an ES module or in a function wrapper called
    //   without setting `this` properly.
    // Note that base.js can't usefully be imported as an ES module, but it may
    // be compiled into bundles that are loadable as ES modules.
    this ||
    // https://developer.mozilla.org/en-US/docs/Web/API/Window/self
    // For in-page browser environments and workers.
    self;


/**
 * A hook for overriding the define values in uncompiled mode.
 *
 * In uncompiled mode, `CLOSURE_UNCOMPILED_DEFINES` may be defined before
 * loading base.js.  If a key is defined in `CLOSURE_UNCOMPILED_DEFINES`,
 * `goog.define` will use the value instead of the default value.  This
 * allows flags to be overwritten without compilation (this is normally
 * accomplished with the compiler's "define" flag).
 *
 * Example:
 * <pre>
 *   var CLOSURE_UNCOMPILED_DEFINES = {'goog.DEBUG': false};
 * </pre>
 *
 * @type {Object<string, (string|number|boolean)>|undefined}
 */
goog.global.CLOSURE_UNCOMPILED_DEFINES;


/**
 * A hook for overriding the define values in uncompiled or compiled mode,
 * like CLOSURE_UNCOMPILED_DEFINES but effective in compiled code.  In
 * uncompiled code CLOSURE_UNCOMPILED_DEFINES takes precedence.
 *
 * Also unlike CLOSURE_UNCOMPILED_DEFINES the values must be number, boolean or
 * string literals or the compiler will emit an error.
 *
 * While any @define value may be set, only those set with goog.define will be
 * effective for uncompiled code.
 *
 * Example:
 * <pre>
 *   var CLOSURE_DEFINES = {'goog.DEBUG': false} ;
 * </pre>
 *
 * Currently the Closure Compiler will only recognize very simple definitions of
 * this value when looking for values to apply to compiled code and ignore all
 * other references.  Specifically, it looks the value defined at the variable
 * declaration, as with the example above.
 *
 * TODO(b/202066289): Improve the recognized definitions.
 *
 * @type {!Object<string, (string|number|boolean)>|null|undefined}
 */
goog.global.CLOSURE_DEFINES;


/**
 * Builds an object structure for the provided namespace path, ensuring that
 * names that already exist are not overwritten. For example:
 * "a.b.c" -> a = {};a.b={};a.b.c={};
 * Used by goog.provide and goog.exportSymbol.
 * @param {string} name The name of the object that this file defines.
 * @param {*=} object The object to expose at the end of the path.
 * @param {boolean=} overwriteImplicit If object is set and a previous call
 *     implicitly constructed the namespace given by name, this parameter
 *     controls whether object should overwrite the implicitly constructed
 *     namespace or be merged into it. Defaults to false.
 * @param {?Object=} objectToExportTo The object to add the path to; if this
 *     field is not specified, its value defaults to `goog.global`.
 * @private
 */
goog.exportPath_ = function(name, object, overwriteImplicit, objectToExportTo) {
  var parts = name.split('.');
  var cur = objectToExportTo || goog.global;

  // Internet Explorer exhibits strange behavior when throwing errors from
  // methods externed in this manner.  See the testExportSymbolExceptions in
  // base_test.html for an example.
  if (!(parts[0] in cur) && typeof cur.execScript != 'undefined') {
    cur.execScript('var ' + parts[0]);
  }

  for (var part; parts.length && (part = parts.shift());) {
    if (!parts.length && object !== undefined) {
      if (!overwriteImplicit && goog.isObject(object) &&
          goog.isObject(cur[part])) {
        // Merge properties on object (the input parameter) with the existing
        // implicitly defined namespace, so as to not clobber previously
        // defined child namespaces.
        for (var prop in object) {
          if (object.hasOwnProperty(prop)) {
            cur[part][prop] = object[prop];
          }
        }
      } else {
        // Either there is no existing implicit namespace, or overwriteImplicit
        // is set to true, so directly assign object (the input parameter) to
        // the namespace.
        cur[part] = object;
      }
    } else if (cur[part] && cur[part] !== Object.prototype[part]) {
      cur = cur[part];
    } else {
      cur = cur[part] = {};
    }
  }
};


/**
 * Defines a named value. In uncompiled mode, the value is retrieved from
 * CLOSURE_DEFINES or CLOSURE_UNCOMPILED_DEFINES if the object is defined and
 * has the property specified, and otherwise used the defined defaultValue.
 * When compiled the default can be overridden using the compiler options or the
 * value set in the CLOSURE_DEFINES object. Returns the defined value so that it
 * can be used safely in modules. Note that the value type MUST be either
 * boolean, number, or string.
 *
 * @param {string} name The distinguished name to provide.
 * @param {T} defaultValue
 * @return {T} The defined value.
 * @template T
 */
goog.define = function(name, defaultValue) {
  var value = defaultValue;
  if (!COMPILED) {
    var uncompiledDefines = goog.global.CLOSURE_UNCOMPILED_DEFINES;
    var defines = goog.global.CLOSURE_DEFINES;
    if (uncompiledDefines &&
        // Anti DOM-clobbering runtime check (b/37736576).
        /** @type {?} */ (uncompiledDefines).nodeType === undefined &&
        Object.prototype.hasOwnProperty.call(uncompiledDefines, name)) {
      value = uncompiledDefines[name];
    } else if (
        defines &&
        // Anti DOM-clobbering runtime check (b/37736576).
        /** @type {?} */ (defines).nodeType === undefined &&
        Object.prototype.hasOwnProperty.call(defines, name)) {
      value = defines[name];
    }
  }
  return value;
};


/**
 * @define {number} Integer year indicating the set of browser features that are
 * guaranteed to be present.  This is defined to include exactly features that
 * work correctly on all "modern" browsers that are stable on January 1 of the
 * specified year.  For example,
 * ```js
 * if (goog.FEATURESET_YEAR >= 2019) {
 *   // use APIs known to be available on all major stable browsers Jan 1, 2019
 * } else {
 *   // polyfill for older browsers
 * }
 * ```
 * This is intended to be the primary define for removing
 * unnecessary browser compatibility code (such as ponyfills and workarounds),
 * and should inform the default value for most other defines:
 * ```js
 * const ASSUME_NATIVE_PROMISE =
 *     goog.define('ASSUME_NATIVE_PROMISE', goog.FEATURESET_YEAR >= 2016);
 * ```
 *
 * The default assumption is that IE9 is the lowest supported browser, which was
 * first available Jan 1, 2012.
 *
 * TODO(mathiasb): Reference more thorough documentation when it's available.
 */
goog.FEATURESET_YEAR = goog.define('goog.FEATURESET_YEAR', 2012);


/**
 * @define {boolean} DEBUG is provided as a convenience so that debugging code
 * that should not be included in a production. It can be easily stripped
 * by specifying --define goog.DEBUG=false to the Closure Compiler aka
 * JSCompiler. For example, most toString() methods should be declared inside an
 * "if (goog.DEBUG)" conditional because they are generally used for debugging
 * purposes and it is difficult for the JSCompiler to statically determine
 * whether they are used.
 */
goog.DEBUG = goog.define('goog.DEBUG', true);


/**
 * @define {string} LOCALE defines the locale being used for compilation. It is
 * used to select locale specific data to be compiled in js binary. BUILD rule
 * can specify this value by "--define goog.LOCALE=<locale_name>" as a compiler
 * option.
 *
 * Take into account that the locale code format is important. You should use
 * the canonical Unicode format with hyphen as a delimiter. Language must be
 * lowercase, Language Script - Capitalized, Region - UPPERCASE.
 * There are few examples: pt-BR, en, en-US, sr-Latin-BO, zh-Hans-CN.
 *
 * See more info about locale codes here:
 * http://www.unicode.org/reports/tr35/#Unicode_Language_and_Locale_Identifiers
 *
 * For language codes you should use values defined by ISO 693-1. See it here
 * http://www.w3.org/WAI/ER/IG/ert/iso639.htm. There is only one exception from
 * this rule: the Hebrew language. For legacy reasons the old code (iw) should
 * be used instead of the new code (he).
 *
 * MOE:begin_intracomment_strip
 * See http://g3doc/i18n/identifiers/g3doc/synonyms.
 * MOE:end_intracomment_strip
 */
goog.LOCALE = goog.define('goog.LOCALE', 'en');  // default to en


/**
 * Same as `goog.LOCALE`, which should be used instead.
 *
 * Using this method just makes it harder for closure-compiler to optimize
 * your locale-specific code, since it has to take the extra step of inlining
 * this function to discover and remove code that is not used for the target
 * locale.
 *
 * @return {string}
 * @deprecated use `goog.LOCALE`
 */
goog.getLocale = function() {
  return goog.LOCALE;
};


/**
 * @define {boolean} Whether this code is running on trusted sites.
 *
 * On untrusted sites, several native functions can be defined or overridden by
 * external libraries like Prototype, Datejs, and JQuery and setting this flag
 * to false forces closure to use its own implementations when possible.
 *
 * If your JavaScript can be loaded by a third party site and you are wary about
 * relying on non-standard implementations, specify
 * "--define goog.TRUSTED_SITE=false" to the compiler.
 */
goog.TRUSTED_SITE = goog.define('goog.TRUSTED_SITE', true);


/**
 * @define {boolean} Whether code that calls {@link goog.setTestOnly} should
 *     be disallowed in the compilation unit.
 */
goog.DISALLOW_TEST_ONLY_CODE =
    goog.define('goog.DISALLOW_TEST_ONLY_CODE', COMPILED && !goog.DEBUG);


/**
 * @define {boolean} Whether to use a Chrome app CSP-compliant method for
 *     loading scripts via goog.require. @see appendScriptSrcNode_.
 */
goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING =
    goog.define('goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING', false);


/**
 * Defines a namespace in Closure.
 *
 * A namespace may only be defined once in a codebase. It may be defined using
 * goog.provide() or goog.module().
 *
 * The presence of one or more goog.provide() calls in a file indicates
 * that the file defines the given objects/namespaces.
 * Provided symbols must not be null or undefined.
 *
 * In addition, goog.provide() creates the object stubs for a namespace
 * (for example, goog.provide("goog.foo.bar") will create the object
 * goog.foo.bar if it does not already exist).
 *
 * Build tools also scan for provide/require/module statements
 * to discern dependencies, build dependency files (see deps.js), etc.
 *
 * @see goog.require
 * @see goog.module
 * @param {string} name Namespace provided by this file in the form
 *     "goog.package.part".
 * deprecated Use goog.module (see b/159289405)
 */
goog.provide = function(name) {
  if (goog.isInModuleLoader_()) {
    throw new Error('goog.provide cannot be used within a module.');
  }
  if (!COMPILED) {
    // Ensure that the same namespace isn't provided twice.
    // A goog.module/goog.provide maps a goog.require to a specific file
    if (goog.isProvided_(name)) {
      throw new Error('Namespace "' + name + '" already declared.');
    }
  }

  goog.constructNamespace_(name);
};


/**
 * @param {string} name Namespace provided by this file in the form
 *     "goog.package.part".
 * @param {?Object=} object The object to embed in the namespace.
 * @param {boolean=} overwriteImplicit If object is set and a previous call
 *     implicitly constructed the namespace given by name, this parameter
 *     controls whether opt_obj should overwrite the implicitly constructed
 *     namespace or be merged into it. Defaults to false.
 * @private
 */
goog.constructNamespace_ = function(name, object, overwriteImplicit) {
  if (!COMPILED) {
    delete goog.implicitNamespaces_[name];

    var namespace = name;
    while ((namespace = namespace.substring(0, namespace.lastIndexOf('.')))) {
      if (goog.getObjectByName(namespace)) {
        break;
      }
      goog.implicitNamespaces_[namespace] = true;
    }
  }

  goog.exportPath_(name, object, overwriteImplicit);
};


/**
 * According to the CSP3 spec a nonce must be a valid base64 string.
 * @see https://www.w3.org/TR/CSP3/#grammardef-base64-value
 * @private @const
 */
goog.NONCE_PATTERN_ = /^[\w+/_-]+[=]{0,2}$/;


/**
 * Returns CSP nonce, if set for any script tag.
 * @param {?Window=} opt_window The window context used to retrieve the nonce.
 *     Defaults to global context.
 * @return {string} CSP nonce or empty string if no nonce is present.
 * @private
 */
goog.getScriptNonce_ = function(opt_window) {
  var doc = (opt_window || goog.global).document;
  var script = doc.querySelector && doc.querySelector('script[nonce]');
  if (script) {
    // Try to get the nonce from the IDL property first, because browsers that
    // implement additional nonce protection features (currently only Chrome) to
    // prevent nonce stealing via CSS do not expose the nonce via attributes.
    // See https://github.com/whatwg/html/issues/2369
    var nonce = script['nonce'] || script.getAttribute('nonce');
    if (nonce && goog.NONCE_PATTERN_.test(nonce)) {
      return nonce;
    }
  }
  return '';
};


/**
 * Module identifier validation regexp.
 * Note: This is a conservative check, it is very possible to be more lenient,
 *   the primary exclusion here is "/" and "\" and a leading ".", these
 *   restrictions are intended to leave the door open for using goog.require
 *   with relative file paths rather than module identifiers.
 * @private
 */
goog.VALID_MODULE_RE_ = /^[a-zA-Z_$][a-zA-Z0-9._$]*$/;


/**
 * Defines a module in Closure.
 *
 * Marks that this file must be loaded as a module and claims the namespace.
 *
 * A namespace may only be defined once in a codebase. It may be defined using
 * goog.provide() or goog.module().
 *
 * goog.module() has three requirements:
 * - goog.module may not be used in the same file as goog.provide.
 * - goog.module must be the first statement in the file.
 * - only one goog.module is allowed per file.
 *
 * When a goog.module annotated file is loaded, it is enclosed in
 * a strict function closure. This means that:
 * - any variables declared in a goog.module file are private to the file
 * (not global), though the compiler is expected to inline the module.
 * - The code must obey all the rules of "strict" JavaScript.
 * - the file will be marked as "use strict"
 *
 * NOTE: unlike goog.provide, goog.module does not declare any symbols by
 * itself. If declared symbols are desired, use
 * goog.module.declareLegacyNamespace().
 *
 * MOE:begin_intracomment_strip
 * See the goog.module announcement at http://go/goog.module-announce
 * MOE:end_intracomment_strip
 *
 * See the public goog.module proposal: http://goo.gl/Va1hin
 *
 * @param {string} name Namespace provided by this file in the form
 *     "goog.package.part", is expected but not required.
 * @return {void}
 */
goog.module = function(name) {
  if (typeof name !== 'string' || !name ||
      name.search(goog.VALID_MODULE_RE_) == -1) {
    throw new Error('Invalid module identifier');
  }
  if (!goog.isInGoogModuleLoader_()) {
    throw new Error(
        'Module ' + name + ' has been loaded incorrectly. Note, ' +
        'modules cannot be loaded as normal scripts. They require some kind of ' +
        'pre-processing step. You\'re likely trying to load a module via a ' +
        'script tag or as a part of a concatenated bundle without rewriting the ' +
        'module. For more info see: ' +
        'https://github.com/google/closure-library/wiki/goog.module:-an-ES6-module-like-alternative-to-goog.provide.');
  }
  if (goog.moduleLoaderState_.moduleName) {
    throw new Error('goog.module may only be called once per module.');
  }

  // Store the module name for the loader.
  goog.moduleLoaderState_.moduleName = name;
  if (!COMPILED) {
    // Ensure that the same namespace isn't provided twice.
    // A goog.module/goog.provide maps a goog.require to a specific file
    if (goog.isProvided_(name)) {
      throw new Error('Namespace "' + name + '" already declared.');
    }
    delete goog.implicitNamespaces_[name];
  }
};


/**
 * @param {string} name The module identifier.
 * @return {?} The module exports for an already loaded module or null.
 *
 * Note: This is not an alternative to goog.require, it does not
 * indicate a hard dependency, instead it is used to indicate
 * an optional dependency or to access the exports of a module
 * that has already been loaded.
 * @suppress {missingProvide}
 */
goog.module.get = function(name) {
  return goog.module.getInternal_(name);
};


/**
 * @param {string} name The module identifier.
 * @return {?} The module exports for an already loaded module or null.
 * @private
 */
goog.module.getInternal_ = function(name) {
  if (!COMPILED) {
    if (name in goog.loadedModules_) {
      return goog.loadedModules_[name].exports;
    } else if (!goog.implicitNamespaces_[name]) {
      var ns = goog.getObjectByName(name);
      return ns != null ? ns : null;
    }
  }
  return null;
};


/**
 * Types of modules the debug loader can load.
 * @enum {string}
 */
goog.ModuleType = {
  ES6: 'es6',
  GOOG: 'goog'
};


/**
 * @private {?{
 *   moduleName: (string|undefined),
 *   declareLegacyNamespace:boolean,
 *   type: ?goog.ModuleType
 * }}
 */
goog.moduleLoaderState_ = null;


/**
 * @private
 * @return {boolean} Whether a goog.module or an es6 module is currently being
 *     initialized.
 */
goog.isInModuleLoader_ = function() {
  return goog.isInGoogModuleLoader_() || goog.isInEs6ModuleLoader_();
};


/**
 * @private
 * @return {boolean} Whether a goog.module is currently being initialized.
 */
goog.isInGoogModuleLoader_ = function() {
  return !!goog.moduleLoaderState_ &&
      goog.moduleLoaderState_.type == goog.ModuleType.GOOG;
};


/**
 * @private
 * @return {boolean} Whether an es6 module is currently being initialized.
 */
goog.isInEs6ModuleLoader_ = function() {
  var inLoader = !!goog.moduleLoaderState_ &&
      goog.moduleLoaderState_.type == goog.ModuleType.ES6;

  if (inLoader) {
    return true;
  }

  var jscomp = goog.global['$jscomp'];

  if (jscomp) {
    // jscomp may not have getCurrentModulePath if this is a compiled bundle
    // that has some of the runtime, but not all of it. This can happen if
    // optimizations are turned on so the unused runtime is removed but renaming
    // and Closure pass are off (so $jscomp is still named $jscomp and the
    // goog.provide/require calls still exist).
    if (typeof jscomp.getCurrentModulePath != 'function') {
      return false;
    }

    // Bundled ES6 module.
    return !!jscomp.getCurrentModulePath();
  }

  return false;
};


/**
 * Provide the module's exports as a globally accessible object under the
 * module's declared name.  This is intended to ease migration to goog.module
 * for files that have existing usages.
 * @suppress {missingProvide}
 */
goog.module.declareLegacyNamespace = function() {
  if (!COMPILED && !goog.isInGoogModuleLoader_()) {
    throw new Error(
        'goog.module.declareLegacyNamespace must be called from ' +
        'within a goog.module');
  }
  if (!COMPILED && !goog.moduleLoaderState_.moduleName) {
    throw new Error(
        'goog.module must be called prior to ' +
        'goog.module.declareLegacyNamespace.');
  }
  goog.moduleLoaderState_.declareLegacyNamespace = true;
};


/**
 * Associates an ES6 module with a Closure module ID so that is available via
 * goog.require. The associated ID  acts like a goog.module ID - it does not
 * create any global names, it is merely available via goog.require /
 * goog.module.get / goog.forwardDeclare / goog.requireType. goog.require and
 * goog.module.get will return the entire module as if it was import *'d. This
 * allows Closure files to reference ES6 modules for the sake of migration.
 *
 * @param {string} namespace
 * @suppress {missingProvide}
 */
goog.declareModuleId = function(namespace) {
  if (!COMPILED) {
    if (!goog.isInEs6ModuleLoader_()) {
      throw new Error(
          'goog.declareModuleId may only be called from ' +
          'within an ES6 module');
    }
    if (goog.moduleLoaderState_ && goog.moduleLoaderState_.moduleName) {
      throw new Error(
          'goog.declareModuleId may only be called once per module.');
    }
    if (namespace in goog.loadedModules_) {
      throw new Error(
          'Module with namespace "' + namespace + '" already exists.');
    }
  }
  if (goog.moduleLoaderState_) {
    // Not bundled - debug loading.
    goog.moduleLoaderState_.moduleName = namespace;
  } else {
    // Bundled - not debug loading, no module loader state.
    var jscomp = goog.global['$jscomp'];
    if (!jscomp || typeof jscomp.getCurrentModulePath != 'function') {
      throw new Error(
          'Module with namespace "' + namespace +
          '" has been loaded incorrectly.');
    }
    var exports = jscomp.require(jscomp.getCurrentModulePath());
    goog.loadedModules_[namespace] = {
      exports: exports,
      type: goog.ModuleType.ES6,
      moduleId: namespace
    };
  }
};


/**
 * Marks that the current file should only be used for testing, and never for
 * live code in production.
 *
 * In the case of unit tests, the message may optionally be an exact namespace
 * for the test (e.g. 'goog.stringTest'). The linter will then ignore the extra
 * provide (if not explicitly defined in the code).
 *
 * @param {string=} opt_message Optional message to add to the error that's
 *     raised when used in production code.
 */
goog.setTestOnly = function(opt_message) {
  if (goog.DISALLOW_TEST_ONLY_CODE) {
    opt_message = opt_message || '';
    throw new Error(
        'Importing test-only code into non-debug environment' +
        (opt_message ? ': ' + opt_message : '.'));
  }
};


/**
 * Forward declares a symbol. This is an indication to the compiler that the
 * symbol may be used in the source yet is not required and may not be provided
 * in compilation.
 *
 * The most common usage of forward declaration is code that takes a type as a
 * function parameter but does not need to require it. By forward declaring
 * instead of requiring, no hard dependency is made, and (if not required
 * elsewhere) the namespace may never be required and thus, not be pulled
 * into the JavaScript binary. If it is required elsewhere, it will be type
 * checked as normal.
 *
 * Before using goog.forwardDeclare, please read the documentation at
 * https://github.com/google/closure-compiler/wiki/Bad-Type-Annotation to
 * understand the options and tradeoffs when working with forward declarations.
 *
 * @param {string} name The namespace to forward declare in the form of
 *     "goog.package.part".
 * @deprecated See go/noforwarddeclaration, Use `goog.requireType` instead.
 */
goog.forwardDeclare = function(name) {};


/**
 * Forward declare type information. Used to assign types to goog.global
 * referenced object that would otherwise result in unknown type references
 * and thus block property disambiguation.
 */
goog.forwardDeclare('Document');
goog.forwardDeclare('HTMLScriptElement');
goog.forwardDeclare('XMLHttpRequest');


if (!COMPILED) {
  /**
   * Check if the given name has been goog.provided. This will return false for
   * names that are available only as implicit namespaces.
   * @param {string} name name of the object to look for.
   * @return {boolean} Whether the name has been provided.
   * @private
   */
  goog.isProvided_ = function(name) {
    return (name in goog.loadedModules_) ||
        (!goog.implicitNamespaces_[name] && goog.getObjectByName(name) != null);
  };

  /**
   * Namespaces implicitly defined by goog.provide. For example,
   * goog.provide('goog.events.Event') implicitly declares that 'goog' and
   * 'goog.events' must be namespaces.
   *
   * @type {!Object<string, (boolean|undefined)>}
   * @private
   */
  goog.implicitNamespaces_ = {'goog.module': true};

  // NOTE: We add goog.module as an implicit namespace as goog.module is defined
  // here and because the existing module package has not been moved yet out of
  // the goog.module namespace. This satisifies both the debug loader and
  // ahead-of-time dependency management.
}


/**
 * Returns an object based on its fully qualified external name.  The object
 * is not found if null or undefined.  If you are using a compilation pass that
 * renames property names beware that using this function will not find renamed
 * properties.
 *
 * @param {string} name The fully qualified name.
 * @param {Object=} opt_obj The object within which to look; default is
 *     |goog.global|.
 * @return {?} The value (object or primitive) or, if not found, null.
 */
goog.getObjectByName = function(name, opt_obj) {
  var parts = name.split('.');
  var cur = opt_obj || goog.global;
  for (var i = 0; i < parts.length; i++) {
    cur = cur[parts[i]];
    if (cur == null) {
      return null;
    }
  }
  return cur;
};


/**
 * Adds a dependency from a file to the files it requires.
 * @param {string} relPath The path to the js file.
 * @param {!Array<string>} provides An array of strings with
 *     the names of the objects this file provides.
 * @param {!Array<string>} requires An array of strings with
 *     the names of the objects this file requires.
 * @param {boolean|!Object<string>=} opt_loadFlags Parameters indicating
 *     how the file must be loaded.  The boolean 'true' is equivalent
 *     to {'module': 'goog'} for backwards-compatibility.  Valid properties
 *     and values include {'module': 'goog'} and {'lang': 'es6'}.
 */
goog.addDependency = function(relPath, provides, requires, opt_loadFlags) {
  if (!COMPILED && goog.DEPENDENCIES_ENABLED) {
    goog.debugLoader_.addDependency(relPath, provides, requires, opt_loadFlags);
  }
};


// NOTE(nnaze): The debug DOM loader was included in base.js as an original way
// to do "debug-mode" development.  The dependency system can sometimes be
// confusing, as can the debug DOM loader's asynchronous nature.
//
// With the DOM loader, a call to goog.require() is not blocking -- the script
// will not load until some point after the current script.  If a namespace is
// needed at runtime, it needs to be defined in a previous script, or loaded via
// require() with its registered dependencies.
//
// User-defined namespaces may need their own deps file. For a reference on
// creating a deps file, see:
// MOE:begin_strip
// Internally: http://go/deps-files and http://go/be#js_deps
// MOE:end_strip
// Externally: https://developers.google.com/closure/library/docs/depswriter
//
// Because of legacy clients, the DOM loader can't be easily removed from
// base.js.  Work was done to make it disableable or replaceable for
// different environments (DOM-less JavaScript interpreters like Rhino or V8,
// for example). See bootstrap/ for more information.


/**
 * @define {boolean} Whether to enable the debug loader.
 *
 * If enabled, a call to goog.require() will attempt to load the namespace by
 * appending a script tag to the DOM (if the namespace has been registered).
 *
 * If disabled, goog.require() will simply assert that the namespace has been
 * provided (and depend on the fact that some outside tool correctly ordered
 * the script).
 */
goog.ENABLE_DEBUG_LOADER = goog.define('goog.ENABLE_DEBUG_LOADER', true);


/**
 * @param {string} msg
 * @private
 */
goog.logToConsole_ = function(msg) {
  if (goog.global.console) {
    goog.global.console['error'](msg);
  }
};


/**
 * Implements a system for the dynamic resolution of dependencies that works in
 * parallel with the BUILD system.
 *
 * Note that all calls to goog.require will be stripped by the compiler.
 *
 * @see goog.provide
 * @param {string} namespace Namespace (as was given in goog.provide,
 *     goog.module, or goog.declareModuleId) in the form
 *     "goog.package.part".
 * @return {?} If called within a goog.module or ES6 module file, the associated
 *     namespace or module otherwise null.
 */
goog.require = function(namespace) {
  if (!COMPILED) {
    // Might need to lazy load on old IE.
    if (goog.ENABLE_DEBUG_LOADER) {
      goog.debugLoader_.requested(namespace);
    }

    // If the object already exists we do not need to do anything.
    if (goog.isProvided_(namespace)) {
      if (goog.isInModuleLoader_()) {
        return goog.module.getInternal_(namespace);
      }
    } else if (goog.ENABLE_DEBUG_LOADER) {
      var moduleLoaderState = goog.moduleLoaderState_;
      goog.moduleLoaderState_ = null;
      try {
        goog.debugLoader_.load_(namespace);
      } finally {
        goog.moduleLoaderState_ = moduleLoaderState;
      }
    }

    return null;
  }
};


/**
 * Requires a symbol for its type information. This is an indication to the
 * compiler that the symbol may appear in type annotations, yet it is not
 * referenced at runtime.
 *
 * When called within a goog.module or ES6 module file, the return value may be
 * assigned to or destructured into a variable, but it may not be otherwise used
 * in code outside of a type annotation.
 *
 * Note that all calls to goog.requireType will be stripped by the compiler.
 *
 * @param {string} namespace Namespace (as was given in goog.provide,
 *     goog.module, or goog.declareModuleId) in the form
 *     "goog.package.part".
 * @return {?}
 */
goog.requireType = function(namespace) {
  // Return an empty object so that single-level destructuring of the return
  // value doesn't crash at runtime when using the debug loader. Multi-level
  // destructuring isn't supported.
  return {};
};


/**
 * Path for included scripts.
 * @type {string}
 */
goog.basePath = '';


/**
 * A hook for overriding the base path.
 * @type {string|undefined}
 */
goog.global.CLOSURE_BASE_PATH;


/**
 * Whether to attempt to load Closure's deps file. By default, when uncompiled,
 * deps files will attempt to be loaded.
 * @type {boolean|undefined}
 */
goog.global.CLOSURE_NO_DEPS;


/**
 * A function to import a single script. This is meant to be overridden when
 * Closure is being run in non-HTML contexts, such as web workers. It's defined
 * in the global scope so that it can be set before base.js is loaded, which
 * allows deps.js to be imported properly.
 *
 * The first parameter the script source, which is a relative URI. The second,
 * optional parameter is the script contents, in the event the script needed
 * transformation. It should return true if the script was imported, false
 * otherwise.
 * @type {(function(string, string=): boolean)|undefined}
 */
goog.global.CLOSURE_IMPORT_SCRIPT;


/**
 * When defining a class Foo with an abstract method bar(), you can do:
 * Foo.prototype.bar = goog.abstractMethod
 *
 * Now if a subclass of Foo fails to override bar(), an error will be thrown
 * when bar() is invoked.
 *
 * @type {!Function}
 * @throws {Error} when invoked to indicate the method should be overridden.
 * @deprecated Use "@abstract" annotation instead of goog.abstractMethod in new
 *     code. See
 *     https://github.com/google/closure-compiler/wiki/@abstract-classes-and-methods
 */
goog.abstractMethod = function() {
  throw new Error('unimplemented abstract method');
};


/**
 * Adds a `getInstance` static method that always returns the same
 * instance object.
 * @param {!Function} ctor The constructor for the class to add the static
 *     method to.
 * @suppress {missingProperties} 'instance_' isn't a property on 'Function'
 *     but we don't have a better type to use here.
 */
goog.addSingletonGetter = function(ctor) {
  // instance_ is immediately set to prevent issues with sealed constructors
  // such as are encountered when a constructor is returned as the export object
  // of a goog.module in unoptimized code.
  // Delcare type to avoid conformance violations that ctor.instance_ is unknown
  /** @type {undefined|!Object} @suppress {underscore} */
  ctor.instance_ = undefined;
  ctor.getInstance = function() {
    if (ctor.instance_) {
      return ctor.instance_;
    }
    if (goog.DEBUG) {
      // NOTE: JSCompiler can't optimize away Array#push.
      goog.instantiatedSingletons_[goog.instantiatedSingletons_.length] = ctor;
    }
    // Cast to avoid conformance violations that ctor.instance_ is unknown
    return /** @type {!Object|undefined} */ (ctor.instance_) = new ctor;
  };
};


/**
 * All singleton classes that have been instantiated, for testing. Don't read
 * it directly, use the `goog.testing.singleton` module. The compiler
 * removes this variable if unused.
 * @type {!Array<!Function>}
 * @private
 */
goog.instantiatedSingletons_ = [];


/**
 * @define {boolean} Whether to load goog.modules using `eval` when using
 * the debug loader.  This provides a better debugging experience as the
 * source is unmodified and can be edited using Chrome Workspaces or similar.
 * However in some environments the use of `eval` is banned
 * so we provide an alternative.
 */
goog.LOAD_MODULE_USING_EVAL = goog.define('goog.LOAD_MODULE_USING_EVAL', true);


/**
 * @define {boolean} Whether the exports of goog.modules should be sealed when
 * possible.
 */
goog.SEAL_MODULE_EXPORTS = goog.define('goog.SEAL_MODULE_EXPORTS', goog.DEBUG);


/**
 * The registry of initialized modules:
 * The module identifier or path to module exports map.
 * @private @const {!Object<string, {exports:?,type:string,moduleId:string}>}
 */
goog.loadedModules_ = {};


/**
 * True if the debug loader enabled and used.
 * @const {boolean}
 */
goog.DEPENDENCIES_ENABLED = !COMPILED && goog.ENABLE_DEBUG_LOADER;


/**
 * @define {string} How to decide whether to transpile.  Valid values
 * are 'always', 'never', and 'detect'.  The default ('detect') is to
 * use feature detection to determine which language levels need
 * transpilation.
 */
// NOTE(sdh): we could expand this to accept a language level to bypass
// detection: e.g. goog.TRANSPILE == 'es5' would transpile ES6 files but
// would leave ES3 and ES5 files alone.
goog.TRANSPILE = goog.define('goog.TRANSPILE', 'detect');

/**
 * @define {boolean} If true assume that ES modules have already been
 * transpiled by the jscompiler (in the same way that transpile.js would
 * transpile them - to jscomp modules). Useful only for servers that wish to use
 * the debug loader and transpile server side. Thus this is only respected if
 * goog.TRANSPILE is "never".
 */
goog.ASSUME_ES_MODULES_TRANSPILED =
    goog.define('goog.ASSUME_ES_MODULES_TRANSPILED', false);


/**
 * @define {string} If a file needs to be transpiled what the output language
 * should be. By default this is the highest language level this file detects
 * the current environment supports. Generally this flag should not be set, but
 * it could be useful to override. Example: If the current environment supports
 * ES6 then by default ES7+ files will be transpiled to ES6, unless this is
 * overridden.
 *
 * Valid values include: es3, es5, es6, es7, and es8. Anything not recognized
 * is treated as es3.
 *
 * Note that setting this value does not force transpilation. Just if
 * transpilation occurs this will be the output. So this is most useful when
 * goog.TRANSPILE is set to 'always' and then forcing the language level to be
 * something lower than what the environment detects.
 */
goog.TRANSPILE_TO_LANGUAGE = goog.define('goog.TRANSPILE_TO_LANGUAGE', '');


/**
 * @define {string} Path to the transpiler.  Executing the script at this
 * path (relative to base.js) should define a function $jscomp.transpile.
 */
goog.TRANSPILER = goog.define('goog.TRANSPILER', 'transpile.js');


/**
 * @define {string} Trusted Types policy name. If non-empty then Closure will
 * use Trusted Types.
 */
goog.TRUSTED_TYPES_POLICY_NAME =
    goog.define('goog.TRUSTED_TYPES_POLICY_NAME', 'goog');


/**
 * @package {?boolean}
 * Visible for testing.
 */
goog.hasBadLetScoping = null;


/**
 * @param {function(?):?|string} moduleDef The module definition.
 */
goog.loadModule = function(moduleDef) {
  // NOTE: we allow function definitions to be either in the from
  // of a string to eval (which keeps the original source intact) or
  // in a eval forbidden environment (CSP) we allow a function definition
  // which in its body must call `goog.module`, and return the exports
  // of the module.
  var previousState = goog.moduleLoaderState_;
  try {
    goog.moduleLoaderState_ = {
      moduleName: '',
      declareLegacyNamespace: false,
      type: goog.ModuleType.GOOG
    };
    var origExports = {};
    var exports = origExports;
    if (typeof moduleDef === 'function') {
      exports = moduleDef.call(undefined, exports);
    } else if (typeof moduleDef === 'string') {
      exports = goog.loadModuleFromSource_.call(undefined, exports, moduleDef);
    } else {
      throw new Error('Invalid module definition');
    }

    var moduleName = goog.moduleLoaderState_.moduleName;
    if (typeof moduleName === 'string' && moduleName) {
      // Don't seal legacy namespaces as they may be used as a parent of
      // another namespace
      if (goog.moduleLoaderState_.declareLegacyNamespace) {
        // Whether exports was overwritten via default export assignment.
        // This is important for legacy namespaces as it dictates whether
        // previously a previously loaded implicit namespace should be clobbered
        // or not.
        var isDefaultExport = origExports !== exports;
        goog.constructNamespace_(moduleName, exports, isDefaultExport);
      } else if (
          goog.SEAL_MODULE_EXPORTS && Object.seal &&
          typeof exports == 'object' && exports != null) {
        Object.seal(exports);
      }

      var data = {
        exports: exports,
        type: goog.ModuleType.GOOG,
        moduleId: goog.moduleLoaderState_.moduleName
      };
      goog.loadedModules_[moduleName] = data;
    } else {
      throw new Error('Invalid module name \"' + moduleName + '\"');
    }
  } finally {
    goog.moduleLoaderState_ = previousState;
  }
};


/**
 * @private @const
 */
goog.loadModuleFromSource_ =
    /** @type {function(!Object, string):?} */ (function(exports) {
      // NOTE: we avoid declaring parameters or local variables here to avoid
      // masking globals or leaking values into the module definition.
      'use strict';
      eval(goog.CLOSURE_EVAL_PREFILTER_.createScript(arguments[1]));
      return exports;
    });


/**
 * Normalize a file path by removing redundant ".." and extraneous "." file
 * path components.
 * @param {string} path
 * @return {string}
 * @private
 */
goog.normalizePath_ = function(path) {
  var components = path.split('/');
  var i = 0;
  while (i < components.length) {
    if (components[i] == '.') {
      components.splice(i, 1);
    } else if (
        i && components[i] == '..' && components[i - 1] &&
        components[i - 1] != '..') {
      components.splice(--i, 2);
    } else {
      i++;
    }
  }
  return components.join('/');
};


/**
 * Provides a hook for loading a file when using Closure's goog.require() API
 * with goog.modules.  In particular this hook is provided to support Node.js.
 *
 * @type {(function(string):string)|undefined}
 */
goog.global.CLOSURE_LOAD_FILE_SYNC;


/**
 * Loads file by synchronous XHR. Should not be used in production environments.
 * @param {string} src Source URL.
 * @return {?string} File contents, or null if load failed.
 * @private
 */
goog.loadFileSync_ = function(src) {
  if (goog.global.CLOSURE_LOAD_FILE_SYNC) {
    return goog.global.CLOSURE_LOAD_FILE_SYNC(src);
  } else {
    try {
      /** @type {XMLHttpRequest} */
      var xhr = new goog.global['XMLHttpRequest']();
      xhr.open('get', src, false);
      xhr.send();
      // NOTE: Successful http: requests have a status of 200, but successful
      // file: requests may have a status of zero.  Any other status, or a
      // thrown exception (particularly in case of file: requests) indicates
      // some sort of error, which we treat as a missing or unavailable file.
      return xhr.status == 0 || xhr.status == 200 ? xhr.responseText : null;
    } catch (err) {
      // No need to rethrow or log, since errors should show up on their own.
      return null;
    }
  }
};


/**
 * Lazily retrieves the transpiler and applies it to the source.
 * @param {string} code JS code.
 * @param {string} path Path to the code.
 * @param {string} target Language level output.
 * @return {string} The transpiled code.
 * @private
 */
goog.transpile_ = function(code, path, target) {
  var jscomp = goog.global['$jscomp'];
  if (!jscomp) {
    goog.global['$jscomp'] = jscomp = {};
  }
  var transpile = jscomp.transpile;
  if (!transpile) {
    var transpilerPath = goog.basePath + goog.TRANSPILER;
    var transpilerCode = goog.loadFileSync_(transpilerPath);
    if (transpilerCode) {
      // This must be executed synchronously, since by the time we know we
      // need it, we're about to load and write the ES6 code synchronously,
      // so a normal script-tag load will be too slow. Wrapped in a function
      // so that code is eval'd in the global scope.
      (function() {
        (0, eval)(transpilerCode + '\n//# sourceURL=' + transpilerPath);
      }).call(goog.global);
      // Even though the transpiler is optional, if $gwtExport is found, it's
      // a sign the transpiler was loaded and the $jscomp.transpile *should*
      // be there.
      if (goog.global['$gwtExport'] && goog.global['$gwtExport']['$jscomp'] &&
          !goog.global['$gwtExport']['$jscomp']['transpile']) {
        throw new Error(
            'The transpiler did not properly export the "transpile" ' +
            'method. $gwtExport: ' + JSON.stringify(goog.global['$gwtExport']));
      }
      // transpile.js only exports a single $jscomp function, transpile. We
      // grab just that and add it to the existing definition of $jscomp which
      // contains the polyfills.
      goog.global['$jscomp'].transpile =
          goog.global['$gwtExport']['$jscomp']['transpile'];
      jscomp = goog.global['$jscomp'];
      transpile = jscomp.transpile;
    }
  }
  if (!transpile) {
    // The transpiler is an optional component.  If it's not available then
    // replace it with a pass-through function that simply logs.
    var suffix = ' requires transpilation but no transpiler was found.';
    // MOE:begin_strip
    suffix +=  // Provide a more appropriate message internally.
        ' Please add "//javascript/closure:transpiler" as a data ' +
        'dependency to ensure it is included.';
    // MOE:end_strip
    transpile = jscomp.transpile = function(code, path) {
      // TODO(sdh): figure out some way to get this error to show up
      // in test results, noting that the failure may occur in many
      // different ways, including in loadModule() before the test
      // runner even comes up.
      goog.logToConsole_(path + suffix);
      return code;
    };
  }
  // Note: any transpilation errors/warnings will be logged to the console.
  return transpile(code, path, target);
};

//==============================================================================
// Language Enhancements
//==============================================================================


/**
 * This is a "fixed" version of the typeof operator.  It differs from the typeof
 * operator in such a way that null returns 'null' and arrays return 'array'.
 * @param {?} value The value to get the type of.
 * @return {string} The name of the type.
 */
goog.typeOf = function(value) {
  var s = typeof value;

  if (s != 'object') {
    return s;
  }

  if (!value) {
    return 'null';
  }

  if (Array.isArray(value)) {
    return 'array';
  }
  return s;
};


/**
 * Returns true if the object looks like an array. To qualify as array like
 * the value needs to be either a NodeList or an object with a Number length
 * property. Note that for this function neither strings nor functions are
 * considered "array-like".
 *
 * @param {?} val Variable to test.
 * @return {boolean} Whether variable is an array.
 */
goog.isArrayLike = function(val) {
  var type = goog.typeOf(val);
  // We do not use goog.isObject here in order to exclude function values.
  return type == 'array' || type == 'object' && typeof val.length == 'number';
};


/**
 * Returns true if the object looks like a Date. To qualify as Date-like the
 * value needs to be an object and have a getFullYear() function.
 * @param {?} val Variable to test.
 * @return {boolean} Whether variable is a like a Date.
 */
goog.isDateLike = function(val) {
  return goog.isObject(val) && typeof val.getFullYear == 'function';
};


/**
 * Returns true if the specified value is an object.  This includes arrays and
 * functions.
 * @param {?} val Variable to test.
 * @return {boolean} Whether variable is an object.
 */
goog.isObject = function(val) {
  var type = typeof val;
  return type == 'object' && val != null || type == 'function';
  // return Object(val) === val also works, but is slower, especially if val is
  // not an object.
};


/**
 * Gets a unique ID for an object. This mutates the object so that further calls
 * with the same object as a parameter returns the same value. The unique ID is
 * guaranteed to be unique across the current session amongst objects that are
 * passed into `getUid`. There is no guarantee that the ID is unique or
 * consistent across sessions. It is unsafe to generate unique ID for function
 * prototypes.
 *
 * @param {Object} obj The object to get the unique ID for.
 * @return {number} The unique ID for the object.
 */
goog.getUid = function(obj) {
  // TODO(arv): Make the type stricter, do not accept null.
  return Object.prototype.hasOwnProperty.call(obj, goog.UID_PROPERTY_) &&
      obj[goog.UID_PROPERTY_] ||
      (obj[goog.UID_PROPERTY_] = ++goog.uidCounter_);
};


/**
 * Whether the given object is already assigned a unique ID.
 *
 * This does not modify the object.
 *
 * @param {!Object} obj The object to check.
 * @return {boolean} Whether there is an assigned unique id for the object.
 */
goog.hasUid = function(obj) {
  return !!obj[goog.UID_PROPERTY_];
};


/**
 * Removes the unique ID from an object. This is useful if the object was
 * previously mutated using `goog.getUid` in which case the mutation is
 * undone.
 * @param {Object} obj The object to remove the unique ID field from.
 */
goog.removeUid = function(obj) {
  // TODO(arv): Make the type stricter, do not accept null.

  // In IE, DOM nodes are not instances of Object and throw an exception if we
  // try to delete.  Instead we try to use removeAttribute.
  if (obj !== null && 'removeAttribute' in obj) {
    obj.removeAttribute(goog.UID_PROPERTY_);
  }

  try {
    delete obj[goog.UID_PROPERTY_];
  } catch (ex) {
  }
};


/**
 * Name for unique ID property. Initialized in a way to help avoid collisions
 * with other closure JavaScript on the same page.
 * @type {string}
 * @private
 */
goog.UID_PROPERTY_ = 'closure_uid_' + ((Math.random() * 1e9) >>> 0);


/**
 * Counter for UID.
 * @type {number}
 * @private
 */
goog.uidCounter_ = 0;


/**
 * Clones a value. The input may be an Object, Array, or basic type. Objects and
 * arrays will be cloned recursively.
 *
 * WARNINGS:
 * <code>goog.cloneObject</code> does not detect reference loops. Objects that
 * refer to themselves will cause infinite recursion.
 *
 * <code>goog.cloneObject</code> is unaware of unique identifiers, and copies
 * UIDs created by <code>getUid</code> into cloned results.
 *
 * @param {*} obj The value to clone.
 * @return {*} A clone of the input value.
 * @deprecated goog.cloneObject is unsafe. Prefer the goog.object methods.
 */
goog.cloneObject = function(obj) {
  var type = goog.typeOf(obj);
  if (type == 'object' || type == 'array') {
    if (typeof obj.clone === 'function') {
      return obj.clone();
    }
    if (typeof Map !== 'undefined' && obj instanceof Map) {
      return new Map(obj);
    } else if (typeof Set !== 'undefined' && obj instanceof Set) {
      return new Set(obj);
    }
    var clone = type == 'array' ? [] : {};
    for (var key in obj) {
      clone[key] = goog.cloneObject(obj[key]);
    }
    return clone;
  }

  return obj;
};


/**
 * A native implementation of goog.bind.
 * @param {?function(this:T, ...)} fn A function to partially apply.
 * @param {T} selfObj Specifies the object which this should point to when the
 *     function is run.
 * @param {...*} var_args Additional arguments that are partially applied to the
 *     function.
 * @return {!Function} A partially-applied form of the function goog.bind() was
 *     invoked as a method of.
 * @template T
 * @private
 */
goog.bindNative_ = function(fn, selfObj, var_args) {
  return /** @type {!Function} */ (fn.call.apply(fn.bind, arguments));
};


/**
 * A pure-JS implementation of goog.bind.
 * @param {?function(this:T, ...)} fn A function to partially apply.
 * @param {T} selfObj Specifies the object which this should point to when the
 *     function is run.
 * @param {...*} var_args Additional arguments that are partially applied to the
 *     function.
 * @return {!Function} A partially-applied form of the function goog.bind() was
 *     invoked as a method of.
 * @template T
 * @private
 */
goog.bindJs_ = function(fn, selfObj, var_args) {
  if (!fn) {
    throw new Error();
  }

  if (arguments.length > 2) {
    var boundArgs = Array.prototype.slice.call(arguments, 2);
    return function() {
      // Prepend the bound arguments to the current arguments.
      var newArgs = Array.prototype.slice.call(arguments);
      Array.prototype.unshift.apply(newArgs, boundArgs);
      return fn.apply(selfObj, newArgs);
    };

  } else {
    return function() {
      return fn.apply(selfObj, arguments);
    };
  }
};


/**
 * Partially applies this function to a particular 'this object' and zero or
 * more arguments. The result is a new function with some arguments of the first
 * function pre-filled and the value of this 'pre-specified'.
 *
 * Remaining arguments specified at call-time are appended to the pre-specified
 * ones.
 *
 * Also see: {@link #partial}.
 *
 * Usage:
 * <pre>var barMethBound = goog.bind(myFunction, myObj, 'arg1', 'arg2');
 * barMethBound('arg3', 'arg4');</pre>
 *
 * @param {?function(this:T, ...)} fn A function to partially apply.
 * @param {T} selfObj Specifies the object which this should point to when the
 *     function is run.
 * @param {...*} var_args Additional arguments that are partially applied to the
 *     function.
 * @return {!Function} A partially-applied form of the function goog.bind() was
 *     invoked as a method of.
 * @template T
 * @suppress {deprecated} See above.
 * @deprecated use `=> {}` or Function.prototype.bind instead.
 */
goog.bind = function(fn, selfObj, var_args) {
  // TODO(nicksantos): narrow the type signature.
  if (Function.prototype.bind &&
      // NOTE(nicksantos): Somebody pulled base.js into the default Chrome
      // extension environment. This means that for Chrome extensions, they get
      // the implementation of Function.prototype.bind that calls goog.bind
      // instead of the native one. Even worse, we don't want to introduce a
      // circular dependency between goog.bind and Function.prototype.bind, so
      // we have to hack this to make sure it works correctly.
      Function.prototype.bind.toString().indexOf('native code') != -1) {
    goog.bind = goog.bindNative_;
  } else {
    goog.bind = goog.bindJs_;
  }
  return goog.bind.apply(null, arguments);
};


/**
 * Like goog.bind(), except that a 'this object' is not required. Useful when
 * the target function is already bound.
 *
 * Usage:
 * var g = goog.partial(f, arg1, arg2);
 * g(arg3, arg4);
 *
 * @param {Function} fn A function to partially apply.
 * @param {...*} var_args Additional arguments that are partially applied to fn.
 * @return {!Function} A partially-applied form of the function goog.partial()
 *     was invoked as a method of.
 */
goog.partial = function(fn, var_args) {
  var args = Array.prototype.slice.call(arguments, 1);
  return function() {
    // Clone the array (with slice()) and append additional arguments
    // to the existing arguments.
    var newArgs = args.slice();
    newArgs.push.apply(newArgs, arguments);
    return fn.apply(/** @type {?} */ (this), newArgs);
  };
};


/**
 * @return {number} An integer value representing the number of milliseconds
 *     between midnight, January 1, 1970 and the current time.
 * @deprecated Use Date.now
 */
goog.now = function() {
  return Date.now();
};


/**
 * Evals JavaScript in the global scope.
 *
 * Throws an exception if neither execScript or eval is defined.
 * @param {string|!TrustedScript} script JavaScript string.
 */
goog.globalEval = function(script) {
  (0, eval)(script);
};


/**
 * Optional map of CSS class names to obfuscated names used with
 * goog.getCssName().
 * @private {!Object<string, string>|undefined}
 * @see goog.setCssNameMapping
 */
goog.cssNameMapping_;


/**
 * Optional obfuscation style for CSS class names. Should be set to either
 * 'BY_WHOLE' or 'BY_PART' if defined.
 * @type {string|undefined}
 * @private
 * @see goog.setCssNameMapping
 */
goog.cssNameMappingStyle_;



/**
 * A hook for modifying the default behavior goog.getCssName. The function
 * if present, will receive the standard output of the goog.getCssName as
 * its input.
 *
 * @type {(function(string):string)|undefined}
 */
goog.global.CLOSURE_CSS_NAME_MAP_FN;


/**
 * Handles strings that are intended to be used as CSS class names.
 *
 * This function works in tandem with @see goog.setCssNameMapping.
 *
 * Without any mapping set, the arguments are simple joined with a hyphen and
 * passed through unaltered.
 *
 * When there is a mapping, there are two possible styles in which these
 * mappings are used. In the BY_PART style, each part (i.e. in between hyphens)
 * of the passed in css name is rewritten according to the map. In the BY_WHOLE
 * style, the full css name is looked up in the map directly. If a rewrite is
 * not specified by the map, the compiler will output a warning.
 *
 * When the mapping is passed to the compiler, it will replace calls to
 * goog.getCssName with the strings from the mapping, e.g.
 *     var x = goog.getCssName('foo');
 *     var y = goog.getCssName(this.baseClass, 'active');
 *  becomes:
 *     var x = 'foo';
 *     var y = this.baseClass + '-active';
 *
 * If one argument is passed it will be processed, if two are passed only the
 * modifier will be processed, as it is assumed the first argument was generated
 * as a result of calling goog.getCssName.
 *
 * @param {string} className The class name.
 * @param {string=} opt_modifier A modifier to be appended to the class name.
 * @return {string} The class name or the concatenation of the class name and
 *     the modifier.
 */
goog.getCssName = function(className, opt_modifier) {
  // String() is used for compatibility with compiled soy where the passed
  // className can be non-string objects.
  if (String(className).charAt(0) == '.') {
    throw new Error(
        'className passed in goog.getCssName must not start with ".".' +
        ' You passed: ' + className);
  }

  var getMapping = function(cssName) {
    return goog.cssNameMapping_[cssName] || cssName;
  };

  var renameByParts = function(cssName) {
    // Remap all the parts individually.
    var parts = cssName.split('-');
    var mapped = [];
    for (var i = 0; i < parts.length; i++) {
      mapped.push(getMapping(parts[i]));
    }
    return mapped.join('-');
  };

  var rename;
  if (goog.cssNameMapping_) {
    rename =
        goog.cssNameMappingStyle_ == 'BY_WHOLE' ? getMapping : renameByParts;
  } else {
    rename = function(a) {
      return a;
    };
  }

  var result =
      opt_modifier ? className + '-' + rename(opt_modifier) : rename(className);

  // The special CLOSURE_CSS_NAME_MAP_FN allows users to specify further
  // processing of the class name.
  if (goog.global.CLOSURE_CSS_NAME_MAP_FN) {
    return goog.global.CLOSURE_CSS_NAME_MAP_FN(result);
  }

  return result;
};


/**
 * Sets the map to check when returning a value from goog.getCssName(). Example:
 * <pre>
 * goog.setCssNameMapping({
 *   "goog": "a",
 *   "disabled": "b",
 * });
 *
 * var x = goog.getCssName('goog');
 * // The following evaluates to: "a a-b".
 * goog.getCssName('goog') + ' ' + goog.getCssName(x, 'disabled')
 * </pre>
 * When declared as a map of string literals to string literals, the JSCompiler
 * will replace all calls to goog.getCssName() using the supplied map if the
 * --process_closure_primitives flag is set.
 *
 * @param {!Object} mapping A map of strings to strings where keys are possible
 *     arguments to goog.getCssName() and values are the corresponding values
 *     that should be returned.
 * @param {string=} opt_style The style of css name mapping. There are two valid
 *     options: 'BY_PART', and 'BY_WHOLE'.
 * @see goog.getCssName for a description.
 */
goog.setCssNameMapping = function(mapping, opt_style) {
  goog.cssNameMapping_ = mapping;
  goog.cssNameMappingStyle_ = opt_style;
};


/**
 * To use CSS renaming in compiled mode, one of the input files should have a
 * call to goog.setCssNameMapping() with an object literal that the JSCompiler
 * can extract and use to replace all calls to goog.getCssName(). In uncompiled
 * mode, JavaScript code should be loaded before this base.js file that declares
 * a global variable, CLOSURE_CSS_NAME_MAPPING, which is used below. This is
 * to ensure that the mapping is loaded before any calls to goog.getCssName()
 * are made in uncompiled mode.
 *
 * A hook for overriding the CSS name mapping.
 * @type {!Object<string, string>|undefined}
 */
goog.global.CLOSURE_CSS_NAME_MAPPING;


if (!COMPILED && goog.global.CLOSURE_CSS_NAME_MAPPING) {
  // This does not call goog.setCssNameMapping() because the JSCompiler
  // requires that goog.setCssNameMapping() be called with an object literal.
  goog.cssNameMapping_ = goog.global.CLOSURE_CSS_NAME_MAPPING;
}

/**
 * Options bag type for `goog.getMsg()` third argument.
 *
 * It is important to note that these options need to be known at compile time,
 * so they must always be provided to `goog.getMsg()` as an actual object
 * literal in the function call. Otherwise, closure-compiler will report an
 * error.
 * @record
 */
goog.GetMsgOptions = function() {};

/**
 * If `true`, escape '<' in the message string to '&lt;'.
 *
 * Used by Closure Templates where the generated code size and performance is
 * critical which is why {@link goog.html.SafeHtmlFormatter} is not used.
 * The value must be literal `true` or `false`.
 * @type {boolean|undefined}
 */
goog.GetMsgOptions.prototype.html;

/**
 * If `true`, unescape common html entities: &gt;, &lt;, &apos;, &quot; and
 * &amp;.
 *
 * Used for messages not in HTML context, such as with the `textContent`
 * property.
 * The value must be literal `true` or `false`.
 * @type {boolean|undefined}
 */
goog.GetMsgOptions.prototype.unescapeHtmlEntities;

/**
 * Associates placeholder names with strings showing how their values are
 * obtained.
 *
 * This field is intended for use in automatically generated JS code.
 * Human-written code should use meaningful placeholder names instead.
 *
 * closure-compiler uses this as the contents of the `<ph>` tag in the
 * XMB file it generates or defaults to `-` for historical reasons.
 *
 * Must be an object literal.
 * Ignored at runtime.
 * Keys are placeholder names.
 * Values are string literals indicating how the value is obtained.
 * Typically this is a snippet of source code.
 * @type {!Object<string, string>|undefined}
 */
goog.GetMsgOptions.prototype.original_code;

/**
 * Associates placeholder names with example values.
 *
 * closure-compiler uses this as the contents of the `<ex>` tag in the
 * XMB file it generates or defaults to `-` for historical reasons.
 *
 * Must be an object literal.
 * Ignored at runtime.
 * Keys are placeholder names.
 * Values are string literals containing example placeholder values.
 * (e.g. "George McFly" for a name placeholder)
 * @type {!Object<string, string>|undefined}
 */
goog.GetMsgOptions.prototype.example;

/**
 * Gets a localized message.
 *
 * This function is a compiler primitive. If you give the compiler a localized
 * message bundle, it will replace the string at compile-time with a localized
 * version, and expand goog.getMsg call to a concatenated string.
 *
 * Messages must be initialized in the form:
 * <code>
 * var MSG_NAME = goog.getMsg('Hello {$placeholder}', {'placeholder': 'world'});
 * </code>
 *
 * This function produces a string which should be treated as plain text. Use
 * {@link goog.html.SafeHtmlFormatter} in conjunction with goog.getMsg to
 * produce SafeHtml.
 *
 * @param {string} str Translatable string, places holders in the form {$foo}.
 * @param {!Object<string, string>=} opt_values Maps place holder name to value.
 * @param {!goog.GetMsgOptions=} opt_options see `goog.GetMsgOptions`
 * @return {string} message with placeholders filled.
 */
goog.getMsg = function(str, opt_values, opt_options) {
  if (opt_options && opt_options.html) {
    // Note that '&' is not replaced because the translation can contain HTML
    // entities.
    str = str.replace(/</g, '&lt;');
  }
  if (opt_options && opt_options.unescapeHtmlEntities) {
    // Note that "&amp;" must be the last to avoid "creating" new entities.
    str = str.replace(/&lt;/g, '<')
              .replace(/&gt;/g, '>')
              .replace(/&apos;/g, '\'')
              .replace(/&quot;/g, '"')
              .replace(/&amp;/g, '&');
  }
  if (opt_values) {
    str = str.replace(/\{\$([^}]+)}/g, function(match, key) {
      return (opt_values != null && key in opt_values) ? opt_values[key] :
                                                         match;
    });
  }
  return str;
};


/**
 * Gets a localized message. If the message does not have a translation, gives a
 * fallback message.
 *
 * This is useful when introducing a new message that has not yet been
 * translated into all languages.
 *
 * This function is a compiler primitive. Must be used in the form:
 * <code>var x = goog.getMsgWithFallback(MSG_A, MSG_B);</code>
 * where MSG_A and MSG_B were initialized with goog.getMsg.
 *
 * @param {string} a The preferred message.
 * @param {string} b The fallback message.
 * @return {string} The best translated message.
 */
goog.getMsgWithFallback = function(a, b) {
  return a;
};


/**
 * Exposes an unobfuscated global namespace path for the given object.
 * Note that fields of the exported object *will* be obfuscated, unless they are
 * exported in turn via this function or goog.exportProperty.
 *
 * Also handy for making public items that are defined in anonymous closures.
 *
 * ex. goog.exportSymbol('public.path.Foo', Foo);
 *
 * ex. goog.exportSymbol('public.path.Foo.staticFunction', Foo.staticFunction);
 *     public.path.Foo.staticFunction();
 *
 * ex. goog.exportSymbol('public.path.Foo.prototype.myMethod',
 *                       Foo.prototype.myMethod);
 *     new public.path.Foo().myMethod();
 *
 * @param {string} publicPath Unobfuscated name to export.
 * @param {*} object Object the name should point to.
 * @param {?Object=} objectToExportTo The object to add the path to; default
 *     is goog.global.
 */
goog.exportSymbol = function(publicPath, object, objectToExportTo) {
  goog.exportPath_(
      publicPath, object, /* overwriteImplicit= */ true, objectToExportTo);
};


/**
 * Exports a property unobfuscated into the object's namespace.
 * ex. goog.exportProperty(Foo, 'staticFunction', Foo.staticFunction);
 * ex. goog.exportProperty(Foo.prototype, 'myMethod', Foo.prototype.myMethod);
 * @param {Object} object Object whose static property is being exported.
 * @param {string} publicName Unobfuscated name to export.
 * @param {*} symbol Object the name should point to.
 */
goog.exportProperty = function(object, publicName, symbol) {
  object[publicName] = symbol;
};


/**
 * Inherit the prototype methods from one constructor into another.
 *
 * Usage:
 * <pre>
 * function ParentClass(a, b) { }
 * ParentClass.prototype.foo = function(a) { };
 *
 * function ChildClass(a, b, c) {
 *   ChildClass.base(this, 'constructor', a, b);
 * }
 * goog.inherits(ChildClass, ParentClass);
 *
 * var child = new ChildClass('a', 'b', 'see');
 * child.foo(); // This works.
 * </pre>
 *
 * @param {!Function} childCtor Child class.
 * @param {!Function} parentCtor Parent class.
 * @suppress {strictMissingProperties} superClass_ and base is not defined on
 *    Function.
 * @deprecated Use ECMAScript class syntax instead.
 */
goog.inherits = function(childCtor, parentCtor) {
  /** @constructor */
  function tempCtor() {}
  tempCtor.prototype = parentCtor.prototype;
  childCtor.superClass_ = parentCtor.prototype;
  childCtor.prototype = new tempCtor();
  /** @override */
  childCtor.prototype.constructor = childCtor;

  /**
   * Calls superclass constructor/method.
   *
   * This function is only available if you use goog.inherits to
   * express inheritance relationships between classes.
   *
   * NOTE: This is a replacement for goog.base and for superClass_
   * property defined in childCtor.
   *
   * @param {!Object} me Should always be "this".
   * @param {string} methodName The method name to call. Calling
   *     superclass constructor can be done with the special string
   *     'constructor'.
   * @param {...*} var_args The arguments to pass to superclass
   *     method/constructor.
   * @return {*} The return value of the superclass method/constructor.
   */
  childCtor.base = function(me, methodName, var_args) {
    // Copying using loop to avoid deop due to passing arguments object to
    // function. This is faster in many JS engines as of late 2014.
    var args = new Array(arguments.length - 2);
    for (var i = 2; i < arguments.length; i++) {
      args[i - 2] = arguments[i];
    }
    return parentCtor.prototype[methodName].apply(me, args);
  };
};


/**
 * Allow for aliasing within scope functions.  This function exists for
 * uncompiled code - in compiled code the calls will be inlined and the aliases
 * applied.  In uncompiled code the function is simply run since the aliases as
 * written are valid JavaScript.
 *
 * MOE:begin_intracomment_strip
 * See the goog.scope document at http://go/goog.scope
 *
 * For more on goog.scope deprecation, see the style guide entry:
 * http://go/jsstyle#appendices-legacy-exceptions-goog-scope
 * MOE:end_intracomment_strip
 *
 * @param {function()} fn Function to call.  This function can contain aliases
 *     to namespaces (e.g. "var dom = goog.dom") or classes
 *     (e.g. "var Timer = goog.Timer").
 * @deprecated Use goog.module instead.
 */
goog.scope = function(fn) {
  if (goog.isInModuleLoader_()) {
    throw new Error('goog.scope is not supported within a module.');
  }
  fn.call(goog.global);
};


/*
 * To support uncompiled, strict mode bundles that use eval to divide source
 * like so:
 *    eval('someSource;//# sourceUrl sourcefile.js');
 * We need to export the globally defined symbols "goog" and "COMPILED".
 * Exporting "goog" breaks the compiler optimizations, so we required that
 * be defined externally.
 * NOTE: We don't use goog.exportSymbol here because we don't want to trigger
 * extern generation when that compiler option is enabled.
 */
if (!COMPILED) {
  goog.global['COMPILED'] = COMPILED;
}


//==============================================================================
// goog.defineClass implementation
//==============================================================================


/**
 * Creates a restricted form of a Closure "class":
 *   - from the compiler's perspective, the instance returned from the
 *     constructor is sealed (no new properties may be added).  This enables
 *     better checks.
 *   - the compiler will rewrite this definition to a form that is optimal
 *     for type checking and optimization (initially this will be a more
 *     traditional form).
 *
 * @param {Function} superClass The superclass, Object or null.
 * @param {goog.defineClass.ClassDescriptor} def
 *     An object literal describing
 *     the class.  It may have the following properties:
 *     "constructor": the constructor function
 *     "statics": an object literal containing methods to add to the constructor
 *        as "static" methods or a function that will receive the constructor
 *        function as its only parameter to which static properties can
 *        be added.
 *     all other properties are added to the prototype.
 * @return {!Function} The class constructor.
 * @deprecated Use ECMAScript class syntax instead.
 */
goog.defineClass = function(superClass, def) {
  // TODO(johnlenz): consider making the superClass an optional parameter.
  var constructor = def.constructor;
  var statics = def.statics;
  // Wrap the constructor prior to setting up the prototype and static methods.
  if (!constructor || constructor == Object.prototype.constructor) {
    constructor = function() {
      throw new Error(
          'cannot instantiate an interface (no constructor defined).');
    };
  }

  var cls = goog.defineClass.createSealingConstructor_(constructor, superClass);
  if (superClass) {
    goog.inherits(cls, superClass);
  }

  // Remove all the properties that should not be copied to the prototype.
  delete def.constructor;
  delete def.statics;

  goog.defineClass.applyProperties_(cls.prototype, def);
  if (statics != null) {
    if (statics instanceof Function) {
      statics(cls);
    } else {
      goog.defineClass.applyProperties_(cls, statics);
    }
  }

  return cls;
};


/**
 * @typedef {{
 *   constructor: (!Function|undefined),
 *   statics: (Object|undefined|function(Function):void)
 * }}
 */
goog.defineClass.ClassDescriptor;


/**
 * @define {boolean} Whether the instances returned by goog.defineClass should
 *     be sealed when possible.
 *
 * When sealing is disabled the constructor function will not be wrapped by
 * goog.defineClass, making it incompatible with ES6 class methods.
 */
goog.defineClass.SEAL_CLASS_INSTANCES =
    goog.define('goog.defineClass.SEAL_CLASS_INSTANCES', goog.DEBUG);


/**
 * If goog.defineClass.SEAL_CLASS_INSTANCES is enabled and Object.seal is
 * defined, this function will wrap the constructor in a function that seals the
 * results of the provided constructor function.
 *
 * @param {!Function} ctr The constructor whose results maybe be sealed.
 * @param {Function} superClass The superclass constructor.
 * @return {!Function} The replacement constructor.
 * @private
 */
goog.defineClass.createSealingConstructor_ = function(ctr, superClass) {
  if (!goog.defineClass.SEAL_CLASS_INSTANCES) {
    // Do now wrap the constructor when sealing is disabled. Angular code
    // depends on this for injection to work properly.
    return ctr;
  }

  // NOTE: The sealing behavior has been removed

  /**
   * @this {Object}
   * @return {?}
   */
  var wrappedCtr = function() {
    // Don't seal an instance of a subclass when it calls the constructor of
    // its super class as there is most likely still setup to do.
    var instance = ctr.apply(this, arguments) || this;
    instance[goog.UID_PROPERTY_] = instance[goog.UID_PROPERTY_];

    return instance;
  };

  return wrappedCtr;
};



// TODO(johnlenz): share these values with the goog.object
/**
 * The names of the fields that are defined on Object.prototype.
 * @type {!Array<string>}
 * @private
 * @const
 */
goog.defineClass.OBJECT_PROTOTYPE_FIELDS_ = [
  'constructor', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable',
  'toLocaleString', 'toString', 'valueOf'
];


// TODO(johnlenz): share this function with the goog.object
/**
 * @param {!Object} target The object to add properties to.
 * @param {!Object} source The object to copy properties from.
 * @private
 */
goog.defineClass.applyProperties_ = function(target, source) {
  // TODO(johnlenz): update this to support ES5 getters/setters

  var key;
  for (key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      target[key] = source[key];
    }
  }

  // For IE the for-in-loop does not contain any properties that are not
  // enumerable on the prototype object (for example isPrototypeOf from
  // Object.prototype) and it will also not include 'replace' on objects that
  // extend String and change 'replace' (not that it is common for anyone to
  // extend anything except Object).
  for (var i = 0; i < goog.defineClass.OBJECT_PROTOTYPE_FIELDS_.length; i++) {
    key = goog.defineClass.OBJECT_PROTOTYPE_FIELDS_[i];
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      target[key] = source[key];
    }
  }
};

/**
 * Returns the parameter.
 * @param {string} s
 * @return {string}
 * @private
 */
goog.identity_ = function(s) {
  return s;
};


/**
 * Creates Trusted Types policy if Trusted Types are supported by the browser.
 * The policy just blesses any string as a Trusted Type. It is not visibility
 * restricted because anyone can also call trustedTypes.createPolicy directly.
 * However, the allowed names should be restricted by a HTTP header and the
 * reference to the created policy should be visibility restricted.
 * @param {string} name
 * @return {?TrustedTypePolicy}
 */
goog.createTrustedTypesPolicy = function(name) {
  var policy = null;
  var policyFactory = goog.global.trustedTypes;
  if (!policyFactory || !policyFactory.createPolicy) {
    return policy;
  }
  // trustedTypes.createPolicy throws if called with a name that is already
  // registered, even in report-only mode. Until the API changes, catch the
  // error not to break the applications functionally. In such case, the code
  // will fall back to using regular Safe Types.
  // TODO(koto): Remove catching once createPolicy API stops throwing.
  try {
    policy = policyFactory.createPolicy(name, {
      createHTML: goog.identity_,
      createScript: goog.identity_,
      createScriptURL: goog.identity_
    });
  } catch (e) {
    goog.logToConsole_(e.message);
  }
  return policy;
};

// There's a bug in the compiler where without collapse properties the
// Closure namespace defines do not guard code correctly. To help reduce code
// size also check for !COMPILED even though it redundant until this is fixed.
if (!COMPILED && goog.DEPENDENCIES_ENABLED) {
  // MOE:begin_strip
  // TODO(b/67050526) This object is obsolete but some people are relying on
  // it internally. Keep it around until we migrate them.
  /**
   * @private
   * @type {{
   *   loadFlags: !Object<string, !Object<string, string>>,
   *   nameToPath: !Object<string, string>,
   *   requires: !Object<string, !Object<string, boolean>>,
   *   visited: !Object<string, boolean>,
   *   written: !Object<string, boolean>,
   *   deferred: !Object<string, string>
   * }}
   */
  goog.dependencies_ = {
    loadFlags: {},  // 1 to 1

    nameToPath: {},  // 1 to 1

    requires: {},  // 1 to many

    // Used when resolving dependencies to prevent us from visiting file
    // twice.
    visited: {},

    written: {},  // Used to keep track of script files we have written.

    deferred: {}  // Used to track deferred module evaluations in old IEs
  };

  /**
   * @return {!Object}
   * @private
   */
  goog.getLoader_ = function() {
    return {
      dependencies_: goog.dependencies_,
      writeScriptTag_: goog.writeScriptTag_
    };
  };


  /**
   * @param {string} src The script url.
   * @param {string=} opt_sourceText The optionally source text to evaluate
   * @return {boolean} True if the script was imported, false otherwise.
   * @private
   */
  goog.writeScriptTag_ = function(src, opt_sourceText) {
    if (goog.inHtmlDocument_()) {
      /** @type {!HTMLDocument} */
      var doc = goog.global.document;

      // If the user tries to require a new symbol after document load,
      // something has gone terribly wrong. Doing a document.write would
      // wipe out the page. This does not apply to the CSP-compliant method
      // of writing script tags.
      if (!goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING &&
          doc.readyState == 'complete') {
        // Certain test frameworks load base.js multiple times, which tries
        // to write deps.js each time. If that happens, just fail silently.
        // These frameworks wipe the page between each load of base.js, so this
        // is OK.
        var isDeps = /\bdeps.js$/.test(src);
        if (isDeps) {
          return false;
        } else {
          throw Error('Cannot write "' + src + '" after document load');
        }
      }

      var nonceAttr = '';
      var nonce = goog.getScriptNonce_();
      if (nonce) {
        nonceAttr = ' nonce="' + nonce + '"';
      }

      if (opt_sourceText === undefined) {
        var script = '<script src="' + src + '"' + nonceAttr + '></' +
            'script>';
        doc.write(
            goog.TRUSTED_TYPES_POLICY_ ?
                goog.TRUSTED_TYPES_POLICY_.createHTML(script) :
                script);
      } else {
        var script = '<script' + nonceAttr + '>' +
            goog.protectScriptTag_(opt_sourceText) + '</' +
            'script>';
        doc.write(
            goog.TRUSTED_TYPES_POLICY_ ?
                goog.TRUSTED_TYPES_POLICY_.createHTML(script) :
                script);
      }
      return true;
    } else {
      return false;
    }
  };
  // MOE:end_strip


  /**
   * Tries to detect whether the current browser is Edge, based on the user
   * agent. This matches only pre-Chromium Edge.
   * @see https://docs.microsoft.com/en-us/microsoft-edge/web-platform/user-agent-string
   * @return {boolean} True if the current browser is Edge.
   * @private
   */
  goog.isEdge_ = function() {
    var userAgent = goog.global.navigator && goog.global.navigator.userAgent ?
        goog.global.navigator.userAgent :
        '';
    var edgeRe = /Edge\/(\d+)(\.\d)*/i;
    return !!userAgent.match(edgeRe);
  };


  /**
   * Tries to detect whether is in the context of an HTML document.
   * @return {boolean} True if it looks like HTML document.
   * @private
   */
  goog.inHtmlDocument_ = function() {
    /** @type {!Document} */
    var doc = goog.global.document;
    return doc != null && 'write' in doc;  // XULDocument misses write.
  };


  /**
   * We'd like to check for if the document readyState is 'loading'; however
   * there are bugs on IE 10 and below where the readyState being anything other
   * than 'complete' is not reliable.
   * @return {boolean}
   * @private
   */
  goog.isDocumentLoading_ = function() {
    // attachEvent is available on IE 6 thru 10 only, and thus can be used to
    // detect those browsers.
    /** @type {!HTMLDocument} */
    var doc = goog.global.document;
    return doc.attachEvent ? doc.readyState != 'complete' :
                             doc.readyState == 'loading';
  };


  /**
   * Tries to detect the base path of base.js script that bootstraps Closure.
   * @private
   */
  goog.findBasePath_ = function() {
    if (goog.global.CLOSURE_BASE_PATH != undefined &&
        // Anti DOM-clobbering runtime check (b/37736576).
        typeof goog.global.CLOSURE_BASE_PATH === 'string') {
      goog.basePath = goog.global.CLOSURE_BASE_PATH;
      return;
    } else if (!goog.inHtmlDocument_()) {
      return;
    }
    /** @type {!Document} */
    var doc = goog.global.document;
    // If we have a currentScript available, use it exclusively.
    var currentScript = doc.currentScript;
    if (currentScript) {
      var scripts = [currentScript];
    } else {
      var scripts = doc.getElementsByTagName('SCRIPT');
    }
    // Search backwards since the current script is in almost all cases the one
    // that has base.js.
    for (var i = scripts.length - 1; i >= 0; --i) {
      var script = /** @type {!HTMLScriptElement} */ (scripts[i]);
      var src = script.src;
      var qmark = src.lastIndexOf('?');
      var l = qmark == -1 ? src.length : qmark;
      if (src.slice(l - 7, l) == 'base.js') {
        goog.basePath = src.slice(0, l - 7);
        return;
      }
    }
  };

  goog.findBasePath_();

  /** @struct @constructor @final */
  goog.Transpiler = function() {
    /** @private {?Object<string, boolean>} */
    this.requiresTranspilation_ = null;
    /** @private {string} */
    this.transpilationTarget_ = goog.TRANSPILE_TO_LANGUAGE;
  };


  // MOE:begin_strip
  // LINT.IfChange
  // MOE:end_strip
  /**
   * Returns a newly created map from language mode string to a boolean
   * indicating whether transpilation should be done for that mode as well as
   * the highest level language that this environment supports.
   *
   * Guaranteed invariant:
   * For any two modes, l1 and l2 where l2 is a newer mode than l1,
   * `map[l1] == true` implies that `map[l2] == true`.
   *
   * Note this method is extracted and used elsewhere, so it cannot rely on
   * anything external (it should easily be able to be transformed into a
   * standalone, top level function).
   *
   * @private
   * @return {{
   *   target: string,
   *   map: !Object<string, boolean>
   * }}
   */
  goog.Transpiler.prototype.createRequiresTranspilation_ = function() {
    var transpilationTarget = 'es3';
    var /** !Object<string, boolean> */ requiresTranspilation = {'es3': false};
    var transpilationRequiredForAllLaterModes = false;

    /**
     * Adds an entry to requiresTranspliation for the given language mode.
     *
     * IMPORTANT: Calls must be made in order from oldest to newest language
     * mode.
     * @param {string} modeName
     * @param {function(): boolean} isSupported Returns true if the JS engine
     *     supports the given mode.
     */
    function addNewerLanguageTranspilationCheck(modeName, isSupported) {
      if (transpilationRequiredForAllLaterModes) {
        requiresTranspilation[modeName] = true;
      } else if (isSupported()) {
        transpilationTarget = modeName;
        requiresTranspilation[modeName] = false;
      } else {
        requiresTranspilation[modeName] = true;
        transpilationRequiredForAllLaterModes = true;
      }
    }

    /**
     * Does the given code evaluate without syntax errors and return a truthy
     * result?
     */
    function /** boolean */ evalCheck(/** string */ code) {
      try {
        return !!eval(goog.CLOSURE_EVAL_PREFILTER_.createScript(code));
      } catch (ignored) {
        return false;
      }
    }

    // Identify ES3-only browsers by their incorrect treatment of commas.
    addNewerLanguageTranspilationCheck('es5', function() {
      return evalCheck('[1,].length==1');
    });
    addNewerLanguageTranspilationCheck('es6', function() {
      // Edge has a non-deterministic (i.e., not reproducible) bug with ES6:
      // https://github.com/Microsoft/ChakraCore/issues/1496.
      // MOE:begin_strip
      // TODO(joeltine): Our internal web-testing version of Edge will need to
      // be updated before we can remove this check. See http://b/34945376.
      // MOE:end_strip
      if (goog.isEdge_()) {
        // The Reflect.construct test below is flaky on Edge. It can sometimes
        // pass or fail on 40 15.15063, so just exit early for Edge and treat
        // it as ES5. Until we're on a more up to date version just always use
        // ES5. See https://github.com/Microsoft/ChakraCore/issues/3217.
        return false;
      }
      // Test es6: [FF50 (?), Edge 14 (?), Chrome 50]
      //   (a) default params (specifically shadowing locals),
      //   (b) destructuring, (c) block-scoped functions,
      //   (d) for-of (const), (e) new.target/Reflect.construct
      var es6fullTest =
          'class X{constructor(){if(new.target!=String)throw 1;this.x=42}}' +
          'let q=Reflect.construct(X,[],String);if(q.x!=42||!(q instanceof ' +
          'String))throw 1;for(const a of[2,3]){if(a==2)continue;function ' +
          'f(z={a}){let a=0;return z.a}{function f(){return 0;}}return f()' +
          '==3}';

      return evalCheck('(()=>{"use strict";' + es6fullTest + '})()');
    });
    // ** and **= are the only new features in 'es7'
    addNewerLanguageTranspilationCheck('es7', function() {
      return evalCheck('2**3==8');
    });
    // async functions are the only new features in 'es8'
    addNewerLanguageTranspilationCheck('es8', function() {
      return evalCheck('async()=>1,1');
    });
    addNewerLanguageTranspilationCheck('es9', function() {
      return evalCheck('({...rest}={}),1');
    });
    // optional catch binding, unescaped unicode paragraph separator in strings
    addNewerLanguageTranspilationCheck('es_2019', function() {
      return evalCheck('let r;try{r="\u2029"}catch{};r');
    });
    // optional chaining, nullish coalescing
    // untested/unsupported: bigint, import meta
    addNewerLanguageTranspilationCheck('es_2020', function() {
      return evalCheck('null?.x??1');
    });
    addNewerLanguageTranspilationCheck('es_next', function() {
      return false;  // assume it always need to transpile
    });
    return {target: transpilationTarget, map: requiresTranspilation};
  };
  // MOE:begin_strip
  // LINT.ThenChange(//depot/google3/java/com/google/testing/web/devtools/updatebrowserinfo/requires_transpilation.js)
  // MOE:end_strip


  /**
   * Determines whether the given language needs to be transpiled.
   * @param {string} lang
   * @param {string|undefined} module
   * @return {boolean}
   */
  goog.Transpiler.prototype.needsTranspile = function(lang, module) {
    if (goog.TRANSPILE == 'always') {
      return true;
    } else if (goog.TRANSPILE == 'never') {
      return false;
    } else if (!this.requiresTranspilation_) {
      var obj = this.createRequiresTranspilation_();
      this.requiresTranspilation_ = obj.map;
      this.transpilationTarget_ = this.transpilationTarget_ || obj.target;
    }
    if (lang in this.requiresTranspilation_) {
      if (this.requiresTranspilation_[lang]) {
        return true;
      } else if (
          goog.inHtmlDocument_() && module == 'es6' &&
          !('noModule' in goog.global.document.createElement('script'))) {
        return true;
      } else {
        return false;
      }
    } else {
      throw new Error('Unknown language mode: ' + lang);
    }
  };


  /**
   * Lazily retrieves the transpiler and applies it to the source.
   * @param {string} code JS code.
   * @param {string} path Path to the code.
   * @return {string} The transpiled code.
   */
  goog.Transpiler.prototype.transpile = function(code, path) {
    // TODO(johnplaisted): We should delete goog.transpile_ and just have this
    // function. But there's some compile error atm where goog.global is being
    // stripped incorrectly without this.
    return goog.transpile_(code, path, this.transpilationTarget_);
  };


  /** @private @final {!goog.Transpiler} */
  goog.transpiler_ = new goog.Transpiler();

  /**
   * Rewrites closing script tags in input to avoid ending an enclosing script
   * tag.
   *
   * @param {string} str
   * @return {string}
   * @private
   */
  goog.protectScriptTag_ = function(str) {
    return str.replace(/<\/(SCRIPT)/ig, '\\x3c/$1');
  };


  /**
   * A debug loader is responsible for downloading and executing javascript
   * files in an unbundled, uncompiled environment.
   *
   * This can be custimized via the setDependencyFactory method, or by
   * CLOSURE_IMPORT_SCRIPT/CLOSURE_LOAD_FILE_SYNC.
   *
   * @struct @constructor @final @private
   */
  goog.DebugLoader_ = function() {
    /** @private @const {!Object<string, !goog.Dependency>} */
    this.dependencies_ = {};
    /** @private @const {!Object<string, string>} */
    this.idToPath_ = {};
    /** @private @const {!Object<string, boolean>} */
    this.written_ = {};
    /** @private @const {!Array<!goog.Dependency>} */
    this.loadingDeps_ = [];
    /** @private {!Array<!goog.Dependency>} */
    this.depsToLoad_ = [];
    /** @private {boolean} */
    this.paused_ = false;
    /** @private {!goog.DependencyFactory} */
    this.factory_ = new goog.DependencyFactory(goog.transpiler_);
    /** @private @const {!Object<string, !Function>} */
    this.deferredCallbacks_ = {};
    /** @private @const {!Array<string>} */
    this.deferredQueue_ = [];
  };

  /**
   * @param {!Array<string>} namespaces
   * @param {function(): undefined} callback Function to call once all the
   *     namespaces have loaded.
   */
  goog.DebugLoader_.prototype.bootstrap = function(namespaces, callback) {
    var cb = callback;
    function resolve() {
      if (cb) {
        goog.global.setTimeout(cb, 0);
        cb = null;
      }
    }

    if (!namespaces.length) {
      resolve();
      return;
    }

    var deps = [];
    for (var i = 0; i < namespaces.length; i++) {
      var path = this.getPathFromDeps_(namespaces[i]);
      if (!path) {
        throw new Error('Unregonized namespace: ' + namespaces[i]);
      }
      deps.push(this.dependencies_[path]);
    }

    var require = goog.require;
    var loaded = 0;
    for (var i = 0; i < namespaces.length; i++) {
      require(namespaces[i]);
      deps[i].onLoad(function() {
        if (++loaded == namespaces.length) {
          resolve();
        }
      });
    }
  };


  /**
   * Loads the Closure Dependency file.
   *
   * Exposed a public function so CLOSURE_NO_DEPS can be set to false, base
   * loaded, setDependencyFactory called, and then this called. i.e. allows
   * custom loading of the deps file.
   */
  goog.DebugLoader_.prototype.loadClosureDeps = function() {
    // Circumvent addDependency, which would try to transpile deps.js if
    // transpile is set to always.
    var relPath = 'deps.js';
    this.depsToLoad_.push(this.factory_.createDependency(
        goog.normalizePath_(goog.basePath + relPath), relPath, [], [], {},
        false));
    this.loadDeps_();
  };


  /**
   * Notifies the debug loader when a dependency has been requested.
   *
   * @param {string} absPathOrId Path of the dependency or goog id.
   * @param {boolean=} opt_force
   */
  goog.DebugLoader_.prototype.requested = function(absPathOrId, opt_force) {
    var path = this.getPathFromDeps_(absPathOrId);
    if (path &&
        (opt_force || this.areDepsLoaded_(this.dependencies_[path].requires))) {
      var callback = this.deferredCallbacks_[path];
      if (callback) {
        delete this.deferredCallbacks_[path];
        callback();
      }
    }
  };


  /**
   * Sets the dependency factory, which can be used to create custom
   * goog.Dependency implementations to control how dependencies are loaded.
   *
   * @param {!goog.DependencyFactory} factory
   */
  goog.DebugLoader_.prototype.setDependencyFactory = function(factory) {
    this.factory_ = factory;
  };


  /**
   * Travserses the dependency graph and queues the given dependency, and all of
   * its transitive dependencies, for loading and then starts loading if not
   * paused.
   *
   * @param {string} namespace
   * @private
   */
  goog.DebugLoader_.prototype.load_ = function(namespace) {
    if (!this.getPathFromDeps_(namespace)) {
      var errorMessage = 'goog.require could not find: ' + namespace;
      goog.logToConsole_(errorMessage);
    } else {
      var loader = this;

      var deps = [];

      /** @param {string} namespace */
      var visit = function(namespace) {
        var path = loader.getPathFromDeps_(namespace);

        if (!path) {
          throw new Error('Bad dependency path or symbol: ' + namespace);
        }

        if (loader.written_[path]) {
          return;
        }

        loader.written_[path] = true;

        var dep = loader.dependencies_[path];
        // MOE:begin_strip
        if (goog.dependencies_.written[dep.relativePath]) {
          return;
        }
        // MOE:end_strip
        for (var i = 0; i < dep.requires.length; i++) {
          if (!goog.isProvided_(dep.requires[i])) {
            visit(dep.requires[i]);
          }
        }

        deps.push(dep);
      };

      visit(namespace);

      var wasLoading = !!this.depsToLoad_.length;
      this.depsToLoad_ = this.depsToLoad_.concat(deps);

      if (!this.paused_ && !wasLoading) {
        this.loadDeps_();
      }
    }
  };


  /**
   * Loads any queued dependencies until they are all loaded or paused.
   *
   * @private
   */
  goog.DebugLoader_.prototype.loadDeps_ = function() {
    var loader = this;
    var paused = this.paused_;

    while (this.depsToLoad_.length && !paused) {
      (function() {
        var loadCallDone = false;
        var dep = loader.depsToLoad_.shift();

        var loaded = false;
        loader.loading_(dep);

        var controller = {
          pause: function() {
            if (loadCallDone) {
              throw new Error('Cannot call pause after the call to load.');
            } else {
              paused = true;
            }
          },
          resume: function() {
            if (loadCallDone) {
              loader.resume_();
            } else {
              // Some dep called pause and then resume in the same load call.
              // Just keep running this same loop.
              paused = false;
            }
          },
          loaded: function() {
            if (loaded) {
              throw new Error('Double call to loaded.');
            }

            loaded = true;
            loader.loaded_(dep);
          },
          pending: function() {
            // Defensive copy.
            var pending = [];
            for (var i = 0; i < loader.loadingDeps_.length; i++) {
              pending.push(loader.loadingDeps_[i]);
            }
            return pending;
          },
          /**
           * @param {goog.ModuleType} type
           */
          setModuleState: function(type) {
            goog.moduleLoaderState_ = {
              type: type,
              moduleName: '',
              declareLegacyNamespace: false
            };
          },
          /** @type {function(string, string, string=)} */
          registerEs6ModuleExports: function(
              path, exports, opt_closureNamespace) {
            if (opt_closureNamespace) {
              goog.loadedModules_[opt_closureNamespace] = {
                exports: exports,
                type: goog.ModuleType.ES6,
                moduleId: opt_closureNamespace || ''
              };
            }
          },
          /** @type {function(string, ?)} */
          registerGoogModuleExports: function(moduleId, exports) {
            goog.loadedModules_[moduleId] = {
              exports: exports,
              type: goog.ModuleType.GOOG,
              moduleId: moduleId
            };
          },
          clearModuleState: function() {
            goog.moduleLoaderState_ = null;
          },
          defer: function(callback) {
            if (loadCallDone) {
              throw new Error(
                  'Cannot register with defer after the call to load.');
            }
            loader.defer_(dep, callback);
          },
          areDepsLoaded: function() {
            return loader.areDepsLoaded_(dep.requires);
          }
        };

        try {
          dep.load(controller);
        } finally {
          loadCallDone = true;
        }
      })();
    }

    if (paused) {
      this.pause_();
    }
  };


  /** @private */
  goog.DebugLoader_.prototype.pause_ = function() {
    this.paused_ = true;
  };


  /** @private */
  goog.DebugLoader_.prototype.resume_ = function() {
    if (this.paused_) {
      this.paused_ = false;
      this.loadDeps_();
    }
  };


  /**
   * Marks the given dependency as loading (load has been called but it has not
   * yet marked itself as finished). Useful for dependencies that want to know
   * what else is loading. Example: goog.modules cannot eval if there are
   * loading dependencies.
   *
   * @param {!goog.Dependency} dep
   * @private
   */
  goog.DebugLoader_.prototype.loading_ = function(dep) {
    this.loadingDeps_.push(dep);
  };


  /**
   * Marks the given dependency as having finished loading and being available
   * for require.
   *
   * @param {!goog.Dependency} dep
   * @private
   */
  goog.DebugLoader_.prototype.loaded_ = function(dep) {
    for (var i = 0; i < this.loadingDeps_.length; i++) {
      if (this.loadingDeps_[i] == dep) {
        this.loadingDeps_.splice(i, 1);
        break;
      }
    }

    for (var i = 0; i < this.deferredQueue_.length; i++) {
      if (this.deferredQueue_[i] == dep.path) {
        this.deferredQueue_.splice(i, 1);
        break;
      }
    }

    if (this.loadingDeps_.length == this.deferredQueue_.length &&
        !this.depsToLoad_.length) {
      // Something has asked to load these, but they may not be directly
      // required again later, so load them now that we know we're done loading
      // everything else. e.g. a goog module entry point.
      while (this.deferredQueue_.length) {
        this.requested(this.deferredQueue_.shift(), true);
      }
    }

    dep.loaded();
  };


  /**
   * @param {!Array<string>} pathsOrIds
   * @return {boolean}
   * @private
   */
  goog.DebugLoader_.prototype.areDepsLoaded_ = function(pathsOrIds) {
    for (var i = 0; i < pathsOrIds.length; i++) {
      var path = this.getPathFromDeps_(pathsOrIds[i]);
      if (!path ||
          (!(path in this.deferredCallbacks_) &&
           !goog.isProvided_(pathsOrIds[i]))) {
        return false;
      }
    }

    return true;
  };


  /**
   * @param {string} absPathOrId
   * @return {?string}
   * @private
   */
  goog.DebugLoader_.prototype.getPathFromDeps_ = function(absPathOrId) {
    if (absPathOrId in this.idToPath_) {
      return this.idToPath_[absPathOrId];
    } else if (absPathOrId in this.dependencies_) {
      return absPathOrId;
    } else {
      return null;
    }
  };


  /**
   * @param {!goog.Dependency} dependency
   * @param {!Function} callback
   * @private
   */
  goog.DebugLoader_.prototype.defer_ = function(dependency, callback) {
    this.deferredCallbacks_[dependency.path] = callback;
    this.deferredQueue_.push(dependency.path);
  };


  /**
   * Interface for goog.Dependency implementations to have some control over
   * loading of dependencies.
   *
   * @record
   */
  goog.LoadController = function() {};


  /**
   * Tells the controller to halt loading of more dependencies.
   */
  goog.LoadController.prototype.pause = function() {};


  /**
   * Tells the controller to resume loading of more dependencies if paused.
   */
  goog.LoadController.prototype.resume = function() {};


  /**
   * Tells the controller that this dependency has finished loading.
   *
   * This causes this to be removed from pending() and any load callbacks to
   * fire.
   */
  goog.LoadController.prototype.loaded = function() {};


  /**
   * List of dependencies on which load has been called but which have not
   * called loaded on their controller. This includes the current dependency.
   *
   * @return {!Array<!goog.Dependency>}
   */
  goog.LoadController.prototype.pending = function() {};


  /**
   * Registers an object as an ES6 module's exports so that goog.modules may
   * require it by path.
   *
   * @param {string} path Full path of the module.
   * @param {?} exports
   * @param {string=} opt_closureNamespace Closure namespace to associate with
   *     this module.
   */
  goog.LoadController.prototype.registerEs6ModuleExports = function(
      path, exports, opt_closureNamespace) {};


  /**
   * Sets the current module state.
   *
   * @param {goog.ModuleType} type Type of module.
   */
  goog.LoadController.prototype.setModuleState = function(type) {};


  /**
   * Clears the current module state.
   */
  goog.LoadController.prototype.clearModuleState = function() {};


  /**
   * Registers a callback to call once the dependency is actually requested
   * via goog.require + all of the immediate dependencies have been loaded or
   * all other files have been loaded. Allows for lazy loading until
   * require'd without pausing dependency loading, which is needed on old IE.
   *
   * @param {!Function} callback
   */
  goog.LoadController.prototype.defer = function(callback) {};


  /**
   * @return {boolean}
   */
  goog.LoadController.prototype.areDepsLoaded = function() {};


  /**
   * Basic super class for all dependencies Closure Library can load.
   *
   * This default implementation is designed to load untranspiled, non-module
   * scripts in a web broswer.
   *
   * For transpiled non-goog.module files {@see goog.TranspiledDependency}.
   * For goog.modules see {@see goog.GoogModuleDependency}.
   * For untranspiled ES6 modules {@see goog.Es6ModuleDependency}.
   *
   * @param {string} path Absolute path of this script.
   * @param {string} relativePath Path of this script relative to goog.basePath.
   * @param {!Array<string>} provides goog.provided or goog.module symbols
   *     in this file.
   * @param {!Array<string>} requires goog symbols or relative paths to Closure
   *     this depends on.
   * @param {!Object<string, string>} loadFlags
   * @struct @constructor
   */
  goog.Dependency = function(
      path, relativePath, provides, requires, loadFlags) {
    /** @const */
    this.path = path;
    /** @const */
    this.relativePath = relativePath;
    /** @const */
    this.provides = provides;
    /** @const */
    this.requires = requires;
    /** @const */
    this.loadFlags = loadFlags;
    /** @private {boolean} */
    this.loaded_ = false;
    /** @private {!Array<function()>} */
    this.loadCallbacks_ = [];
  };


  /**
   * @return {string} The pathname part of this dependency's path if it is a
   *     URI.
   */
  goog.Dependency.prototype.getPathName = function() {
    var pathName = this.path;
    var protocolIndex = pathName.indexOf('://');
    if (protocolIndex >= 0) {
      pathName = pathName.substring(protocolIndex + 3);
      var slashIndex = pathName.indexOf('/');
      if (slashIndex >= 0) {
        pathName = pathName.substring(slashIndex + 1);
      }
    }
    return pathName;
  };


  /**
   * @param {function()} callback Callback to fire as soon as this has loaded.
   * @final
   */
  goog.Dependency.prototype.onLoad = function(callback) {
    if (this.loaded_) {
      callback();
    } else {
      this.loadCallbacks_.push(callback);
    }
  };


  /**
   * Marks this dependency as loaded and fires any callbacks registered with
   * onLoad.
   * @final
   */
  goog.Dependency.prototype.loaded = function() {
    this.loaded_ = true;
    var callbacks = this.loadCallbacks_;
    this.loadCallbacks_ = [];
    for (var i = 0; i < callbacks.length; i++) {
      callbacks[i]();
    }
  };


  /**
   * Whether or not document.written / appended script tags should be deferred.
   *
   * @private {boolean}
   */
  goog.Dependency.defer_ = false;


  /**
   * Map of script ready / state change callbacks. Old IE cannot handle putting
   * these properties on goog.global.
   *
   * @private @const {!Object<string, function(?):undefined>}
   */
  goog.Dependency.callbackMap_ = {};


  /**
   * @param {function(...?):?} callback
   * @return {string}
   * @private
   */
  goog.Dependency.registerCallback_ = function(callback) {
    var key = Math.random().toString(32);
    goog.Dependency.callbackMap_[key] = callback;
    return key;
  };


  /**
   * @param {string} key
   * @private
   */
  goog.Dependency.unregisterCallback_ = function(key) {
    delete goog.Dependency.callbackMap_[key];
  };


  /**
   * @param {string} key
   * @param {...?} var_args
   * @private
   * @suppress {unusedPrivateMembers}
   */
  goog.Dependency.callback_ = function(key, var_args) {
    if (key in goog.Dependency.callbackMap_) {
      var callback = goog.Dependency.callbackMap_[key];
      var args = [];
      for (var i = 1; i < arguments.length; i++) {
        args.push(arguments[i]);
      }
      callback.apply(undefined, args);
    } else {
      var errorMessage = 'Callback key ' + key +
          ' does not exist (was base.js loaded more than once?).';
      // MOE:begin_strip
      // TODO(johnplaisted): Some people internally are mistakenly loading
      // base.js twice, and this can happen while a dependency is loading,
      // wiping out state.
      goog.logToConsole_(errorMessage);
      // MOE:end_strip
      // MOE:insert throw Error(errorMessage);
    }
  };


  /**
   * Starts loading this dependency. This dependency can pause loading if it
   * needs to and resume it later via the controller interface.
   *
   * When this is loaded it should call controller.loaded(). Note that this will
   * end up calling the loaded method of this dependency; there is no need to
   * call it explicitly.
   *
   * @param {!goog.LoadController} controller
   */
  goog.Dependency.prototype.load = function(controller) {
    if (goog.global.CLOSURE_IMPORT_SCRIPT) {
      if (goog.global.CLOSURE_IMPORT_SCRIPT(this.path)) {
        controller.loaded();
      } else {
        controller.pause();
      }
      return;
    }

    if (!goog.inHtmlDocument_()) {
      goog.logToConsole_(
          'Cannot use default debug loader outside of HTML documents.');
      if (this.relativePath == 'deps.js') {
        // Some old code is relying on base.js auto loading deps.js failing with
        // no error before later setting CLOSURE_IMPORT_SCRIPT.
        // CLOSURE_IMPORT_SCRIPT should be set *before* base.js is loaded, or
        // CLOSURE_NO_DEPS set to true.
        goog.logToConsole_(
            'Consider setting CLOSURE_IMPORT_SCRIPT before loading base.js, ' +
            'or setting CLOSURE_NO_DEPS to true.');
        controller.loaded();
      } else {
        controller.pause();
      }
      return;
    }

    /** @type {!HTMLDocument} */
    var doc = goog.global.document;

    // If the user tries to require a new symbol after document load,
    // something has gone terribly wrong. Doing a document.write would
    // wipe out the page. This does not apply to the CSP-compliant method
    // of writing script tags.
    if (doc.readyState == 'complete' &&
        !goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING) {
      // Certain test frameworks load base.js multiple times, which tries
      // to write deps.js each time. If that happens, just fail silently.
      // These frameworks wipe the page between each load of base.js, so this
      // is OK.
      var isDeps = /\bdeps.js$/.test(this.path);
      if (isDeps) {
        controller.loaded();
        return;
      } else {
        throw Error('Cannot write "' + this.path + '" after document load');
      }
    }

    var nonce = goog.getScriptNonce_();
    if (!goog.ENABLE_CHROME_APP_SAFE_SCRIPT_LOADING &&
        goog.isDocumentLoading_()) {
      var key;
      var callback = function(script) {
        if (script.readyState && script.readyState != 'complete') {
          script.onload = callback;
          return;
        }
        goog.Dependency.unregisterCallback_(key);
        controller.loaded();
      };
      key = goog.Dependency.registerCallback_(callback);

      var defer = goog.Dependency.defer_ ? ' defer' : '';
      var nonceAttr = nonce ? ' nonce="' + nonce + '"' : '';
      var script = '<script src="' + this.path + '"' + nonceAttr + defer +
          ' id="script-' + key + '"><\/script>';

      script += '<script' + nonceAttr + '>';

      if (goog.Dependency.defer_) {
        script += 'document.getElementById(\'script-' + key +
            '\').onload = function() {\n' +
            '  goog.Dependency.callback_(\'' + key + '\', this);\n' +
            '};\n';
      } else {
        script += 'goog.Dependency.callback_(\'' + key +
            '\', document.getElementById(\'script-' + key + '\'));';
      }

      script += '<\/script>';

      doc.write(
          goog.TRUSTED_TYPES_POLICY_ ?
              goog.TRUSTED_TYPES_POLICY_.createHTML(script) :
              script);
    } else {
      var scriptEl =
          /** @type {!HTMLScriptElement} */ (doc.createElement('script'));
      scriptEl.defer = goog.Dependency.defer_;
      scriptEl.async = false;

      // If CSP nonces are used, propagate them to dynamically created scripts.
      // This is necessary to allow nonce-based CSPs without 'strict-dynamic'.
      if (nonce) {
        scriptEl.nonce = nonce;
      }

      scriptEl.onload = function() {
        scriptEl.onload = null;
        controller.loaded();
      };

      scriptEl.src = goog.TRUSTED_TYPES_POLICY_ ?
          goog.TRUSTED_TYPES_POLICY_.createScriptURL(this.path) :
          this.path;
      doc.head.appendChild(scriptEl);
    }
  };


  /**
   * @param {string} path Absolute path of this script.
   * @param {string} relativePath Path of this script relative to goog.basePath.
   * @param {!Array<string>} provides Should be an empty array.
   *     TODO(johnplaisted) add support for adding closure namespaces to ES6
   *     modules for interop purposes.
   * @param {!Array<string>} requires goog symbols or relative paths to Closure
   *     this depends on.
   * @param {!Object<string, string>} loadFlags
   * @struct @constructor
   * @extends {goog.Dependency}
   */
  goog.Es6ModuleDependency = function(
      path, relativePath, provides, requires, loadFlags) {
    goog.Es6ModuleDependency.base(
        this, 'constructor', path, relativePath, provides, requires, loadFlags);
  };
  goog.inherits(goog.Es6ModuleDependency, goog.Dependency);


  /**
   * @override
   * @param {!goog.LoadController} controller
   */
  goog.Es6ModuleDependency.prototype.load = function(controller) {
    if (goog.global.CLOSURE_IMPORT_SCRIPT) {
      if (goog.global.CLOSURE_IMPORT_SCRIPT(this.path)) {
        controller.loaded();
      } else {
        controller.pause();
      }
      return;
    }

    if (!goog.inHtmlDocument_()) {
      goog.logToConsole_(
          'Cannot use default debug loader outside of HTML documents.');
      controller.pause();
      return;
    }

    /** @type {!HTMLDocument} */
    var doc = goog.global.document;

    var dep = this;

    // TODO(johnplaisted): Does document.writing really speed up anything? Any
    // difference between this and just waiting for interactive mode and then
    // appending?
    function write(src, contents) {
      var nonceAttr = '';
      var nonce = goog.getScriptNonce_();
      if (nonce) {
        nonceAttr = ' nonce="' + nonce + '"';
      }

      if (contents) {
        var script = '<script type="module" crossorigin' + nonceAttr + '>' +
            contents + '</' +
            'script>';
        doc.write(
            goog.TRUSTED_TYPES_POLICY_ ?
                goog.TRUSTED_TYPES_POLICY_.createHTML(script) :
                script);
      } else {
        var script = '<script type="module" crossorigin src="' + src + '"' +
            nonceAttr + '></' +
            'script>';
        doc.write(
            goog.TRUSTED_TYPES_POLICY_ ?
                goog.TRUSTED_TYPES_POLICY_.createHTML(script) :
                script);
      }
    }

    function append(src, contents) {
      var scriptEl =
          /** @type {!HTMLScriptElement} */ (doc.createElement('script'));
      scriptEl.defer = true;
      scriptEl.async = false;
      scriptEl.type = 'module';
      scriptEl.setAttribute('crossorigin', true);

      // If CSP nonces are used, propagate them to dynamically created scripts.
      // This is necessary to allow nonce-based CSPs without 'strict-dynamic'.
      var nonce = goog.getScriptNonce_();
      if (nonce) {
        scriptEl.nonce = nonce;
      }

      if (contents) {
        scriptEl.text = goog.TRUSTED_TYPES_POLICY_ ?
            goog.TRUSTED_TYPES_POLICY_.createScript(contents) :
            contents;
      } else {
        scriptEl.src = goog.TRUSTED_TYPES_POLICY_ ?
            goog.TRUSTED_TYPES_POLICY_.createScriptURL(src) :
            src;
      }

      doc.head.appendChild(scriptEl);
    }

    var create;

    if (goog.isDocumentLoading_()) {
      create = write;
      // We can ONLY call document.write if we are guaranteed that any
      // non-module script tags document.written after this are deferred.
      // Small optimization, in theory document.writing is faster.
      goog.Dependency.defer_ = true;
    } else {
      create = append;
    }

    // Write 4 separate tags here:
    // 1) Sets the module state at the correct time (just before execution).
    // 2) A src node for this, which just hopefully lets the browser load it a
    //    little early (no need to parse #3).
    // 3) Import the module and register it.
    // 4) Clear the module state at the correct time. Guaranteed to run even
    //    if there is an error in the module (#3 will not run if there is an
    //    error in the module).
    var beforeKey = goog.Dependency.registerCallback_(function() {
      goog.Dependency.unregisterCallback_(beforeKey);
      controller.setModuleState(goog.ModuleType.ES6);
    });
    create(undefined, 'goog.Dependency.callback_("' + beforeKey + '")');

    // TODO(johnplaisted): Does this really speed up anything?
    create(this.path, undefined);

    var registerKey = goog.Dependency.registerCallback_(function(exports) {
      goog.Dependency.unregisterCallback_(registerKey);
      controller.registerEs6ModuleExports(
          dep.path, exports, goog.moduleLoaderState_.moduleName);
    });
    create(
        undefined,
        'import * as m from "' + this.path + '"; goog.Dependency.callback_("' +
            registerKey + '", m)');

    var afterKey = goog.Dependency.registerCallback_(function() {
      goog.Dependency.unregisterCallback_(afterKey);
      controller.clearModuleState();
      controller.loaded();
    });
    create(undefined, 'goog.Dependency.callback_("' + afterKey + '")');
  };


  /**
   * Superclass of any dependency that needs to be loaded into memory,
   * transformed, and then eval'd (goog.modules and transpiled files).
   *
   * @param {string} path Absolute path of this script.
   * @param {string} relativePath Path of this script relative to goog.basePath.
   * @param {!Array<string>} provides goog.provided or goog.module symbols
   *     in this file.
   * @param {!Array<string>} requires goog symbols or relative paths to Closure
   *     this depends on.
   * @param {!Object<string, string>} loadFlags
   * @struct @constructor @abstract
   * @extends {goog.Dependency}
   */
  goog.TransformedDependency = function(
      path, relativePath, provides, requires, loadFlags) {
    goog.TransformedDependency.base(
        this, 'constructor', path, relativePath, provides, requires, loadFlags);
    /** @private {?string} */
    this.contents_ = null;

    /**
     * Whether to lazily make the synchronous XHR (when goog.require'd) or make
     * the synchronous XHR when initially loading. On FireFox 61 there is a bug
     * where an ES6 module cannot make a synchronous XHR (rather, it can, but if
     * it does then no other ES6 modules will load after).
     *
     * tl;dr we lazy load due to bugs on older browsers and eager load due to
     * bugs on newer ones.
     *
     * https://bugzilla.mozilla.org/show_bug.cgi?id=1477090
     *
     * @private @const {boolean}
     */
    this.lazyFetch_ = !goog.inHtmlDocument_() ||
        !('noModule' in goog.global.document.createElement('script'));
  };
  goog.inherits(goog.TransformedDependency, goog.Dependency);


  /**
   * @override
   * @param {!goog.LoadController} controller
   */
  goog.TransformedDependency.prototype.load = function(controller) {
    var dep = this;

    function fetch() {
      dep.contents_ = goog.loadFileSync_(dep.path);

      if (dep.contents_) {
        dep.contents_ = dep.transform(dep.contents_);
        if (dep.contents_) {
          dep.contents_ += '\n//# sourceURL=' + dep.path;
        }
      }
    }

    if (goog.global.CLOSURE_IMPORT_SCRIPT) {
      fetch();
      if (this.contents_ &&
          goog.global.CLOSURE_IMPORT_SCRIPT('', this.contents_)) {
        this.contents_ = null;
        controller.loaded();
      } else {
        controller.pause();
      }
      return;
    }


    var isEs6 = this.loadFlags['module'] == goog.ModuleType.ES6;

    if (!this.lazyFetch_) {
      fetch();
    }

    function load() {
      if (dep.lazyFetch_) {
        fetch();
      }

      if (!dep.contents_) {
        // loadFileSync_ or transform are responsible. Assume they logged an
        // error.
        return;
      }

      if (isEs6) {
        controller.setModuleState(goog.ModuleType.ES6);
      }

      var namespace;

      try {
        var contents = dep.contents_;
        dep.contents_ = null;
        goog.globalEval(goog.CLOSURE_EVAL_PREFILTER_.createScript(contents));
        if (isEs6) {
          namespace = goog.moduleLoaderState_.moduleName;
        }
      } finally {
        if (isEs6) {
          controller.clearModuleState();
        }
      }

      if (isEs6) {
        // Due to circular dependencies this may not be available for require
        // right now.
        goog.global['$jscomp']['require']['ensure'](
            [dep.getPathName()], function() {
              controller.registerEs6ModuleExports(
                  dep.path,
                  goog.global['$jscomp']['require'](dep.getPathName()),
                  namespace);
            });
      }

      controller.loaded();
    }

    // Do not fetch now; in FireFox 47 the synchronous XHR doesn't block all
    // events. If we fetched now and then document.write'd the contents the
    // document.write would be an eval and would execute too soon! Instead write
    // a script tag to fetch and eval synchronously at the correct time.
    function fetchInOwnScriptThenLoad() {
      /** @type {!HTMLDocument} */
      var doc = goog.global.document;

      var key = goog.Dependency.registerCallback_(function() {
        goog.Dependency.unregisterCallback_(key);
        load();
      });

      var nonce = goog.getScriptNonce_();
      var nonceAttr = nonce ? ' nonce="' + nonce + '"' : '';
      var script = '<script' + nonceAttr + '>' +
          goog.protectScriptTag_('goog.Dependency.callback_("' + key + '");') +
          '</' +
          'script>';
      doc.write(
          goog.TRUSTED_TYPES_POLICY_ ?
              goog.TRUSTED_TYPES_POLICY_.createHTML(script) :
              script);
    }

    // If one thing is pending it is this.
    var anythingElsePending = controller.pending().length > 1;

    // Additionally if we are meant to defer scripts but the page is still
    // loading (e.g. an ES6 module is loading) then also defer. Or if we are
    // meant to defer and anything else is pending then defer (those may be
    // scripts that did not need transformation and are just script tags with
    // defer set to true, and we need to evaluate after that deferred script).
    var needsAsyncLoading = goog.Dependency.defer_ &&
        (anythingElsePending || goog.isDocumentLoading_());

    if (needsAsyncLoading) {
      // Note that we only defer when we have to rather than 100% of the time.
      // Always defering would work, but then in theory the order of
      // goog.require calls would then matter. We want to enforce that most of
      // the time the order of the require calls does not matter.
      controller.defer(function() {
        load();
      });
      return;
    }
    // TODO(johnplaisted): Externs are missing onreadystatechange for
    // HTMLDocument.
    /** @type {?} */
    var doc = goog.global.document;

    var isInternetExplorerOrEdge = goog.inHtmlDocument_() &&
        ('ActiveXObject' in goog.global || goog.isEdge_());

    // Don't delay in any version of IE or pre-Chromium Edge. There's a bug
    // around this that will cause out of order script execution. This means
    // that on older IE ES6 modules will load too early (while the document is
    // still loading + the dom is not available). The other option is to load
    // too late (when the document is complete and the onload even will never
    // fire). This seems to be the lesser of two evils as scripts already act
    // like the former.
    if (isEs6 && goog.inHtmlDocument_() && goog.isDocumentLoading_() &&
        !isInternetExplorerOrEdge) {
      goog.Dependency.defer_ = true;
      // Transpiled ES6 modules still need to load like regular ES6 modules,
      // aka only after the document is interactive.
      controller.pause();
      var oldCallback = doc.onreadystatechange;
      doc.onreadystatechange = function() {
        if (doc.readyState == 'interactive') {
          doc.onreadystatechange = oldCallback;
          load();
          controller.resume();
        }
        if (typeof oldCallback === 'function') {
          oldCallback.apply(undefined, arguments);
        }
      };
    } else {
      // Always eval on old IE.
      if (!goog.inHtmlDocument_() || !goog.isDocumentLoading_()) {
        load();
      } else {
        fetchInOwnScriptThenLoad();
      }
    }
  };


  /**
   * @param {string} contents
   * @return {string}
   * @abstract
   */
  goog.TransformedDependency.prototype.transform = function(contents) {};


  /**
   * Any non-goog.module dependency which needs to be transpiled before eval.
   *
   * @param {string} path Absolute path of this script.
   * @param {string} relativePath Path of this script relative to goog.basePath.
   * @param {!Array<string>} provides goog.provided or goog.module symbols
   *     in this file.
   * @param {!Array<string>} requires goog symbols or relative paths to Closure
   *     this depends on.
   * @param {!Object<string, string>} loadFlags
   * @param {!goog.Transpiler} transpiler
   * @struct @constructor
   * @extends {goog.TransformedDependency}
   */
  goog.TranspiledDependency = function(
      path, relativePath, provides, requires, loadFlags, transpiler) {
    goog.TranspiledDependency.base(
        this, 'constructor', path, relativePath, provides, requires, loadFlags);
    /** @protected @const*/
    this.transpiler = transpiler;
  };
  goog.inherits(goog.TranspiledDependency, goog.TransformedDependency);


  /**
   * @override
   * @param {string} contents
   * @return {string}
   */
  goog.TranspiledDependency.prototype.transform = function(contents) {
    // Transpile with the pathname so that ES6 modules are domain agnostic.
    return this.transpiler.transpile(contents, this.getPathName());
  };


  /**
   * An ES6 module dependency that was transpiled to a jscomp module outside
   * of the debug loader, e.g. server side.
   *
   * @param {string} path Absolute path of this script.
   * @param {string} relativePath Path of this script relative to goog.basePath.
   * @param {!Array<string>} provides goog.provided or goog.module symbols
   *     in this file.
   * @param {!Array<string>} requires goog symbols or relative paths to Closure
   *     this depends on.
   * @param {!Object<string, string>} loadFlags
   * @struct @constructor
   * @extends {goog.TransformedDependency}
   */
  goog.PreTranspiledEs6ModuleDependency = function(
      path, relativePath, provides, requires, loadFlags) {
    goog.PreTranspiledEs6ModuleDependency.base(
        this, 'constructor', path, relativePath, provides, requires, loadFlags);
  };
  goog.inherits(
      goog.PreTranspiledEs6ModuleDependency, goog.TransformedDependency);


  /**
   * @override
   * @param {string} contents
   * @return {string}
   */
  goog.PreTranspiledEs6ModuleDependency.prototype.transform = function(
      contents) {
    return contents;
  };


  /**
   * A goog.module, transpiled or not. Will always perform some minimal
   * transformation even when not transpiled to wrap in a goog.loadModule
   * statement.
   *
   * @param {string} path Absolute path of this script.
   * @param {string} relativePath Path of this script relative to goog.basePath.
   * @param {!Array<string>} provides goog.provided or goog.module symbols
   *     in this file.
   * @param {!Array<string>} requires goog symbols or relative paths to Closure
   *     this depends on.
   * @param {!Object<string, string>} loadFlags
   * @param {boolean} needsTranspile
   * @param {!goog.Transpiler} transpiler
   * @struct @constructor
   * @extends {goog.TransformedDependency}
   */
  goog.GoogModuleDependency = function(
      path, relativePath, provides, requires, loadFlags, needsTranspile,
      transpiler) {
    goog.GoogModuleDependency.base(
        this, 'constructor', path, relativePath, provides, requires, loadFlags);
    /** @private @const */
    this.needsTranspile_ = needsTranspile;
    /** @private @const */
    this.transpiler_ = transpiler;
  };
  goog.inherits(goog.GoogModuleDependency, goog.TransformedDependency);


  /**
   * @override
   * @param {string} contents
   * @return {string}
   */
  goog.GoogModuleDependency.prototype.transform = function(contents) {
    if (this.needsTranspile_) {
      contents = this.transpiler_.transpile(contents, this.getPathName());
    }

    if (!goog.LOAD_MODULE_USING_EVAL || goog.global.JSON === undefined) {
      return '' +
          'goog.loadModule(function(exports) {' +
          '"use strict";' + contents +
          '\n' +  // terminate any trailing single line comment.
          ';return exports' +
          '});' +
          '\n//# sourceURL=' + this.path + '\n';
    } else {
      return '' +
          'goog.loadModule(' +
          goog.global.JSON.stringify(
              contents + '\n//# sourceURL=' + this.path + '\n') +
          ');';
    }
  };


  /**
   * @param {string} relPath
   * @param {!Array<string>|undefined} provides
   * @param {!Array<string>} requires
   * @param {boolean|!Object<string>=} opt_loadFlags
   * @see goog.addDependency
   */
  goog.DebugLoader_.prototype.addDependency = function(
      relPath, provides, requires, opt_loadFlags) {
    provides = provides || [];
    relPath = relPath.replace(/\\/g, '/');
    var path = goog.normalizePath_(goog.basePath + relPath);
    if (!opt_loadFlags || typeof opt_loadFlags === 'boolean') {
      opt_loadFlags = opt_loadFlags ? {'module': goog.ModuleType.GOOG} : {};
    }
    var dep = this.factory_.createDependency(
        path, relPath, provides, requires, opt_loadFlags,
        goog.transpiler_.needsTranspile(
            opt_loadFlags['lang'] || 'es3', opt_loadFlags['module']));
    this.dependencies_[path] = dep;
    for (var i = 0; i < provides.length; i++) {
      this.idToPath_[provides[i]] = path;
    }
    this.idToPath_[relPath] = path;
  };


  /**
   * Creates goog.Dependency instances for the debug loader to load.
   *
   * Should be overridden to have the debug loader use custom subclasses of
   * goog.Dependency.
   *
   * @param {!goog.Transpiler} transpiler
   * @struct @constructor
   */
  goog.DependencyFactory = function(transpiler) {
    /** @protected @const */
    this.transpiler = transpiler;
  };


  /**
   * @param {string} path Absolute path of the file.
   * @param {string} relativePath Path relative to closure’s base.js.
   * @param {!Array<string>} provides Array of provided goog.provide/module ids.
   * @param {!Array<string>} requires Array of required goog.provide/module /
   *     relative ES6 module paths.
   * @param {!Object<string, string>} loadFlags
   * @param {boolean} needsTranspile True if the file needs to be transpiled
   *     per the goog.Transpiler.
   * @return {!goog.Dependency}
   */
  goog.DependencyFactory.prototype.createDependency = function(
      path, relativePath, provides, requires, loadFlags, needsTranspile) {
    // MOE:begin_strip
    var provide, require;
    for (var i = 0; provide = provides[i]; i++) {
      goog.dependencies_.nameToPath[provide] = relativePath;
      goog.dependencies_.loadFlags[relativePath] = loadFlags;
    }
    for (var j = 0; require = requires[j]; j++) {
      if (!(relativePath in goog.dependencies_.requires)) {
        goog.dependencies_.requires[relativePath] = {};
      }
      goog.dependencies_.requires[relativePath][require] = true;
    }
    // MOE:end_strip

    if (loadFlags['module'] == goog.ModuleType.GOOG) {
      return new goog.GoogModuleDependency(
          path, relativePath, provides, requires, loadFlags, needsTranspile,
          this.transpiler);
    } else if (needsTranspile) {
      return new goog.TranspiledDependency(
          path, relativePath, provides, requires, loadFlags, this.transpiler);
    } else {
      if (loadFlags['module'] == goog.ModuleType.ES6) {
        if (goog.TRANSPILE == 'never' && goog.ASSUME_ES_MODULES_TRANSPILED) {
          return new goog.PreTranspiledEs6ModuleDependency(
              path, relativePath, provides, requires, loadFlags);
        } else {
          return new goog.Es6ModuleDependency(
              path, relativePath, provides, requires, loadFlags);
        }
      } else {
        return new goog.Dependency(
            path, relativePath, provides, requires, loadFlags);
      }
    }
  };


  /** @private @const */
  goog.debugLoader_ = new goog.DebugLoader_();


  /**
   * Loads the Closure Dependency file.
   *
   * Exposed a public function so CLOSURE_NO_DEPS can be set to false, base
   * loaded, setDependencyFactory called, and then this called. i.e. allows
   * custom loading of the deps file.
   */
  goog.loadClosureDeps = function() {
    goog.debugLoader_.loadClosureDeps();
  };


  /**
   * Sets the dependency factory, which can be used to create custom
   * goog.Dependency implementations to control how dependencies are loaded.
   *
   * Note: if you wish to call this function and provide your own implemnetation
   * it is a wise idea to set CLOSURE_NO_DEPS to true, otherwise the dependency
   * file and all of its goog.addDependency calls will use the default factory.
   * You can call goog.loadClosureDeps to load the Closure dependency file
   * later, after your factory is injected.
   *
   * @param {!goog.DependencyFactory} factory
   */
  goog.setDependencyFactory = function(factory) {
    goog.debugLoader_.setDependencyFactory(factory);
  };


  /**
   * Trusted Types policy for the debug loader.
   * @private @const {?TrustedTypePolicy}
   */
  goog.TRUSTED_TYPES_POLICY_ = goog.TRUSTED_TYPES_POLICY_NAME ?
      goog.createTrustedTypesPolicy(goog.TRUSTED_TYPES_POLICY_NAME + '#base') :
      null;

  if (!goog.global.CLOSURE_NO_DEPS) {
    goog.debugLoader_.loadClosureDeps();
  }


  /**
   * Bootstraps the given namespaces and calls the callback once they are
   * available either via goog.require. This is a replacement for using
   * `goog.require` to bootstrap Closure JavaScript. Previously a `goog.require`
   * in an HTML file would guarantee that the require'd namespace was available
   * in the next immediate script tag. With ES6 modules this no longer a
   * guarantee.
   *
   * @param {!Array<string>} namespaces
   * @param {function(): ?} callback Function to call once all the namespaces
   *     have loaded. Always called asynchronously.
   */
  goog.bootstrap = function(namespaces, callback) {
    goog.debugLoader_.bootstrap(namespaces, callback);
  };
}


if (!COMPILED) {
  var isChrome87 = false;
  // Cannot run check for Chrome <87 bug in case of strict CSP environments.
  // TODO(aaronshim): Remove once Chrome <87 bug is no longer a problem.
  try {
    isChrome87 = eval(goog.global.trustedTypes.emptyScript) !==
        goog.global.trustedTypes.emptyScript;
  } catch (err) {
  }

  /**
   * Trusted Types for running dev servers.
   *
   * @private @const
   */
  goog.CLOSURE_EVAL_PREFILTER_ =
      // Detect Chrome <87 bug with TT and eval.
      goog.global.trustedTypes && isChrome87 &&
          goog.createTrustedTypesPolicy('goog#base#devonly#eval') ||
      {createScript: goog.identity_};
}

//third_party/javascript/lodash/lodash.4.min.js
/**
 * @license
 * Lodash <https://lodash.com/>
 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */
(/** @suppress {checkTypes|suspiciousCode|uselessCode|globalThis|checkVars} */
function(){function n(n,t,r){switch(r.length){case 0:return n.call(t);case 1:return n.call(t,r[0]);case 2:return n.call(t,r[0],r[1]);case 3:return n.call(t,r[0],r[1],r[2])}return n.apply(t,r)}function t(n,t,r,e){for(var u=-1,i=null==n?0:n.length;++u<i;){var o=n[u];t(e,o,r(o),n)}return e}function r(n,t){for(var r=-1,e=null==n?0:n.length;++r<e&&t(n[r],r,n)!==!1;);return n}function e(n,t){for(var r=null==n?0:n.length;r--&&t(n[r],r,n)!==!1;);return n}function u(n,t){for(var r=-1,e=null==n?0:n.length;++r<e;)if(!t(n[r],r,n))return!1;
return!0}function i(n,t){for(var r=-1,e=null==n?0:n.length,u=0,i=[];++r<e;){var o=n[r];t(o,r,n)&&(i[u++]=o)}return i}function o(n,t){return!!(null==n?0:n.length)&&y(n,t,0)>-1}function f(n,t,r){for(var e=-1,u=null==n?0:n.length;++e<u;)if(r(t,n[e]))return!0;return!1}function c(n,t){for(var r=-1,e=null==n?0:n.length,u=Array(e);++r<e;)u[r]=t(n[r],r,n);return u}function a(n,t){for(var r=-1,e=t.length,u=n.length;++r<e;)n[u+r]=t[r];return n}function l(n,t,r,e){var u=-1,i=null==n?0:n.length;for(e&&i&&(r=n[++u]);++u<i;)r=t(r,n[u],u,n);
return r}function s(n,t,r,e){var u=null==n?0:n.length;for(e&&u&&(r=n[--u]);u--;)r=t(r,n[u],u,n);return r}function h(n,t){for(var r=-1,e=null==n?0:n.length;++r<e;)if(t(n[r],r,n))return!0;return!1}function p(n){return n.split("")}function v(n){return n.match(Ct)||[]}function _(n,t,r){var e;return r(n,function(n,r,u){if(t(n,r,u))return e=r,!1}),e}function g(n,t,r,e){for(var u=n.length,i=r+(e?1:-1);e?i--:++i<u;)if(t(n[i],i,n))return i;return-1}function y(n,t,r){return t===t?q(n,t,r):g(n,b,r)}function d(n,t,r,e){
for(var u=r-1,i=n.length;++u<i;)if(e(n[u],t))return u;return-1}function b(n){return n!==n}function w(n,t){var r=null==n?0:n.length;return r?k(n,t)/r:Wn}function m(n){return function(t){return null==t?Q:t[n]}}function x(n){return function(t){return null==n?Q:n[t]}}function j(n,t,r,e,u){return u(n,function(n,u,i){r=e?(e=!1,n):t(r,n,u,i)}),r}function A(n,t){var r=n.length;for(n.sort(t);r--;)n[r]=n[r].value;return n}function k(n,t){for(var r,e=-1,u=n.length;++e<u;){var i=t(n[e]);i!==Q&&(r=r===Q?i:r+i);
}return r}function O(n,t){for(var r=-1,e=Array(n);++r<n;)e[r]=t(r);return e}function I(n,t){return c(t,function(t){return[t,n[t]]})}function z(n){return n?n.slice(0,G(n)+1).replace(zt,""):n}function E(n){return function(t){return n(t)}}function R(n,t){return c(t,function(t){return n[t]})}function S(n,t){return n.has(t)}function W(n,t){for(var r=-1,e=n.length;++r<e&&y(t,n[r],0)>-1;);return r}function C(n,t){for(var r=n.length;r--&&y(t,n[r],0)>-1;);return r}function L(n,t){for(var r=n.length,e=0;r--;)n[r]===t&&++e;
return e}function B(n,t){return null==n?Q:n[t]}function T(n){return Cr.test(n)}function U(n){return Lr.test(n)}function D(n){for(var t,r=[];!(t=n.next()).done;)r.push(t.value);return r}function $(n){var t=-1,r=Array(n.size);return n.forEach(function(n,e){r[++t]=[e,n]}),r}function M(n,t){return function(r){return n(t(r))}}function F(n,t){for(var r=-1,e=n.length,u=0,i=[];++r<e;){var o=n[r];o!==t&&o!==on||(n[r]=on,i[u++]=r)}return i}function N(n){var t=-1,r=Array(n.size);return n.forEach(function(n){
r[++t]=n}),r}function P(n){var t=-1,r=Array(n.size);return n.forEach(function(n){r[++t]=[n,n]}),r}function q(n,t,r){for(var e=r-1,u=n.length;++e<u;)if(n[e]===t)return e;return-1}function Z(n,t,r){for(var e=r+1;e--;)if(n[e]===t)return e;return e}function K(n){return T(n)?H(n):ee(n)}function V(n){return T(n)?J(n):p(n)}function G(n){for(var t=n.length;t--&&Et.test(n.charAt(t)););return t}function H(n){for(var t=Sr.lastIndex=0;Sr.test(n);)++t;return t}function J(n){return n.match(Sr)||[]}function Y(n){
return n.match(Wr)||[]}var Q,X="4.17.21",nn=200,tn="Unsupported core-js use. Try https://npms.io/search?q=ponyfill.",rn="Expected a function",en="__lodash_hash_undefined__",un=500,on="__lodash_placeholder__",fn=1,cn=2,an=4,ln=1,sn=2,hn=1,pn=2,vn=4,_n=8,gn=16,yn=32,dn=64,bn=128,wn=256,mn=512,xn=30,jn="...",An=800,kn=16,On=1,In=2,zn=3,En=1/0,Rn=9007199254740991,Sn=1.7976931348623157e308,Wn=NaN,Cn=4294967295,Ln=Cn-1,Bn=Cn>>>1,Tn=[["ary",bn],["bind",hn],["bindKey",pn],["curry",_n],["curryRight",gn],["flip",mn],["partial",yn],["partialRight",dn],["rearg",wn]],Un="[object Arguments]",Dn="[object Array]",$n="[object AsyncFunction]",Mn="[object Boolean]",Fn="[object Date]",Nn="[object DOMException]",Pn="[object Error]",qn="[object Function]",Zn="[object GeneratorFunction]",Kn="[object Map]",Vn="[object Number]",Gn="[object Null]",Hn="[object Object]",Jn="[object Promise]",Yn="[object Proxy]",Qn="[object RegExp]",Xn="[object Set]",nt="[object String]",tt="[object Symbol]",rt="[object Undefined]",et="[object WeakMap]",ut="[object WeakSet]",it="[object ArrayBuffer]",ot="[object DataView]",ft="[object Float32Array]",ct="[object Float64Array]",at="[object Int8Array]",lt="[object Int16Array]",st="[object Int32Array]",ht="[object Uint8Array]",pt="[object Uint8ClampedArray]",vt="[object Uint16Array]",_t="[object Uint32Array]",gt=/&(?:amp|lt|gt|quot|#39);/g,yt=/[&<>"']/g,dt=RegExp(gt.source),bt=RegExp(yt.source),wt=/<%-([\s\S]+?)%>/g,mt=/<%([\s\S]+?)%>/g,xt=/<%=([\s\S]+?)%>/g,jt=/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,At=/^\w*$/,kt=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,Ot=/[\\^$.*+?()[\]{}|]/g,It=RegExp(Ot.source),zt=/^\s+/,Et=/\s/,Rt=/\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,St=/\{\n\/\* \[wrapped with (.+)\] \*/,Wt=/,? & /,Ct=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,Lt=/\\(\\)?/g,Bt=/\w*$/,Tt=/^[-+]0x[0-9a-f]+$/i,Ut=/^0b[01]+$/i,Dt=/^\[object .+?Constructor\]$/,$t=/^0o[0-7]+$/i,Mt=/^(?:0|[1-9]\d*)$/,Ft=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,Nt="\\ud800-\\udfff",Pt="\\u0300-\\u036f",qt="\\ufe20-\\ufe2f",Zt="\\u20d0-\\u20ff",Kt=Pt+qt+Zt,Vt="\\u2700-\\u27bf",Gt="a-z\\xdf-\\xf6\\xf8-\\xff",Ht="\\xac\\xb1\\xd7\\xf7",Jt="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",Yt="\\u2000-\\u206f",Qt=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",Xt="A-Z\\xc0-\\xd6\\xd8-\\xde",nr="\\ufe0e\\ufe0f",tr=Ht+Jt+Yt+Qt,rr="['\u2019]",er="["+Nt+"]",ur="["+tr+"]",ir="["+Kt+"]",or="\\d+",fr="["+Vt+"]",cr="["+Gt+"]",ar="[^"+Nt+tr+or+Vt+Gt+Xt+"]",lr="\\ud83c[\\udffb-\\udfff]",sr="(?:"+ir+"|"+lr+")",hr="[^"+Nt+"]",pr="(?:\\ud83c[\\udde6-\\uddff]){2}",vr="[\\ud800-\\udbff][\\udc00-\\udfff]",_r="["+Xt+"]",gr="\\u200d",yr="(?:"+cr+"|"+ar+")",dr="(?:"+_r+"|"+ar+")",br="(?:"+rr+"(?:d|ll|m|re|s|t|ve))?",wr="(?:"+rr+"(?:D|LL|M|RE|S|T|VE))?",mr=sr+"?",xr="["+nr+"]?",jr="(?:"+gr+"(?:"+[hr,pr,vr].join("|")+")"+xr+mr+")*",Ar="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",kr="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",Or=xr+mr+jr,Ir="(?:"+[fr,pr,vr].join("|")+")"+Or,zr="(?:"+[hr+ir+"?",ir,pr,vr,er].join("|")+")",Er=RegExp(rr,"g"),Rr=RegExp(ir,"g"),Sr=RegExp(lr+"(?="+lr+")|"+zr+Or,"g"),Wr=RegExp([_r+"?"+cr+"+"+br+"(?="+[ur,_r,"$"].join("|")+")",dr+"+"+wr+"(?="+[ur,_r+yr,"$"].join("|")+")",_r+"?"+yr+"+"+br,_r+"+"+wr,kr,Ar,or,Ir].join("|"),"g"),Cr=RegExp("["+gr+Nt+Kt+nr+"]"),Lr=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,Br=["Array","Buffer","DataView","Date","Error","Float32Array","Float64Array","Function","Int8Array","Int16Array","Int32Array","Map","Math","Object","Promise","RegExp","Set","String","Symbol","TypeError","Uint8Array","Uint8ClampedArray","Uint16Array","Uint32Array","WeakMap","_","clearTimeout","isFinite","parseInt","setTimeout"],Tr={};
Tr[ft]=Tr[ct]=Tr[at]=Tr[lt]=Tr[st]=Tr[ht]=Tr[pt]=Tr[vt]=Tr[_t]=!0,Tr[Un]=Tr[Dn]=Tr[it]=Tr[Mn]=Tr[ot]=Tr[Fn]=Tr[Pn]=Tr[qn]=Tr[Kn]=Tr[Vn]=Tr[Hn]=Tr[Qn]=Tr[Xn]=Tr[nt]=Tr[et]=!1;var Ur={};Ur[Un]=Ur[Dn]=Ur[it]=Ur[ot]=Ur[Mn]=Ur[Fn]=Ur[ft]=Ur[ct]=Ur[at]=Ur[lt]=Ur[st]=Ur[Kn]=Ur[Vn]=Ur[Hn]=Ur[Qn]=Ur[Xn]=Ur[nt]=Ur[tt]=Ur[ht]=Ur[pt]=Ur[vt]=Ur[_t]=!0,Ur[Pn]=Ur[qn]=Ur[et]=!1;var Dr={"\xc0":"A","\xc1":"A","\xc2":"A","\xc3":"A","\xc4":"A","\xc5":"A","\xe0":"a","\xe1":"a","\xe2":"a","\xe3":"a","\xe4":"a","\xe5":"a",
"\xc7":"C","\xe7":"c","\xd0":"D","\xf0":"d","\xc8":"E","\xc9":"E","\xca":"E","\xcb":"E","\xe8":"e","\xe9":"e","\xea":"e","\xeb":"e","\xcc":"I","\xcd":"I","\xce":"I","\xcf":"I","\xec":"i","\xed":"i","\xee":"i","\xef":"i","\xd1":"N","\xf1":"n","\xd2":"O","\xd3":"O","\xd4":"O","\xd5":"O","\xd6":"O","\xd8":"O","\xf2":"o","\xf3":"o","\xf4":"o","\xf5":"o","\xf6":"o","\xf8":"o","\xd9":"U","\xda":"U","\xdb":"U","\xdc":"U","\xf9":"u","\xfa":"u","\xfb":"u","\xfc":"u","\xdd":"Y","\xfd":"y","\xff":"y","\xc6":"Ae",
"\xe6":"ae","\xde":"Th","\xfe":"th","\xdf":"ss","\u0100":"A","\u0102":"A","\u0104":"A","\u0101":"a","\u0103":"a","\u0105":"a","\u0106":"C","\u0108":"C","\u010a":"C","\u010c":"C","\u0107":"c","\u0109":"c","\u010b":"c","\u010d":"c","\u010e":"D","\u0110":"D","\u010f":"d","\u0111":"d","\u0112":"E","\u0114":"E","\u0116":"E","\u0118":"E","\u011a":"E","\u0113":"e","\u0115":"e","\u0117":"e","\u0119":"e","\u011b":"e","\u011c":"G","\u011e":"G","\u0120":"G","\u0122":"G","\u011d":"g","\u011f":"g","\u0121":"g",
"\u0123":"g","\u0124":"H","\u0126":"H","\u0125":"h","\u0127":"h","\u0128":"I","\u012a":"I","\u012c":"I","\u012e":"I","\u0130":"I","\u0129":"i","\u012b":"i","\u012d":"i","\u012f":"i","\u0131":"i","\u0134":"J","\u0135":"j","\u0136":"K","\u0137":"k","\u0138":"k","\u0139":"L","\u013b":"L","\u013d":"L","\u013f":"L","\u0141":"L","\u013a":"l","\u013c":"l","\u013e":"l","\u0140":"l","\u0142":"l","\u0143":"N","\u0145":"N","\u0147":"N","\u014a":"N","\u0144":"n","\u0146":"n","\u0148":"n","\u014b":"n","\u014c":"O",
"\u014e":"O","\u0150":"O","\u014d":"o","\u014f":"o","\u0151":"o","\u0154":"R","\u0156":"R","\u0158":"R","\u0155":"r","\u0157":"r","\u0159":"r","\u015a":"S","\u015c":"S","\u015e":"S","\u0160":"S","\u015b":"s","\u015d":"s","\u015f":"s","\u0161":"s","\u0162":"T","\u0164":"T","\u0166":"T","\u0163":"t","\u0165":"t","\u0167":"t","\u0168":"U","\u016a":"U","\u016c":"U","\u016e":"U","\u0170":"U","\u0172":"U","\u0169":"u","\u016b":"u","\u016d":"u","\u016f":"u","\u0171":"u","\u0173":"u","\u0174":"W","\u0175":"w",
"\u0176":"Y","\u0177":"y","\u0178":"Y","\u0179":"Z","\u017b":"Z","\u017d":"Z","\u017a":"z","\u017c":"z","\u017e":"z","\u0132":"IJ","\u0133":"ij","\u0152":"Oe","\u0153":"oe","\u0149":"'n","\u017f":"s"},$r={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},Mr={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"',"&#39;":"'"},Fr=parseFloat,Nr=parseInt,Pr="object"==typeof global&&global&&global.Object===Object&&global,qr="object"==typeof self&&self&&self.Object===Object&&self,Zr=Pr||qr||Function("return this")(),Kr="object"==typeof exports&&exports&&!exports.nodeType&&exports,Vr=Kr&&"object"==typeof module&&module&&!module.nodeType&&module,Gr=Vr&&Vr.exports===Kr,Hr=Gr&&Pr.process,Jr=function(){
try{var n=Vr&&Vr.require&&Vr.require("util").types;return n?n:Hr&&Hr.binding&&Hr.binding("util")}catch(n){}}(),Yr=Jr&&Jr.isArrayBuffer,Qr=Jr&&Jr.isDate,Xr=Jr&&Jr.isMap,ne=Jr&&Jr.isRegExp,te=Jr&&Jr.isSet,re=Jr&&Jr.isTypedArray,ee=m("length"),ue=x(Dr),ie=x($r),oe=x(Mr),fe=function p(x){function q(n){if(Yf(n)&&!fh(n)&&!(n instanceof Et)){if(n instanceof J)return n;if(fl.call(n,"__wrapped__"))return Ki(n)}return new J(n)}function H(){}function J(n,t){this.__wrapped__=n,this.__actions__=[],this.__chain__=!!t,
this.__index__=0,this.__values__=Q}function Et(n){this.__wrapped__=n,this.__actions__=[],this.__dir__=1,this.__filtered__=!1,this.__iteratees__=[],this.__takeCount__=Cn,this.__views__=[]}function Ct(){var n=new Et(this.__wrapped__);return n.__actions__=Iu(this.__actions__),n.__dir__=this.__dir__,n.__filtered__=this.__filtered__,n.__iteratees__=Iu(this.__iteratees__),n.__takeCount__=this.__takeCount__,n.__views__=Iu(this.__views__),n}function Nt(){if(this.__filtered__){var n=new Et(this);n.__dir__=-1,
n.__filtered__=!0}else n=this.clone(),n.__dir__*=-1;return n}function Pt(){var n=this.__wrapped__.value(),t=this.__dir__,r=fh(n),e=t<0,u=r?n.length:0,i=_i(0,u,this.__views__),o=i.start,f=i.end,c=f-o,a=e?f:o-1,l=this.__iteratees__,s=l.length,h=0,p=Ul(c,this.__takeCount__);if(!r||!e&&u==c&&p==c)return lu(n,this.__actions__);var v=[];n:for(;c--&&h<p;){a+=t;for(var _=-1,g=n[a];++_<s;){var y=l[_],d=y.iteratee,b=y.type,w=d(g);if(b==In)g=w;else if(!w){if(b==On)continue n;break n}}v[h++]=g}return v}function qt(n){
var t=-1,r=null==n?0:n.length;for(this.clear();++t<r;){var e=n[t];this.set(e[0],e[1])}}function Zt(){this.__data__=Vl?Vl(null):{},this.size=0}function Kt(n){var t=this.has(n)&&delete this.__data__[n];return this.size-=t?1:0,t}function Vt(n){var t=this.__data__;if(Vl){var r=t[n];return r===en?Q:r}return fl.call(t,n)?t[n]:Q}function Gt(n){var t=this.__data__;return Vl?t[n]!==Q:fl.call(t,n)}function Ht(n,t){var r=this.__data__;return this.size+=this.has(n)?0:1,r[n]=Vl&&t===Q?en:t,this}function Jt(n){
var t=-1,r=null==n?0:n.length;for(this.clear();++t<r;){var e=n[t];this.set(e[0],e[1])}}function Yt(){this.__data__=[],this.size=0}function Qt(n){var t=this.__data__,r=jr(t,n);return!(r<0)&&(r==t.length-1?t.pop():ml.call(t,r,1),--this.size,!0)}function Xt(n){var t=this.__data__,r=jr(t,n);return r<0?Q:t[r][1]}function nr(n){return jr(this.__data__,n)>-1}function tr(n,t){var r=this.__data__,e=jr(r,n);return e<0?(++this.size,r.push([n,t])):r[e][1]=t,this}function rr(n){var t=-1,r=null==n?0:n.length;for(this.clear();++t<r;){
var e=n[t];this.set(e[0],e[1])}}function er(){this.size=0,this.__data__={hash:new qt,map:new(Pl||Jt),string:new qt}}function ur(n){var t=si(this,n).delete(n);return this.size-=t?1:0,t}function ir(n){return si(this,n).get(n)}function or(n){return si(this,n).has(n)}function fr(n,t){var r=si(this,n),e=r.size;return r.set(n,t),this.size+=r.size==e?0:1,this}function cr(n){var t=-1,r=null==n?0:n.length;for(this.__data__=new rr;++t<r;)this.add(n[t])}function ar(n){return this.__data__.set(n,en),this}function lr(n){
return this.__data__.has(n)}function sr(n){this.size=(this.__data__=new Jt(n)).size}function hr(){this.__data__=new Jt,this.size=0}function pr(n){var t=this.__data__,r=t.delete(n);return this.size=t.size,r}function vr(n){return this.__data__.get(n)}function _r(n){return this.__data__.has(n)}function gr(n,t){var r=this.__data__;if(r instanceof Jt){var e=r.__data__;if(!Pl||e.length<nn-1)return e.push([n,t]),this.size=++r.size,this;r=this.__data__=new rr(e)}return r.set(n,t),this.size=r.size,this}function yr(n,t){
var r=fh(n),e=!r&&oh(n),u=!r&&!e&&ah(n),i=!r&&!e&&!u&&vh(n),o=r||e||u||i,f=o?O(n.length,nl):[],c=f.length;for(var a in n)!t&&!fl.call(n,a)||o&&("length"==a||u&&("offset"==a||"parent"==a)||i&&("buffer"==a||"byteLength"==a||"byteOffset"==a)||ji(a,c))||f.push(a);return f}function dr(n){var t=n.length;return t?n[Ze(0,t-1)]:Q}function br(n,t){return Ni(Iu(n),Sr(t,0,n.length))}function wr(n){return Ni(Iu(n))}function mr(n,t,r){(r===Q||Uf(n[t],r))&&(r!==Q||t in n)||Ir(n,t,r)}function xr(n,t,r){var e=n[t];
fl.call(n,t)&&Uf(e,r)&&(r!==Q||t in n)||Ir(n,t,r)}function jr(n,t){for(var r=n.length;r--;)if(Uf(n[r][0],t))return r;return-1}function Ar(n,t,r,e){return is(n,function(n,u,i){t(e,n,r(n),i)}),e}function kr(n,t){return n&&zu(t,Wc(t),n)}function Or(n,t){return n&&zu(t,Cc(t),n)}function Ir(n,t,r){"__proto__"==t&&kl?kl(n,t,{configurable:!0,enumerable:!0,value:r,writable:!0}):n[t]=r}function zr(n,t){for(var r=-1,e=t.length,u=Va(e),i=null==n;++r<e;)u[r]=i?Q:Ec(n,t[r]);return u}function Sr(n,t,r){return n===n&&(r!==Q&&(n=n<=r?n:r),
t!==Q&&(n=n>=t?n:t)),n}function Wr(n,t,e,u,i,o){var f,c=t&fn,a=t&cn,l=t&an;if(e&&(f=i?e(n,u,i,o):e(n)),f!==Q)return f;if(!Jf(n))return n;var s=fh(n);if(s){if(f=di(n),!c)return Iu(n,f)}else{var h=ys(n),p=h==qn||h==Zn;if(ah(n))return yu(n,c);if(h==Hn||h==Un||p&&!i){if(f=a||p?{}:bi(n),!c)return a?Ru(n,Or(f,n)):Eu(n,kr(f,n))}else{if(!Ur[h])return i?n:{};f=wi(n,h,c)}}o||(o=new sr);var v=o.get(n);if(v)return v;o.set(n,f),ph(n)?n.forEach(function(r){f.add(Wr(r,t,e,r,n,o))}):sh(n)&&n.forEach(function(r,u){
f.set(u,Wr(r,t,e,u,n,o))});var _=l?a?fi:oi:a?Cc:Wc,g=s?Q:_(n);return r(g||n,function(r,u){g&&(u=r,r=n[u]),xr(f,u,Wr(r,t,e,u,n,o))}),f}function Cr(n){var t=Wc(n);return function(r){return Lr(r,n,t)}}function Lr(n,t,r){var e=r.length;if(null==n)return!e;for(n=Qa(n);e--;){var u=r[e],i=t[u],o=n[u];if(o===Q&&!(u in n)||!i(o))return!1}return!0}function Dr(n,t,r){if("function"!=typeof n)throw new tl(rn);return ws(function(){n.apply(Q,r)},t)}function $r(n,t,r,e){var u=-1,i=o,a=!0,l=n.length,s=[],h=t.length;
if(!l)return s;r&&(t=c(t,E(r))),e?(i=f,a=!1):t.length>=nn&&(i=S,a=!1,t=new cr(t));n:for(;++u<l;){var p=n[u],v=null==r?p:r(p);if(p=e||0!==p?p:0,a&&v===v){for(var _=h;_--;)if(t[_]===v)continue n;s.push(p)}else i(t,v,e)||s.push(p)}return s}function Mr(n,t){var r=!0;return is(n,function(n,e,u){return r=!!t(n,e,u)}),r}function Pr(n,t,r){for(var e=-1,u=n.length;++e<u;){var i=n[e],o=t(i);if(null!=o&&(f===Q?o===o&&!cc(o):r(o,f)))var f=o,c=i}return c}function qr(n,t,r,e){var u=n.length;for(r=vc(r),r<0&&(r=-r>u?0:u+r),
e=e===Q||e>u?u:vc(e),e<0&&(e+=u),e=r>e?0:_c(e);r<e;)n[r++]=t;return n}function Kr(n,t){var r=[];return is(n,function(n,e,u){t(n,e,u)&&r.push(n)}),r}function Vr(n,t,r,e,u){var i=-1,o=n.length;for(r||(r=xi),u||(u=[]);++i<o;){var f=n[i];t>0&&r(f)?t>1?Vr(f,t-1,r,e,u):a(u,f):e||(u[u.length]=f)}return u}function Hr(n,t){return n&&fs(n,t,Wc)}function Jr(n,t){return n&&cs(n,t,Wc)}function ee(n,t){return i(t,function(t){return Vf(n[t])})}function fe(n,t){t=_u(t,n);for(var r=0,e=t.length;null!=n&&r<e;)n=n[Pi(t[r++])];
return r&&r==e?n:Q}function ae(n,t,r){var e=t(n);return fh(n)?e:a(e,r(n))}function le(n){return null==n?n===Q?rt:Gn:Al&&Al in Qa(n)?vi(n):Bi(n)}function se(n,t){return n>t}function he(n,t){return null!=n&&fl.call(n,t)}function pe(n,t){return null!=n&&t in Qa(n)}function ve(n,t,r){return n>=Ul(t,r)&&n<Tl(t,r)}function _e(n,t,r){for(var e=r?f:o,u=n[0].length,i=n.length,a=i,l=Va(i),s=1/0,h=[];a--;){var p=n[a];a&&t&&(p=c(p,E(t))),s=Ul(p.length,s),l[a]=!r&&(t||u>=120&&p.length>=120)?new cr(a&&p):Q}p=n[0];
var v=-1,_=l[0];n:for(;++v<u&&h.length<s;){var g=p[v],y=t?t(g):g;if(g=r||0!==g?g:0,!(_?S(_,y):e(h,y,r))){for(a=i;--a;){var d=l[a];if(!(d?S(d,y):e(n[a],y,r)))continue n}_&&_.push(y),h.push(g)}}return h}function ge(n,t,r,e){return Hr(n,function(n,u,i){t(e,r(n),u,i)}),e}function ye(t,r,e){r=_u(r,t),t=Ui(t,r);var u=null==t?t:t[Pi(so(r))];return null==u?Q:n(u,t,e)}function de(n){return Yf(n)&&le(n)==Un}function be(n){return Yf(n)&&le(n)==it}function we(n){return Yf(n)&&le(n)==Fn}function me(n,t,r,e,u){
return n===t||(null==n||null==t||!Yf(n)&&!Yf(t)?n!==n&&t!==t:xe(n,t,r,e,me,u))}function xe(n,t,r,e,u,i){var o=fh(n),f=fh(t),c=o?Dn:ys(n),a=f?Dn:ys(t);c=c==Un?Hn:c,a=a==Un?Hn:a;var l=c==Hn,s=a==Hn,h=c==a;if(h&&ah(n)){if(!ah(t))return!1;o=!0,l=!1}if(h&&!l)return i||(i=new sr),o||vh(n)?ri(n,t,r,e,u,i):ei(n,t,c,r,e,u,i);if(!(r&ln)){var p=l&&fl.call(n,"__wrapped__"),v=s&&fl.call(t,"__wrapped__");if(p||v){var _=p?n.value():n,g=v?t.value():t;return i||(i=new sr),u(_,g,r,e,i)}}return!!h&&(i||(i=new sr),ui(n,t,r,e,u,i));
}function je(n){return Yf(n)&&ys(n)==Kn}function Ae(n,t,r,e){var u=r.length,i=u,o=!e;if(null==n)return!i;for(n=Qa(n);u--;){var f=r[u];if(o&&f[2]?f[1]!==n[f[0]]:!(f[0]in n))return!1}for(;++u<i;){f=r[u];var c=f[0],a=n[c],l=f[1];if(o&&f[2]){if(a===Q&&!(c in n))return!1}else{var s=new sr;if(e)var h=e(a,l,c,n,t,s);if(!(h===Q?me(l,a,ln|sn,e,s):h))return!1}}return!0}function ke(n){return!(!Jf(n)||zi(n))&&(Vf(n)?pl:Dt).test(qi(n))}function Oe(n){return Yf(n)&&le(n)==Qn}function Ie(n){return Yf(n)&&ys(n)==Xn;
}function ze(n){return Yf(n)&&Hf(n.length)&&!!Tr[le(n)]}function Ee(n){return"function"==typeof n?n:null==n?ma:"object"==typeof n?fh(n)?Be(n[0],n[1]):Le(n):Ea(n)}function Re(n){if(!Ei(n))return Bl(n);var t=[];for(var r in Qa(n))fl.call(n,r)&&"constructor"!=r&&t.push(r);return t}function Se(n){if(!Jf(n))return Li(n);var t=Ei(n),r=[];for(var e in n)("constructor"!=e||!t&&fl.call(n,e))&&r.push(e);return r}function We(n,t){return n<t}function Ce(n,t){var r=-1,e=Df(n)?Va(n.length):[];return is(n,function(n,u,i){
e[++r]=t(n,u,i)}),e}function Le(n){var t=hi(n);return 1==t.length&&t[0][2]?Si(t[0][0],t[0][1]):function(r){return r===n||Ae(r,n,t)}}function Be(n,t){return ki(n)&&Ri(t)?Si(Pi(n),t):function(r){var e=Ec(r,n);return e===Q&&e===t?Sc(r,n):me(t,e,ln|sn)}}function Te(n,t,r,e,u){n!==t&&fs(t,function(i,o){if(u||(u=new sr),Jf(i))Ue(n,t,o,r,Te,e,u);else{var f=e?e($i(n,o),i,o+"",n,t,u):Q;f===Q&&(f=i),mr(n,o,f)}},Cc)}function Ue(n,t,r,e,u,i,o){var f=$i(n,r),c=$i(t,r),a=o.get(c);if(a)return mr(n,r,a),Q;var l=i?i(f,c,r+"",n,t,o):Q,s=l===Q;
if(s){var h=fh(c),p=!h&&ah(c),v=!h&&!p&&vh(c);l=c,h||p||v?fh(f)?l=f:$f(f)?l=Iu(f):p?(s=!1,l=yu(c,!0)):v?(s=!1,l=xu(c,!0)):l=[]:ic(c)||oh(c)?(l=f,oh(f)?l=yc(f):Jf(f)&&!Vf(f)||(l=bi(c))):s=!1}s&&(o.set(c,l),u(l,c,e,i,o),o.delete(c)),mr(n,r,l)}function De(n,t){var r=n.length;if(r)return t+=t<0?r:0,ji(t,r)?n[t]:Q}function $e(n,t,r){t=t.length?c(t,function(n){return fh(n)?function(t){return fe(t,1===n.length?n[0]:n)}:n}):[ma];var e=-1;return t=c(t,E(li())),A(Ce(n,function(n,r,u){return{criteria:c(t,function(t){
return t(n)}),index:++e,value:n}}),function(n,t){return Au(n,t,r)})}function Me(n,t){return Fe(n,t,function(t,r){return Sc(n,r)})}function Fe(n,t,r){for(var e=-1,u=t.length,i={};++e<u;){var o=t[e],f=fe(n,o);r(f,o)&&Ye(i,_u(o,n),f)}return i}function Ne(n){return function(t){return fe(t,n)}}function Pe(n,t,r,e){var u=e?d:y,i=-1,o=t.length,f=n;for(n===t&&(t=Iu(t)),r&&(f=c(n,E(r)));++i<o;)for(var a=0,l=t[i],s=r?r(l):l;(a=u(f,s,a,e))>-1;)f!==n&&ml.call(f,a,1),ml.call(n,a,1);return n}function qe(n,t){for(var r=n?t.length:0,e=r-1;r--;){
var u=t[r];if(r==e||u!==i){var i=u;ji(u)?ml.call(n,u,1):fu(n,u)}}return n}function Ze(n,t){return n+Rl(Ml()*(t-n+1))}function Ke(n,t,r,e){for(var u=-1,i=Tl(El((t-n)/(r||1)),0),o=Va(i);i--;)o[e?i:++u]=n,n+=r;return o}function Ve(n,t){var r="";if(!n||t<1||t>Rn)return r;do t%2&&(r+=n),t=Rl(t/2),t&&(n+=n);while(t);return r}function Ge(n,t){return ms(Ti(n,t,ma),n+"")}function He(n){return dr(Zc(n))}function Je(n,t){var r=Zc(n);return Ni(r,Sr(t,0,r.length))}function Ye(n,t,r,e){if(!Jf(n))return n;t=_u(t,n);
for(var u=-1,i=t.length,o=i-1,f=n;null!=f&&++u<i;){var c=Pi(t[u]),a=r;if("__proto__"===c||"constructor"===c||"prototype"===c)return n;if(u!=o){var l=f[c];a=e?e(l,c,f):Q,a===Q&&(a=Jf(l)?l:ji(t[u+1])?[]:{})}xr(f,c,a),f=f[c]}return n}function Qe(n){return Ni(Zc(n))}function Xe(n,t,r){var e=-1,u=n.length;t<0&&(t=-t>u?0:u+t),r=r>u?u:r,r<0&&(r+=u),u=t>r?0:r-t>>>0,t>>>=0;for(var i=Va(u);++e<u;)i[e]=n[e+t];return i}function nu(n,t){var r;return is(n,function(n,e,u){return r=t(n,e,u),!r}),!!r}function tu(n,t,r){
var e=0,u=null==n?e:n.length;if("number"==typeof t&&t===t&&u<=Bn){for(;e<u;){var i=e+u>>>1,o=n[i];null!==o&&!cc(o)&&(r?o<=t:o<t)?e=i+1:u=i}return u}return ru(n,t,ma,r)}function ru(n,t,r,e){var u=0,i=null==n?0:n.length;if(0===i)return 0;t=r(t);for(var o=t!==t,f=null===t,c=cc(t),a=t===Q;u<i;){var l=Rl((u+i)/2),s=r(n[l]),h=s!==Q,p=null===s,v=s===s,_=cc(s);if(o)var g=e||v;else g=a?v&&(e||h):f?v&&h&&(e||!p):c?v&&h&&!p&&(e||!_):!p&&!_&&(e?s<=t:s<t);g?u=l+1:i=l}return Ul(i,Ln)}function eu(n,t){for(var r=-1,e=n.length,u=0,i=[];++r<e;){
var o=n[r],f=t?t(o):o;if(!r||!Uf(f,c)){var c=f;i[u++]=0===o?0:o}}return i}function uu(n){return"number"==typeof n?n:cc(n)?Wn:+n}function iu(n){if("string"==typeof n)return n;if(fh(n))return c(n,iu)+"";if(cc(n))return es?es.call(n):"";var t=n+"";return"0"==t&&1/n==-En?"-0":t}function ou(n,t,r){var e=-1,u=o,i=n.length,c=!0,a=[],l=a;if(r)c=!1,u=f;else if(i>=nn){var s=t?null:ps(n);if(s)return N(s);c=!1,u=S,l=new cr}else l=t?[]:a;n:for(;++e<i;){var h=n[e],p=t?t(h):h;if(h=r||0!==h?h:0,c&&p===p){for(var v=l.length;v--;)if(l[v]===p)continue n;
t&&l.push(p),a.push(h)}else u(l,p,r)||(l!==a&&l.push(p),a.push(h))}return a}function fu(n,t){return t=_u(t,n),n=Ui(n,t),null==n||delete n[Pi(so(t))]}function cu(n,t,r,e){return Ye(n,t,r(fe(n,t)),e)}function au(n,t,r,e){for(var u=n.length,i=e?u:-1;(e?i--:++i<u)&&t(n[i],i,n););return r?Xe(n,e?0:i,e?i+1:u):Xe(n,e?i+1:0,e?u:i)}function lu(n,t){var r=n;return r instanceof Et&&(r=r.value()),l(t,function(n,t){return t.func.apply(t.thisArg,a([n],t.args))},r)}function su(n,t,r){var e=n.length;if(e<2)return e?ou(n[0]):[];
for(var u=-1,i=Va(e);++u<e;)for(var o=n[u],f=-1;++f<e;)f!=u&&(i[u]=$r(i[u]||o,n[f],t,r));return ou(Vr(i,1),t,r)}function hu(n,t,r){for(var e=-1,u=n.length,i=t.length,o={};++e<u;){r(o,n[e],e<i?t[e]:Q)}return o}function pu(n){return $f(n)?n:[]}function vu(n){return"function"==typeof n?n:ma}function _u(n,t){return fh(n)?n:ki(n,t)?[n]:xs(bc(n))}function gu(n,t,r){var e=n.length;return r=r===Q?e:r,!t&&r>=e?n:Xe(n,t,r)}function yu(n,t){if(t)return n.slice();var r=n.length,e=yl?yl(r):new n.constructor(r);
return n.copy(e),e}function du(n){var t=new n.constructor(n.byteLength);return new gl(t).set(new gl(n)),t}function bu(n,t){return new n.constructor(t?du(n.buffer):n.buffer,n.byteOffset,n.byteLength)}function wu(n){var t=new n.constructor(n.source,Bt.exec(n));return t.lastIndex=n.lastIndex,t}function mu(n){return rs?Qa(rs.call(n)):{}}function xu(n,t){return new n.constructor(t?du(n.buffer):n.buffer,n.byteOffset,n.length)}function ju(n,t){if(n!==t){var r=n!==Q,e=null===n,u=n===n,i=cc(n),o=t!==Q,f=null===t,c=t===t,a=cc(t);
if(!f&&!a&&!i&&n>t||i&&o&&c&&!f&&!a||e&&o&&c||!r&&c||!u)return 1;if(!e&&!i&&!a&&n<t||a&&r&&u&&!e&&!i||f&&r&&u||!o&&u||!c)return-1}return 0}function Au(n,t,r){for(var e=-1,u=n.criteria,i=t.criteria,o=u.length,f=r.length;++e<o;){var c=ju(u[e],i[e]);if(c){if(e>=f)return c;return c*("desc"==r[e]?-1:1)}}return n.index-t.index}function ku(n,t,r,e){for(var u=-1,i=n.length,o=r.length,f=-1,c=t.length,a=Tl(i-o,0),l=Va(c+a),s=!e;++f<c;)l[f]=t[f];for(;++u<o;)(s||u<i)&&(l[r[u]]=n[u]);for(;a--;)l[f++]=n[u++];return l;
}function Ou(n,t,r,e){for(var u=-1,i=n.length,o=-1,f=r.length,c=-1,a=t.length,l=Tl(i-f,0),s=Va(l+a),h=!e;++u<l;)s[u]=n[u];for(var p=u;++c<a;)s[p+c]=t[c];for(;++o<f;)(h||u<i)&&(s[p+r[o]]=n[u++]);return s}function Iu(n,t){var r=-1,e=n.length;for(t||(t=Va(e));++r<e;)t[r]=n[r];return t}function zu(n,t,r,e){var u=!r;r||(r={});for(var i=-1,o=t.length;++i<o;){var f=t[i],c=e?e(r[f],n[f],f,r,n):Q;c===Q&&(c=n[f]),u?Ir(r,f,c):xr(r,f,c)}return r}function Eu(n,t){return zu(n,_s(n),t)}function Ru(n,t){return zu(n,gs(n),t);
}function Su(n,r){return function(e,u){var i=fh(e)?t:Ar,o=r?r():{};return i(e,n,li(u,2),o)}}function Wu(n){return Ge(function(t,r){var e=-1,u=r.length,i=u>1?r[u-1]:Q,o=u>2?r[2]:Q;for(i=n.length>3&&"function"==typeof i?(u--,i):Q,o&&Ai(r[0],r[1],o)&&(i=u<3?Q:i,u=1),t=Qa(t);++e<u;){var f=r[e];f&&n(t,f,e,i)}return t})}function Cu(n,t){return function(r,e){if(null==r)return r;if(!Df(r))return n(r,e);for(var u=r.length,i=t?u:-1,o=Qa(r);(t?i--:++i<u)&&e(o[i],i,o)!==!1;);return r}}function Lu(n){return function(t,r,e){
for(var u=-1,i=Qa(t),o=e(t),f=o.length;f--;){var c=o[n?f:++u];if(r(i[c],c,i)===!1)break}return t}}function Bu(n,t,r){function e(){return(this&&this!==Zr&&this instanceof e?i:n).apply(u?r:this,arguments)}var u=t&hn,i=Du(n);return e}function Tu(n){return function(t){t=bc(t);var r=T(t)?V(t):Q,e=r?r[0]:t.charAt(0),u=r?gu(r,1).join(""):t.slice(1);return e[n]()+u}}function Uu(n){return function(t){return l(ga(Yc(t).replace(Er,"")),n,"")}}function Du(n){return function(){var t=arguments;switch(t.length){
case 0:return new n;case 1:return new n(t[0]);case 2:return new n(t[0],t[1]);case 3:return new n(t[0],t[1],t[2]);case 4:return new n(t[0],t[1],t[2],t[3]);case 5:return new n(t[0],t[1],t[2],t[3],t[4]);case 6:return new n(t[0],t[1],t[2],t[3],t[4],t[5]);case 7:return new n(t[0],t[1],t[2],t[3],t[4],t[5],t[6])}var r=us(n.prototype),e=n.apply(r,t);return Jf(e)?e:r}}function $u(t,r,e){function u(){for(var o=arguments.length,f=Va(o),c=o,a=ai(u);c--;)f[c]=arguments[c];var l=o<3&&f[0]!==a&&f[o-1]!==a?[]:F(f,a);
return o-=l.length,o<e?Ju(t,r,Nu,u.placeholder,Q,f,l,Q,Q,e-o):n(this&&this!==Zr&&this instanceof u?i:t,this,f)}var i=Du(t);return u}function Mu(n){return function(t,r,e){var u=Qa(t);if(!Df(t)){var i=li(r,3);t=Wc(t),r=function(n){return i(u[n],n,u)}}var o=n(t,r,e);return o>-1?u[i?t[o]:o]:Q}}function Fu(n){return ii(function(t){var r=t.length,e=r,u=J.prototype.thru;for(n&&t.reverse();e--;){var i=t[e];if("function"!=typeof i)throw new tl(rn);if(u&&!o&&"wrapper"==ci(i))var o=new J([],!0)}for(e=o?e:r;++e<r;){
i=t[e];var f=ci(i),c="wrapper"==f?vs(i):Q;o=c&&Ii(c[0])&&c[1]==(bn|_n|yn|wn)&&!c[4].length&&1==c[9]?o[ci(c[0])].apply(o,c[3]):1==i.length&&Ii(i)?o[f]():o.thru(i)}return function(){var n=arguments,e=n[0];if(o&&1==n.length&&fh(e))return o.plant(e).value();for(var u=0,i=r?t[u].apply(this,n):e;++u<r;)i=t[u].call(this,i);return i}})}function Nu(n,t,r,e,u,i,o,f,c,a){function l(){for(var y=arguments.length,d=Va(y),b=y;b--;)d[b]=arguments[b];if(v)var w=ai(l),m=L(d,w);if(e&&(d=ku(d,e,u,v)),i&&(d=Ou(d,i,o,v)),
y-=m,v&&y<a){return Ju(n,t,Nu,l.placeholder,r,d,F(d,w),f,c,a-y)}var x=h?r:this,j=p?x[n]:n;return y=d.length,f?d=Di(d,f):_&&y>1&&d.reverse(),s&&c<y&&(d.length=c),this&&this!==Zr&&this instanceof l&&(j=g||Du(j)),j.apply(x,d)}var s=t&bn,h=t&hn,p=t&pn,v=t&(_n|gn),_=t&mn,g=p?Q:Du(n);return l}function Pu(n,t){return function(r,e){return ge(r,n,t(e),{})}}function qu(n,t){return function(r,e){var u;if(r===Q&&e===Q)return t;if(r!==Q&&(u=r),e!==Q){if(u===Q)return e;"string"==typeof r||"string"==typeof e?(r=iu(r),
e=iu(e)):(r=uu(r),e=uu(e)),u=n(r,e)}return u}}function Zu(t){return ii(function(r){return r=c(r,E(li())),Ge(function(e){var u=this;return t(r,function(t){return n(t,u,e)})})})}function Ku(n,t){t=t===Q?" ":iu(t);var r=t.length;if(r<2)return r?Ve(t,n):t;var e=Ve(t,El(n/K(t)));return T(t)?gu(V(e),0,n).join(""):e.slice(0,n)}function Vu(t,r,e,u){function i(){for(var r=-1,c=arguments.length,a=-1,l=u.length,s=Va(l+c),h=this&&this!==Zr&&this instanceof i?f:t;++a<l;)s[a]=u[a];for(;c--;)s[a++]=arguments[++r];
return n(h,o?e:this,s)}var o=r&hn,f=Du(t);return i}function Gu(n){return function(t,r,e){return e&&"number"!=typeof e&&Ai(t,r,e)&&(r=e=Q),t=pc(t),r===Q?(r=t,t=0):r=pc(r),e=e===Q?t<r?1:-1:pc(e),Ke(t,r,e,n)}}function Hu(n){return function(t,r){return"string"==typeof t&&"string"==typeof r||(t=gc(t),r=gc(r)),n(t,r)}}function Ju(n,t,r,e,u,i,o,f,c,a){var l=t&_n,s=l?o:Q,h=l?Q:o,p=l?i:Q,v=l?Q:i;t|=l?yn:dn,t&=~(l?dn:yn),t&vn||(t&=~(hn|pn));var _=[n,t,u,p,s,v,h,f,c,a],g=r.apply(Q,_);return Ii(n)&&bs(g,_),g.placeholder=e,
Mi(g,n,t)}function Yu(n){var t=Ya[n];return function(n,r){if(n=gc(n),r=null==r?0:Ul(vc(r),292),r&&Cl(n)){var e=(bc(n)+"e").split("e");return e=(bc(t(e[0]+"e"+(+e[1]+r)))+"e").split("e"),+(e[0]+"e"+(+e[1]-r))}return t(n)}}function Qu(n){return function(t){var r=ys(t);return r==Kn?$(t):r==Xn?P(t):I(t,n(t))}}function Xu(n,t,r,e,u,i,o,f){var c=t&pn;if(!c&&"function"!=typeof n)throw new tl(rn);var a=e?e.length:0;if(a||(t&=~(yn|dn),e=u=Q),o=o===Q?o:Tl(vc(o),0),f=f===Q?f:vc(f),a-=u?u.length:0,t&dn){var l=e,s=u;
e=u=Q}var h=c?Q:vs(n),p=[n,t,r,e,u,l,s,i,o,f];if(h&&Ci(p,h),n=p[0],t=p[1],r=p[2],e=p[3],u=p[4],f=p[9]=p[9]===Q?c?0:n.length:Tl(p[9]-a,0),!f&&t&(_n|gn)&&(t&=~(_n|gn)),t&&t!=hn)v=t==_n||t==gn?$u(n,t,f):t!=yn&&t!=(hn|yn)||u.length?Nu.apply(Q,p):Vu(n,t,r,e);else var v=Bu(n,t,r);return Mi((h?as:bs)(v,p),n,t)}function ni(n,t,r,e,u,i){return Jf(n)&&Jf(t)&&(i.set(t,n),Te(n,t,Q,ni,i),i.delete(t)),n}function ti(n){return ic(n)?Q:n}function ri(n,t,r,e,u,i){var o=r&ln,f=n.length,c=t.length;if(f!=c&&!(o&&c>f))return!1;
var a=i.get(n),l=i.get(t);if(a&&l)return a==t&&l==n;var s=-1,p=!0,v=r&sn?new cr:Q;for(i.set(n,t),i.set(t,n);++s<f;){var _=n[s],g=t[s];if(e)var y=o?e(g,_,s,t,n,i):e(_,g,s,n,t,i);if(y!==Q){if(y)continue;p=!1;break}if(v){if(!h(t,function(n,t){if(!S(v,t)&&(_===n||u(_,n,r,e,i)))return v.push(t)})){p=!1;break}}else if(_!==g&&!u(_,g,r,e,i)){p=!1;break}}return i.delete(n),i.delete(t),p}function ei(n,t,r,e,u,i,o){switch(r){case ot:if(n.byteLength!=t.byteLength||n.byteOffset!=t.byteOffset)return!1;n=n.buffer,
t=t.buffer;case it:return!(n.byteLength!=t.byteLength||!i(new gl(n),new gl(t)));case Mn:case Fn:case Vn:return Uf(+n,+t);case Pn:return n.name==t.name&&n.message==t.message;case Qn:case nt:return n==t+"";case Kn:var f=$;case Xn:var c=e&ln;if(f||(f=N),n.size!=t.size&&!c)return!1;var a=o.get(n);if(a)return a==t;e|=sn,o.set(n,t);var l=ri(f(n),f(t),e,u,i,o);return o.delete(n),l;case tt:if(rs)return rs.call(n)==rs.call(t)}return!1}function ui(n,t,r,e,u,i){var o=r&ln,f=oi(n),c=f.length;if(c!=oi(t).length&&!o)return!1;
for(var a=c;a--;){var l=f[a];if(!(o?l in t:fl.call(t,l)))return!1}var s=i.get(n),h=i.get(t);if(s&&h)return s==t&&h==n;var p=!0;i.set(n,t),i.set(t,n);for(var v=o;++a<c;){l=f[a];var _=n[l],g=t[l];if(e)var y=o?e(g,_,l,t,n,i):e(_,g,l,n,t,i);if(!(y===Q?_===g||u(_,g,r,e,i):y)){p=!1;break}v||(v="constructor"==l)}if(p&&!v){var d=n.constructor,b=t.constructor;d!=b&&"constructor"in n&&"constructor"in t&&!("function"==typeof d&&d instanceof d&&"function"==typeof b&&b instanceof b)&&(p=!1)}return i.delete(n),
i.delete(t),p}function ii(n){return ms(Ti(n,Q,eo),n+"")}function oi(n){return ae(n,Wc,_s)}function fi(n){return ae(n,Cc,gs)}function ci(n){for(var t=n.name+"",r=Hl[t],e=fl.call(Hl,t)?r.length:0;e--;){var u=r[e],i=u.func;if(null==i||i==n)return u.name}return t}function ai(n){return(fl.call(q,"placeholder")?q:n).placeholder}function li(){var n=q.iteratee||xa;return n=n===xa?Ee:n,arguments.length?n(arguments[0],arguments[1]):n}function si(n,t){var r=n.__data__;return Oi(t)?r["string"==typeof t?"string":"hash"]:r.map;
}function hi(n){for(var t=Wc(n),r=t.length;r--;){var e=t[r],u=n[e];t[r]=[e,u,Ri(u)]}return t}function pi(n,t){var r=B(n,t);return ke(r)?r:Q}function vi(n){var t=fl.call(n,Al),r=n[Al];try{n[Al]=Q;var e=!0}catch(n){}var u=ll.call(n);return e&&(t?n[Al]=r:delete n[Al]),u}function _i(n,t,r){for(var e=-1,u=r.length;++e<u;){var i=r[e],o=i.size;switch(i.type){case"drop":n+=o;break;case"dropRight":t-=o;break;case"take":t=Ul(t,n+o);break;case"takeRight":n=Tl(n,t-o)}}return{start:n,end:t}}function gi(n){var t=n.match(St);
return t?t[1].split(Wt):[]}function yi(n,t,r){t=_u(t,n);for(var e=-1,u=t.length,i=!1;++e<u;){var o=Pi(t[e]);if(!(i=null!=n&&r(n,o)))break;n=n[o]}return i||++e!=u?i:(u=null==n?0:n.length,!!u&&Hf(u)&&ji(o,u)&&(fh(n)||oh(n)))}function di(n){var t=n.length,r=new n.constructor(t);return t&&"string"==typeof n[0]&&fl.call(n,"index")&&(r.index=n.index,r.input=n.input),r}function bi(n){return"function"!=typeof n.constructor||Ei(n)?{}:us(dl(n))}function wi(n,t,r){var e=n.constructor;switch(t){case it:return du(n);
case Mn:case Fn:return new e(+n);case ot:return bu(n,r);case ft:case ct:case at:case lt:case st:case ht:case pt:case vt:case _t:return xu(n,r);case Kn:return new e;case Vn:case nt:return new e(n);case Qn:return wu(n);case Xn:return new e;case tt:return mu(n)}}function mi(n,t){var r=t.length;if(!r)return n;var e=r-1;return t[e]=(r>1?"& ":"")+t[e],t=t.join(r>2?", ":" "),n.replace(Rt,"{\n/* [wrapped with "+t+"] */\n")}function xi(n){return fh(n)||oh(n)||!!(xl&&n&&n[xl])}function ji(n,t){var r=typeof n;
return t=null==t?Rn:t,!!t&&("number"==r||"symbol"!=r&&Mt.test(n))&&n>-1&&n%1==0&&n<t}function Ai(n,t,r){if(!Jf(r))return!1;var e=typeof t;return!!("number"==e?Df(r)&&ji(t,r.length):"string"==e&&t in r)&&Uf(r[t],n)}function ki(n,t){if(fh(n))return!1;var r=typeof n;return!("number"!=r&&"symbol"!=r&&"boolean"!=r&&null!=n&&!cc(n))||(At.test(n)||!jt.test(n)||null!=t&&n in Qa(t))}function Oi(n){var t=typeof n;return"string"==t||"number"==t||"symbol"==t||"boolean"==t?"__proto__"!==n:null===n}function Ii(n){
var t=ci(n),r=q[t];if("function"!=typeof r||!(t in Et.prototype))return!1;if(n===r)return!0;var e=vs(r);return!!e&&n===e[0]}function zi(n){return!!al&&al in n}function Ei(n){var t=n&&n.constructor;return n===("function"==typeof t&&t.prototype||ul)}function Ri(n){return n===n&&!Jf(n)}function Si(n,t){return function(r){return null!=r&&(r[n]===t&&(t!==Q||n in Qa(r)))}}function Wi(n){var t=jf(n,function(n){return r.size===un&&r.clear(),n}),r=t.cache;return t}function Ci(n,t){var r=n[1],e=t[1],u=r|e,i=u<(hn|pn|bn),o=e==bn&&r==_n||e==bn&&r==wn&&n[7].length<=t[8]||e==(bn|wn)&&t[7].length<=t[8]&&r==_n;
if(!i&&!o)return n;e&hn&&(n[2]=t[2],u|=r&hn?0:vn);var f=t[3];if(f){var c=n[3];n[3]=c?ku(c,f,t[4]):f,n[4]=c?F(n[3],on):t[4]}return f=t[5],f&&(c=n[5],n[5]=c?Ou(c,f,t[6]):f,n[6]=c?F(n[5],on):t[6]),f=t[7],f&&(n[7]=f),e&bn&&(n[8]=null==n[8]?t[8]:Ul(n[8],t[8])),null==n[9]&&(n[9]=t[9]),n[0]=t[0],n[1]=u,n}function Li(n){var t=[];if(null!=n)for(var r in Qa(n))t.push(r);return t}function Bi(n){return ll.call(n)}function Ti(t,r,e){return r=Tl(r===Q?t.length-1:r,0),function(){for(var u=arguments,i=-1,o=Tl(u.length-r,0),f=Va(o);++i<o;)f[i]=u[r+i];
i=-1;for(var c=Va(r+1);++i<r;)c[i]=u[i];return c[r]=e(f),n(t,this,c)}}function Ui(n,t){return t.length<2?n:fe(n,Xe(t,0,-1))}function Di(n,t){for(var r=n.length,e=Ul(t.length,r),u=Iu(n);e--;){var i=t[e];n[e]=ji(i,r)?u[i]:Q}return n}function $i(n,t){if(("constructor"!==t||"function"!=typeof n[t])&&"__proto__"!=t)return n[t]}function Mi(n,t,r){var e=t+"";return ms(n,mi(e,Zi(gi(e),r)))}function Fi(n){var t=0,r=0;return function(){var e=Dl(),u=kn-(e-r);if(r=e,u>0){if(++t>=An)return arguments[0]}else t=0;
return n.apply(Q,arguments)}}function Ni(n,t){var r=-1,e=n.length,u=e-1;for(t=t===Q?e:t;++r<t;){var i=Ze(r,u),o=n[i];n[i]=n[r],n[r]=o}return n.length=t,n}function Pi(n){if("string"==typeof n||cc(n))return n;var t=n+"";return"0"==t&&1/n==-En?"-0":t}function qi(n){if(null!=n){try{return ol.call(n)}catch(n){}try{return n+""}catch(n){}}return""}function Zi(n,t){return r(Tn,function(r){var e="_."+r[0];t&r[1]&&!o(n,e)&&n.push(e)}),n.sort()}function Ki(n){if(n instanceof Et)return n.clone();var t=new J(n.__wrapped__,n.__chain__);
return t.__actions__=Iu(n.__actions__),t.__index__=n.__index__,t.__values__=n.__values__,t}function Vi(n,t,r){t=(r?Ai(n,t,r):t===Q)?1:Tl(vc(t),0);var e=null==n?0:n.length;if(!e||t<1)return[];for(var u=0,i=0,o=Va(El(e/t));u<e;)o[i++]=Xe(n,u,u+=t);return o}function Gi(n){for(var t=-1,r=null==n?0:n.length,e=0,u=[];++t<r;){var i=n[t];i&&(u[e++]=i)}return u}function Hi(){var n=arguments.length;if(!n)return[];for(var t=Va(n-1),r=arguments[0],e=n;e--;)t[e-1]=arguments[e];return a(fh(r)?Iu(r):[r],Vr(t,1));
}function Ji(n,t,r){var e=null==n?0:n.length;return e?(t=r||t===Q?1:vc(t),Xe(n,t<0?0:t,e)):[]}function Yi(n,t,r){var e=null==n?0:n.length;return e?(t=r||t===Q?1:vc(t),t=e-t,Xe(n,0,t<0?0:t)):[]}function Qi(n,t){return n&&n.length?au(n,li(t,3),!0,!0):[]}function Xi(n,t){return n&&n.length?au(n,li(t,3),!0):[]}function no(n,t,r,e){var u=null==n?0:n.length;return u?(r&&"number"!=typeof r&&Ai(n,t,r)&&(r=0,e=u),qr(n,t,r,e)):[]}function to(n,t,r){var e=null==n?0:n.length;if(!e)return-1;var u=null==r?0:vc(r);
return u<0&&(u=Tl(e+u,0)),g(n,li(t,3),u)}function ro(n,t,r){var e=null==n?0:n.length;if(!e)return-1;var u=e-1;return r!==Q&&(u=vc(r),u=r<0?Tl(e+u,0):Ul(u,e-1)),g(n,li(t,3),u,!0)}function eo(n){return(null==n?0:n.length)?Vr(n,1):[]}function uo(n){return(null==n?0:n.length)?Vr(n,En):[]}function io(n,t){return(null==n?0:n.length)?(t=t===Q?1:vc(t),Vr(n,t)):[]}function oo(n){for(var t=-1,r=null==n?0:n.length,e={};++t<r;){var u=n[t];e[u[0]]=u[1]}return e}function fo(n){return n&&n.length?n[0]:Q}function co(n,t,r){
var e=null==n?0:n.length;if(!e)return-1;var u=null==r?0:vc(r);return u<0&&(u=Tl(e+u,0)),y(n,t,u)}function ao(n){return(null==n?0:n.length)?Xe(n,0,-1):[]}function lo(n,t){return null==n?"":Ll.call(n,t)}function so(n){var t=null==n?0:n.length;return t?n[t-1]:Q}function ho(n,t,r){var e=null==n?0:n.length;if(!e)return-1;var u=e;return r!==Q&&(u=vc(r),u=u<0?Tl(e+u,0):Ul(u,e-1)),t===t?Z(n,t,u):g(n,b,u,!0)}function po(n,t){return n&&n.length?De(n,vc(t)):Q}function vo(n,t){return n&&n.length&&t&&t.length?Pe(n,t):n;
}function _o(n,t,r){return n&&n.length&&t&&t.length?Pe(n,t,li(r,2)):n}function go(n,t,r){return n&&n.length&&t&&t.length?Pe(n,t,Q,r):n}function yo(n,t){var r=[];if(!n||!n.length)return r;var e=-1,u=[],i=n.length;for(t=li(t,3);++e<i;){var o=n[e];t(o,e,n)&&(r.push(o),u.push(e))}return qe(n,u),r}function bo(n){return null==n?n:Fl.call(n)}function wo(n,t,r){var e=null==n?0:n.length;return e?(r&&"number"!=typeof r&&Ai(n,t,r)?(t=0,r=e):(t=null==t?0:vc(t),r=r===Q?e:vc(r)),Xe(n,t,r)):[]}function mo(n,t){
return tu(n,t)}function xo(n,t,r){return ru(n,t,li(r,2))}function jo(n,t){var r=null==n?0:n.length;if(r){var e=tu(n,t);if(e<r&&Uf(n[e],t))return e}return-1}function Ao(n,t){return tu(n,t,!0)}function ko(n,t,r){return ru(n,t,li(r,2),!0)}function Oo(n,t){if(null==n?0:n.length){var r=tu(n,t,!0)-1;if(Uf(n[r],t))return r}return-1}function Io(n){return n&&n.length?eu(n):[]}function zo(n,t){return n&&n.length?eu(n,li(t,2)):[]}function Eo(n){var t=null==n?0:n.length;return t?Xe(n,1,t):[]}function Ro(n,t,r){
return n&&n.length?(t=r||t===Q?1:vc(t),Xe(n,0,t<0?0:t)):[]}function So(n,t,r){var e=null==n?0:n.length;return e?(t=r||t===Q?1:vc(t),t=e-t,Xe(n,t<0?0:t,e)):[]}function Wo(n,t){return n&&n.length?au(n,li(t,3),!1,!0):[]}function Co(n,t){return n&&n.length?au(n,li(t,3)):[]}function Lo(n){return n&&n.length?ou(n):[]}function Bo(n,t){return n&&n.length?ou(n,li(t,2)):[]}function To(n,t){return t="function"==typeof t?t:Q,n&&n.length?ou(n,Q,t):[]}function Uo(n){if(!n||!n.length)return[];var t=0;return n=i(n,function(n){
if($f(n))return t=Tl(n.length,t),!0}),O(t,function(t){return c(n,m(t))})}function Do(t,r){if(!t||!t.length)return[];var e=Uo(t);return null==r?e:c(e,function(t){return n(r,Q,t)})}function $o(n,t){return hu(n||[],t||[],xr)}function Mo(n,t){return hu(n||[],t||[],Ye)}function Fo(n){var t=q(n);return t.__chain__=!0,t}function No(n,t){return t(n),n}function Po(n,t){return t(n)}function qo(){return Fo(this)}function Zo(){return new J(this.value(),this.__chain__)}function Ko(){this.__values__===Q&&(this.__values__=hc(this.value()));
var n=this.__index__>=this.__values__.length;return{done:n,value:n?Q:this.__values__[this.__index__++]}}function Vo(){return this}function Go(n){for(var t,r=this;r instanceof H;){var e=Ki(r);e.__index__=0,e.__values__=Q,t?u.__wrapped__=e:t=e;var u=e;r=r.__wrapped__}return u.__wrapped__=n,t}function Ho(){var n=this.__wrapped__;if(n instanceof Et){var t=n;return this.__actions__.length&&(t=new Et(this)),t=t.reverse(),t.__actions__.push({func:Po,args:[bo],thisArg:Q}),new J(t,this.__chain__)}return this.thru(bo);
}function Jo(){return lu(this.__wrapped__,this.__actions__)}function Yo(n,t,r){var e=fh(n)?u:Mr;return r&&Ai(n,t,r)&&(t=Q),e(n,li(t,3))}function Qo(n,t){return(fh(n)?i:Kr)(n,li(t,3))}function Xo(n,t){return Vr(of(n,t),1)}function nf(n,t){return Vr(of(n,t),En)}function tf(n,t,r){return r=r===Q?1:vc(r),Vr(of(n,t),r)}function rf(n,t){return(fh(n)?r:is)(n,li(t,3))}function ef(n,t){return(fh(n)?e:os)(n,li(t,3))}function uf(n,t,r,e){n=Df(n)?n:Zc(n),r=r&&!e?vc(r):0;var u=n.length;return r<0&&(r=Tl(u+r,0)),
fc(n)?r<=u&&n.indexOf(t,r)>-1:!!u&&y(n,t,r)>-1}function of(n,t){return(fh(n)?c:Ce)(n,li(t,3))}function ff(n,t,r,e){return null==n?[]:(fh(t)||(t=null==t?[]:[t]),r=e?Q:r,fh(r)||(r=null==r?[]:[r]),$e(n,t,r))}function cf(n,t,r){var e=fh(n)?l:j,u=arguments.length<3;return e(n,li(t,4),r,u,is)}function af(n,t,r){var e=fh(n)?s:j,u=arguments.length<3;return e(n,li(t,4),r,u,os)}function lf(n,t){return(fh(n)?i:Kr)(n,Af(li(t,3)))}function sf(n){return(fh(n)?dr:He)(n)}function hf(n,t,r){return t=(r?Ai(n,t,r):t===Q)?1:vc(t),
(fh(n)?br:Je)(n,t)}function pf(n){return(fh(n)?wr:Qe)(n)}function vf(n){if(null==n)return 0;if(Df(n))return fc(n)?K(n):n.length;var t=ys(n);return t==Kn||t==Xn?n.size:Re(n).length}function _f(n,t,r){var e=fh(n)?h:nu;return r&&Ai(n,t,r)&&(t=Q),e(n,li(t,3))}function gf(n,t){if("function"!=typeof t)throw new tl(rn);return n=vc(n),function(){if(--n<1)return t.apply(this,arguments)}}function yf(n,t,r){return t=r?Q:t,t=n&&null==t?n.length:t,Xu(n,bn,Q,Q,Q,Q,t)}function df(n,t){var r;if("function"!=typeof t)throw new tl(rn);
return n=vc(n),function(){return--n>0&&(r=t.apply(this,arguments)),n<=1&&(t=Q),r}}function bf(n,t,r){t=r?Q:t;var e=Xu(n,_n,Q,Q,Q,Q,Q,t);return e.placeholder=bf.placeholder,e}function wf(n,t,r){t=r?Q:t;var e=Xu(n,gn,Q,Q,Q,Q,Q,t);return e.placeholder=wf.placeholder,e}function mf(n,t,r){function e(t){var r=h,e=p;return h=p=Q,d=t,_=n.apply(e,r)}function u(n){return d=n,g=ws(f,t),b?e(n):_}function i(n){var r=n-y,e=n-d,u=t-r;return w?Ul(u,v-e):u}function o(n){var r=n-y,e=n-d;return y===Q||r>=t||r<0||w&&e>=v;
}function f(){var n=Hs();return o(n)?c(n):(g=ws(f,i(n)),Q)}function c(n){return g=Q,m&&h?e(n):(h=p=Q,_)}function a(){g!==Q&&hs(g),d=0,h=y=p=g=Q}function l(){return g===Q?_:c(Hs())}function s(){var n=Hs(),r=o(n);if(h=arguments,p=this,y=n,r){if(g===Q)return u(y);if(w)return hs(g),g=ws(f,t),e(y)}return g===Q&&(g=ws(f,t)),_}var h,p,v,_,g,y,d=0,b=!1,w=!1,m=!0;if("function"!=typeof n)throw new tl(rn);return t=gc(t)||0,Jf(r)&&(b=!!r.leading,w="maxWait"in r,v=w?Tl(gc(r.maxWait)||0,t):v,m="trailing"in r?!!r.trailing:m),
s.cancel=a,s.flush=l,s}function xf(n){return Xu(n,mn)}function jf(n,t){if("function"!=typeof n||null!=t&&"function"!=typeof t)throw new tl(rn);var r=function(){var e=arguments,u=t?t.apply(this,e):e[0],i=r.cache;if(i.has(u))return i.get(u);var o=n.apply(this,e);return r.cache=i.set(u,o)||i,o};return r.cache=new(jf.Cache||rr),r}function Af(n){if("function"!=typeof n)throw new tl(rn);return function(){var t=arguments;switch(t.length){case 0:return!n.call(this);case 1:return!n.call(this,t[0]);case 2:
return!n.call(this,t[0],t[1]);case 3:return!n.call(this,t[0],t[1],t[2])}return!n.apply(this,t)}}function kf(n){return df(2,n)}function Of(n,t){if("function"!=typeof n)throw new tl(rn);return t=t===Q?t:vc(t),Ge(n,t)}function If(t,r){if("function"!=typeof t)throw new tl(rn);return r=null==r?0:Tl(vc(r),0),Ge(function(e){var u=e[r],i=gu(e,0,r);return u&&a(i,u),n(t,this,i)})}function zf(n,t,r){var e=!0,u=!0;if("function"!=typeof n)throw new tl(rn);return Jf(r)&&(e="leading"in r?!!r.leading:e,u="trailing"in r?!!r.trailing:u),
mf(n,t,{leading:e,maxWait:t,trailing:u})}function Ef(n){return yf(n,1)}function Rf(n,t){return th(vu(t),n)}function Sf(){if(!arguments.length)return[];var n=arguments[0];return fh(n)?n:[n]}function Wf(n){return Wr(n,an)}function Cf(n,t){return t="function"==typeof t?t:Q,Wr(n,an,t)}function Lf(n){return Wr(n,fn|an)}function Bf(n,t){return t="function"==typeof t?t:Q,Wr(n,fn|an,t)}function Tf(n,t){return null==t||Lr(n,t,Wc(t))}function Uf(n,t){return n===t||n!==n&&t!==t}function Df(n){return null!=n&&Hf(n.length)&&!Vf(n);
}function $f(n){return Yf(n)&&Df(n)}function Mf(n){return n===!0||n===!1||Yf(n)&&le(n)==Mn}function Ff(n){return Yf(n)&&1===n.nodeType&&!ic(n)}function Nf(n){if(null==n)return!0;if(Df(n)&&(fh(n)||"string"==typeof n||"function"==typeof n.splice||ah(n)||vh(n)||oh(n)))return!n.length;var t=ys(n);if(t==Kn||t==Xn)return!n.size;if(Ei(n))return!Re(n).length;for(var r in n)if(fl.call(n,r))return!1;return!0}function Pf(n,t){return me(n,t)}function qf(n,t,r){r="function"==typeof r?r:Q;var e=r?r(n,t):Q;return e===Q?me(n,t,Q,r):!!e;
}function Zf(n){if(!Yf(n))return!1;var t=le(n);return t==Pn||t==Nn||"string"==typeof n.message&&"string"==typeof n.name&&!ic(n)}function Kf(n){return"number"==typeof n&&Cl(n)}function Vf(n){if(!Jf(n))return!1;var t=le(n);return t==qn||t==Zn||t==$n||t==Yn}function Gf(n){return"number"==typeof n&&n==vc(n)}function Hf(n){return"number"==typeof n&&n>-1&&n%1==0&&n<=Rn}function Jf(n){var t=typeof n;return null!=n&&("object"==t||"function"==t)}function Yf(n){return null!=n&&"object"==typeof n}function Qf(n,t){
return n===t||Ae(n,t,hi(t))}function Xf(n,t,r){return r="function"==typeof r?r:Q,Ae(n,t,hi(t),r)}function nc(n){return uc(n)&&n!=+n}function tc(n){if(ds(n))throw new Ha(tn);return ke(n)}function rc(n){return null===n}function ec(n){return null==n}function uc(n){return"number"==typeof n||Yf(n)&&le(n)==Vn}function ic(n){if(!Yf(n)||le(n)!=Hn)return!1;var t=dl(n);if(null===t)return!0;var r=fl.call(t,"constructor")&&t.constructor;return"function"==typeof r&&r instanceof r&&ol.call(r)==sl}function oc(n){
return Gf(n)&&n>=-Rn&&n<=Rn}function fc(n){return"string"==typeof n||!fh(n)&&Yf(n)&&le(n)==nt}function cc(n){return"symbol"==typeof n||Yf(n)&&le(n)==tt}function ac(n){return n===Q}function lc(n){return Yf(n)&&ys(n)==et}function sc(n){return Yf(n)&&le(n)==ut}function hc(n){if(!n)return[];if(Df(n))return fc(n)?V(n):Iu(n);if(jl&&n[jl])return D(n[jl]());var t=ys(n);return(t==Kn?$:t==Xn?N:Zc)(n)}function pc(n){if(!n)return 0===n?n:0;if(n=gc(n),n===En||n===-En){return(n<0?-1:1)*Sn}return n===n?n:0}function vc(n){
var t=pc(n),r=t%1;return t===t?r?t-r:t:0}function _c(n){return n?Sr(vc(n),0,Cn):0}function gc(n){if("number"==typeof n)return n;if(cc(n))return Wn;if(Jf(n)){var t="function"==typeof n.valueOf?n.valueOf():n;n=Jf(t)?t+"":t}if("string"!=typeof n)return 0===n?n:+n;n=z(n);var r=Ut.test(n);return r||$t.test(n)?Nr(n.slice(2),r?2:8):Tt.test(n)?Wn:+n}function yc(n){return zu(n,Cc(n))}function dc(n){return n?Sr(vc(n),-Rn,Rn):0===n?n:0}function bc(n){return null==n?"":iu(n)}function wc(n,t){var r=us(n);return null==t?r:kr(r,t);
}function mc(n,t){return _(n,li(t,3),Hr)}function xc(n,t){return _(n,li(t,3),Jr)}function jc(n,t){return null==n?n:fs(n,li(t,3),Cc)}function Ac(n,t){return null==n?n:cs(n,li(t,3),Cc)}function kc(n,t){return n&&Hr(n,li(t,3))}function Oc(n,t){return n&&Jr(n,li(t,3))}function Ic(n){return null==n?[]:ee(n,Wc(n))}function zc(n){return null==n?[]:ee(n,Cc(n))}function Ec(n,t,r){var e=null==n?Q:fe(n,t);return e===Q?r:e}function Rc(n,t){return null!=n&&yi(n,t,he)}function Sc(n,t){return null!=n&&yi(n,t,pe);
}function Wc(n){return Df(n)?yr(n):Re(n)}function Cc(n){return Df(n)?yr(n,!0):Se(n)}function Lc(n,t){var r={};return t=li(t,3),Hr(n,function(n,e,u){Ir(r,t(n,e,u),n)}),r}function Bc(n,t){var r={};return t=li(t,3),Hr(n,function(n,e,u){Ir(r,e,t(n,e,u))}),r}function Tc(n,t){return Uc(n,Af(li(t)))}function Uc(n,t){if(null==n)return{};var r=c(fi(n),function(n){return[n]});return t=li(t),Fe(n,r,function(n,r){return t(n,r[0])})}function Dc(n,t,r){t=_u(t,n);var e=-1,u=t.length;for(u||(u=1,n=Q);++e<u;){var i=null==n?Q:n[Pi(t[e])];
i===Q&&(e=u,i=r),n=Vf(i)?i.call(n):i}return n}function $c(n,t,r){return null==n?n:Ye(n,t,r)}function Mc(n,t,r,e){return e="function"==typeof e?e:Q,null==n?n:Ye(n,t,r,e)}function Fc(n,t,e){var u=fh(n),i=u||ah(n)||vh(n);if(t=li(t,4),null==e){var o=n&&n.constructor;e=i?u?new o:[]:Jf(n)&&Vf(o)?us(dl(n)):{}}return(i?r:Hr)(n,function(n,r,u){return t(e,n,r,u)}),e}function Nc(n,t){return null==n||fu(n,t)}function Pc(n,t,r){return null==n?n:cu(n,t,vu(r))}function qc(n,t,r,e){return e="function"==typeof e?e:Q,
null==n?n:cu(n,t,vu(r),e)}function Zc(n){return null==n?[]:R(n,Wc(n))}function Kc(n){return null==n?[]:R(n,Cc(n))}function Vc(n,t,r){return r===Q&&(r=t,t=Q),r!==Q&&(r=gc(r),r=r===r?r:0),t!==Q&&(t=gc(t),t=t===t?t:0),Sr(gc(n),t,r)}function Gc(n,t,r){return t=pc(t),r===Q?(r=t,t=0):r=pc(r),n=gc(n),ve(n,t,r)}function Hc(n,t,r){if(r&&"boolean"!=typeof r&&Ai(n,t,r)&&(t=r=Q),r===Q&&("boolean"==typeof t?(r=t,t=Q):"boolean"==typeof n&&(r=n,n=Q)),n===Q&&t===Q?(n=0,t=1):(n=pc(n),t===Q?(t=n,n=0):t=pc(t)),n>t){
var e=n;n=t,t=e}if(r||n%1||t%1){var u=Ml();return Ul(n+u*(t-n+Fr("1e-"+((u+"").length-1))),t)}return Ze(n,t)}function Jc(n){return Mh(bc(n).toLowerCase())}function Yc(n){return n=bc(n),n&&n.replace(Ft,ue).replace(Rr,"")}function Qc(n,t,r){n=bc(n),t=iu(t);var e=n.length;r=r===Q?e:Sr(vc(r),0,e);var u=r;return r-=t.length,r>=0&&n.slice(r,u)==t}function Xc(n){return n=bc(n),n&&bt.test(n)?n.replace(yt,ie):n}function na(n){return n=bc(n),n&&It.test(n)?n.replace(Ot,"\\$&"):n}function ta(n,t,r){n=bc(n),t=vc(t);
var e=t?K(n):0;if(!t||e>=t)return n;var u=(t-e)/2;return Ku(Rl(u),r)+n+Ku(El(u),r)}function ra(n,t,r){n=bc(n),t=vc(t);var e=t?K(n):0;return t&&e<t?n+Ku(t-e,r):n}function ea(n,t,r){n=bc(n),t=vc(t);var e=t?K(n):0;return t&&e<t?Ku(t-e,r)+n:n}function ua(n,t,r){return r||null==t?t=0:t&&(t=+t),$l(bc(n).replace(zt,""),t||0)}function ia(n,t,r){return t=(r?Ai(n,t,r):t===Q)?1:vc(t),Ve(bc(n),t)}function oa(){var n=arguments,t=bc(n[0]);return n.length<3?t:t.replace(n[1],n[2])}function fa(n,t,r){return r&&"number"!=typeof r&&Ai(n,t,r)&&(t=r=Q),
(r=r===Q?Cn:r>>>0)?(n=bc(n),n&&("string"==typeof t||null!=t&&!hh(t))&&(t=iu(t),!t&&T(n))?gu(V(n),0,r):n.split(t,r)):[]}function ca(n,t,r){return n=bc(n),r=null==r?0:Sr(vc(r),0,n.length),t=iu(t),n.slice(r,r+t.length)==t}function aa(n){return bc(n).toLowerCase()}function la(n){return bc(n).toUpperCase()}function sa(n,t,r){if(n=bc(n),n&&(r||t===Q))return z(n);if(!n||!(t=iu(t)))return n;var e=V(n),u=V(t);return gu(e,W(e,u),C(e,u)+1).join("")}function ha(n,t,r){if(n=bc(n),n&&(r||t===Q))return n.slice(0,G(n)+1);
if(!n||!(t=iu(t)))return n;var e=V(n);return gu(e,0,C(e,V(t))+1).join("")}function pa(n,t,r){if(n=bc(n),n&&(r||t===Q))return n.replace(zt,"");if(!n||!(t=iu(t)))return n;var e=V(n);return gu(e,W(e,V(t))).join("")}function va(n,t){var r=xn,e=jn;if(Jf(t)){var u="separator"in t?t.separator:u;r="length"in t?vc(t.length):r,e="omission"in t?iu(t.omission):e}n=bc(n);var i=n.length;if(T(n)){var o=V(n);i=o.length}if(r>=i)return n;var f=r-K(e);if(f<1)return e;var c=o?gu(o,0,f).join(""):n.slice(0,f);if(u===Q)return c+e;
if(o&&(f+=c.length-f),hh(u)){if(n.slice(f).search(u)){var a,l=c;for(u.global||(u=Xa(u.source,bc(Bt.exec(u))+"g")),u.lastIndex=0;a=u.exec(l);)var s=a.index;c=c.slice(0,s===Q?f:s)}}else if(n.indexOf(iu(u),f)!=f){var h=c.lastIndexOf(u);h>-1&&(c=c.slice(0,h))}return c+e}function _a(n){return n=bc(n),n&&dt.test(n)?n.replace(gt,oe):n}function ga(n,t,r){return n=bc(n),t=r?Q:t,t===Q?U(n)?Y(n):v(n):n.match(t)||[]}function ya(t){var r=null==t?0:t.length,e=li();return t=r?c(t,function(n){if("function"!=typeof n[1])throw new tl(rn);
return[e(n[0]),n[1]]}):[],Ge(function(e){for(var u=-1;++u<r;){var i=t[u];if(n(i[0],this,e))return n(i[1],this,e)}})}function da(n){return Cr(Wr(n,fn))}function ba(n){return function(){return n}}function wa(n,t){return null==n||n!==n?t:n}function ma(n){return n}function xa(n){return Ee("function"==typeof n?n:Wr(n,fn))}function ja(n){return Le(Wr(n,fn))}function Aa(n,t){return Be(n,Wr(t,fn))}function ka(n,t,e){var u=Wc(t),i=ee(t,u);null!=e||Jf(t)&&(i.length||!u.length)||(e=t,t=n,n=this,i=ee(t,Wc(t)));
var o=!(Jf(e)&&"chain"in e&&!e.chain),f=Vf(n);return r(i,function(r){var e=t[r];n[r]=e,f&&(n.prototype[r]=function(){var t=this.__chain__;if(o||t){var r=n(this.__wrapped__);return(r.__actions__=Iu(this.__actions__)).push({func:e,args:arguments,thisArg:n}),r.__chain__=t,r}return e.apply(n,a([this.value()],arguments))})}),n}function Oa(){return Zr._===this&&(Zr._=hl),this}function Ia(){}function za(n){return n=vc(n),Ge(function(t){return De(t,n)})}function Ea(n){return ki(n)?m(Pi(n)):Ne(n)}function Ra(n){
return function(t){return null==n?Q:fe(n,t)}}function Sa(){return[]}function Wa(){return!1}function Ca(){return{}}function La(){return""}function Ba(){return!0}function Ta(n,t){if(n=vc(n),n<1||n>Rn)return[];var r=Cn,e=Ul(n,Cn);t=li(t),n-=Cn;for(var u=O(e,t);++r<n;)t(r);return u}function Ua(n){return fh(n)?c(n,Pi):cc(n)?[n]:Iu(xs(bc(n)))}function Da(n){var t=++cl;return bc(n)+t}function $a(n){return n&&n.length?Pr(n,ma,se):Q}function Ma(n,t){return n&&n.length?Pr(n,li(t,2),se):Q}function Fa(n){return w(n,ma);
}function Na(n,t){return w(n,li(t,2))}function Pa(n){return n&&n.length?Pr(n,ma,We):Q}function qa(n,t){return n&&n.length?Pr(n,li(t,2),We):Q}function Za(n){return n&&n.length?k(n,ma):0}function Ka(n,t){return n&&n.length?k(n,li(t,2)):0}x=null==x?Zr:ce.defaults(Zr.Object(),x,ce.pick(Zr,Br));var Va=x.Array,Ga=x.Date,Ha=x.Error,Ja=x.Function,Ya=x.Math,Qa=x.Object,Xa=x.RegExp,nl=x.String,tl=x.TypeError,rl=Va.prototype,el=Ja.prototype,ul=Qa.prototype,il=x["__core-js_shared__"],ol=el.toString,fl=ul.hasOwnProperty,cl=0,al=function(){
var n=/[^.]+$/.exec(il&&il.keys&&il.keys.IE_PROTO||"");return n?"Symbol(src)_1."+n:""}(),ll=ul.toString,sl=ol.call(Qa),hl=Zr._,pl=Xa("^"+ol.call(fl).replace(Ot,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$"),vl=Gr?x.Buffer:Q,_l=x.Symbol,gl=x.Uint8Array,yl=vl?vl.allocUnsafe:Q,dl=M(Qa.getPrototypeOf,Qa),bl=Qa.create,wl=ul.propertyIsEnumerable,ml=rl.splice,xl=_l?_l.isConcatSpreadable:Q,jl=_l?_l.iterator:Q,Al=_l?_l.toStringTag:Q,kl=function(){try{var n=pi(Qa,"defineProperty");
return n({},"",{}),n}catch(n){}}(),Ol=x.clearTimeout!==Zr.clearTimeout&&x.clearTimeout,Il=Ga&&Ga.now!==Zr.Date.now&&Ga.now,zl=x.setTimeout!==Zr.setTimeout&&x.setTimeout,El=Ya.ceil,Rl=Ya.floor,Sl=Qa.getOwnPropertySymbols,Wl=vl?vl.isBuffer:Q,Cl=x.isFinite,Ll=rl.join,Bl=M(Qa.keys,Qa),Tl=Ya.max,Ul=Ya.min,Dl=Ga.now,$l=x.parseInt,Ml=Ya.random,Fl=rl.reverse,Nl=pi(x,"DataView"),Pl=pi(x,"Map"),ql=pi(x,"Promise"),Zl=pi(x,"Set"),Kl=pi(x,"WeakMap"),Vl=pi(Qa,"create"),Gl=Kl&&new Kl,Hl={},Jl=qi(Nl),Yl=qi(Pl),Ql=qi(ql),Xl=qi(Zl),ns=qi(Kl),ts=_l?_l.prototype:Q,rs=ts?ts.valueOf:Q,es=ts?ts.toString:Q,us=function(){
function n(){}return function(t){if(!Jf(t))return{};if(bl)return bl(t);n.prototype=t;var r=new n;return n.prototype=Q,r}}();q.templateSettings={escape:wt,evaluate:mt,interpolate:xt,variable:"",imports:{_:q}},q.prototype=H.prototype,q.prototype.constructor=q,J.prototype=us(H.prototype),J.prototype.constructor=J,Et.prototype=us(H.prototype),Et.prototype.constructor=Et,qt.prototype.clear=Zt,qt.prototype.delete=Kt,qt.prototype.get=Vt,qt.prototype.has=Gt,qt.prototype.set=Ht,Jt.prototype.clear=Yt,Jt.prototype.delete=Qt,
Jt.prototype.get=Xt,Jt.prototype.has=nr,Jt.prototype.set=tr,rr.prototype.clear=er,rr.prototype.delete=ur,rr.prototype.get=ir,rr.prototype.has=or,rr.prototype.set=fr,cr.prototype.add=cr.prototype.push=ar,cr.prototype.has=lr,sr.prototype.clear=hr,sr.prototype.delete=pr,sr.prototype.get=vr,sr.prototype.has=_r,sr.prototype.set=gr;var is=Cu(Hr),os=Cu(Jr,!0),fs=Lu(),cs=Lu(!0),as=Gl?function(n,t){return Gl.set(n,t),n}:ma,ls=kl?function(n,t){return kl(n,"toString",{configurable:!0,enumerable:!1,value:ba(t),
writable:!0})}:ma,ss=Ge,hs=Ol||function(n){return Zr.clearTimeout(n)},ps=Zl&&1/N(new Zl([,-0]))[1]==En?function(n){return new Zl(n)}:Ia,vs=Gl?function(n){return Gl.get(n)}:Ia,_s=Sl?function(n){return null==n?[]:(n=Qa(n),i(Sl(n),function(t){return wl.call(n,t)}))}:Sa,gs=Sl?function(n){for(var t=[];n;)a(t,_s(n)),n=dl(n);return t}:Sa,ys=le;(Nl&&ys(new Nl(new ArrayBuffer(1)))!=ot||Pl&&ys(new Pl)!=Kn||ql&&ys(ql.resolve())!=Jn||Zl&&ys(new Zl)!=Xn||Kl&&ys(new Kl)!=et)&&(ys=function(n){var t=le(n),r=t==Hn?n.constructor:Q,e=r?qi(r):"";
if(e)switch(e){case Jl:return ot;case Yl:return Kn;case Ql:return Jn;case Xl:return Xn;case ns:return et}return t});var ds=il?Vf:Wa,bs=Fi(as),ws=zl||function(n,t){return Zr.setTimeout(n,t)},ms=Fi(ls),xs=Wi(function(n){var t=[];return 46===n.charCodeAt(0)&&t.push(""),n.replace(kt,function(n,r,e,u){t.push(e?u.replace(Lt,"$1"):r||n)}),t}),js=Ge(function(n,t){return $f(n)?$r(n,Vr(t,1,$f,!0)):[]}),As=Ge(function(n,t){var r=so(t);return $f(r)&&(r=Q),$f(n)?$r(n,Vr(t,1,$f,!0),li(r,2)):[]}),ks=Ge(function(n,t){
var r=so(t);return $f(r)&&(r=Q),$f(n)?$r(n,Vr(t,1,$f,!0),Q,r):[]}),Os=Ge(function(n){var t=c(n,pu);return t.length&&t[0]===n[0]?_e(t):[]}),Is=Ge(function(n){var t=so(n),r=c(n,pu);return t===so(r)?t=Q:r.pop(),r.length&&r[0]===n[0]?_e(r,li(t,2)):[]}),zs=Ge(function(n){var t=so(n),r=c(n,pu);return t="function"==typeof t?t:Q,t&&r.pop(),r.length&&r[0]===n[0]?_e(r,Q,t):[]}),Es=Ge(vo),Rs=ii(function(n,t){var r=null==n?0:n.length,e=zr(n,t);return qe(n,c(t,function(n){return ji(n,r)?+n:n}).sort(ju)),e}),Ss=Ge(function(n){
return ou(Vr(n,1,$f,!0))}),Ws=Ge(function(n){var t=so(n);return $f(t)&&(t=Q),ou(Vr(n,1,$f,!0),li(t,2))}),Cs=Ge(function(n){var t=so(n);return t="function"==typeof t?t:Q,ou(Vr(n,1,$f,!0),Q,t)}),Ls=Ge(function(n,t){return $f(n)?$r(n,t):[]}),Bs=Ge(function(n){return su(i(n,$f))}),Ts=Ge(function(n){var t=so(n);return $f(t)&&(t=Q),su(i(n,$f),li(t,2))}),Us=Ge(function(n){var t=so(n);return t="function"==typeof t?t:Q,su(i(n,$f),Q,t)}),Ds=Ge(Uo),$s=Ge(function(n){var t=n.length,r=t>1?n[t-1]:Q;return r="function"==typeof r?(n.pop(),
r):Q,Do(n,r)}),Ms=ii(function(n){var t=n.length,r=t?n[0]:0,e=this.__wrapped__,u=function(t){return zr(t,n)};return!(t>1||this.__actions__.length)&&e instanceof Et&&ji(r)?(e=e.slice(r,+r+(t?1:0)),e.__actions__.push({func:Po,args:[u],thisArg:Q}),new J(e,this.__chain__).thru(function(n){return t&&!n.length&&n.push(Q),n})):this.thru(u)}),Fs=Su(function(n,t,r){fl.call(n,r)?++n[r]:Ir(n,r,1)}),Ns=Mu(to),Ps=Mu(ro),qs=Su(function(n,t,r){fl.call(n,r)?n[r].push(t):Ir(n,r,[t])}),Zs=Ge(function(t,r,e){var u=-1,i="function"==typeof r,o=Df(t)?Va(t.length):[];
return is(t,function(t){o[++u]=i?n(r,t,e):ye(t,r,e)}),o}),Ks=Su(function(n,t,r){Ir(n,r,t)}),Vs=Su(function(n,t,r){n[r?0:1].push(t)},function(){return[[],[]]}),Gs=Ge(function(n,t){if(null==n)return[];var r=t.length;return r>1&&Ai(n,t[0],t[1])?t=[]:r>2&&Ai(t[0],t[1],t[2])&&(t=[t[0]]),$e(n,Vr(t,1),[])}),Hs=Il||function(){return Zr.Date.now()},Js=Ge(function(n,t,r){var e=hn;if(r.length){var u=F(r,ai(Js));e|=yn}return Xu(n,e,t,r,u)}),Ys=Ge(function(n,t,r){var e=hn|pn;if(r.length){var u=F(r,ai(Ys));e|=yn;
}return Xu(t,e,n,r,u)}),Qs=Ge(function(n,t){return Dr(n,1,t)}),Xs=Ge(function(n,t,r){return Dr(n,gc(t)||0,r)});jf.Cache=rr;var nh=ss(function(t,r){r=1==r.length&&fh(r[0])?c(r[0],E(li())):c(Vr(r,1),E(li()));var e=r.length;return Ge(function(u){for(var i=-1,o=Ul(u.length,e);++i<o;)u[i]=r[i].call(this,u[i]);return n(t,this,u)})}),th=Ge(function(n,t){return Xu(n,yn,Q,t,F(t,ai(th)))}),rh=Ge(function(n,t){return Xu(n,dn,Q,t,F(t,ai(rh)))}),eh=ii(function(n,t){return Xu(n,wn,Q,Q,Q,t)}),uh=Hu(se),ih=Hu(function(n,t){
return n>=t}),oh=de(function(){return arguments}())?de:function(n){return Yf(n)&&fl.call(n,"callee")&&!wl.call(n,"callee")},fh=Va.isArray,ch=Yr?E(Yr):be,ah=Wl||Wa,lh=Qr?E(Qr):we,sh=Xr?E(Xr):je,hh=ne?E(ne):Oe,ph=te?E(te):Ie,vh=re?E(re):ze,_h=Hu(We),gh=Hu(function(n,t){return n<=t}),yh=Wu(function(n,t){if(Ei(t)||Df(t))return zu(t,Wc(t),n),Q;for(var r in t)fl.call(t,r)&&xr(n,r,t[r])}),dh=Wu(function(n,t){zu(t,Cc(t),n)}),bh=Wu(function(n,t,r,e){zu(t,Cc(t),n,e)}),wh=Wu(function(n,t,r,e){zu(t,Wc(t),n,e);
}),mh=ii(zr),xh=Ge(function(n,t){n=Qa(n);var r=-1,e=t.length,u=e>2?t[2]:Q;for(u&&Ai(t[0],t[1],u)&&(e=1);++r<e;)for(var i=t[r],o=Cc(i),f=-1,c=o.length;++f<c;){var a=o[f],l=n[a];(l===Q||Uf(l,ul[a])&&!fl.call(n,a))&&(n[a]=i[a])}return n}),jh=Ge(function(t){return t.push(Q,ni),n(zh,Q,t)}),Ah=Pu(function(n,t,r){null!=t&&"function"!=typeof t.toString&&(t=ll.call(t)),n[t]=r},ba(ma)),kh=Pu(function(n,t,r){null!=t&&"function"!=typeof t.toString&&(t=ll.call(t)),fl.call(n,t)?n[t].push(r):n[t]=[r]},li),Oh=Ge(ye),Ih=Wu(function(n,t,r){
Te(n,t,r)}),zh=Wu(function(n,t,r,e){Te(n,t,r,e)}),Eh=ii(function(n,t){var r={};if(null==n)return r;var e=!1;t=c(t,function(t){return t=_u(t,n),e||(e=t.length>1),t}),zu(n,fi(n),r),e&&(r=Wr(r,fn|cn|an,ti));for(var u=t.length;u--;)fu(r,t[u]);return r}),Rh=ii(function(n,t){return null==n?{}:Me(n,t)}),Sh=Qu(Wc),Wh=Qu(Cc),Ch=Uu(function(n,t,r){return t=t.toLowerCase(),n+(r?Jc(t):t)}),Lh=Uu(function(n,t,r){return n+(r?"-":"")+t.toLowerCase()}),Bh=Uu(function(n,t,r){return n+(r?" ":"")+t.toLowerCase()}),Th=Tu("toLowerCase"),Uh=Uu(function(n,t,r){
return n+(r?"_":"")+t.toLowerCase()}),Dh=Uu(function(n,t,r){return n+(r?" ":"")+Mh(t)}),$h=Uu(function(n,t,r){return n+(r?" ":"")+t.toUpperCase()}),Mh=Tu("toUpperCase"),Fh=Ge(function(t,r){try{return n(t,Q,r)}catch(n){return Zf(n)?n:new Ha(n)}}),Nh=ii(function(n,t){return r(t,function(t){t=Pi(t),Ir(n,t,Js(n[t],n))}),n}),Ph=Fu(),qh=Fu(!0),Zh=Ge(function(n,t){return function(r){return ye(r,n,t)}}),Kh=Ge(function(n,t){return function(r){return ye(n,r,t)}}),Vh=Zu(c),Gh=Zu(u),Hh=Zu(h),Jh=Gu(),Yh=Gu(!0),Qh=qu(function(n,t){
return n+t},0),Xh=Yu("ceil"),np=qu(function(n,t){return n/t},1),tp=Yu("floor"),rp=qu(function(n,t){return n*t},1),ep=Yu("round"),up=qu(function(n,t){return n-t},0);return q.after=gf,q.ary=yf,q.assign=yh,q.assignIn=dh,q.assignInWith=bh,q.assignWith=wh,q.at=mh,q.before=df,q.bind=Js,q.bindAll=Nh,q.bindKey=Ys,q.castArray=Sf,q.chain=Fo,q.chunk=Vi,q.compact=Gi,q.concat=Hi,q.cond=ya,q.conforms=da,q.constant=ba,q.countBy=Fs,q.create=wc,q.curry=bf,q.curryRight=wf,q.debounce=mf,q.defaults=xh,q.defaultsDeep=jh,
q.defer=Qs,q.delay=Xs,q.difference=js,q.differenceBy=As,q.differenceWith=ks,q.drop=Ji,q.dropRight=Yi,q.dropRightWhile=Qi,q.dropWhile=Xi,q.fill=no,q.filter=Qo,q.flatMap=Xo,q.flatMapDeep=nf,q.flatMapDepth=tf,q.flatten=eo,q.flattenDeep=uo,q.flattenDepth=io,q.flip=xf,q.flow=Ph,q.flowRight=qh,q.fromPairs=oo,q.functions=Ic,q.functionsIn=zc,q.groupBy=qs,q.initial=ao,q.intersection=Os,q.intersectionBy=Is,q.intersectionWith=zs,q.invert=Ah,q.invertBy=kh,q.invokeMap=Zs,q.iteratee=xa,q.keyBy=Ks,q.keys=Wc,q.keysIn=Cc,
q.map=of,q.mapKeys=Lc,q.mapValues=Bc,q.matches=ja,q.matchesProperty=Aa,q.memoize=jf,q.merge=Ih,q.mergeWith=zh,q.method=Zh,q.methodOf=Kh,q.mixin=ka,q.negate=Af,q.nthArg=za,q.omit=Eh,q.omitBy=Tc,q.once=kf,q.orderBy=ff,q.over=Vh,q.overArgs=nh,q.overEvery=Gh,q.overSome=Hh,q.partial=th,q.partialRight=rh,q.partition=Vs,q.pick=Rh,q.pickBy=Uc,q.property=Ea,q.propertyOf=Ra,q.pull=Es,q.pullAll=vo,q.pullAllBy=_o,q.pullAllWith=go,q.pullAt=Rs,q.range=Jh,q.rangeRight=Yh,q.rearg=eh,q.reject=lf,q.remove=yo,q.rest=Of,
q.reverse=bo,q.sampleSize=hf,q.set=$c,q.setWith=Mc,q.shuffle=pf,q.slice=wo,q.sortBy=Gs,q.sortedUniq=Io,q.sortedUniqBy=zo,q.split=fa,q.spread=If,q.tail=Eo,q.take=Ro,q.takeRight=So,q.takeRightWhile=Wo,q.takeWhile=Co,q.tap=No,q.throttle=zf,q.thru=Po,q.toArray=hc,q.toPairs=Sh,q.toPairsIn=Wh,q.toPath=Ua,q.toPlainObject=yc,q.transform=Fc,q.unary=Ef,q.union=Ss,q.unionBy=Ws,q.unionWith=Cs,q.uniq=Lo,q.uniqBy=Bo,q.uniqWith=To,q.unset=Nc,q.unzip=Uo,q.unzipWith=Do,q.update=Pc,q.updateWith=qc,q.values=Zc,q.valuesIn=Kc,
q.without=Ls,q.words=ga,q.wrap=Rf,q.xor=Bs,q.xorBy=Ts,q.xorWith=Us,q.zip=Ds,q.zipObject=$o,q.zipObjectDeep=Mo,q.zipWith=$s,q.entries=Sh,q.entriesIn=Wh,q.extend=dh,q.extendWith=bh,ka(q,q),q.add=Qh,q.attempt=Fh,q.camelCase=Ch,q.capitalize=Jc,q.ceil=Xh,q.clamp=Vc,q.clone=Wf,q.cloneDeep=Lf,q.cloneDeepWith=Bf,q.cloneWith=Cf,q.conformsTo=Tf,q.deburr=Yc,q.defaultTo=wa,q.divide=np,q.endsWith=Qc,q.eq=Uf,q.escape=Xc,q.escapeRegExp=na,q.every=Yo,q.find=Ns,q.findIndex=to,q.findKey=mc,q.findLast=Ps,q.findLastIndex=ro,
q.findLastKey=xc,q.floor=tp,q.forEach=rf,q.forEachRight=ef,q.forIn=jc,q.forInRight=Ac,q.forOwn=kc,q.forOwnRight=Oc,q.get=Ec,q.gt=uh,q.gte=ih,q.has=Rc,q.hasIn=Sc,q.head=fo,q.identity=ma,q.includes=uf,q.indexOf=co,q.inRange=Gc,q.invoke=Oh,q.isArguments=oh,q.isArray=fh,q.isArrayBuffer=ch,q.isArrayLike=Df,q.isArrayLikeObject=$f,q.isBoolean=Mf,q.isBuffer=ah,q.isDate=lh,q.isElement=Ff,q.isEmpty=Nf,q.isEqual=Pf,q.isEqualWith=qf,q.isError=Zf,q.isFinite=Kf,q.isFunction=Vf,q.isInteger=Gf,q.isLength=Hf,q.isMap=sh,
q.isMatch=Qf,q.isMatchWith=Xf,q.isNaN=nc,q.isNative=tc,q.isNil=ec,q.isNull=rc,q.isNumber=uc,q.isObject=Jf,q.isObjectLike=Yf,q.isPlainObject=ic,q.isRegExp=hh,q.isSafeInteger=oc,q.isSet=ph,q.isString=fc,q.isSymbol=cc,q.isTypedArray=vh,q.isUndefined=ac,q.isWeakMap=lc,q.isWeakSet=sc,q.join=lo,q.kebabCase=Lh,q.last=so,q.lastIndexOf=ho,q.lowerCase=Bh,q.lowerFirst=Th,q.lt=_h,q.lte=gh,q.max=$a,q.maxBy=Ma,q.mean=Fa,q.meanBy=Na,q.min=Pa,q.minBy=qa,q.stubArray=Sa,q.stubFalse=Wa,q.stubObject=Ca,q.stubString=La,
q.stubTrue=Ba,q.multiply=rp,q.nth=po,q.noConflict=Oa,q.noop=Ia,q.now=Hs,q.pad=ta,q.padEnd=ra,q.padStart=ea,q.parseInt=ua,q.random=Hc,q.reduce=cf,q.reduceRight=af,q.repeat=ia,q.replace=oa,q.result=Dc,q.round=ep,q.runInContext=p,q.sample=sf,q.size=vf,q.snakeCase=Uh,q.some=_f,q.sortedIndex=mo,q.sortedIndexBy=xo,q.sortedIndexOf=jo,q.sortedLastIndex=Ao,q.sortedLastIndexBy=ko,q.sortedLastIndexOf=Oo,q.startCase=Dh,q.startsWith=ca,q.subtract=up,q.sum=Za,q.sumBy=Ka,q.times=Ta,q.toFinite=pc,q.toInteger=vc,
q.toLength=_c,q.toLower=aa,q.toNumber=gc,q.toSafeInteger=dc,q.toString=bc,q.toUpper=la,q.trim=sa,q.trimEnd=ha,q.trimStart=pa,q.truncate=va,q.unescape=_a,q.uniqueId=Da,q.upperCase=$h,q.upperFirst=Mh,q.each=rf,q.eachRight=ef,q.first=fo,ka(q,function(){var n={};return Hr(q,function(t,r){fl.call(q.prototype,r)||(n[r]=t)}),n}(),{chain:!1}),q.VERSION=X,r(["bind","bindKey","curry","curryRight","partial","partialRight"],function(n){q[n].placeholder=q}),r(["drop","take"],function(n,t){Et.prototype[n]=function(r){
r=r===Q?1:Tl(vc(r),0);var e=this.__filtered__&&!t?new Et(this):this.clone();return e.__filtered__?e.__takeCount__=Ul(r,e.__takeCount__):e.__views__.push({size:Ul(r,Cn),type:n+(e.__dir__<0?"Right":"")}),e},Et.prototype[n+"Right"]=function(t){return this.reverse()[n](t).reverse()}}),r(["filter","map","takeWhile"],function(n,t){var r=t+1,e=r==On||r==zn;Et.prototype[n]=function(n){var t=this.clone();return t.__iteratees__.push({iteratee:li(n,3),type:r}),t.__filtered__=t.__filtered__||e,t}}),r(["head","last"],function(n,t){
var r="take"+(t?"Right":"");Et.prototype[n]=function(){return this[r](1).value()[0]}}),r(["initial","tail"],function(n,t){var r="drop"+(t?"":"Right");Et.prototype[n]=function(){return this.__filtered__?new Et(this):this[r](1)}}),Et.prototype.compact=function(){return this.filter(ma)},Et.prototype.find=function(n){return this.filter(n).head()},Et.prototype.findLast=function(n){return this.reverse().find(n)},Et.prototype.invokeMap=Ge(function(n,t){return"function"==typeof n?new Et(this):this.map(function(r){
return ye(r,n,t)})}),Et.prototype.reject=function(n){return this.filter(Af(li(n)))},Et.prototype.slice=function(n,t){n=vc(n);var r=this;return r.__filtered__&&(n>0||t<0)?new Et(r):(n<0?r=r.takeRight(-n):n&&(r=r.drop(n)),t!==Q&&(t=vc(t),r=t<0?r.dropRight(-t):r.take(t-n)),r)},Et.prototype.takeRightWhile=function(n){return this.reverse().takeWhile(n).reverse()},Et.prototype.toArray=function(){return this.take(Cn)},Hr(Et.prototype,function(n,t){var r=/^(?:filter|find|map|reject)|While$/.test(t),e=/^(?:head|last)$/.test(t),u=q[e?"take"+("last"==t?"Right":""):t],i=e||/^find/.test(t);
u&&(q.prototype[t]=function(){var t=this.__wrapped__,o=e?[1]:arguments,f=t instanceof Et,c=o[0],l=f||fh(t),s=function(n){var t=u.apply(q,a([n],o));return e&&h?t[0]:t};l&&r&&"function"==typeof c&&1!=c.length&&(f=l=!1);var h=this.__chain__,p=!!this.__actions__.length,v=i&&!h,_=f&&!p;if(!i&&l){t=_?t:new Et(this);var g=n.apply(t,o);return g.__actions__.push({func:Po,args:[s],thisArg:Q}),new J(g,h)}return v&&_?n.apply(this,o):(g=this.thru(s),v?e?g.value()[0]:g.value():g)})}),r(["pop","push","shift","sort","splice","unshift"],function(n){
var t=rl[n],r=/^(?:push|sort|unshift)$/.test(n)?"tap":"thru",e=/^(?:pop|shift)$/.test(n);q.prototype[n]=function(){var n=arguments;if(e&&!this.__chain__){var u=this.value();return t.apply(fh(u)?u:[],n)}return this[r](function(r){return t.apply(fh(r)?r:[],n)})}}),Hr(Et.prototype,function(n,t){var r=q[t];if(r){var e=r.name+"";fl.call(Hl,e)||(Hl[e]=[]),Hl[e].push({name:t,func:r})}}),Hl[Nu(Q,pn).name]=[{name:"wrapper",func:Q}],Et.prototype.clone=Ct,Et.prototype.reverse=Nt,Et.prototype.value=Pt,q.prototype.at=Ms,
q.prototype.chain=qo,q.prototype.commit=Zo,q.prototype.next=Ko,q.prototype.plant=Go,q.prototype.reverse=Ho,q.prototype.toJSON=q.prototype.valueOf=q.prototype.value=Jo,q.prototype.first=q.prototype.head,jl&&(q.prototype[jl]=Vo),q},ce=fe();"function"==typeof define&&"object"==typeof define.amd&&define.amd?(Zr._=ce,define(function(){return ce})):Vr?((Vr.exports=ce)._=ce,Kr._=ce):Zr._=ce}).call(this);
//third_party/javascript/angular/v1_6/angular.min.js
/*
 AngularJS v1.6.4-local+sha.617b36117
 (c) 2010-2018 Google, Inc. http://angularjs.org
 License: MIT

 Copyright 2013 Google, Inc. http://angularjs.org
 SPDX-License-Identifier: MIT
*/
(function(ia){'use strict';function Nf(a){if(fa(a))R(a.objectMaxDepth)&&(de.objectMaxDepth=fd(a.objectMaxDepth)?a.objectMaxDepth:NaN);else return de}function fd(a){return Ra(a)&&0<a}function va(a){return function(){var b=arguments[0];var d="["+(a?a+":":"")+b+"] http://errors.angularjs.org/1.6.4-local+sha.617b36117/"+(a?a+"/":"")+b;for(b=1;b<arguments.length;b++){d=d+(1==b?"?":"&")+"p"+(b-1)+"=";var c=encodeURIComponent;var e=arguments[b];e="function"==typeof e?e.toString().replace(/ \{[\s\S]*$/,""):"undefined"==
typeof e?"undefined":"string"!=typeof e?JSON.stringify(e):e;d+=c(e)}return Error(d)}}function ub(a){if(null==a||$b(a))return!1;if(na(a)||oa(a)||da&&a instanceof da)return!0;var b="length"in Object(a)&&a.length;return Ra(b)&&(0<=b&&(b-1 in a||a instanceof Array)||"function"===typeof a.item)}function J(a,b,d){var c;if(a)if(ca(a))for(f in a)"prototype"!==f&&"length"!==f&&"name"!==f&&a.hasOwnProperty(f)&&b.call(d,a[f],f,a);else if(na(a)||ub(a)){var e="object"!==typeof a;var f=0;for(c=a.length;f<c;f++)(e||
f in a)&&b.call(d,a[f],f,a)}else if(a.forEach&&a.forEach!==J)a.forEach(b,d,a);else if(ee(a))for(f in a)b.call(d,a[f],f,a);else if("function"===typeof a.hasOwnProperty)for(f in a)a.hasOwnProperty(f)&&b.call(d,a[f],f,a);else for(f in a)bb.call(a,f)&&b.call(d,a[f],f,a);return a}function fe(a,b,d){for(var c=Object.keys(a).sort(),e=0;e<c.length;e++)b.call(d,a[c[e]],c[e]);return c}function gd(a){return function(b,d){a(d,b)}}function Of(){return++sc}function hd(a,b,d){for(var c=a.$$hashKey,e=0,f=b.length;e<
f;++e){var g=b[e];if(fa(g)||ca(g))for(var k=Object.keys(g),h=0,l=k.length;h<l;h++){var n=k[h],r=g[n];d&&fa(r)?Xa(r)?a[n]=new Date(r.valueOf()):tc(r)?a[n]=new RegExp(r):r.nodeName?a[n]=r.cloneNode(!0):id(r)?a[n]=r.clone():"__proto__"!==n&&(fa(a[n])||(a[n]=na(r)?[]:{}),hd(a[n],[r],!0)):a[n]=r}}c?a.$$hashKey=c:delete a.$$hashKey;return a}function Aa(a){return hd(a,hb.call(arguments,1),!1)}function Pf(a){return hd(a,hb.call(arguments,1),!0)}function jd(a,b){return Aa(Object.create(a),b)}function la(){}
function uc(a){return a}function cb(a){return function(){return a}}function kd(a){return ca(a.toString)&&a.toString!==Ta}function U(a){return"undefined"===typeof a}function R(a){return"undefined"!==typeof a}function fa(a){return null!==a&&"object"===typeof a}function ee(a){return null!==a&&"object"===typeof a&&!ge(a)}function oa(a){return"string"===typeof a}function Ra(a){return"number"===typeof a}function Xa(a){return"[object Date]"===Ta.call(a)}function ld(a){switch(Ta.call(a)){case "[object Error]":return!0;
case "[object Exception]":return!0;case "[object DOMException]":return!0;default:return a instanceof Error}}function ca(a){return"function"===typeof a}function tc(a){return"[object RegExp]"===Ta.call(a)}function $b(a){return a&&a.window===a}function ac(a){return a&&a.$evalAsync&&a.$watch}function vb(a){return"boolean"===typeof a}function Qf(a){return a&&Ra(a.length)&&Rf.test(Ta.call(a))}function id(a){return!(!a||!(a.nodeName||a.prop&&a.attr&&a.find))}function Sf(a){var b={};a=a.split(",");var d;
for(d=0;d<a.length;d++)b[a[d]]=!0;return b}function ib(a){return xa(a.nodeName||a[0]&&a[0].nodeName)}function bc(a,b){b=a.indexOf(b);0<=b&&a.splice(b,1);return b}function Bb(a,b,d){function c(h,l,n){n--;if(0>n)return"...";var r=l.$$hashKey;if(na(h)){var u=0;for(var w=h.length;u<w;u++)l.push(e(h[u],n))}else if(ee(h))for(u in h)l[u]=e(h[u],n);else if(h&&"function"===typeof h.hasOwnProperty)for(u in h)h.hasOwnProperty(u)&&(l[u]=e(h[u],n));else for(u in h)bb.call(h,u)&&(l[u]=e(h[u],n));r?l.$$hashKey=
r:delete l.$$hashKey;return l}function e(h,l){if(!fa(h))return h;var n=g.indexOf(h);if(-1!==n)return k[n];if($b(h)||ac(h))throw Cb("cpws");n=!1;var r=f(h);void 0===r&&(r=na(h)?[]:Object.create(ge(h)),n=!0);g.push(h);k.push(r);return n?c(h,r,l):r}function f(h){switch(Ta.call(h)){case "[object Int8Array]":case "[object Int16Array]":case "[object Int32Array]":case "[object Float32Array]":case "[object Float64Array]":case "[object Uint8Array]":case "[object Uint8ClampedArray]":case "[object Uint16Array]":case "[object Uint32Array]":return new h.constructor(e(h.buffer),
h.byteOffset,h.length);case "[object ArrayBuffer]":if(!h.slice){var l=new ArrayBuffer(h.byteLength);(new Uint8Array(l)).set(new Uint8Array(h));return l}return h.slice(0);case "[object Boolean]":case "[object Number]":case "[object String]":case "[object Date]":return new h.constructor(h.valueOf());case "[object RegExp]":return l=new RegExp(h.source,h.toString().match(/[^/]*$/)[0]),l.lastIndex=h.lastIndex,l;case "[object Blob]":return new h.constructor([h],{type:h.type})}if(ca(h.cloneNode))return h.cloneNode(!0)}
var g=[],k=[];d=fd(d)?d:NaN;if(b){if(Qf(b)||"[object ArrayBuffer]"===Ta.call(b))throw Cb("cpta");if(a===b)throw Cb("cpi");na(b)?b.length=0:J(b,function(h,l){"$$hashKey"!==l&&delete b[l]});g.push(a);k.push(b);return c(a,b,d)}return e(a,d)}function md(a,b){return a===b||a!==a&&b!==b}function db(a,b){if(a===b)return!0;if(null===a||null===b)return!1;if(a!==a&&b!==b)return!0;var d=typeof a,c;if(d===typeof b&&"object"===d)if(na(a)){if(!na(b))return!1;if((d=a.length)===b.length){for(c=0;c<d;c++)if(!db(a[c],
b[c]))return!1;return!0}}else{if(Xa(a))return Xa(b)?md(a.getTime(),b.getTime()):!1;if(tc(a))return tc(b)?a.toString()===b.toString():!1;if(ac(a)||ac(b)||$b(a)||$b(b)||na(b)||Xa(b)||tc(b))return!1;d=Ea();for(c in a)if("$"!==c.charAt(0)&&!ca(a[c])){if(!db(a[c],b[c]))return!1;d[c]=!0}for(c in b)if(!(c in d)&&"$"!==c.charAt(0)&&R(b[c])&&!ca(b[c]))return!1;return!0}return!1}function cc(a,b,d){return a.concat(hb.call(b,d))}function Mb(a,b){var d=2<arguments.length?hb.call(arguments,2):[];return!ca(b)||
b instanceof RegExp?b:d.length?function(){return arguments.length?b.apply(a,cc(d,arguments,0)):b.apply(a,d)}:function(){return arguments.length?b.apply(a,arguments):b.call(a)}}function he(a,b){var d=b;"string"===typeof a&&"$"===a.charAt(0)&&"$"===a.charAt(1)?d=void 0:$b(b)?d="$WINDOW":b&&ia.document===b?d="$DOCUMENT":ac(b)&&(d="$SCOPE");return d}function dc(a,b){if(!U(a))return Ra(b)||(b=b?2:null),JSON.stringify(a,he,b)}function ie(a){return oa(a)?JSON.parse(a):a}function nd(a,b){a=a.replace(Tf,"");
a=Date.parse("Jan 01, 1970 00:00:00 "+a)/6E4;return Ua(a)?b:a}function je(a,b){a=new Date(a.getTime());a.setMinutes(a.getMinutes()+b);return a}function od(a,b,d){d=d?-1:1;var c=a.getTimezoneOffset();b=nd(b,c);return je(a,d*(b-c))}function jb(a){a=da(a).clone().empty();var b=da("<div></div>").append(a).html();try{return a[0].nodeType===wb?xa(b):b.match(/^(<[^>]+>)/)[1].replace(/^<([\w-]+)/,function(d,c){return"<"+xa(c)})}catch(d){return xa(b)}}function ke(a){try{return decodeURIComponent(a)}catch(b){}}
function pd(a){var b={};J((a||"").split("&"),function(d){if(d){var c=d=d.replace(/\+/g,"%20");var e=d.indexOf("=");if(-1!==e){c=d.substring(0,e);var f=d.substring(e+1)}c=ke(c);R(c)&&(f=R(f)?ke(f):!0,bb.call(b,c)?na(b[c])?b[c].push(f):b[c]=[b[c],f]:b[c]=f)}});return b}function qd(a){var b=[];J(a,function(d,c){na(d)?J(d,function(e){b.push(Za(c,!0)+(!0===e?"":"="+Za(e,!0)))}):b.push(Za(c,!0)+(!0===d?"":"="+Za(d,!0)))});return b.length?b.join("&"):""}function ec(a){return Za(a,!0).replace(/%26/gi,"&").replace(/%3D/gi,
"=").replace(/%2B/gi,"+")}function Za(a,b){return encodeURIComponent(a).replace(/%40/gi,"@").replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%3B/gi,";").replace(/%20/g,b?"%20":"+")}function Uf(a,b){var d,c=Nb.length;for(d=0;d<c;++d){var e=Nb[d]+b;if(oa(e=a.getAttribute(e)))return e}return null}function Vf(a,b){var d,c,e={};J(Nb,function(f){f+="app";!d&&a.hasAttribute&&a.hasAttribute(f)&&(d=a,c=a.getAttribute(f))});J(Nb,function(f){f+="app";var g;!d&&(g=a.querySelector("["+f.replace(":",
"\\:")+"]"))&&(d=g,c=g.getAttribute(f))});d&&(Wf?(e.strictDi=null!==Uf(d,"strict-di"),b(d,c?[c]:[],e)):ia.console.error("AngularJS: disabling automatic bootstrap. <script> protocol indicates an extension, document.location.href does not match."))}function le(a,b,d){fa(d)||(d={});d=Aa({strictDi:!1},d);var c=function(){a=da(a);if(a.injector()){var g=a[0]===ia.document?"document":jb(a);throw Cb("btstrpd",g.replace(/</,"&lt;").replace(/>/,"&gt;"));}b=b||[];b.unshift(["$provide",function(k){k.value("$rootElement",
a)}]);d.debugInfoEnabled&&b.push(["$compileProvider",function(k){k.debugInfoEnabled(!0)}]);b.unshift("ng");g=fc(b,d.strictDi);g.invoke(["$rootScope","$rootElement","$compile","$injector",function(k,h,l,n){k.$apply(function(){h.data("$injector",n);l(h)(k)})}]);return g},e=/^NG_ENABLE_DEBUG_INFO!/,f=/^NG_DEFER_BOOTSTRAP!/;ia&&e.test(ia.name)&&(d.debugInfoEnabled=!0,ia.name=ia.name.replace(e,""));if(ia&&!f.test(ia.name))return c();ia.name=ia.name.replace(f,"");Va.resumeBootstrap=function(g){J(g,function(k){b.push(k)});
return c()};ca(Va.resumeDeferredBootstrap)&&Va.resumeDeferredBootstrap()}function Xf(){ia.name="NG_ENABLE_DEBUG_INFO!"+ia.name;ia.location.reload()}function Yf(a){a=Va.element(a).injector();if(!a)throw Cb("test");return a.get("$$testability")}function me(a,b){b=b||"_";return a.replace(Zf,function(d,c){return(c?b:"")+d.toLowerCase()})}function gc(a,b,d){if(!a)throw Cb("areq",b||"?",d||"required");return a}function vc(a,b,d){d&&na(a)&&(a=a[a.length-1]);gc(ca(a),b,"not a function, got "+(a&&"object"===
typeof a?a.constructor.name||"Object":typeof a));return a}function Ob(a,b){if("hasOwnProperty"===a)throw Cb("badname",b);}function ne(a,b,d){if(!b)return a;b=b.split(".");for(var c,e=a,f=b.length,g=0;g<f;g++)c=b[g],a&&(a=(e=a)[c]);return!d&&ca(a)?Mb(e,a):a}function wc(a){for(var b=a[0],d=a[a.length-1],c,e=1;b!==d&&(b=b.nextSibling);e++)if(c||a[e]!==b)c||(c=da(hb.call(a,0,e))),c.push(b);return c||a}function Ea(){return Object.create(null)}function rd(a){if(null==a)return"";switch(typeof a){case "string":break;
case "number":a=""+a;break;default:a=!kd(a)||na(a)||Xa(a)?dc(a):a.toString()}return a}function $f(a){function b(e,f,g){return e[f]||(e[f]=g())}var d=va("$injector"),c=va("ng");a=b(a,"angular",Object);a.$$minErr=a.$$minErr||va;return b(a,"module",function(){var e={};return function(f,g,k){var h={};if("hasOwnProperty"===f)throw c("badname","module");g&&e.hasOwnProperty(f)&&(e[f]=null);return b(e,f,function(){function l(C,D,y,v){v||(v=r);return function(){v[y||"push"]([C,D,arguments]);return F}}function n(C,
D,y){y||(y=r);return function(v,p){p&&ca(p)&&(p.$$moduleName=f);y.push([C,D,arguments]);return F}}if(!g)throw d("nomod",f);var r=[],u=[],w=[],H=l("$injector","invoke","push",u),F={_invokeQueue:r,_configBlocks:u,_runBlocks:w,info:function(C){if(R(C)){if(!fa(C))throw c("aobj","value");h=C;return this}return h},requires:g,name:f,provider:n("$provide","provider"),factory:n("$provide","factory"),service:n("$provide","service"),value:l("$provide","value"),constant:l("$provide","constant","unshift"),decorator:n("$provide",
"decorator",u),animation:n("$animateProvider","register"),filter:n("$filterProvider","register"),controller:n("$controllerProvider","register"),directive:n("$compileProvider","directive"),component:n("$compileProvider","component"),config:H,run:function(C){w.push(C);return this}};k&&H(k);return F})}})}function kb(a,b){if(na(a)){b=b||[];for(var d=0,c=a.length;d<c;d++)b[d]=a[d]}else if(fa(a))for(d in b=b||{},a)if("$"!==d.charAt(0)||"$"!==d.charAt(1))b[d]=a[d];return b||a}function ag(a,b){var d=[];fd(b)&&
(a=Va.copy(a,null,b));return JSON.stringify(a,function(c,e){e=he(c,e);if(fa(e)){if(0<=d.indexOf(e))return"...";d.push(e)}return e})}function Db(a,b){return b.toUpperCase()}function sd(a){a=a.nodeType;return 1===a||!a||9===a}function oe(a,b){var d=b.createDocumentFragment(),c=[];if(td.test(a)){b=d.appendChild(b.createElement("div"));var e=(bg.exec(a)||["",""])[1].toLowerCase();e=eb[e]||eb._default;b.innerHTML=e[1]+a.replace(cg,"<$1></$2>")+e[2];for(a=e[0];a--;)b=b.lastChild;c=cc(c,b.childNodes);b=
d.firstChild;b.textContent=""}else c.push(b.createTextNode(a));d.textContent="";d.innerHTML="";J(c,function(f){d.appendChild(f)});return d}function Ha(a){if(a instanceof Ha)return a;if(oa(a)){a=Ca(a);var b=!0}if(!(this instanceof Ha)){if(b&&"<"!==a.charAt(0))throw ud("nosel");return new Ha(a)}if(b){b=a;var d=ia.document;var c;a=(c=dg.exec(b))?[d.createElement(c[1])]:(c=oe(b,d))?c.childNodes:[];vd(this,a)}else ca(a)?pe(a):vd(this,a)}function wd(a){return a.cloneNode(!0)}function xc(a,b){!b&&sd(a)&&
da.cleanData([a]);a.querySelectorAll&&da.cleanData(a.querySelectorAll("*"))}function qe(a,b,d,c){if(R(c))throw ud("offargs");var e=(c=yc(a))&&c.events,f=c&&c.handle;if(f)if(b){var g=function(k){var h=e[k];R(d)&&bc(h||[],d);R(d)&&h&&0<h.length||(a.removeEventListener(k,f),delete e[k])};J(b.split(" "),function(k){g(k);zc[k]&&g(zc[k])})}else for(b in e)"$destroy"!==b&&a.removeEventListener(b,f),delete e[b]}function xd(a,b){var d=a.ng339,c=d&&hc[d];c&&(b?delete c.data[b]:(c.handle&&(c.events.$destroy&&
c.handle({},"$destroy"),qe(a)),delete hc[d],a.ng339=void 0))}function yc(a,b){var d=a.ng339;d=d&&hc[d];b&&!d&&(a.ng339=d=++eg,d=hc[d]={events:{},data:{},handle:void 0});return d}function yd(a,b,d){if(sd(a)){var c,e=R(d),f=!e&&b&&!fa(b),g=!b;a=(a=yc(a,!f))&&a.data;if(e)a[b.replace(Ac,Db)]=d;else{if(g)return a;if(f)return a&&a[b.replace(Ac,Db)];for(c in b)a[c.replace(Ac,Db)]=b[c]}}}function Bc(a,b){return a.getAttribute?-1<(" "+(a.getAttribute("class")||"")+" ").replace(/[\n\t]/g," ").indexOf(" "+b+
" "):!1}function Cc(a,b){if(b&&a.setAttribute){var d=(" "+(a.getAttribute("class")||"")+" ").replace(/[\n\t]/g," "),c=d;J(b.split(" "),function(e){e=Ca(e);c=c.replace(" "+e+" "," ")});c!==d&&a.setAttribute("class",Ca(c))}}function Dc(a,b){if(b&&a.setAttribute){var d=(" "+(a.getAttribute("class")||"")+" ").replace(/[\n\t]/g," "),c=d;J(b.split(" "),function(e){e=Ca(e);-1===c.indexOf(" "+e+" ")&&(c+=e+" ")});c!==d&&a.setAttribute("class",Ca(c))}}function vd(a,b){if(b)if(b.nodeType)a[a.length++]=b;else{var d=
b.length;if("number"===typeof d&&b.window!==b){if(d)for(var c=0;c<d;c++)a[a.length++]=b[c]}else a[a.length++]=b}}function re(a,b){return Ec(a,"$"+(b||"ngController")+"Controller")}function Ec(a,b,d){9===a.nodeType&&(a=a.documentElement);for(b=na(b)?b:[b];a;){for(var c=0,e=b.length;c<e;c++)if(R(d=da.data(a,b[c])))return d;a=a.parentNode||11===a.nodeType&&a.host}}function se(a){for(xc(a,!0);a.firstChild;)a.removeChild(a.firstChild)}function Fc(a,b){b||xc(a);(b=a.parentNode)&&b.removeChild(a)}function fg(a,
b){b=b||ia;if("complete"===b.document.readyState)b.setTimeout(a);else da(b).on("load",a)}function pe(a){function b(){ia.document.removeEventListener("DOMContentLoaded",b);ia.removeEventListener("load",b);a()}"complete"===ia.document.readyState?ia.setTimeout(a):(ia.document.addEventListener("DOMContentLoaded",b),ia.addEventListener("load",b))}function te(a,b){return(b=Gc[b.toLowerCase()])&&ue[ib(a)]&&b}function gg(a,b){var d=function(c,e){c.isDefaultPrevented=function(){return c.defaultPrevented};
var f=(e=b[e||c.type])?e.length:0;if(f){if(U(c.immediatePropagationStopped)){var g=c.stopImmediatePropagation;c.stopImmediatePropagation=function(){c.immediatePropagationStopped=!0;c.stopPropagation&&c.stopPropagation();g&&g.call(c)}}c.isImmediatePropagationStopped=function(){return!0===c.immediatePropagationStopped};var k=e.specialHandlerWrapper||hg;1<f&&(e=kb(e));for(var h=0;h<f;h++)c.isImmediatePropagationStopped()||k(a,c,e[h])}};d.elem=a;return d}function hg(a,b,d){d.call(a,b)}function ig(a,b,
d){var c=b.relatedTarget;c&&(c===a||jg.call(a,c))||d.call(a,b)}function kg(){this.$get=function(){return Aa(Ha,{hasClass:function(a,b){a.attr&&(a=a[0]);return Bc(a,b)},addClass:function(a,b){a.attr&&(a=a[0]);return Dc(a,b)},removeClass:function(a,b){a.attr&&(a=a[0]);return Cc(a,b)}})}}function Pb(a,b){var d=a&&a.$$hashKey;if(d)return"function"===typeof d&&(d=a.$$hashKey()),d;d=typeof a;return d="function"===d||"object"===d&&null!==a?a.$$hashKey=d+":"+(b||Of)():d+":"+a}function ve(){this._keys=[];
this._values=[];this._lastKey=NaN;this._lastIndex=-1}function we(a){a=Function.prototype.toString.call(a).replace(lg,"");return a.match(mg)||a.match(og)}function pg(a){return(a=we(a))?"function("+(a[1]||"").replace(/[\s\r\n]+/," ")+")":"fn"}function fc(a,b){function d(C){return function(D,y){if(fa(D))J(D,gd(C));else return C(D,y)}}function c(C,D){Ob(C,"service");if(ca(D)||na(D))D=u.instantiate(D);if(!D.$get)throw Eb("pget",C);return r[C+"Provider"]=D}function e(C,D){return function(){var y=F.invoke(D,
this);if(U(y))throw Eb("undef",C);return y}}function f(C,D,y){return c(C,{$get:!1!==y?e(C,D):D})}function g(C){gc(U(C)||na(C),"modulesToLoad","not an array");var D=[],y;J(C,function(v){function p(q){var m;var x=0;for(m=q.length;x<m;x++){var G=q[x],B=u.get(G[0]);B[G[1]].apply(B,G[2])}}if(!n.get(v)){n.set(v,!0);try{oa(v)?(y=zd(v),F.modules[v]=y,D=D.concat(g(y.requires)).concat(y._runBlocks),p(y._invokeQueue),p(y._configBlocks)):ca(v)?D.push(u.invoke(v)):na(v)?D.push(u.invoke(v)):vc(v,"module")}catch(q){throw na(v)&&
(v=v[v.length-1]),q.message&&q.stack&&-1===q.stack.indexOf(q.message)&&(q=q.message+"\n"+q.stack),Eb("modulerr",v,q.stack||q.message||q);}}});return D}function k(C,D){function y(p,q){if(C.hasOwnProperty(p)){if(C[p]===h)throw Eb("cdep",p+" <- "+l.join(" <- "));return C[p]}try{return l.unshift(p),C[p]=h,C[p]=D(p,q),C[p]}catch(m){throw C[p]===h&&delete C[p],m;}finally{l.shift()}}function v(p,q,m){var x=[];p=fc.$$annotate(p,b,m);for(var G=0,B=p.length;G<B;G++){var A=p[G];if("string"!==typeof A)throw Eb("itkn",
A);x.push(q&&q.hasOwnProperty(A)?q[A]:y(A,m))}return x}return{invoke:function(p,q,m,x){"string"===typeof m&&(x=m,m=null);m=v(p,m,x);na(p)&&(p=p[p.length-1]);x=p;if(qb||"function"!==typeof x)x=!1;else{var G=x.$$ngIsClass;vb(G)||(G=x.$$ngIsClass=/^(?:class\b|constructor\()/.test(Function.prototype.toString.call(x)));x=G}return x?(m.unshift(null),new (Function.prototype.bind.apply(p,m))):p.apply(q,m)},instantiate:function(p,q,m){var x=na(p)?p[p.length-1]:p;p=v(p,q,m);p.unshift(null);return new (Function.prototype.bind.apply(x,
p))},get:y,annotate:fc.$$annotate,has:function(p){return r.hasOwnProperty(p+"Provider")||C.hasOwnProperty(p)}}}b=!0===b;var h={},l=[],n=new Hc,r={$provide:{provider:d(c),factory:d(f),service:d(function(C,D){return f(C,["$injector",function(y){return y.instantiate(D)}])}),value:d(function(C,D){return f(C,cb(D),!1)}),constant:d(function(C,D){Ob(C,"constant");r[C]=D;w[C]=D}),decorator:function(C,D){var y=u.get(C+"Provider"),v=y.$get;y.$get=function(){var p=F.invoke(v,y);return F.invoke(D,null,{$delegate:p})}}}},
u=r.$injector=k(r,function(C,D){Va.isString(D)&&l.push(D);throw Eb("unpr",l.join(" <- "));}),w={},H=k(w,function(C,D){D=u.get(C+"Provider",D);return F.invoke(D.$get,D,void 0,C)}),F=H;r.$injectorProvider={$get:cb(H)};F.modules=u.modules=Ea();a=g(a);F=H.get("$injector");F.strictDi=b;J(a,function(C){C&&F.invoke(C)});F.loadNewModules=function(C){J(g(C),function(D){D&&F.invoke(D)})};return F}function qg(){var a=!0;this.disableAutoScrolling=function(){a=!1};this.$get=["$window","$location","$rootScope",
function(b,d,c){function e(h){var l=null;Array.prototype.some.call(h,function(n){if("a"===ib(n))return l=n,!0});return l}function f(h){if(h){h.scrollIntoView();var l=g.yOffset;ca(l)?l=l():id(l)?(l=l[0],l="fixed"!==b.getComputedStyle(l).position?0:l.getBoundingClientRect().bottom):Ra(l)||(l=0);l&&(h=h.getBoundingClientRect().top,b.scrollBy(0,h-l))}else b.scrollTo(0,0)}function g(h){h=oa(h)?h:Ra(h)?h.toString():d.hash();var l;h?(l=k.getElementById(h))?f(l):(l=e(k.getElementsByName(h)))?f(l):"top"===
h&&f(null):f(null)}var k=b.document;a&&c.$watch(function(){return d.hash()},function(h,l){h===l&&""===h||fg(function(){c.$evalAsync(g)})});return g}]}function ic(a,b){if(!a&&!b)return"";if(!a)return b;if(!b)return a;na(a)&&(a=a.join(" "));na(b)&&(b=b.join(" "));return a+" "+b}function rg(a){oa(a)&&(a=a.split(" "));var b=Ea();J(a,function(d){d.length&&(b[d]=!0)});return b}function Fb(a){return fa(a)?a:{}}function sg(a,b,d,c){function e(B){try{B.apply(null,hb.call(arguments,1))}finally{if(H--,0===H)for(;F.length;)try{F.pop()()}catch(A){d.error(A)}}}
function f(){p=null;k()}function g(){C=q();C=U(C)?null:C;db(C,G)&&(C=G);D=G=C}function k(){var B=D;g();if(y!==h.url()||B!==C)y=h.url(),D=C,J(m,function(A){A(h.url(),C)})}var h=this,l=a.location,n=a.history,r=a.setTimeout,u=a.clearTimeout,w={};h.isMock=!1;var H=0,F=[];h.$$completeOutstandingRequest=e;h.$$incOutstandingRequestCount=function(){H++};h.notifyWhenNoOutstandingRequests=function(B){0===H?B():F.push(B)};var C,D,y=l.href,v=b.find("base"),p=null,q=c.history?function(){try{return n.state}catch(B){}}:
la;g();h.url=function(B,A,E){U(E)&&(E=null);l!==a.location&&(l=a.location);n!==a.history&&(n=a.history);if(B){var L=D===E;if(y===B&&(!c.history||L))return h;var P=y&&Gb(y)===Gb(B);y=B;D=E;!c.history||P&&L?(P||(p=B),A?l.replace(B):P?(A=l,E=B.indexOf("#"),E=-1===E?"":B.substr(E),A.hash=E):l.href=B,l.href!==B&&(p=B)):(n[A?"replaceState":"pushState"](E,"",B),g());p&&(p=B);return h}return p||l.href.replace(/%27/g,"'")};h.state=function(){return C};var m=[],x=!1,G=null;h.onUrlChange=function(B){if(!x){if(c.history)da(a).on("popstate",
f);da(a).on("hashchange",f);x=!0}m.push(B);return B};h.$$applicationDestroyed=function(){da(a).off("hashchange popstate",f)};h.$$checkUrlChange=k;h.baseHref=function(){var B=v.attr("href");return B?B.replace(/^(https?:)?\/\/[^/]*/,""):""};h.defer=function(B,A){H++;var E=r(function(){delete w[E];e(B)},A||0);w[E]=!0;return E};h.defer.cancel=function(B){return w[B]?(delete w[B],u(B),e(la),!0):!1}}function tg(){this.$get=["$window","$log","$sniffer","$document",function(a,b,d,c){return new sg(a,c,b,d)}]}
function ug(){this.$get=function(){function a(d,c){function e(w){w!==r&&(u?u===w&&(u=w.n):u=w,f(w.n,w.p),f(w,r),r=w,r.n=null)}function f(w,H){w!==H&&(w&&(w.p=H),H&&(H.n=w))}if(d in b)throw va("$cacheFactory")("iid",d);var g=0,k=Aa({},c,{id:d}),h=Ea(),l=c&&c.capacity||Number.MAX_VALUE,n=Ea(),r=null,u=null;return b[d]={put:function(w,H){if(!U(H)){if(l<Number.MAX_VALUE){var F=n[w]||(n[w]={key:w});e(F)}w in h||g++;h[w]=H;g>l&&this.remove(u.key);return H}},get:function(w){if(l<Number.MAX_VALUE){var H=
n[w];if(!H)return;e(H)}return h[w]},remove:function(w){if(l<Number.MAX_VALUE){var H=n[w];if(!H)return;H===r&&(r=H.p);H===u&&(u=H.n);f(H.n,H.p);delete n[w]}w in h&&(delete h[w],g--)},removeAll:function(){h=Ea();g=0;n=Ea();r=u=null},destroy:function(){n=k=h=null;delete b[d]},info:function(){return Aa({},k,{size:g})}}}var b={};a.info=function(){var d={};J(b,function(c,e){d[e]=c.info()});return d};a.get=function(d){return b[d]};return a}}function vg(){this.$get=["$cacheFactory",function(a){return a("templates")}]}
function xe(a,b){function d(y,v,p){var q=/^([@&<]|=(\*?))(\??)\s*([\w$]*)$/,m=Ea();J(y,function(x,G){x=x.trim();if(x in r)m[G]=r[x];else{var B=x.match(q);if(!B)throw Ja("iscp",v,G,x,p?"controller bindings definition":"isolate scope definition");m[G]={mode:B[1][0],collection:"*"===B[2],optional:"?"===B[3],attrName:B[4]||G};B[4]&&(r[x]=m[G])}});return m}function c(y){var v=y.charAt(0);if(!v||v!==xa(v))throw Ja("baddir",y);if(y!==y.trim())throw Ja("baddir",y);}function e(y){var v=y.require||y.controller&&
y.name;!na(v)&&fa(v)&&J(v,function(p,q){var m=p.match(l);p.substring(m[0].length)||(v[q]=m[0]+q)});return v}var f={},g=/^\s*directive:\s*([\w-]+)\s+(.*)$/,k=/(([\w-]+)(?::([^;]+))?;?)/,h=Sf("ngSrc,ngSrcset,src,srcset"),l=/^(?:(\^\^?)?(\?)?(\^\^?)?)?/,n=/^(on[a-z]+|formaction)$/,r=Ea();this.directive=function q(v,p){gc(v,"name");Ob(v,"directive");oa(v)?(c(v),gc(p,"directiveFactory"),f.hasOwnProperty(v)||(f[v]=[],a.factory(v+"Directive",["$injector","$exceptionHandler",function(m,x){var G=[];J(f[v],
function(B,A){try{var E=m.invoke(B);ca(E)?E={compile:cb(E)}:!E.compile&&E.link&&(E.compile=cb(E.link));E.priority=E.priority||0;E.index=A;E.name=E.name||v;E.require=e(E);A=E;var L=E.restrict;if(L&&(!oa(L)||!/[EACM]/.test(L)))throw Ja("badrestrict",L,v);A.restrict=L||"EA";E.$$moduleName=B.$$moduleName;G.push(E)}catch(P){x(P)}});return G}])),f[v].push(p)):J(v,gd(q));return this};this.component=function m(p,q){function x(B){function A(P){return ca(P)||na(P)?function(S,X){return B.invoke(P,this,{$element:S,
$attrs:X})}:P}var E=q.template||q.templateUrl?q.template:"",L={controller:G,controllerAs:wg(q.controller)||q.controllerAs||"$ctrl",template:A(E),templateUrl:A(q.templateUrl),transclude:q.transclude,scope:{},bindToController:q.bindings||{},restrict:"E",require:q.require};J(q,function(P,S){"$"===S.charAt(0)&&(L[S]=P)});return L}if(!oa(p))return J(p,gd(Mb(this,m))),this;var G=q.controller||function(){};J(q,function(B,A){"$"===A.charAt(0)&&(x[A]=B,ca(G)&&(G[A]=B))});x.$inject=["$injector"];return this.directive(p,
x)};this.aHrefSanitizationWhitelist=function(p){return R(p)?(b.aHrefSanitizationWhitelist(p),this):b.aHrefSanitizationWhitelist()};this.imgSrcSanitizationWhitelist=function(p){return R(p)?(b.imgSrcSanitizationWhitelist(p),this):b.imgSrcSanitizationWhitelist()};var u=!0;this.debugInfoEnabled=function(p){return R(p)?(u=p,this):u};var w=!1;this.preAssignBindingsEnabled=function(p){return R(p)?(w=p,this):w};var H=!1;this.strictComponentBindingsEnabled=function(p){return R(p)?(H=p,this):H};var F=10;this.onChangesTtl=
function(p){return arguments.length?(F=p,this):F};var C=!0;this.commentDirectivesEnabled=function(p){return arguments.length?(C=p,this):C};var D=!0;this.cssClassDirectivesEnabled=function(p){return arguments.length?(D=p,this):D};this.$get=["$injector","$interpolate","$exceptionHandler","$templateRequest","$parse","$controller","$rootScope","$sce","$animate","$$sanitizeUri",function(p,q,m,x,G,B,A,E,L,P){function S(){try{if(!--ye)throw Hb=void 0,Ja("infchng",F);A.$apply(function(){for(var t=0,z=Hb.length;t<
z;++t)try{Hb[t]()}catch(I){m(I)}Hb=void 0})}finally{ye++}}function X(t,z){if(z){var I=Object.keys(z),M;var N=0;for(M=I.length;N<M;N++){var K=I[N];this[K]=z[K]}}else this.$attr={};this.$$element=t}function ha(t,z,I){ze.innerHTML="<span "+z+">";z=ze.firstChild.attributes;var M=z[0];z.removeNamedItem(M.name);M.value=I;t.attributes.setNamedItem(M)}function ja(t,z){try{t.addClass(z)}catch(I){}}function ea(t,z,I,M,N){t instanceof da||(t=da(t));var K=ma(t,z,t,I,M,N);ea.$$addScopeClass(t);var aa=null;return function(O,
Z,V){if(!t)throw Ja("multilink");gc(O,"scope");N&&N.needsNewScope&&(O=O.$parent.$new());V=V||{};var W=V.parentBoundTranscludeFn,ba=V.transcludeControllers;V=V.futureParentElement;W&&W.$$boundTransclude&&(W=W.$$boundTransclude);aa||(aa=(V=V&&V[0])?"foreignobject"!==ib(V)&&Ta.call(V).match(/SVG/)?"svg":"html":"html");V="html"!==aa?da(Ad(aa,da("<div></div>").append(t).html())):Z?Qb.clone.call(t):t;if(ba)for(var T in ba)V.data("$"+T+"Controller",ba[T].instance);ea.$$addScopeInfo(V,O);Z&&Z(V,O);K&&K(O,
V,V,W);Z||(t=K=null);return V}}function ma(t,z,I,M,N,K){function aa(sa,pa,Ga,Fa){var za,qa;if(ta){var Y=Array(pa.length);for(za=0;za<O.length;za+=3){var Ka=O[za];Y[Ka]=pa[Ka]}}else Y=pa;za=0;for(qa=O.length;za<qa;){var Ia=Y[O[za++]];pa=O[za++];Ka=O[za++];if(pa){if(pa.scope){var $a=sa.$new();ea.$$addScopeInfo(da(Ia),$a)}else $a=sa;var xb=pa.transcludeOnThisElement?ya(sa,pa.transclude,Fa):!pa.templateOnThisElement&&Fa?Fa:!Fa&&z?ya(sa,z):null;pa(Ka,$a,Ia,Ga,xb)}else Ka&&Ka(sa,Ia.childNodes,void 0,Fa)}}
for(var O=[],Z=na(t)||t instanceof da,V,W,ba,T,ta,ra=0;ra<t.length;ra++){V=new X;11===qb&&ka(t,ra,Z);W=ua(t[ra],[],V,0===ra?M:void 0,N);(K=W.length?Ae(W,t[ra],V,z,I,null,[],[],K):null)&&K.scope&&ea.$$addScopeClass(V.$$element);V=K&&K.terminal||!(ba=t[ra].childNodes)||!ba.length?null:ma(ba,K?(K.transcludeOnThisElement||!K.templateOnThisElement)&&K.transclude:z);if(K||V)O.push(ra,K,V),T=!0,ta=ta||K;K=null}return T?aa:null}function ka(t,z,I){var M=t[z],N=M.parentNode;if(M.nodeType===wb)for(;;){var K=
N?M.nextSibling:t[z+1];if(!K||K.nodeType!==wb)break;M.nodeValue+=K.nodeValue;K.parentNode&&K.parentNode.removeChild(K);I&&K===t[z+1]&&t.splice(z+1,1)}}function ya(t,z,I){function M(aa,O,Z,V,W){aa||(aa=t.$new(!1,W),aa.$$transcluded=!0);return z(aa,O,{parentBoundTranscludeFn:I,transcludeControllers:Z,futureParentElement:V})}var N=M.$$slots=Ea(),K;for(K in z.$$slots)N[K]=z.$$slots[K]?ya(t,z.$$slots[K],I):null;return M}function ua(t,z,I,M,N){var K=I.$attr;switch(t.nodeType){case 1:var aa=ib(t);Ic(z,lb(aa),
"E",M,N);for(var O,Z,V,W,ba=t.attributes,T=0,ta=ba&&ba.length;T<ta;T++){var ra=!1,sa=!1;O=ba[T];Z=O.name;V=O.value;O=lb(Z);(W=xg.test(O))&&(Z=Z.replace(Be,"").substr(8).replace(/_(.)/g,function(pa,Ga){return Ga.toUpperCase()}));(O=O.match(yg))&&zg(O[1])&&(ra=Z,sa=Z.substr(0,Z.length-5)+"end",Z=Z.substr(0,Z.length-6));O=lb(Z.toLowerCase());K[O]=Z;if(W||!I.hasOwnProperty(O))I[O]=V,te(t,O)&&(I[O]=!0);Ag(t,z,V,O,W);Ic(z,O,"A",M,N,ra,sa)}"input"===aa&&"hidden"===t.getAttribute("type")&&t.setAttribute("autocomplete",
"off");if(!Bg)break;K=t.className;fa(K)&&(K=K.animVal);if(oa(K)&&""!==K)for(;t=k.exec(K);)O=lb(t[2]),Ic(z,O,"C",M,N)&&(I[O]=Ca(t[3])),K=K.substr(t.index+t[0].length);break;case wb:Cg(z,t.nodeValue);break;case 8:Dg&&mb(t,z,I,M,N)}z.sort(Eg);return z}function mb(t,z,I,M,N){try{var K=g.exec(t.nodeValue);if(K){var aa=lb(K[1]);Ic(z,aa,"M",M,N)&&(I[aa]=Ca(K[2]))}}catch(O){}}function Ce(t,z,I){var M=[],N=0;if(z&&t.hasAttribute&&t.hasAttribute(z)){do{if(!t)throw Ja("uterdir",z,I);1===t.nodeType&&(t.hasAttribute(z)&&
N++,t.hasAttribute(I)&&N--);M.push(t);t=t.nextSibling}while(0<N)}else M.push(t);return da(M)}function De(t,z,I){return function(M,N,K,aa,O){N=Ce(N[0],z,I);return t(M,N,K,aa,O)}}function Bd(t,z,I,M,N,K){var aa;return t?ea(z,I,M,N,K):function(){aa||(aa=ea(z,I,M,N,K),z=I=K=null);return aa.apply(this,arguments)}}function Ae(t,z,I,M,N,K,aa,O,Z){function V(Da,wa,fb,ab){if(Da){fb&&(Da=De(Da,fb,ab));Da.require=Y.require;Da.directiveName=Ka;if(ra===Y||Y.$$isolateScope)Da=Ee(Da,{isolateScope:!0});aa.push(Da)}if(wa){fb&&
(wa=De(wa,fb,ab));wa.require=Y.require;wa.directiveName=Ka;if(ra===Y||Y.$$isolateScope)wa=Ee(wa,{isolateScope:!0});O.push(wa)}}function W(Da,wa,fb,ab,Rb){function Fg(La,Na,Wa,Jc){var Cd;ac(La)||(Jc=Wa,Wa=Na,Na=La,La=void 0);za&&(Cd=nb);Wa||(Wa=za?Sa.parent():Sa);if(Jc){var Dd=Rb.$$slots[Jc];if(Dd)return Dd(La,Na,Cd,Wa,Kc);if(U(Dd))throw Ja("noslot",Jc,jb(Sa));}else return Rb(La,Na,Cd,Wa,Kc)}var nb;if(z===fb){ab=I;var Sa=I.$$element}else Sa=da(fb),ab=new X(Sa,I);var Sb=wa;if(ra)var rb=wa.$new(!0);
else T&&(Sb=wa.$parent);if(Rb){var jc=Fg;jc.$$boundTransclude=Rb;jc.isSlotFilled=function(La){return!!Rb.$$slots[La]}}ta&&(nb=Gg(Sa,ab,jc,ta,rb,wa,ra));if(ra){ea.$$addScopeInfo(Sa,rb,!0,!(sa&&(sa===ra||sa===ra.$$originalDirective)));ea.$$addScopeClass(Sa,!0);rb.$$isolateBindings=ra.$$isolateBindings;var gb=Lc(wa,ab,rb,rb.$$isolateBindings,ra);gb.removeWatches&&rb.$on("$destroy",gb.removeWatches)}for(ob in nb){gb=ta[ob];var Ba=nb[ob];var Mc=gb.$$bindings.bindToController;if(w){Ba.bindingInfo=Mc?Lc(Sb,
ab,Ba.instance,Mc,gb):{};var Ed=Ba();Ed!==Ba.instance&&(Ba.instance=Ed,Sa.data("$"+gb.name+"Controller",Ed),Ba.bindingInfo.removeWatches&&Ba.bindingInfo.removeWatches(),Ba.bindingInfo=Lc(Sb,ab,Ba.instance,Mc,gb))}else Ba.instance=Ba(),Sa.data("$"+gb.name+"Controller",Ba.instance),Ba.bindingInfo=Lc(Sb,ab,Ba.instance,Mc,gb)}J(ta,function(La,Na){var Wa=La.require;La.bindToController&&!na(Wa)&&fa(Wa)&&Aa(nb[Na].instance,kc(Na,Wa,Sa,nb))});J(nb,function(La){var Na=La.instance;if(ca(Na.$onChanges))try{Na.$onChanges(La.bindingInfo.initialChanges)}catch(Wa){m(Wa)}if(ca(Na.$onInit))try{Na.$onInit()}catch(Wa){m(Wa)}ca(Na.$doCheck)&&
(Sb.$watch(function(){Na.$doCheck()}),Na.$doCheck());ca(Na.$onDestroy)&&Sb.$on("$destroy",function(){Na.$onDestroy()})});var ob=0;for(gb=aa.length;ob<gb;ob++)Ba=aa[ob],Fe(Ba,Ba.isolateScope?rb:wa,Sa,ab,Ba.require&&kc(Ba.directiveName,Ba.require,Sa,nb),jc);var Kc=wa;ra&&(ra.template||null===ra.templateUrl)&&(Kc=rb);Da&&Da(Kc,fb.childNodes,void 0,Rb);for(ob=O.length-1;0<=ob;ob--)Ba=O[ob],Fe(Ba,Ba.isolateScope?rb:wa,Sa,ab,Ba.require&&kc(Ba.directiveName,Ba.require,Sa,nb),jc);J(nb,function(La){La=La.instance;
ca(La.$postLink)&&La.$postLink()})}Z=Z||{};for(var ba=-Number.MAX_VALUE,T=Z.newScopeDirective,ta=Z.controllerDirectives,ra=Z.newIsolateScopeDirective,sa=Z.templateDirective,pa=Z.nonTlbTranscludeDirective,Ga=!1,Fa=!1,za=Z.hasElementTranscludeDirective,qa=I.$$element=da(z),Y,Ka,Ia,$a=M,xb,yb=!1,Nc=!1,Oa,zb=0,Tb=t.length;zb<Tb;zb++){Y=t[zb];var Oc=Y.$$start,Fd=Y.$$end;Oc&&(qa=Ce(z,Oc,Fd));Ia=void 0;if(ba>Y.priority)break;if(Oa=Y.scope)Y.templateUrl||(fa(Oa)?(Ub("new/isolated scope",ra||T,Y,qa),ra=Y):
Ub("new/isolated scope",ra,Y,qa)),T=T||Y;Ka=Y.name;if(!yb&&(Y.replace&&(Y.templateUrl||Y.template)||Y.transclude&&!Y.$$tlb)){for(Oa=zb+1;yb=t[Oa++];)if(yb.transclude&&!yb.$$tlb||yb.replace&&(yb.templateUrl||yb.template)){Nc=!0;break}yb=!0}!Y.templateUrl&&Y.controller&&(ta=ta||Ea(),Ub("'"+Ka+"' controller",ta[Ka],Y,qa),ta[Ka]=Y);if(Oa=Y.transclude)if(Ga=!0,Y.$$tlb||(Ub("transclusion",pa,Y,qa),pa=Y),"element"===Oa)za=!0,ba=Y.priority,Ia=qa,qa=I.$$element=da(ea.$$createComment(Ka,I[Ka])),z=qa[0],Pc(N,
hb.call(Ia,0),z),Ia[0].$$parentNode=Ia[0].parentNode,$a=Bd(Nc,Ia,M,ba,K&&K.name,{nonTlbTranscludeDirective:pa});else{var sb=Ea();if(fa(Oa)){Ia=[];var Ge=Ea(),Gd=Ea();J(Oa,function(Da,wa){var fb="?"===Da.charAt(0);Da=fb?Da.substring(1):Da;Ge[Da]=wa;sb[wa]=null;Gd[wa]=fb});J(qa.contents(),function(Da){var wa=Ge[lb(ib(Da))];wa?(Gd[wa]=!0,sb[wa]=sb[wa]||[],sb[wa].push(Da)):Ia.push(Da)});J(Gd,function(Da,wa){if(!Da)throw Ja("reqslot",wa);});for(var Hd in sb)sb[Hd]&&(sb[Hd]=Bd(Nc,sb[Hd],M))}else Ia=da(wd(z)).contents();
qa.empty();$a=Bd(Nc,Ia,M,void 0,void 0,{needsNewScope:Y.$$isolateScope||Y.$$newScope});$a.$$slots=sb}if(Y.template)if(Fa=!0,Ub("template",sa,Y,qa),sa=Y,Oa=ca(Y.template)?Y.template(qa,I):Y.template,Oa=He(Oa),Y.replace){K=Y;Ia=td.test(Oa)?Ie(Ad(Y.templateNamespace,Ca(Oa))):[];z=Ia[0];if(1!==Ia.length||1!==z.nodeType)throw Ja("tplrt",Ka,"");Pc(N,qa,z);Tb={$attr:{}};Oa=ua(z,[],Tb);var Hg=t.splice(zb+1,t.length-(zb+1));(ra||T)&&Je(Oa,ra,T);t=t.concat(Oa).concat(Hg);Ke(I,Tb);Tb=t.length}else qa.html(Oa);
if(Y.templateUrl)Fa=!0,Ub("template",sa,Y,qa),sa=Y,Y.replace&&(K=Y),W=Ig(t.splice(zb,t.length-zb),qa,I,N,Ga&&$a,aa,O,{controllerDirectives:ta,newScopeDirective:T!==Y&&T,newIsolateScopeDirective:ra,templateDirective:sa,nonTlbTranscludeDirective:pa}),Tb=t.length;else if(Y.compile)try{xb=Y.compile(qa,I,$a);var Id=Y.$$originalDirective||Y;ca(xb)?V(null,Mb(Id,xb),Oc,Fd):xb&&V(Mb(Id,xb.pre),Mb(Id,xb.post),Oc,Fd)}catch(Da){m(Da,jb(qa))}Y.terminal&&(W.terminal=!0,ba=Math.max(ba,Y.priority))}W.scope=T&&!0===
T.scope;W.transcludeOnThisElement=Ga;W.templateOnThisElement=Fa;W.transclude=$a;Z.hasElementTranscludeDirective=za;return W}function kc(t,z,I,M){if(oa(z)){var N=z.match(l);z=z.substring(N[0].length);var K=N[1]||N[3];N="?"===N[2];if("^^"===K)I=I.parent();else var aa=(aa=M&&M[z])&&aa.instance;if(!aa){var O="$"+z+"Controller";aa=K?I.inheritedData(O):I.data(O)}if(!aa&&!N)throw Ja("ctreq",z,t);}else if(na(z))for(aa=[],K=0,N=z.length;K<N;K++)aa[K]=kc(t,z[K],I,M);else fa(z)&&(aa={},J(z,function(Z,V){aa[V]=
kc(t,Z,I,M)}));return aa||null}function Gg(t,z,I,M,N,K,aa){var O=Ea(),Z;for(Z in M){var V=M[Z],W={$scope:V===aa||V.$$isolateScope?N:K,$element:t,$attrs:z,$transclude:I},ba=V.controller;"@"===ba&&(ba=z[V.name]);W=B(ba,W,!0,V.controllerAs);O[V.name]=W;t.data("$"+V.name+"Controller",W.instance)}return O}function Je(t,z,I){for(var M=0,N=t.length;M<N;M++)t[M]=jd(t[M],{$$isolateScope:z,$$newScope:I})}function Ic(t,z,I,M,N,K,aa){if(z===N)return null;var O=null;if(f.hasOwnProperty(z)){N=p.get(z+"Directive");
for(var Z=0,V=N.length;Z<V;Z++)if(z=N[Z],(U(M)||M>z.priority)&&-1!==z.restrict.indexOf(I)){K&&(z=jd(z,{$$start:K,$$end:aa}));if(!z.$$bindings){var W=O=z,ba=z.name,T={isolateScope:null,bindToController:null};fa(W.scope)&&(!0===W.bindToController?(T.bindToController=d(W.scope,ba,!0),T.isolateScope={}):T.isolateScope=d(W.scope,ba,!1));fa(W.bindToController)&&(T.bindToController=d(W.bindToController,ba,!0));if(T.bindToController&&!W.controller)throw Ja("noctrl",ba);O=O.$$bindings=T;fa(O.isolateScope)&&
(z.$$isolateBindings=O.isolateScope)}t.push(z);O=z}}return O}function zg(t){if(f.hasOwnProperty(t))for(var z=p.get(t+"Directive"),I=0,M=z.length;I<M;I++)if(t=z[I],t.multiElement)return!0;return!1}function Ke(t,z){var I=z.$attr,M=t.$attr;J(t,function(N,K){"$"!==K.charAt(0)&&(z[K]&&z[K]!==N&&(N=N.length?N+(("style"===K?";":" ")+z[K]):z[K]),t.$set(K,N,!0,I[K]))});J(z,function(N,K){t.hasOwnProperty(K)||"$"===K.charAt(0)||(t[K]=N,"class"!==K&&"style"!==K&&(M[K]=I[K]))})}function Ig(t,z,I,M,N,K,aa,O){var Z=
[],V,W,ba=z[0],T=t.shift(),ta=jd(T,{templateUrl:null,transclude:null,replace:null,$$originalDirective:T}),ra=ca(T.templateUrl)?T.templateUrl(z,I):T.templateUrl,sa=T.templateNamespace;z.empty();x(ra).then(function(pa){pa=He(pa);if(T.replace){pa=td.test(pa)?Ie(Ad(sa,Ca(pa))):[];var Ga=pa[0];if(1!==pa.length||1!==Ga.nodeType)throw Ja("tplrt",T.name,ra);pa={$attr:{}};Pc(M,z,Ga);var Fa=ua(Ga,[],pa);fa(T.scope)&&Je(Fa,!0);t=Fa.concat(t);Ke(I,pa)}else Ga=ba,z.html(pa);t.unshift(ta);V=Ae(t,Ga,I,N,z,T,K,aa,
O);J(M,function(Ia,$a){Ia===Ga&&(M[$a]=z[0])});for(W=ma(z[0].childNodes,N);Z.length;){pa=Z.shift();var za=Z.shift();var qa=Z.shift(),Y=Z.shift();Fa=z[0];if(!pa.$$destroyed){if(za!==ba){var Ka=za.className;O.hasElementTranscludeDirective&&T.replace||(Fa=wd(Ga));Pc(qa,da(za),Fa);ja(da(Fa),Ka)}za=V.transcludeOnThisElement?ya(pa,V.transclude,Y):Y;V(W,pa,Fa,M,za)}}Z=null}).catch(function(pa){ld(pa)&&m(pa)});return function(pa,Ga,Fa,za,qa){pa=qa;Ga.$$destroyed||(Z?Z.push(Ga,Fa,za,pa):(V.transcludeOnThisElement&&
(pa=ya(Ga,V.transclude,qa)),V(W,Ga,Fa,za,pa)))}}function Eg(t,z){var I=z.priority-t.priority;return 0!==I?I:t.name!==z.name?t.name<z.name?-1:1:t.index-z.index}function Ub(t,z,I,M){function N(K){return K?" (module: "+K+")":""}if(z)throw Ja("multidir",z.name,N(z.$$moduleName),I.name,N(I.$$moduleName),t,jb(M));}function Cg(t,z){var I=q(z,!0);I&&t.push({priority:0,compile:function(M){M=M.parent();var N=!!M.length;N&&ea.$$addBindingClass(M);return function(K,aa){var O=aa.parent();N||ea.$$addBindingClass(O);
ea.$$addBindingInfo(O,I.expressions);K.$watch(I,function(Z){aa[0].nodeValue=Z})}}})}function Ad(t,z){t=xa(t||"html");switch(t){case "svg":case "math":var I=ia.document.createElement("div");I.innerHTML="<"+t+">"+z+"</"+t+">";return I.childNodes[0].childNodes;default:return z}}function Jg(t,z){if("srcdoc"===z)return E.HTML;t=ib(t);if("src"===z||"ngSrc"===z){if(-1===["img","video","audio","source","track"].indexOf(t))return E.RESOURCE_URL}else if("xlinkHref"===z||"form"===t&&"action"===z||"link"===t&&
"href"===z)return E.RESOURCE_URL}function Ag(t,z,I,M,N){var K=Jg(t,M),aa=h[M]||N,O=q(I,!N,K,aa);if(O){if("multiple"===M&&"select"===ib(t))throw Ja("selmulti",jb(t));if(n.test(M))throw Ja("nodomevents");z.push({priority:100,compile:function(){return{pre:function(Z,V,W){V=W.$$observers||(W.$$observers=Ea());var ba=W[M];ba!==I&&(O=ba&&q(ba,!0,K,aa),I=ba);O&&(W[M]=O(Z),(V[M]||(V[M]=[])).$$inter=!0,(W.$$observers&&W.$$observers[M].$$scope||Z).$watch(O,function(T,ta){"class"===M&&T!==ta?W.$updateClass(T,
ta):W.$set(M,T)}))}}}})}}function Pc(t,z,I){var M=z[0],N=z.length,K=M.parentNode,aa;if(t){var O=0;for(aa=t.length;O<aa;O++)if(t[O]===M){t[O++]=I;aa=O+N-1;for(var Z=t.length;O<Z;O++,aa++)aa<Z?t[O]=t[aa]:delete t[O];t.length-=N-1;t.context===M&&(t.context=I);break}}K&&K.replaceChild(I,M);t=ia.document.createDocumentFragment();for(O=0;O<N;O++)t.appendChild(z[O]);da.hasData(M)&&(da.data(I,da.data(M)),da(M).off("$destroy"));da.cleanData(t.querySelectorAll("*"));for(O=1;O<N;O++)delete z[O];z[0]=I;z.length=
1}function Ee(t,z){return Aa(function(){return t.apply(null,arguments)},t,z)}function Fe(t,z,I,M,N,K){try{t(z,I,M,N,K)}catch(aa){m(aa,jb(I))}}function Qc(t,z){if(H)throw Ja("missingattr",t,z);}function Lc(t,z,I,M,N){function K(W,ba,T){ca(I.$onChanges)&&!md(ba,T)&&(Hb||(t.$$postDigest(S),Hb=[]),V||(V={},Hb.push(aa)),V[W]&&(T=V[W].previousValue),V[W]=new Rc(T,ba))}function aa(){I.$onChanges(V);V=void 0}var O=[],Z={},V;J(M,function(W,ba){var T=W.attrName,ta=W.optional;switch(W.mode){case "@":ta||bb.call(z,
T)||(Qc(T,N.name),I[ba]=z[T]=void 0);W=z.$observe(T,function(qa){if(oa(qa)||vb(qa))K(ba,qa,I[ba]),I[ba]=qa});z.$$observers[T].$$scope=t;var ra=z[T];oa(ra)?I[ba]=q(ra)(t):vb(ra)&&(I[ba]=ra);Z[ba]=new Rc(Jd,I[ba]);O.push(W);break;case "=":if(!bb.call(z,T)){if(ta)break;Qc(T,N.name);z[T]=void 0}if(ta&&!z[T])break;var sa=G(z[T]);var pa=sa.literal?db:md;var Ga=sa.assign||function(){ra=I[ba]=sa(t);throw Ja("nonassign",z[T],T,N.name);};ra=I[ba]=sa(t);ta=function(qa){pa(qa,I[ba])||(pa(qa,ra)?Ga(t,qa=I[ba]):
I[ba]=qa);return ra=qa};ta.$stateful=!0;W=W.collection?t.$watchCollection(z[T],ta):t.$watch(G(z[T],ta),null,sa.literal);O.push(W);break;case "<":if(!bb.call(z,T)){if(ta)break;Qc(T,N.name);z[T]=void 0}if(ta&&!z[T])break;sa=G(z[T]);var Fa=sa.literal,za=I[ba]=sa(t);Z[ba]=new Rc(Jd,I[ba]);W=t.$watch(sa,function(qa,Y){if(Y===qa){if(Y===za||Fa&&db(Y,za))return;Y=za}K(ba,qa,Y);I[ba]=qa},Fa);O.push(W);break;case "&":ta||bb.call(z,T)||Qc(T,N.name),sa=z.hasOwnProperty(T)?G(z[T]):la,sa===la&&ta||(I[ba]=function(qa){return sa(t,
qa)})}});return{initialChanges:Z,removeWatches:O.length&&function(){for(var W=0,ba=O.length;W<ba;++W)O[W]()}}}var Kg=/^\w/,ze=ia.document.createElement("div"),Dg=C,Bg=D,ye=F,Hb;X.prototype={$normalize:lb,$addClass:function(t){t&&0<t.length&&L.addClass(this.$$element,t)},$removeClass:function(t){t&&0<t.length&&L.removeClass(this.$$element,t)},$updateClass:function(t,z){var I=Le(t,z);I&&I.length&&L.addClass(this.$$element,I);(t=Le(z,t))&&t.length&&L.removeClass(this.$$element,t)},$set:function(t,z,
I,M){var N=te(this.$$element[0],t),K=Me[t],aa=t;N?(this.$$element.prop(t,z),M=N):K&&(this[K]=z,aa=K);this[t]=z;M?this.$attr[t]=M:(M=this.$attr[t])||(this.$attr[t]=M=me(t,"-"));N=ib(this.$$element);if("a"===N&&("href"===t||"xlinkHref"===t)||"img"===N&&"src"===t)this[t]=z=null==z?z:P(z,"src"===t);else if("img"===N&&"srcset"===t&&R(z)){N="";K=Ca(z);var O=/(\s+\d+x\s*,|\s+\d+w\s*,|\s+,|,\s+)/;O=/\s/.test(K)?O:/(,)/;K=K.split(O);O=Math.floor(K.length/2);for(var Z=0;Z<O;Z++){var V=2*Z;N+=P(Ca(K[V]),!0);
N+=" "+Ca(K[V+1])}K=Ca(K[2*Z]).split(/\s/);N+=P(Ca(K[0]),!0);2===K.length&&(N+=" "+Ca(K[1]));this[t]=z=N}!1!==I&&(null==z?this.$$element.removeAttr(M):Kg.test(M)?this.$$element.attr(M,z):ha(this.$$element[0],M,z));(t=this.$$observers)&&J(t[aa],function(W){try{W(z)}catch(ba){m(ba)}})},$observe:function(t,z){var I=this,M=I.$$observers||(I.$$observers=Ea()),N=M[t]||(M[t]=[]);N.push(z);A.$evalAsync(function(){N.$$inter||!I.hasOwnProperty(t)||U(I[t])||z(I[t])});return function(){bc(N,z)}}};var Ne=q.startSymbol(),
Oe=q.endSymbol(),He="{{"===Ne&&"}}"===Oe?uc:function(t){return t.replace(/\{\{/g,Ne).replace(/}}/g,Oe)},xg=/^ngAttr[A-Z]/,yg=/^(.+)Start$/;ea.$$addBindingInfo=u?function(t,z){var I=t.data("$binding")||[];na(z)?I=I.concat(z):I.push(z);t.data("$binding",I)}:la;ea.$$addBindingClass=u?function(t){ja(t,"ng-binding")}:la;ea.$$addScopeInfo=u?function(t,z,I,M){t.data(I?M?"$isolateScopeNoTemplate":"$isolateScope":"$scope",z)}:la;ea.$$addScopeClass=u?function(t,z){ja(t,z?"ng-isolate-scope":"ng-scope")}:la;
ea.$$createComment=function(t,z){var I="";u&&(I=" "+(t||"")+": ",z&&(I+=z+" "));return ia.document.createComment(I)};return ea}]}function Rc(a,b){this.previousValue=a;this.currentValue=b}function lb(a){return a.replace(Be,"").replace(Lg,function(b,d,c){return c?d.toUpperCase():d})}function Le(a,b){var d="";a=a.split(/\s+/);b=b.split(/\s+/);var c=0;a:for(;c<a.length;c++){for(var e=a[c],f=0;f<b.length;f++)if(e===b[f])continue a;d+=(0<d.length?" ":"")+e}return d}function Ie(a){a=da(a);var b=a.length;
if(1>=b)return a;for(;b--;){var d=a[b];(8===d.nodeType||d.nodeType===wb&&""===d.nodeValue.trim())&&Mg.call(a,b,1)}return a}function wg(a,b){if(b&&oa(b))return b;if(oa(a)&&(a=Pe.exec(a)))return a[3]}function Ng(){var a={},b=!1;this.has=function(d){return a.hasOwnProperty(d)};this.register=function(d,c){Ob(d,"controller");fa(d)?Aa(a,d):a[d]=c};this.allowGlobals=function(){b=!0};this.$get=["$injector","$window",function(d,c){function e(f,g,k,h){if(!f||!fa(f.$scope))throw va("$controller")("noscp",h,
g);f.$scope[g]=k}return function(f,g,k,h){var l;k=!0===k;h&&oa(h)&&(l=h);if(oa(f)){h=f.match(Pe);if(!h)throw Qe("ctrlfmt",f);var n=h[1];l=l||h[3];f=a.hasOwnProperty(n)?a[n]:ne(g.$scope,n,!0)||(b?ne(c,n,!0):void 0);if(!f)throw Qe("ctrlreg",n);vc(f,n,!0)}if(k){k=(na(f)?f[f.length-1]:f).prototype;var r=Object.create(k||null);l&&e(g,l,r,n||f.name);return Aa(function(){var u=d.invoke(f,r,g,n);u!==r&&(fa(u)||ca(u))&&(r=u,l&&e(g,l,r,n||f.name));return r},{instance:r,identifier:l})}r=d.instantiate(f,g,n);
l&&e(g,l,r,n||f.name);return r}}]}function Og(){this.$get=["$window",function(a){return da(a.document)}]}function Pg(){this.$get=["$document","$rootScope",function(a,b){function d(){e=c.hidden}var c=a[0],e=c&&c.hidden;a.on("visibilitychange",d);b.$on("$destroy",function(){a.off("visibilitychange",d)});return function(){return e}}]}function Qg(){this.$get=["$log",function(a){return function(b,d){a.error.apply(a,arguments)}}]}function Kd(a){return fa(a)?Xa(a)?a.toISOString():dc(a):a}function Rg(){this.$get=
function(){return function(a){if(!a)return"";var b=[];fe(a,function(d,c){null===d||U(d)||ca(d)||(na(d)?J(d,function(e){b.push(Za(c)+"="+Za(Kd(e)))}):b.push(Za(c)+"="+Za(Kd(d))))});return b.join("&")}}}function Sg(){this.$get=function(){return function(a){function b(c,e,f){null===c||U(c)||(na(c)?J(c,function(g,k){b(g,e+"["+(fa(g)?k:"")+"]")}):fa(c)&&!Xa(c)?fe(c,function(g,k){b(g,e+(f?"":"[")+k+(f?"":"]"))}):d.push(Za(e)+"="+Za(Kd(c))))}if(!a)return"";var d=[];b(a,"",!0);return d.join("&")}}}function Ld(a,
b){if(oa(a)){var d=a.replace(Tg,"").trim();if(d){b=(b=b("Content-Type"))&&0===b.indexOf(Re);var c;(c=b)||(c=(c=d.match(Ug))&&Vg[c[0]].test(d));if(c)try{a=ie(d)}catch(e){if(!b)return a;throw Sc("baddata",a,e);}}}return a}function Se(a){var b=Ea(),d;oa(a)?J(a.split("\n"),function(c){d=c.indexOf(":");var e=xa(Ca(c.substr(0,d)));c=Ca(c.substr(d+1));e&&(b[e]=b[e]?b[e]+", "+c:c)}):fa(a)&&J(a,function(c,e){e=xa(e);c=Ca(c);e&&(b[e]=b[e]?b[e]+", "+c:c)});return b}function Te(a){var b;return function(d){b||
(b=Se(a));return d?(d=b[xa(d)],void 0===d&&(d=null),d):b}}function Ue(a,b,d,c){if(ca(c))return c(a,b,d);J(c,function(e){a=e(a,b,d)});return a}function Wg(){var a=this.defaults={transformResponse:[Ld],transformRequest:[function(e){return fa(e)&&"[object File]"!==Ta.call(e)&&"[object Blob]"!==Ta.call(e)&&"[object FormData]"!==Ta.call(e)?dc(e):e}],headers:{common:{Accept:"application/json, text/plain, */*"},post:kb(Md),put:kb(Md),patch:kb(Md)},xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",
paramSerializer:"$httpParamSerializer",jsonpCallbackParam:"callback"},b=!1;this.useApplyAsync=function(e){return R(e)?(b=!!e,this):b};var d=this.interceptors=[],c=this.xsrfWhitelistedOrigins=[];this.$get=["$browser","$httpBackend","$$cookieReader","$cacheFactory","$rootScope","$q","$injector","$sce",function(e,f,g,k,h,l,n,r){function u(v){function p(A,E){for(var L=0,P=E.length;L<P;){var S=E[L++],X=E[L++];A=A.then(S,X)}E.length=0;return A}function q(A,E){var L,P={};J(A,function(S,X){ca(S)?(L=S(E),
null!=L&&(P[X]=L)):P[X]=S});return P}function m(A){var E=Aa({},A);E.data=Ue(A.data,A.headers,A.status,x.transformResponse);A=A.status;return 200<=A&&300>A?E:l.reject(E)}if(!fa(v))throw va("$http")("badreq",v);if(!oa(r.valueOf(v.url)))throw va("$http")("badreq",v.url);var x=Aa({method:"get",transformRequest:a.transformRequest,transformResponse:a.transformResponse,paramSerializer:a.paramSerializer,jsonpCallbackParam:a.jsonpCallbackParam},v);x.headers=function(A){var E=a.headers,L=Aa({},A.headers),P,
S;E=Aa({},E.common,E[xa(A.method)]);a:for(P in E){var X=xa(P);for(S in L)if(xa(S)===X)continue a;L[P]=E[P]}return q(L,kb(A))}(v);x.method=Tc(x.method);x.paramSerializer=oa(x.paramSerializer)?n.get(x.paramSerializer):x.paramSerializer;e.$$incOutstandingRequestCount();var G=[],B=[];v=l.resolve(x);J(D,function(A){(A.request||A.requestError)&&G.unshift(A.request,A.requestError);(A.response||A.responseError)&&B.push(A.response,A.responseError)});v=p(v,G);v=v.then(function(A){var E=A.headers,L=Ue(A.data,
Te(E),void 0,A.transformRequest);U(L)&&J(E,function(P,S){"content-type"===xa(S)&&delete E[S]});U(A.withCredentials)&&!U(a.withCredentials)&&(A.withCredentials=a.withCredentials);return w(A,L).then(m,m)});v=p(v,B);return v=v.finally(function(){e.$$completeOutstandingRequest(la)})}function w(v,p){function q(ja){if(ja){var ea={};J(ja,function(ma,ka){ea[ka]=function(ya){function ua(){ma(ya)}b?h.$applyAsync(ua):h.$$phase?ua():h.$apply(ua)}});return ea}}function m(ja,ea,ma,ka,ya){function ua(){x(ea,ja,
ma,ka,ya)}L&&(200<=ja&&300>ja?L.put(X,[ja,ea,Se(ma),ka,ya]):L.remove(X));b?h.$applyAsync(ua):(ua(),h.$$phase||h.$apply())}function x(ja,ea,ma,ka,ya){ea=-1<=ea?ea:0;(200<=ea&&300>ea?A.resolve:A.reject)({data:ja,status:ea,headers:Te(ma),config:v,statusText:ka,xhrStatus:ya})}function G(ja){x(ja.data,ja.status,kb(ja.headers()),ja.statusText,ja.xhrStatus)}function B(){var ja=u.pendingRequests.indexOf(v);-1!==ja&&u.pendingRequests.splice(ja,1)}var A=l.defer(),E=A.promise,L,P=v.headers,S="jsonp"===xa(v.method),
X=v.url;S?X=r.getTrustedResourceUrl(X):oa(X)||(X=r.valueOf(X));X=H(X,v.paramSerializer(v.params));S&&(X=F(X,v.jsonpCallbackParam));u.pendingRequests.push(v);E.then(B,B);!v.cache&&!a.cache||!1===v.cache||"GET"!==v.method&&"JSONP"!==v.method||(L=fa(v.cache)?v.cache:fa(a.cache)?a.cache:C);if(L){var ha=L.get(X);R(ha)?ha&&ca(ha.then)?ha.then(G,G):na(ha)?x(ha[1],ha[0],kb(ha[2]),ha[3],ha[4]):x(ha,200,{},"OK","complete"):L.put(X,E)}U(ha)&&((ha=y(v.url)?g()[v.xsrfCookieName||a.xsrfCookieName]:void 0)&&(P[v.xsrfHeaderName||
a.xsrfHeaderName]=ha),f(v.method,X,p,m,P,v.timeout,v.withCredentials,v.responseType,q(v.eventHandlers),q(v.uploadEventHandlers)));return E}function H(v,p){0<p.length&&(v+=(-1===v.indexOf("?")?"?":"&")+p);return v}function F(v,p){var q=v.split("?");if(2<q.length)throw Sc("badjsonp",v);q=pd(q[1]);J(q,function(m,x){if("JSON_CALLBACK"===m)throw Sc("badjsonp",v);if(x===p)throw Sc("badjsonp",p,v);});return v+=(-1===v.indexOf("?")?"?":"&")+p+"=JSON_CALLBACK"}var C=k("$http");a.paramSerializer=oa(a.paramSerializer)?
n.get(a.paramSerializer):a.paramSerializer;var D=[];J(d,function(v){D.unshift(oa(v)?n.get(v):n.invoke(v))});var y=Xg(c);u.pendingRequests=[];(function(v){J(arguments,function(p){u[p]=function(q,m){return u(Aa({},m||{},{method:p,url:q}))}})})("get","delete","head","jsonp");(function(v){J(arguments,function(p){u[p]=function(q,m,x){return u(Aa({},x||{},{method:p,url:q,data:m}))}})})("post","put","patch");u.defaults=a;return u}]}function Yg(){this.$get=function(){return function(){return new ia.XMLHttpRequest}}}
function Zg(){this.$get=["$browser","$jsonpCallbacks","$document","$xhrFactory",function(a,b,d,c){return $g(a,c,a.defer,b,d[0])}]}function $g(a,b,d,c,e){function f(g,k,h){g=g.replace("JSON_CALLBACK",k);var l=e.createElement("script"),n=null;l.type="text/javascript";l.src=g;l.async=!0;n=function(r){l.removeEventListener("load",n);l.removeEventListener("error",n);e.body.removeChild(l);l=null;var u=-1,w="unknown";r&&("load"!==r.type||c.wasCalled(k)||(r={type:"error"}),w=r.type,u="error"===r.type?404:
200);h&&h(u,w)};l.addEventListener("load",n);l.addEventListener("error",n);e.body.appendChild(l);return n}return function(g,k,h,l,n,r,u,w,H,F){function C(x){q="timeout"===x;v&&v();p&&p.abort()}function D(x,G,B,A,E,L){R(m)&&d.cancel(m);v=p=null;x(G,B,A,E,L)}k=k||a.url();if("jsonp"===xa(g))var y=c.createCallback(k),v=f(k,y,function(x,G){var B=200===x&&c.getResponse(y);D(l,x,B,"",G,"complete");c.removeCallback(y)});else{var p=b(g,k),q=!1;p.open(g,k,!0);J(n,function(x,G){R(x)&&p.setRequestHeader(G,x)});
p.onload=function(){var x=p.statusText||"",G="response"in p?p.response:p.responseText,B=1223===p.status?204:p.status;0===B&&(B=G?200:"file"===pb(k).protocol?404:0);D(l,B,G,p.getAllResponseHeaders(),x,"complete")};p.onerror=function(){D(l,-1,null,null,"","error")};p.ontimeout=function(){D(l,-1,null,null,"","timeout")};p.onabort=function(){D(l,-1,null,null,"",q?"timeout":"abort")};J(H,function(x,G){p.addEventListener(G,x)});J(F,function(x,G){p.upload.addEventListener(G,x)});u&&(p.withCredentials=!0);
if(w)try{p.responseType=w}catch(x){if("json"!==w)throw x;}p.send(U(h)?null:h)}if(0<r)var m=d(function(){C("timeout")},r);else r&&ca(r.then)&&r.then(function(){C(R(r.$$timeoutId)?"timeout":"abort")})}}function ah(){var a="{{",b="}}";this.startSymbol=function(d){return d?(a=d,this):a};this.endSymbol=function(d){return d?(b=d,this):b};this.$get=["$parse","$exceptionHandler","$sce",function(d,c,e){function f(w){return"\\\\\\"+w}function g(w){return w.replace(r,a).replace(u,b)}function k(w,H,F,C){var D=
w.$watch(function(y){D();return C(y)},H,F);return D}function h(w,H,F,C){function D(E){try{var L=E;E=F?e.getTrusted(F,L):e.valueOf(L);return C&&!R(E)?E:rd(E)}catch(P){c(Ib.interr(w,P))}}if(!w.length||-1===w.indexOf(a)){if(!H){H=g(w);var y=cb(H);y.exp=w;y.expressions=[];y.$$watchDelegate=k}return y}C=!!C;var v,p,q=0,m=[],x=[];y=w.length;for(var G=[],B=[];q<y;)if(-1!==(v=w.indexOf(a,q))&&-1!==(p=w.indexOf(b,v+l)))q!==v&&G.push(g(w.substring(q,v))),q=w.substring(v+l,p),m.push(q),x.push(d(q,D)),q=p+n,
B.push(G.length),G.push("");else{q!==y&&G.push(g(w.substring(q)));break}F&&1<G.length&&Ib.throwNoconcat(w);if(!H||m.length){var A=function(E){for(var L=0,P=m.length;L<P;L++){if(C&&U(E[L]))return;G[B[L]]=E[L]}return G.join("")};return Aa(function(E){var L=0,P=m.length,S=Array(P);try{for(;L<P;L++)S[L]=x[L](E);return A(S)}catch(X){c(Ib.interr(w,X))}},{exp:w,expressions:m,$$watchDelegate:function(E,L){var P;return E.$watchGroup(x,function(S,X){var ha=A(S);L.call(this,ha,S!==X?P:ha,E);P=ha})}})}}var l=
a.length,n=b.length,r=new RegExp(a.replace(/./g,f),"g"),u=new RegExp(b.replace(/./g,f),"g");h.startSymbol=function(){return a};h.endSymbol=function(){return b};return h}]}function bh(){this.$get=["$rootScope","$window","$q","$$q","$browser",function(a,b,d,c,e){function f(k,h,l,n){function r(){u?k.apply(null,w):k(C)}var u=4<arguments.length,w=u?hb.call(arguments,4):[],H=b.setInterval,F=b.clearInterval,C=0,D=R(n)&&!n,y=(D?c:d).defer(),v=y.promise;l=R(l)?l:0;v.$$intervalId=H(function(){D?e.defer(r):
a.$evalAsync(r);y.notify(C++);0<l&&C>=l&&(y.resolve(C),F(v.$$intervalId),delete g[v.$$intervalId]);D||a.$apply()},h);g[v.$$intervalId]=y;return v}var g={};f.cancel=function(k){return k&&k.$$intervalId in g?(g[k.$$intervalId].promise.$$state.pur=!0,g[k.$$intervalId].reject("canceled"),b.clearInterval(k.$$intervalId),delete g[k.$$intervalId],!0):!1};return f}]}function Nd(a){a=a.split("/");for(var b=a.length;b--;)a[b]=ec(a[b].replace(/%2F/g,"/"));return a.join("/")}function Ve(a,b){a=pb(a);b.$$protocol=
a.protocol;b.$$host=a.hostname;b.$$port=parseInt(a.port,10)||ch[a.protocol]||null}function We(a,b,d){if(dh.test(a))throw lc("badpath",a);var c="/"!==a.charAt(0);c&&(a="/"+a);a=pb(a);c=(c&&"/"===a.pathname.charAt(0)?a.pathname.substring(1):a.pathname).split("/");for(var e=c.length;e--;)c[e]=decodeURIComponent(c[e]),d&&(c[e]=c[e].replace(/\//g,"%2F"));d=c.join("/");b.$$path=d;b.$$search=pd(a.search);b.$$hash=decodeURIComponent(a.hash);b.$$path&&"/"!==b.$$path.charAt(0)&&(b.$$path="/"+b.$$path)}function Od(a,
b){return a.slice(0,b.length)===b}function tb(a,b){if(Od(b,a))return b.substr(a.length)}function Gb(a){var b=a.indexOf("#");return-1===b?a:a.substr(0,b)}function mc(a){return a.replace(/(#.+)|#$/,"$1")}function Pd(a,b,d){this.$$html5=!0;d=d||"";Ve(a,this);this.$$parse=function(c){var e=tb(b,c);if(!oa(e))throw lc("ipthprfx",c,b);We(e,this,!0);this.$$path||(this.$$path="/");this.$$compose()};this.$$compose=function(){var c=qd(this.$$search),e=this.$$hash?"#"+ec(this.$$hash):"";this.$$url=Nd(this.$$path)+
(c?"?"+c:"")+e;this.$$absUrl=b+this.$$url.substr(1);this.$$urlUpdatedByLocation=!0};this.$$parseLinkUrl=function(c,e){if(e&&"#"===e[0])return this.hash(e.slice(1)),!0;if(R(e=tb(a,c))){c=e;var f=d&&R(e=tb(d,e))?b+(tb("/",e)||e):a+c}else R(e=tb(b,c))?f=b+e:b===c+"/"&&(f=b);f&&this.$$parse(f);return!!f}}function Qd(a,b,d){Ve(a,this);this.$$parse=function(c){var e=tb(a,c)||tb(b,c);if(U(e)||"#"!==e.charAt(0))if(this.$$html5)var f=e;else f="",U(e)&&(a=c,this.replace());else f=tb(d,e),U(f)&&(f=e);We(f,this,
!1);c=this.$$path;e=a;var g=/^\/[A-Z]:(\/.*)/;Od(f,e)&&(f=f.replace(e,""));g.exec(f)||(c=(f=g.exec(c))?f[1]:c);this.$$path=c;this.$$compose()};this.$$compose=function(){var c=qd(this.$$search),e=this.$$hash?"#"+ec(this.$$hash):"";this.$$url=Nd(this.$$path)+(c?"?"+c:"")+e;this.$$absUrl=a+(this.$$url?d+this.$$url:"");this.$$urlUpdatedByLocation=!0};this.$$parseLinkUrl=function(c,e){return Gb(a)===Gb(c)?(this.$$parse(c),!0):!1}}function Xe(a,b,d){this.$$html5=!0;Qd.apply(this,arguments);this.$$parseLinkUrl=
function(c,e){if(e&&"#"===e[0])return this.hash(e.slice(1)),!0;var f,g;a===Gb(c)?f=c:(g=tb(b,c))?f=a+d+g:b===c+"/"&&(f=b);f&&this.$$parse(f);return!!f};this.$$compose=function(){var c=qd(this.$$search),e=this.$$hash?"#"+ec(this.$$hash):"";this.$$url=Nd(this.$$path)+(c?"?"+c:"")+e;this.$$absUrl=a+d+this.$$url;this.$$urlUpdatedByLocation=!0}}function Uc(a){return function(){return this[a]}}function Ye(a,b){return function(d){if(U(d))return this[a];this[a]=b(d);this.$$compose();return this}}function eh(){var a=
"!",b={enabled:!1,requireBase:!0,rewriteLinks:!0},d=function(c,e,f){return c!==e};this.hashPrefix=function(c){return R(c)?(a=c,this):a};this.html5Mode=function(c){if(vb(c))return b.enabled=c,this;if(fa(c)){vb(c.enabled)&&(b.enabled=c.enabled);vb(c.requireBase)&&(b.requireBase=c.requireBase);if(vb(c.rewriteLinks)||oa(c.rewriteLinks))b.rewriteLinks=c.rewriteLinks;return this}return b};this.compareUrls=function(c){return R(c)?(d=c,this):d};this.$get=["$rootScope","$browser","$sniffer","$rootElement",
"$window",function(c,e,f,g,k){function h(y,v,p){var q=F.url(),m=F.$$state;try{e.url(y,v,p),F.$$state=e.state()}catch(x){throw F.url(q),F.$$state=m,x;}}function l(y,v){c.$broadcast("$locationChangeSuccess",F.absUrl(),y,F.$$state,v)}var n=e.baseHref(),r=e.url();if(b.enabled){if(!n&&b.requireBase)throw lc("nobase");var u=r.substring(0,r.indexOf("/",r.indexOf("//")+2))+(n||"/");var w=f.history?Pd:Xe}else u=Gb(r),w=Qd;var H=u.substr(0,Gb(u).lastIndexOf("/")+1);var F=new w(u,H,"#"+a);F.$$parseLinkUrl(r,
r);F.$$state=e.state();var C=/^\s*(javascript|mailto):/i;g.on("click",function(y){var v=b.rewriteLinks;if(v&&!y.ctrlKey&&!y.metaKey&&!y.shiftKey&&2!==y.which&&2!==y.button){for(var p=da(y.target);"a"!==ib(p[0]);)if(p[0]===g[0]||!(p=p.parent())[0])return;if(!oa(v)||!U(p.attr(v))){v=p.prop("href");var q=p.attr("href")||p.attr("xlink:href");fa(v)&&"[object SVGAnimatedString]"===v.toString()&&(v=pb(v.animVal).href);C.test(v)||!v||p.attr("target")||y.isDefaultPrevented()||!F.$$parseLinkUrl(v,q)||(y.preventDefault(),
F.absUrl()!==e.url()&&(c.$apply(),k.angular["ff-684208-preventDefault"]=!0))}}});mc(F.absUrl())!==mc(r)&&e.url(F.absUrl(),!0);var D=!0;e.onUrlChange(function(y,v){Od(y,H)?(c.$evalAsync(function(){var p=F.absUrl(),q=F.$$state;y=mc(y);F.$$parse(y);F.$$state=v;var m=c.$broadcast("$locationChangeStart",y,p,v,q).defaultPrevented;F.absUrl()===y&&(m?(F.$$parse(p),F.$$state=q,h(p,!1,q)):(D=!1,l(p,q)))}),c.$$phase||c.$digest()):k.location.href=y});c.$watch(function(){if(D||F.$$urlUpdatedByLocation){F.$$urlUpdatedByLocation=
!1;var y=mc(e.url()),v=mc(F.absUrl()),p=e.state(),q=F.$$replace,m=d(y,v,function(){return new w(u,H,"#"+a)}),x=F.$$html5&&f.history&&p!==F.$$state,G=y!==v||x;if(D||G)D=!1,c.$evalAsync(function(){var B=F.absUrl(),A=c.$broadcast("$locationChangeStart",B,y,F.$$state,p).defaultPrevented;F.absUrl()===B&&(A?(F.$$parse(y),F.$$state=p):((D||G&&m)&&h(B,q,p===F.$$state?null:F.$$state),l(y,p)))})}F.$$replace=!1});return F}]}function fh(){var a=!0,b=this;this.debugEnabled=function(d){return R(d)?(a=d,this):a};
this.$get=["$window",function(d){function c(f){var g=d.console||{},k=g[f]||g.log||la;return function(){var h=[];J(arguments,function(l){var n=h.push;ld(l)&&(l.stack&&e?l=l.message&&-1===l.stack.indexOf(l.message)?"Error: "+l.message+"\n"+l.stack:l.stack:l.sourceURL&&(l=l.message+"\n"+l.sourceURL+":"+l.line));n.call(h,l)});return Function.prototype.apply.call(k,g,h)}}var e=qb||/\bEdge\//.test(d.navigator&&d.navigator.userAgent);return{log:c("log"),info:c("info"),warn:c("warn"),error:c("error"),debug:function(){var f=
c("debug");return function(){a&&f.apply(b,arguments)}}()}}]}function gh(a,b){switch(a.type){case Q.MemberExpression:if(a.computed)return!1;break;case Q.UnaryExpression:return 1;case Q.BinaryExpression:return"+"!==a.operator?1:!1;case Q.CallExpression:return!1}return void 0===b?Ze:b}function Ma(a,b,d){var c=a.isPure=gh(a,d);switch(a.type){case Q.Program:var e=!0;J(a.body,function(g){Ma(g.expression,b,c);e=e&&g.expression.constant});a.constant=e;break;case Q.Literal:a.constant=!0;a.toWatch=[];break;
case Q.UnaryExpression:Ma(a.argument,b,c);a.constant=a.argument.constant;a.toWatch=a.argument.toWatch;break;case Q.BinaryExpression:Ma(a.left,b,c);Ma(a.right,b,c);a.constant=a.left.constant&&a.right.constant;a.toWatch=a.left.toWatch.concat(a.right.toWatch);break;case Q.LogicalExpression:Ma(a.left,b,c);Ma(a.right,b,c);a.constant=a.left.constant&&a.right.constant;a.toWatch=a.constant?[]:[a];break;case Q.ConditionalExpression:Ma(a.test,b,c);Ma(a.alternate,b,c);Ma(a.consequent,b,c);a.constant=a.test.constant&&
a.alternate.constant&&a.consequent.constant;a.toWatch=a.constant?[]:[a];break;case Q.Identifier:a.constant=!1;a.toWatch=[a];break;case Q.MemberExpression:Ma(a.object,b,c);a.computed&&Ma(a.property,b,c);a.constant=a.object.constant&&(!a.computed||a.property.constant);a.toWatch=a.constant?[]:[a];break;case Q.CallExpression:e=d=a.filter?!b(a.callee.name).$stateful:!1;var f=[];J(a.arguments,function(g){Ma(g,b,c);e=e&&g.constant;f.push.apply(f,g.toWatch)});a.constant=e;a.toWatch=d?f:[a];break;case Q.AssignmentExpression:Ma(a.left,
b,c);Ma(a.right,b,c);a.constant=a.left.constant&&a.right.constant;a.toWatch=[a];break;case Q.ArrayExpression:e=!0;f=[];J(a.elements,function(g){Ma(g,b,c);e=e&&g.constant;f.push.apply(f,g.toWatch)});a.constant=e;a.toWatch=f;break;case Q.ObjectExpression:e=!0;f=[];J(a.properties,function(g){Ma(g.value,b,c);e=e&&g.value.constant;f.push.apply(f,g.value.toWatch);g.computed&&(Ma(g.key,b,!1),e=e&&g.key.constant,f.push.apply(f,g.key.toWatch))});a.constant=e;a.toWatch=f;break;case Q.ThisExpression:a.constant=
!1;a.toWatch=[];break;case Q.LocalsExpression:a.constant=!1,a.toWatch=[]}}function hh(a){if(1===a.length){a=a[0].expression;var b=a.toWatch;return 1!==b.length?b:b[0]!==a?b:void 0}}function $e(a){return a.type===Q.Identifier||a.type===Q.MemberExpression}function ih(a){if(1===a.body.length&&$e(a.body[0].expression))return{type:Q.AssignmentExpression,left:a.body[0].expression,right:{type:Q.NGValueParameter},operator:"="}}function af(a){this.$filter=a}function Vc(a,b,d){this.ast=new Q(a,d);this.astCompiler=
new af(b)}function Rd(a){return ca(a.valueOf)?a.valueOf():jh.call(a)}function kh(){var a=Ea(),b={"true":!0,"false":!1,"null":null,undefined:void 0},d,c;this.addLiteral=function(e,f){b[e]=f};this.setIdentifierFns=function(e,f){d=e;c=f;return this};this.$get=["$filter",function(e){function f(w,H){switch(typeof w){case "string":var F=w=w.trim();var C=a[F];C||(C=new Wc(u),C=(new Vc(C,e,u)).parse(w),C.constant?C.$$watchDelegate=n:C.oneTime?C.$$watchDelegate=C.literal?l:h:C.inputs&&(C.$$watchDelegate=k),
a[F]=C);return r(C,H);case "function":return r(w,H);default:return r(la,H)}}function g(w,H,F){return null==w||null==H?w===H:"object"!==typeof w||(w=Rd(w),"object"!==typeof w||F)?w===H||w!==w&&H!==H:!1}function k(w,H,F,C,D){var y=C.inputs,v;if(1===y.length){var p=g;y=y[0];return w.$watch(function(B){var A=y(B);g(A,p,y.isPure)||(v=C(B,void 0,void 0,[A]),p=A&&Rd(A));return v},H,F,D)}for(var q=[],m=[],x=0,G=y.length;x<G;x++)q[x]=g,m[x]=null;return w.$watch(function(B){for(var A=!1,E=0,L=y.length;E<L;E++){var P=
y[E](B);if(A||(A=!g(P,q[E],y[E].isPure)))m[E]=P,q[E]=P&&Rd(P)}A&&(v=C(B,void 0,void 0,m));return v},H,F,D)}function h(w,H,F,C,D){function y(m){return C(m)}function v(m,x,G){q=m;ca(H)&&H(m,x,G);R(m)&&G.$$postDigest(function(){R(q)&&p()})}var p,q;return p=C.inputs?k(w,v,F,C,D):w.$watch(y,v,F)}function l(w,H,F,C){function D(p){var q=!0;J(p,function(m){R(m)||(q=!1)});return q}var y,v;return y=w.$watch(function(p){return C(p)},function(p,q,m){v=p;ca(H)&&H(p,q,m);D(p)&&m.$$postDigest(function(){D(v)&&y()})},
F)}function n(w,H,F,C){var D=w.$watch(function(y){D();return C(y)},H,F);return D}function r(w,H){if(!H)return w;var F=w.$$watchDelegate,C=!1,D=F!==l&&F!==h?function(y,v,p,q){p=C&&q?q[0]:w(y,v,p,q);return H(p,y,v)}:function(y,v,p,q){p=w(y,v,p,q);y=H(p,y,v);return R(p)?y:p};C=!w.inputs;F&&F!==k?(D.$$watchDelegate=F,D.inputs=w.inputs):H.$stateful||(D.$$watchDelegate=k,D.inputs=w.inputs?w.inputs:[w]);D.inputs&&(D.inputs=D.inputs.map(function(y){return y.isPure===Ze?function(v){return y(v)}:y}));return D}
var u={csp:Jb().noUnsafeEval,literals:Bb(b),isIdentifierStart:ca(d)&&d,isIdentifierContinue:ca(c)&&c};f.$$getAst=function(w){var H=new Wc(u);return(new Vc(H,e,u)).getAst(w).ast};return f}]}function lh(){var a=!0;this.$get=["$rootScope","$exceptionHandler",function(b,d){return bf(function(c){b.$evalAsync(c)},d,a)}];this.errorOnUnhandledRejections=function(b){return R(b)?(a=b,this):a}}function mh(){var a=!0;this.$get=["$browser","$exceptionHandler",function(b,d){return bf(function(c){b.defer(c)},d,
a)}];this.errorOnUnhandledRejections=function(b){return R(b)?(a=b,this):a}}function bf(a,b,d){function c(){return new e}function e(){var q=this.promise=new f;this.resolve=function(m){h(q,m)};this.reject=function(m){n(q,m)};this.notify=function(m){u(q,m)}}function f(){this.$$state={status:0}}function g(){for(;!y&&v.length;){var q=v.shift();if(!q.pur){q.pur=!0;var m=q.value;m="Possibly unhandled rejection: "+("function"===typeof m?m.toString().replace(/ \{[\s\S]*$/,""):U(m)?"undefined":"string"!==typeof m?
ag(m,void 0):m);ld(q.value)?b(q.value,m):b(m)}}}function k(q){!d||q.pending||2!==q.status||q.pur||(0===y&&0===v.length&&a(g),v.push(q));!q.processScheduled&&q.pending&&(q.processScheduled=!0,++y,a(function(){var m=q.pending;q.processScheduled=!1;q.pending=void 0;try{for(var x=0,G=m.length;x<G;++x){q.pur=!0;var B=m[x][0];var A=m[x][q.status];try{ca(A)?h(B,A(q.value)):1===q.status?h(B,q.value):n(B,q.value)}catch(E){n(B,E),E&&!0===E.$$passToExceptionHandler&&b(E)}}}finally{--y,d&&0===y&&a(g)}}))}function h(q,
m){q.$$state.status||(m===q?r(q,D("qcycle",m)):l(q,m))}function l(q,m){function x(L){A||(A=!0,l(q,L))}function G(L){A||(A=!0,r(q,L))}function B(L){u(q,L)}var A=!1;try{if(fa(m)||ca(m))var E=m.then;ca(E)?(q.$$state.status=-1,E.call(m,x,G,B)):(q.$$state.value=m,q.$$state.status=1,k(q.$$state))}catch(L){G(L)}}function n(q,m){q.$$state.status||r(q,m)}function r(q,m){q.$$state.value=m;q.$$state.status=2;k(q.$$state)}function u(q,m){var x=q.$$state.pending;0>=q.$$state.status&&x&&x.length&&a(function(){for(var G,
B,A=0,E=x.length;A<E;A++){B=x[A][0];G=x[A][3];try{u(B,ca(G)?G(m):m)}catch(L){b(L)}}})}function w(q){var m=new f;n(m,q);return m}function H(q,m,x){var G=null;try{ca(x)&&(G=x())}catch(B){return w(B)}return G&&ca(G.then)?G.then(function(){return m(q)},w):m(q)}function F(q,m,x,G){var B=new f;h(B,q);return B.then(m,x,G)}function C(q){if(!ca(q))throw D("norslvr",q);var m=new f;q(function(x){h(m,x)},function(x){n(m,x)});return m}var D=va("$q",TypeError),y=0,v=[];Aa(f.prototype,{then:function(q,m,x){if(U(q)&&
U(m)&&U(x))return this;var G=new f;this.$$state.pending=this.$$state.pending||[];this.$$state.pending.push([G,q,m,x]);0<this.$$state.status&&k(this.$$state);return G},"catch":function(q){return this.then(null,q)},"finally":function(q,m){return this.then(function(x){return H(x,p,q)},function(x){return H(x,w,q)},m)}});var p=F;C.prototype=f.prototype;C.defer=c;C.reject=w;C.when=F;C.resolve=p;C.all=function(q){var m=new f,x=0,G=na(q)?[]:{};J(q,function(B,A){x++;F(B).then(function(E){G[A]=E;--x||h(m,G)},
function(E){n(m,E)})});0===x&&h(m,G);return m};C.race=function(q){var m=c();J(q,function(x){F(x).then(m.resolve,m.reject)});return m.promise};return C}function nh(){this.$get=["$window","$timeout",function(a,b){var d=a.requestAnimationFrame||a.webkitRequestAnimationFrame,c=a.cancelAnimationFrame||a.webkitCancelAnimationFrame||a.webkitCancelRequestAnimationFrame,e=(a=!!d)?function(f){var g=d(f);return function(){c(g)}}:function(f){var g=b(f,16.66,!1);return function(){b.cancel(g)}};e.supported=a;return e}]}
function oh(){function a(f){function g(){this.$$watchers=this.$$nextSibling=this.$$childHead=this.$$childTail=null;this.$$listeners={};this.$$listenerCount={};this.$$watchersCount=0;this.$id=++sc;this.$$ChildScope=null;this.$$suspended=!1}g.prototype=f;return g}var b=10,d=va("$rootScope"),c=null,e=null;this.digestTtl=function(f){arguments.length&&(b=f);return b};this.$get=["$exceptionHandler","$parse","$browser",function(f,g,k){function h(m){m.currentScope.$$destroyed=!0}function l(m){9===qb&&(m.$$childHead&&
l(m.$$childHead),m.$$nextSibling&&l(m.$$nextSibling));m.$parent=m.$$nextSibling=m.$$prevSibling=m.$$childHead=m.$$childTail=m.$root=m.$$watchers=null}function n(){this.$id=++sc;this.$$phase=this.$parent=this.$$watchers=this.$$nextSibling=this.$$prevSibling=this.$$childHead=this.$$childTail=null;this.$root=this;this.$$suspended=this.$$destroyed=!1;this.$$listeners={};this.$$listenerCount={};this.$$watchersCount=0;this.$$isolateBindings=null}function r(m){if(D.$$phase)throw d("inprog",D.$$phase);D.$$phase=
m}function u(m,x){do m.$$watchersCount+=x;while(m=m.$parent)}function w(m,x,G){do m.$$listenerCount[G]-=x,0===m.$$listenerCount[G]&&delete m.$$listenerCount[G];while(m=m.$parent)}function H(){}function F(){for(;p.length;)try{p.shift()()}catch(m){f(m)}e=null}function C(){null===e&&(e=k.defer(function(){D.$apply(F)}))}n.prototype={constructor:n,$new:function(m,x){x=x||this;if(m){var G=new n;G.$root=this.$root}else this.$$ChildScope||(this.$$ChildScope=a(this)),G=new this.$$ChildScope;G.$parent=x;G.$$prevSibling=
x.$$childTail;x.$$childHead?(x.$$childTail.$$nextSibling=G,x.$$childTail=G):x.$$childHead=x.$$childTail=G;(m||x!==this)&&G.$on("$destroy",h);return G},$watch:function(m,x,G,B){var A=g(m);x=ca(x)?x:la;if(A.$$watchDelegate)return A.$$watchDelegate(this,x,G,A,m);var E=this,L=E.$$watchers,P={fn:x,last:H,get:A,exp:B||m,eq:!!G};c=null;L||(L=E.$$watchers=[],L.$$digestWatchIndex=-1);L.unshift(P);L.$$digestWatchIndex++;u(this,1);return function(){var S=bc(L,P);0<=S&&(u(E,-1),S<L.$$digestWatchIndex&&L.$$digestWatchIndex--);
c=null}},$watchGroup:function(m,x){function G(){P=!1;S?(S=!1,x(A,A,L)):x(A,B,L)}var B=Array(m.length),A=Array(m.length),E=[],L=this,P=!1,S=!0;if(!m.length){var X=!0;L.$evalAsync(function(){X&&x(A,A,L)});return function(){X=!1}}if(1===m.length)return this.$watch(m[0],function(ha,ja,ea){A[0]=ha;B[0]=ja;x(A,ha===ja?A:B,ea)});J(m,function(ha,ja){ha=L.$watch(ha,function(ea,ma){A[ja]=ea;B[ja]=ma;P||(P=!0,L.$evalAsync(G))});E.push(ha)});return function(){for(;E.length;)E.shift()()}},$watchCollection:function(m,
x){function G(ma){A=ma;var ka;if(!U(A)){if(fa(A))if(ub(A))for(E!==X&&(E=X,ea=E.length=0,S++),ma=A.length,ea!==ma&&(S++,E.length=ea=ma),ka=0;ka<ma;ka++){var ya=E[ka];var ua=A[ka];var mb=ya!==ya&&ua!==ua;mb||ya===ua||(S++,E[ka]=ua)}else{E!==ha&&(E=ha={},ea=0,S++);ma=0;for(ka in A)bb.call(A,ka)&&(ma++,ua=A[ka],ya=E[ka],ka in E?(mb=ya!==ya&&ua!==ua,mb||ya===ua||(S++,E[ka]=ua)):(ea++,E[ka]=ua,S++));if(ea>ma)for(ka in S++,E)bb.call(A,ka)||(ea--,delete E[ka])}else E!==A&&(E=A,S++);return S}}G.$stateful=
!0;var B=this,A,E,L,P=1<x.length,S=0;m=g(m,G);var X=[],ha={},ja=!0,ea=0;return this.$watch(m,function(){ja?(ja=!1,x(A,A,B)):x(A,L,B);if(P)if(fa(A))if(ub(A)){L=Array(A.length);for(var ma=0;ma<A.length;ma++)L[ma]=A[ma]}else for(ma in L={},A)bb.call(A,ma)&&(L[ma]=A[ma]);else L=A})},$digest:function(){var m,x,G,B,A=b,E=[];r("$digest");k.$$checkUrlChange();this===D&&null!==e&&(k.defer.cancel(e),F());c=null;do{var L=!1;var P=this;for(B=0;B<y.length;B++){try{var S=y[B];var X=S.fn;X(S.scope,S.locals)}catch(ea){f(ea)}c=
null}y.length=0;a:do{if(B=!P.$$suspended&&P.$$watchers)for(B.$$digestWatchIndex=B.length;B.$$digestWatchIndex--;)try{if(m=B[B.$$digestWatchIndex]){var ha=m.get;if((x=ha(P))!==(G=m.last)&&!(m.eq?db(x,G):Ua(x)&&Ua(G))){if(L=!0,c=m,m.last=m.eq?Bb(x,null):x,X=m.fn,X(x,G===H?x:G,P),5>A){var ja=4-A;E[ja]||(E[ja]=[]);E[ja].push({msg:ca(m.exp)?"fn: "+(m.exp.name||m.exp.toString()):m.exp,newVal:x,oldVal:G})}}else if(m===c){L=!1;break a}}}catch(ea){f(ea)}if(!(B=!P.$$suspended&&P.$$watchersCount&&P.$$childHead||
P!==this&&P.$$nextSibling))for(;P!==this&&!(B=P.$$nextSibling);)P=P.$parent}while(P=B);if((L||y.length)&&!A--)throw D.$$phase=null,d("infdig",b,E);}while(L||y.length);for(D.$$phase=null;q<v.length;)try{v[q++]()}catch(ea){f(ea)}v.length=q=0;k.$$checkUrlChange()},$suspend:function(){this.$$suspended=!0},$isSuspended:function(){return this.$$suspended},$resume:function(){this.$$suspended=!1},$destroy:function(){if(!this.$$destroyed){var m=this.$parent;this.$broadcast("$destroy");this.$$destroyed=!0;
this===D&&k.$$applicationDestroyed();u(this,-this.$$watchersCount);for(var x in this.$$listenerCount)w(this,this.$$listenerCount[x],x);m&&m.$$childHead===this&&(m.$$childHead=this.$$nextSibling);m&&m.$$childTail===this&&(m.$$childTail=this.$$prevSibling);this.$$prevSibling&&(this.$$prevSibling.$$nextSibling=this.$$nextSibling);this.$$nextSibling&&(this.$$nextSibling.$$prevSibling=this.$$prevSibling);this.$destroy=this.$digest=this.$apply=this.$evalAsync=this.$applyAsync=la;this.$on=this.$watch=this.$watchGroup=
function(){return la};this.$$listeners={};this.$$nextSibling=null;l(this)}},$eval:function(m,x){return g(m)(this,x)},$evalAsync:function(m,x){D.$$phase||y.length||k.defer(function(){y.length&&D.$digest()});y.push({scope:this,fn:g(m),locals:x})},$$postDigest:function(m){v.push(m)},$apply:function(m){try{r("$apply");try{return this.$eval(m)}finally{D.$$phase=null}}catch(x){f(x)}finally{try{D.$digest()}catch(x){throw f(x),x;}}},$applyAsync:function(m){function x(){G.$eval(m)}var G=this;m&&p.push(x);
m=g(m);C()},$on:function(m,x){var G=this.$$listeners[m];G||(this.$$listeners[m]=G=[]);G.push(x);var B=this;do B.$$listenerCount[m]||(B.$$listenerCount[m]=0),B.$$listenerCount[m]++;while(B=B.$parent);var A=this;return function(){var E=G.indexOf(x);-1!==E&&(delete G[E],w(A,1,m))}},$emit:function(m,x){var G=[],B=this,A=!1,E={name:m,targetScope:B,stopPropagation:function(){A=!0},preventDefault:function(){E.defaultPrevented=!0},defaultPrevented:!1},L=cc([E],arguments,1),P;do{var S=B.$$listeners[m]||G;
E.currentScope=B;var X=0;for(P=S.length;X<P;X++)if(S[X])try{S[X].apply(null,L)}catch(ha){f(ha)}else S.splice(X,1),X--,P--;if(A)break;B=B.$parent}while(B);E.currentScope=null;return E},$broadcast:function(m,x){var G=this,B=this,A={name:m,targetScope:this,preventDefault:function(){A.defaultPrevented=!0},defaultPrevented:!1};if(!this.$$listenerCount[m])return A;for(var E=cc([A],arguments,1),L,P;G=B;){A.currentScope=G;B=G.$$listeners[m]||[];L=0;for(P=B.length;L<P;L++)if(B[L])try{B[L].apply(null,E)}catch(S){f(S)}else B.splice(L,
1),L--,P--;if(!(B=G.$$listenerCount[m]&&G.$$childHead||G!==this&&G.$$nextSibling))for(;G!==this&&!(B=G.$$nextSibling);)G=G.$parent}A.currentScope=null;return A}};var D=new n,y=D.$$asyncQueue=[],v=D.$$postDigestQueue=[],p=D.$$applyAsyncQueue=[],q=0;return D}]}function ph(){var a=/^\s*(https?|s?ftp|mailto|tel|file):/,b=/^\s*((https?|ftp|file|blob):|data:image\/)/;this.aHrefSanitizationWhitelist=function(d){return R(d)?(a=d,this):a};this.imgSrcSanitizationWhitelist=function(d){return R(d)?(b=d,this):
b};this.$get=function(){return function(d,c){c=c?b:a;var e=pb(d&&d.trim()).href;return""===e||e.match(c)?d:"unsafe:"+e}}}function qh(){this.$get=["$window","$document",function(a,b){var d={},c=!((!a.nw||!a.nw.process)&&a.chrome&&(a.chrome.app&&a.chrome.app.runtime||!a.chrome.app&&a.chrome.runtime&&a.chrome.runtime.id))&&a.history&&a.history.pushState,e=parseInt((/android (\d+)/.exec(xa((a.navigator||{}).userAgent))||[])[1],10);a=/Boxee/i.test((a.navigator||{}).userAgent);var f=b[0]||{};b=f.body&&
f.body.style;var g=!1,k=!1;b&&(g=!!("transition"in b||"webkitTransition"in b),k=!!("animation"in b||"webkitAnimation"in b));return{history:!(!c||4>e||a),hasEvent:function(h){if("input"===h&&qb)return!1;if(U(d[h])){var l=f.createElement("div");d[h]="on"+h in l}return d[h]},csp:Jb(),transitions:g,animations:k,android:e}}]}function rh(){this.$get=["$rootScope","$browser","$location",function(a,b,d){return{findBindings:function(c,e,f){c=c.getElementsByClassName("ng-binding");var g=[];J(c,function(k){var h=
Va.element(k).data("$binding");h&&J(h,function(l){f?(new RegExp("(^|\\s)"+e.replace(/([-()[\]{}+?*.$^|,:#<!\\])/g,"\\$1").replace(/\x08/g,"\\x08")+"(\\s|\\||$)")).test(l)&&g.push(k):-1!==l.indexOf(e)&&g.push(k)})});return g},findModels:function(c,e,f){for(var g=["ng-","data-ng-","ng\\:"],k=0;k<g.length;++k){var h=c.querySelectorAll("["+g[k]+"model"+(f?"=":"*=")+'"'+e+'"]');if(h.length)return h}},getLocation:function(){return d.url()},setLocation:function(c){c!==d.url()&&(d.url(c),a.$digest())},whenStable:function(c){b.notifyWhenNoOutstandingRequests(c)}}}]}
function sh(){this.$get=["$rootScope","$browser","$q","$$q","$exceptionHandler",function(a,b,d,c,e){function f(k,h,l){ca(k)||(l=h,h=k,k=la);var n=hb.call(arguments,3),r=R(l)&&!l,u=(r?c:d).defer(),w=u.promise;var H=b.defer(function(){try{u.resolve(k.apply(null,n))}catch(F){u.reject(F),e(F)}finally{delete g[w.$$timeoutId]}r||a.$apply()},h);w.$$timeoutId=H;g[H]=u;return w}var g={};f.cancel=function(k){return k&&k.$$timeoutId in g?(g[k.$$timeoutId].promise.$$state.pur=!0,g[k.$$timeoutId].reject("canceled"),
delete g[k.$$timeoutId],b.defer.cancel(k.$$timeoutId)):!1};return f}]}function pb(a){if(!oa(a))return a;qb&&(Pa.setAttribute("href",a),a=Pa.href);Pa.setAttribute("href",a);return{href:Pa.href,protocol:Pa.protocol?Pa.protocol.replace(/:$/,""):"",host:Pa.host,search:Pa.search?Pa.search.replace(/^\?/,""):"",hash:Pa.hash?Pa.hash.replace(/^#/,""):"",hostname:Pa.hostname,port:Pa.port,pathname:"/"===Pa.pathname.charAt(0)?Pa.pathname:"/"+Pa.pathname}}function Xg(a){var b=[cf].concat(a.map(pb));return function(d){d=
pb(d);return b.some(df.bind(null,d))}}function df(a,b){a=pb(a);b=pb(b);return a.protocol===b.protocol&&a.host===b.host}function th(){this.$get=cb(ia)}function ef(a){function b(f){try{return decodeURIComponent(f)}catch(g){return f}}var d=a[0]||{},c={},e="";return function(){var f;try{var g=d.cookie||""}catch(n){g=""}if(g!==e)for(e=g,g=e.split("; "),c={},f=0;f<g.length;f++){var k=g[f];var h=k.indexOf("=");if(0<h){var l=b(k.substring(0,h));U(c[l])&&(c[l]=b(k.substring(h+1)))}}return c}}function uh(){this.$get=
ef}function ff(a){function b(d,c){if(fa(d)){var e={};J(d,function(f,g){e[g]=b(g,f)});return e}return a.factory(d+"Filter",c)}this.register=b;this.$get=["$injector",function(d){return function(c){return d.get(c+"Filter")}}];b("currency",gf);b("date",hf);b("filter",vh);b("json",wh);b("limitTo",xh);b("lowercase",yh);b("number",jf);b("orderBy",kf);b("uppercase",zh)}function vh(){return function(a,b,d,c){if(!ub(a)){if(null==a)return a;throw va("filter")("notarray",a);}c=c||"$";switch(Sd(b)){case "function":break;
case "boolean":case "null":case "number":case "string":var e=!0;case "object":b=Ah(b,d,c,e);break;default:return a}return Array.prototype.filter.call(a,b)}}function Ah(a,b,d,c){var e=fa(a)&&d in a;!0===b?b=db:ca(b)||(b=function(f,g){if(U(f))return!1;if(null===f||null===g)return f===g;if(fa(g)||fa(f)&&!kd(f))return!1;f=xa(""+f);g=xa(""+g);return-1!==f.indexOf(g)});return function(f){return e&&!fa(f)?Kb(f,a[d],b,d,!1):Kb(f,a,b,d,c)}}function Kb(a,b,d,c,e,f){var g=Sd(a),k=Sd(b);if("string"===k&&"!"===
b.charAt(0))return!Kb(a,b.substring(1),d,c,e);if(na(a))return a.some(function(l){return Kb(l,b,d,c,e)});switch(g){case "object":var h;if(e){for(h in a)if(h.charAt&&"$"!==h.charAt(0)&&Kb(a[h],b,d,c,!0))return!0;return f?!1:Kb(a,b,d,c,!1)}if("object"===k){for(h in b)if(f=b[h],!ca(f)&&!U(f)&&(g=h===c,!Kb(g?a:a[h],f,d,c,g,g)))return!1;return!0}return d(a,b);case "function":return!1;default:return d(a,b)}}function Sd(a){return null===a?"null":typeof a}function gf(a){var b=a.NUMBER_FORMATS;return function(d,
c,e){U(c)&&(c=b.CURRENCY_SYM);U(e)&&(e=b.PATTERNS[1].maxFrac);var f=c?/\u00A4/g:/\s*\u00A4\s*/g;return null==d?d:lf(d,b.PATTERNS[1],b.GROUP_SEP,b.DECIMAL_SEP,e).replace(f,c)}}function jf(a){var b=a.NUMBER_FORMATS;return function(d,c){return null==d?d:lf(d,b.PATTERNS[0],b.GROUP_SEP,b.DECIMAL_SEP,c)}}function Bh(a){var b=0,d,c,e,f;-1<(d=a.indexOf(mf))&&(a=a.replace(mf,""));0<(c=a.search(/e/i))?(0>d&&(d=c),d+=+a.slice(c+1),a=a.substring(0,c)):0>d&&(d=a.length);for(c=0;a.charAt(c)===Td;c++);if(c===(f=
a.length)){var g=[0];d=1}else{for(f--;a.charAt(f)===Td;)f--;d-=c;g=[];for(e=0;c<=f;c++,e++)g[e]=+a.charAt(c)}d>nf&&(g=g.splice(0,nf-1),b=d-1,d=1);return{d:g,e:b,i:d}}function Ch(a,b,d,c){var e=a.d,f=e.length-a.i;b=U(b)?Math.min(Math.max(d,f),c):+b;d=b+a.i;c=e[d];if(0<d){e.splice(Math.max(a.i,d));for(var g=d;g<e.length;g++)e[g]=0}else for(f=Math.max(0,f),a.i=1,e.length=Math.max(1,d=b+1),e[0]=0,g=1;g<d;g++)e[g]=0;if(5<=c)if(0>d-1){for(c=0;c>d;c--)e.unshift(0),a.i++;e.unshift(1);a.i++}else e[d-1]++;
for(;f<Math.max(0,b);f++)e.push(0);if(b=e.reduceRight(function(k,h,l,n){h+=k;n[l]=h%10;return Math.floor(h/10)},0))e.unshift(b),a.i++}function lf(a,b,d,c,e){if(!oa(a)&&!Ra(a)||isNaN(a))return"";var f=!isFinite(a),g=!1,k=Math.abs(a)+"",h="";if(f)h="\u221e";else{g=Bh(k);Ch(g,e,b.minFrac,b.maxFrac);h=g.d;k=g.i;e=g.e;f=[];for(g=h.reduce(function(l,n){return l&&!n},!0);0>k;)h.unshift(0),k++;0<k?f=h.splice(k,h.length):(f=h,h=[0]);k=[];for(h.length>=b.lgSize&&k.unshift(h.splice(-b.lgSize,h.length).join(""));h.length>
b.gSize;)k.unshift(h.splice(-b.gSize,h.length).join(""));h.length&&k.unshift(h.join(""));h=k.join(d);f.length&&(h+=c+f.join(""));e&&(h+="e+"+e)}return 0>a&&!g?b.negPre+h+b.negSuf:b.posPre+h+b.posSuf}function Xc(a,b,d,c){var e="";if(0>a||c&&0>=a)c?a=-a+1:(a=-a,e="-");for(a=""+a;a.length<b;)a=Td+a;d&&(a=a.substr(a.length-b));return e+a}function Qa(a,b,d,c,e){d=d||0;return function(f){f=f["get"+a]();if(0<d||f>-d)f+=d;0===f&&-12===d&&(f=12);return Xc(f,b,c,e)}}function nc(a,b,d){return function(c,e){c=
c["get"+a]();var f=Tc((d?"STANDALONE":"")+(b?"SHORT":"")+a);return e[f][c]}}function of(a){var b=(new Date(a,0,1)).getDay();return new Date(a,0,(4>=b?5:12)-b)}function pf(a){return function(b){var d=of(b.getFullYear());b=new Date(b.getFullYear(),b.getMonth(),b.getDate()+(4-b.getDay()));return Xc(1+Math.round((+b-+d)/6048E5),a)}}function Ud(a,b){return 0>=a.getFullYear()?b.ERAS[0]:b.ERAS[1]}function hf(a){function b(c){var e;if(e=c.match(d)){c=new Date(0);var f=0,g=0,k=e[8]?c.setUTCFullYear:c.setFullYear,
h=e[8]?c.setUTCHours:c.setHours;e[9]&&(f=parseInt(e[9]+e[10],10),g=parseInt(e[9]+e[11],10));k.call(c,parseInt(e[1],10),parseInt(e[2],10)-1,parseInt(e[3],10));f=parseInt(e[4]||0,10)-f;g=parseInt(e[5]||0,10)-g;k=parseInt(e[6]||0,10);e=Math.round(1E3*parseFloat("0."+(e[7]||0)));h.call(c,f,g,k,e);return c}return c}var d=/^(\d{4})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/;return function(c,e,f){var g="",k=[],h,l;e=e||"mediumDate";e=a.DATETIME_FORMATS[e]||
e;oa(c)&&(c=Dh.test(c)?parseInt(c,10):b(c));Ra(c)&&(c=new Date(c));if(!Xa(c)||!isFinite(c.getTime()))return c;for(;e;)(l=Eh.exec(e))?(k=cc(k,l,1),e=k.pop()):(k.push(e),e=null);var n=c.getTimezoneOffset();f&&(n=nd(f,n),c=od(c,f,!0));J(k,function(r){h=Fh[r];g+=h?h(c,a.DATETIME_FORMATS,n):"''"===r?"'":r.replace(/(^'|'$)/g,"").replace(/''/g,"'")});return g}}function wh(){return function(a,b){U(b)&&(b=2);return dc(a,b)}}function xh(){return function(a,b,d){b=Infinity===Math.abs(Number(b))?Number(b):parseInt(b,
10);if(Ua(b))return a;Ra(a)&&(a=a.toString());if(!ub(a))return a;d=!d||isNaN(d)?0:parseInt(d,10);d=0>d?Math.max(0,a.length+d):d;return 0<=b?Vd(a,d,d+b):0===d?Vd(a,b,a.length):Vd(a,Math.max(0,d+b),d)}}function Vd(a,b,d){return oa(a)?a.slice(b,d):hb.call(a,b,d)}function kf(a){function b(e){return e.map(function(f){var g=1,k=uc;if(ca(f))k=f;else if(oa(f)){if("+"===f.charAt(0)||"-"===f.charAt(0))g="-"===f.charAt(0)?-1:1,f=f.substring(1);if(""!==f&&(k=a(f),k.constant)){var h=k();k=function(l){return l[h]}}}return{get:k,
descending:g}})}function d(e){switch(typeof e){case "number":case "boolean":case "string":return!0;default:return!1}}function c(e,f){var g=0,k=e.type,h=f.type;if(k===h){h=e.value;var l=f.value;"string"===k?(h=h.toLowerCase(),l=l.toLowerCase()):"object"===k&&(fa(h)&&(h=e.index),fa(l)&&(l=f.index));h!==l&&(g=h<l?-1:1)}else g=k<h?-1:1;return g}return function(e,f,g,k){if(null==e)return e;if(!ub(e))throw va("orderBy")("notarray",e);na(f)||(f=[f]);0===f.length&&(f=["+"]);var h=b(f),l=g?-1:1,n=ca(k)?k:
c;e=Array.prototype.map.call(e,function(r,u){return{value:r,tieBreaker:{value:u,type:"number",index:u},predicateValues:h.map(function(w){var H=w.get(r);w=typeof H;if(null===H)w="string",H="null";else if("object"===w)a:{if(ca(H.valueOf)&&(H=H.valueOf(),d(H)))break a;kd(H)&&(H=H.toString(),d(H))}return{value:H,type:w,index:u}})}});e.sort(function(r,u){for(var w=0,H=h.length;w<H;w++){var F=n(r.predicateValues[w],u.predicateValues[w]);if(F)return F*h[w].descending*l}return(n(r.tieBreaker,u.tieBreaker)||
c(r.tieBreaker,u.tieBreaker))*l});return e=e.map(function(r){return r.value})}}function Vb(a){ca(a)&&(a={link:a});a.restrict=a.restrict||"AC";return cb(a)}function Yc(a,b,d,c,e){this.$$controls=[];this.$error={};this.$$success={};this.$pending=void 0;this.$name=e(b.name||b.ngForm||"")(d);this.$dirty=!1;this.$valid=this.$pristine=!0;this.$submitted=this.$invalid=!1;this.$$parentForm=Zc;this.$$element=a;this.$$animate=c;qf(this)}function qf(a){a.$$classCache={};a.$$classCache[rf]=!(a.$$classCache[oc]=
a.$$element.hasClass(oc))}function sf(a){function b(f,g,k){k&&!f.$$classCache[g]?(f.$$animate.addClass(f.$$element,g),f.$$classCache[g]=!0):!k&&f.$$classCache[g]&&(f.$$animate.removeClass(f.$$element,g),f.$$classCache[g]=!1)}function d(f,g,k){g=g?"-"+me(g,"-"):"";b(f,oc+g,!0===k);b(f,rf+g,!1===k)}var c=a.set,e=a.unset;a.clazz.prototype.$setValidity=function(f,g,k){U(g)?(this.$pending||(this.$pending={}),c(this.$pending,f,k)):(this.$pending&&e(this.$pending,f,k),tf(this.$pending)&&(this.$pending=void 0));
vb(g)?g?(e(this.$error,f,k),c(this.$$success,f,k)):(c(this.$error,f,k),e(this.$$success,f,k)):(e(this.$error,f,k),e(this.$$success,f,k));this.$pending?(b(this,"ng-pending",!0),this.$valid=this.$invalid=void 0,d(this,"",null)):(b(this,"ng-pending",!1),this.$valid=tf(this.$error),this.$invalid=!this.$valid,d(this,"",this.$valid));g=this.$pending&&this.$pending[f]?void 0:this.$error[f]?!1:this.$$success[f]?!0:null;d(this,f,g);this.$$parentForm.$setValidity(f,g,this)}}function tf(a){if(a)for(var b in a)if(a.hasOwnProperty(b))return!1;
return!0}function Wd(a){a.$formatters.push(function(b){return a.$isEmpty(b)?b:b.toString()})}function Wb(a,b,d,c,e,f){var g=xa(b[0].type);if(!e.android){var k=!1;b.on("compositionstart",function(){k=!0});b.on("compositionupdate",function(r){if(U(r.data)||""===r.data)k=!1});b.on("compositionend",function(){k=!1;l()})}var h,l=function(r){h&&(f.defer.cancel(h),h=null);if(!k){var u=b.val();r=r&&r.type;"password"===g||d.ngTrim&&"false"===d.ngTrim||(u=Ca(u));(c.$viewValue!==u||""===u&&c.$$hasNativeValidators)&&
c.$setViewValue(u,r)}};if(e.hasEvent("input"))b.on("input",l);else{var n=function(r,u,w){h||(h=f.defer(function(){h=null;u&&u.value===w||l(r)}))};b.on("keydown",function(r){var u=r.keyCode;91===u||15<u&&19>u||37<=u&&40>=u||n(r,this,this.value)});if(e.hasEvent("paste"))b.on("paste cut drop",n)}b.on("change",l);if(uf[g]&&c.$$hasNativeValidators&&g===d.type)b.on("keydown wheel mousedown",function(r){if(!h){var u=this.validity,w=u.badInput,H=u.typeMismatch;h=f.defer(function(){h=null;u.badInput===w&&
u.typeMismatch===H||l(r)})}});c.$render=function(){var r=c.$isEmpty(c.$viewValue)?"":c.$viewValue;b.val()!==r&&b.val(r)}}function $c(a,b){return function(d,c){if(Xa(d))return d;if(oa(d)){'"'===d.charAt(0)&&'"'===d.charAt(d.length-1)&&(d=d.substring(1,d.length-1));if(Gh.test(d))return new Date(d);a.lastIndex=0;if(d=a.exec(d)){d.shift();var e=c?{yyyy:c.getFullYear(),MM:c.getMonth()+1,dd:c.getDate(),HH:c.getHours(),mm:c.getMinutes(),ss:c.getSeconds(),sss:c.getMilliseconds()/1E3}:{yyyy:1970,MM:1,dd:1,
HH:0,mm:0,ss:0,sss:0};J(d,function(f,g){g<b.length&&(e[b[g]]=+f)});c=new Date(e.yyyy,e.MM-1,e.dd,e.HH,e.mm,e.ss||0,1E3*e.sss||0);100>e.yyyy&&c.setFullYear(e.yyyy);return c}}return NaN}}function pc(a,b,d,c){return function(e,f,g,k,h,l,n){function r(y){return y&&!(y.getTime&&y.getTime()!==y.getTime())}function u(y){return R(y)&&!Xa(y)?w(y)||void 0:y}function w(y,v){var p=k.$options.getOption("timezone");F&&F!==p&&(v=je(v,nd(F)));y=d(y,v);!isNaN(y)&&p&&(y=od(y,p));return y}Xd(e,f,g,k);Wb(e,f,g,k,h,l);
var H,F;k.$$parserName=a;k.$parsers.push(function(y){if(k.$isEmpty(y))return null;if(b.test(y))return w(y,H)});k.$formatters.push(function(y){if(y&&!Xa(y))throw qc("datefmt",y);if(r(y)){H=y;var v=k.$options.getOption("timezone");v&&(F=v,H=od(H,v,!0));return n("date")(y,c,v)}F=H=null;return""});if(R(g.min)||g.ngMin){var C;k.$validators.min=function(y){return!r(y)||U(C)||d(y)>=C};g.$observe("min",function(y){C=u(y);k.$validate()})}if(R(g.max)||g.ngMax){var D;k.$validators.max=function(y){return!r(y)||
U(D)||d(y)<=D};g.$observe("max",function(y){D=u(y);k.$validate()})}}}function Xd(a,b,d,c){(c.$$hasNativeValidators=fa(b[0].validity))&&c.$parsers.push(function(e){var f=b.prop("validity")||{};return f.badInput||f.typeMismatch?void 0:e})}function vf(a){a.$$parserName="number";a.$parsers.push(function(b){if(a.$isEmpty(b))return null;if(Hh.test(b))return parseFloat(b)});a.$formatters.push(function(b){if(!a.$isEmpty(b)){if(!Ra(b))throw qc("numfmt",b);b=b.toString()}return b})}function Xb(a){R(a)&&!Ra(a)&&
(a=parseFloat(a));return Ua(a)?void 0:a}function Yd(a){var b=a.toString(),d=b.indexOf(".");return-1===d?-1<a&&1>a&&(a=/e-(\d+)$/.exec(b))?Number(a[1]):0:b.length-d-1}function wf(a,b,d){a=Number(a);var c=(a|0)!==a,e=(b|0)!==b,f=(d|0)!==d;if(c||e||f){var g=c?Yd(a):0,k=e?Yd(b):0,h=f?Yd(d):0;g=Math.pow(10,Math.max(g,k,h));a*=g;b*=g;d*=g;c&&(a=Math.round(a));e&&(b=Math.round(b));f&&(d=Math.round(d))}return 0===(a-b)%d}function xf(a,b,d,c,e){if(R(c)){a=a(c);if(!a.constant)throw qc("constexpr",d,c);return a(b)}return e}
function Zd(a,b){function d(g,k){if(!g||!g.length)return[];if(!k||!k.length)return g;var h=[],l=0;a:for(;l<g.length;l++){for(var n=g[l],r=0;r<k.length;r++)if(n===k[r])continue a;h.push(n)}return h}function c(g){var k=g;na(g)?k=g.map(c).join(" "):fa(g)&&(k=Object.keys(g).filter(function(h){return g[h]}).join(" "));return k}function e(g){var k=g;if(na(g))k=g.map(e);else if(fa(g)){var h=!1;k=Object.keys(g).filter(function(l){l=g[l];!h&&U(l)&&(h=!0);return l});h&&k.push(void 0)}return k}a="ngClass"+a;
var f;return["$parse",function(g){return{restrict:"AC",link:function(k,h,l){function n(p,q){var m=[];J(p,function(x){if(0<q||D[x])D[x]=(D[x]||0)+q,D[x]===+(0<q)&&m.push(x)});return m.join(" ")}function r(p){if(p===b){var q=v;q=n(q&&q.split(" "),1);l.$addClass(q)}else q=v,q=n(q&&q.split(" "),-1),l.$removeClass(q);y=p}function u(p){p=c(p);p!==v&&w(p)}function w(p){if(y===b){var q=v&&v.split(" "),m=p&&p.split(" "),x=d(q,m);q=d(m,q);x=n(x,-1);q=n(q,1);l.$addClass(q);l.$removeClass(x)}v=p}var H=l[a].trim(),
F=":"===H.charAt(0)&&":"===H.charAt(1);H=g(H,F?e:c);var C=F?u:w,D=h.data("$classCounts"),y=!0,v;D||(D=Ea(),h.data("$classCounts",D));"ngClass"!==a&&(f||(f=g("$index",function(p){return p&1})),k.$watch(f,r));k.$watch(H,C,F)}}}]}function ad(a,b,d,c,e,f,g,k,h){this.$modelValue=this.$viewValue=Number.NaN;this.$$rawModelValue=void 0;this.$validators={};this.$asyncValidators={};this.$parsers=[];this.$formatters=[];this.$viewChangeListeners=[];this.$untouched=!0;this.$touched=!1;this.$pristine=!0;this.$dirty=
!1;this.$valid=!0;this.$invalid=!1;this.$error={};this.$$success={};this.$pending=void 0;this.$name=h(d.name||"",!1)(a);this.$$parentForm=Zc;this.$options=$d;this.$$updateEvents="";this.$$updateEventHandler=this.$$updateEventHandler.bind(this);this.$$parsedNgModel=e(d.ngModel);this.$$parsedNgModelAssign=this.$$parsedNgModel.assign;this.$$ngModelGet=this.$$parsedNgModel;this.$$ngModelSet=this.$$parsedNgModelAssign;this.$$pendingDebounce=null;this.$$parserValid=void 0;this.$$currentValidationRunId=
0;Object.defineProperty(this,"$$scope",{value:a});this.$$attr=d;this.$$element=c;this.$$animate=f;this.$$timeout=g;this.$$parse=e;this.$$q=k;this.$$exceptionHandler=b;qf(this);Ih(this)}function Ih(a){a.$$scope.$watch(function(b){b=a.$$ngModelGet(b);b===a.$modelValue||a.$modelValue!==a.$modelValue&&b!==b||a.$$setModelValue(b);return b})}function ae(a){this.$$options=a}function yf(a,b){J(b,function(d,c){R(a[c])||(a[c]=d)})}function Lb(a,b){a.prop("selected",b);a.attr("selected",b)}function Jh(){this.SCE_CONTEXTS=
Yb;this.resourceUrlWhitelist=function(a){throw Ya("noresourceurlwhitelist");};this.resourceUrlBlacklist=function(a){throw Ya("noresourceurlblacklist");};this.$get=["$injector",function(a){var b=function(d){throw Ya("unsafe");};a.has("$sanitize")&&(b=a.get("$sanitize"));return{trustAs:function(d,c){throw Ya("notrustas");},getTrusted:function(d,c){if(null===c||U(c)||""===c)return c;if("string"==typeof c){if(d==Yb.TEMPLATE_URL){d=a.has("html2JsTemplatesCached")?!a.get("html2JsTemplatesCached")():!ng.safehtml.googSceHelper.isCOMPILED();
if(d&&df(c,cf))return c;throw Ya("insecurl",c);}if(d==Yb.RESOURCE_URL)throw Ya("insecurl",c);if(d==Yb.HTML)return b(c);throw Ya("unsafe",d);}if(ng.safehtml.googSceHelper.isGoogHtmlType(c))try{return ng.safehtml.googSceHelper.unwrapGivenContext(d,c)}catch(e){throw Ya("googhtml",c.toString(),d);}else throw Ya("unsafe",d);},valueOf:function(d){if(ng.safehtml.googSceHelper.isGoogHtmlType(d))try{return ng.safehtml.googSceHelper.unwrapAny(d)}catch(c){throw Ya("googhtml",d.toString());}else return d}}}]}
function Kh(){this.enabled=function(a){if(arguments.length)throw Ya("nodisabling");return!0};this.$get=["$parse","$sceDelegate",function(a,b){if(8>qb)throw Ya("iequirks");if("undefined"==typeof ng||!ng.safehtml||!ng.safehtml.googSceHelper)throw Ya("nodep");var d=kb(Yb);d.isEnabled=function(){return!0};d.trustAs=b.trustAs;d.getTrusted=b.getTrusted;d.valueOf=b.valueOf;d.parseAs=function(g,k){var h=a(k);return h.literal&&h.constant?h:a(k,function(l){return d.getTrusted(g,l)})};var c=d.parseAs,e=d.getTrusted,
f=d.trustAs;J(Yb,function(g,k){k=xa(k);d[("parse_as_"+k).replace(be,Db)]=function(h){return c(g,h)};d[("get_trusted_"+k).replace(be,Db)]=function(h){return e(g,h)};d[("trust_as_"+k).replace(be,Db)]=function(h){return f(g,h)}});return d}]}function Lh(){var a;this.httpOptions=function(b){return b?(a=b,this):a};this.$get=["$exceptionHandler","$templateCache","$http","$q","$sce",function(b,d,c,e,f){function g(k,h){g.totalPendingRequests++;if(!oa(k)||U(d.get(k)))k=f.getTrustedTemplateUrl(k);var l=c.defaults&&
c.defaults.transformResponse;na(l)?l=l.filter(function(n){return n!==Ld}):l===Ld&&(l=null);return c.get(k,Aa({cache:d,transformResponse:l},a)).finally(function(){g.totalPendingRequests--}).then(function(n){d.put(k,n.data);return n.data},function(n){h||(n=Mh("tpload",k,n.status,n.statusText),b(n));return e.reject(n)})}g.totalPendingRequests=0;return g}]}var de={objectMaxDepth:5},Nh=/^\/(.+)\/([a-z]*)$/,bb=Object.prototype.hasOwnProperty,xa=function(a){return oa(a)?a.toLowerCase():a},Tc=function(a){return oa(a)?
a.toUpperCase():a},da,Ab,hb=[].slice,Mg=[].splice,Oh=[].push,Ta=Object.prototype.toString,ge=Object.getPrototypeOf,Cb=va("ng"),Va=ia.angular||(ia.angular={}),zd,sc=0;var qb=ia.document.documentMode;var Ua=Number.isNaN||function(a){return a!==a};la.$inject=[];uc.$inject=[];var na=Array.isArray,Rf=/^\[object (?:Uint8|Uint8Clamped|Uint16|Uint32|Int8|Int16|Int32|Float32|Float64)Array]$/,Ca=function(a){return oa(a)?a.trim():a},Jb=function(){if(!R(Jb.rules)){var a=ia.document.querySelector("[ng-csp]")||
ia.document.querySelector("[data-ng-csp]");a?(a=a.getAttribute("ng-csp")||a.getAttribute("data-ng-csp"),Jb.rules={noUnsafeEval:!0,noInlineStyle:!a||-1!==a.indexOf("no-inline-style")}):Jb.rules={noUnsafeEval:!0,noInlineStyle:!1}}return Jb.rules},bd=function(){if(R(bd.name_))return bd.name_;var a,b,d=Nb.length;for(b=0;b<d;++b){var c=Nb[b];if(a=ia.document.querySelector("["+c.replace(":","\\:")+"jq]")){var e=a.getAttribute(c+"jq");break}}return bd.name_=e},Tf=/:/g,Nb=["ng-","data-ng-","ng:","x-ng-"],
Wf=function(a){var b=a.currentScript;if(!b)return!0;if(!(b instanceof ia.HTMLScriptElement||b instanceof ia.SVGScriptElement))return!1;b=b.attributes;return[b.getNamedItem("src"),b.getNamedItem("href"),b.getNamedItem("xlink:href")].every(function(d){if(!d)return!0;if(!d.value)return!1;var c=a.createElement("a");c.href=d.value;if(a.location.origin===c.origin)return!0;switch(c.protocol){case "http:":case "https:":case "ftp:":case "blob:":case "file:":case "data:":return!0;default:return!1}})}(ia.document),
Zf=/[A-Z]/g,zf=!1,wb=3,Ph={full:"1.6.4-local+sha.617b36117",major:1,minor:6,dot:void 0,codeName:"undefined"};Ha.expando="ng339";var hc=Ha.cache={},eg=1;Ha._data=function(a){return this.cache[a[this.expando]]||{}};var Ac=/-([a-z])/g,Qh=/^-ms-/,zc={mouseleave:"mouseout",mouseenter:"mouseover"},ud=va("jqLite"),dg=/^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,td=/<|&#?\w+;/,bg=/<([\w:-]+)/,cg=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,eb={option:[1,'<select multiple="multiple">',"</select>"],
thead:[1,"<table>","</table>"],col:[2,"<table><colgroup>","</colgroup></table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:[0,"",""]};eb.optgroup=eb.option;eb.tbody=eb.tfoot=eb.colgroup=eb.caption=eb.thead;eb.th=eb.td;var jg=ia.Node.prototype.contains||function(a){return!!(this.compareDocumentPosition(a)&16)},Qb=Ha.prototype={ready:pe,toString:function(){var a=[];J(this,function(b){a.push(""+b)});return"["+a.join(", ")+"]"},eq:function(a){return 0<=
a?da(this[a]):da(this[this.length+a])},length:0,push:Oh,sort:[].sort,splice:[].splice},Gc={};J("multiple selected checked disabled readOnly required open".split(" "),function(a){Gc[xa(a)]=a});var ue={};J("input select option textarea button form details".split(" "),function(a){ue[a]=!0});var Me={ngMinlength:"minlength",ngMaxlength:"maxlength",ngMin:"min",ngMax:"max",ngPattern:"pattern",ngStep:"step"};J({data:yd,removeData:xd,hasData:function(a){for(var b in hc[a.ng339])return!0;return!1},cleanData:function(a){for(var b=
0,d=a.length;b<d;b++)xd(a[b])}},function(a,b){Ha[b]=a});J({data:yd,inheritedData:Ec,scope:function(a){return da.data(a,"$scope")||Ec(a.parentNode||a,["$isolateScope","$scope"])},isolateScope:function(a){return da.data(a,"$isolateScope")||da.data(a,"$isolateScopeNoTemplate")},controller:re,injector:function(a){return Ec(a,"$injector")},removeAttr:function(a,b){a.removeAttribute(b)},hasClass:Bc,css:function(a,b,d){b=b.replace(Qh,"ms-").replace(Ac,Db);if(R(d))a.style[b]=d;else return a.style[b]},attr:function(a,
b,d){var c=a.nodeType;if(c!==wb&&2!==c&&8!==c&&a.getAttribute){c=xa(b);var e=Gc[c];if(R(d))null===d||!1===d&&e?a.removeAttribute(b):a.setAttribute(b,e?c:d);else return a=a.getAttribute(b),e&&null!==a&&(a=c),null===a?void 0:a}},prop:function(a,b,d){if(R(d))a[b]=d;else return a[b]},text:function(){function a(b,d){if(U(d))return d=b.nodeType,1===d||d===wb?b.textContent:"";b.textContent=d}a.$dv="";return a}(),val:function(a,b){if(U(b)){if(a.multiple&&"select"===ib(a)){var d=[];J(a.options,function(c){c.selected&&
d.push(c.value||c.text)});return d}return a.value}a.value=b},html:function(a,b){if(U(b))return a.innerHTML;xc(a,!0);a.innerHTML=b},empty:se},function(a,b){Ha.prototype[b]=function(d,c){var e,f,g=this.length;if(a!==se&&U(2===a.length&&a!==Bc&&a!==re?d:c)){if(fa(d)){for(e=0;e<g;e++)if(a===yd)a(this[e],d);else for(f in d)a(this[e],f,d[f]);return this}e=a.$dv;g=U(e)?Math.min(g,1):g;for(f=0;f<g;f++){var k=a(this[f],d,c);e=e?e+k:k}return e}for(e=0;e<g;e++)a(this[e],d,c);return this}});J({removeData:xd,
on:function(a,b,d,c){if(R(c))throw ud("onargs");if(sd(a)){c=yc(a,!0);var e=c.events,f=c.handle;f||(f=c.handle=gg(a,e));c=0<=b.indexOf(" ")?b.split(" "):[b];for(var g=c.length,k=function(h,l,n){var r=e[h];r||(r=e[h]=[],r.specialHandlerWrapper=l,"$destroy"===h||n||a.addEventListener(h,f));r.push(d)};g--;)b=c[g],zc[b]?(k(zc[b],ig),k(b,void 0,!0)):k(b)}},off:qe,one:function(a,b,d){a=da(a);a.on(b,function e(){a.off(b,d);a.off(b,e)});a.on(b,d)},replaceWith:function(a,b){var d,c=a.parentNode;xc(a);J(new Ha(b),
function(e){d?c.insertBefore(e,d.nextSibling):c.replaceChild(e,a);d=e})},children:function(a){var b=[];J(a.childNodes,function(d){1===d.nodeType&&b.push(d)});return b},contents:function(a){return a.contentDocument||a.childNodes||[]},append:function(a,b){var d=a.nodeType;if(1===d||11===d){b=new Ha(b);d=0;for(var c=b.length;d<c;d++)a.appendChild(b[d])}},prepend:function(a,b){if(1===a.nodeType){var d=a.firstChild;J(new Ha(b),function(c){a.insertBefore(c,d)})}},wrap:function(a,b){b=da(b).eq(0).clone()[0];
var d=a.parentNode;d&&d.replaceChild(b,a);b.appendChild(a)},remove:Fc,detach:function(a){Fc(a,!0)},after:function(a,b){var d=a;if(a=a.parentNode){b=new Ha(b);for(var c=0,e=b.length;c<e;c++){var f=b[c];a.insertBefore(f,d.nextSibling);d=f}}},addClass:Dc,removeClass:Cc,toggleClass:function(a,b,d){b&&J(b.split(" "),function(c){var e=d;U(e)&&(e=!Bc(a,c));(e?Dc:Cc)(a,c)})},parent:function(a){return(a=a.parentNode)&&11!==a.nodeType?a:null},next:function(a){return a.nextElementSibling},find:function(a,b){return a.getElementsByTagName?
a.getElementsByTagName(b):[]},clone:wd,triggerHandler:function(a,b,d){var c=b.type||b,e=yc(a);if(e=(e=e&&e.events)&&e[c]){var f={preventDefault:function(){this.defaultPrevented=!0},isDefaultPrevented:function(){return!0===this.defaultPrevented},stopImmediatePropagation:function(){this.immediatePropagationStopped=!0},isImmediatePropagationStopped:function(){return!0===this.immediatePropagationStopped},stopPropagation:la,type:c,target:a};b.type&&(f=Aa(f,b));b=kb(e);var g=d?[f].concat(d):[f];J(b,function(k){f.isImmediatePropagationStopped()||
k.apply(a,g)})}}},function(a,b){Ha.prototype[b]=function(d,c,e){for(var f,g=0,k=this.length;g<k;g++)U(f)?(f=a(this[g],d,c,e),R(f)&&(f=da(f))):vd(f,a(this[g],d,c,e));return R(f)?f:this}});Ha.prototype.bind=Ha.prototype.on;Ha.prototype.unbind=Ha.prototype.off;var Rh=Object.create(null);ve.prototype={_idx:function(a){if(a===this._lastKey)return this._lastIndex;this._lastKey=a;return this._lastIndex=this._keys.indexOf(a)},_transformKey:function(a){return Ua(a)?Rh:a},get:function(a){a=this._transformKey(a);
a=this._idx(a);if(-1!==a)return this._values[a]},set:function(a,b){a=this._transformKey(a);var d=this._idx(a);-1===d&&(d=this._lastIndex=this._keys.length);this._keys[d]=a;this._values[d]=b},delete:function(a){a=this._transformKey(a);a=this._idx(a);if(-1===a)return!1;this._keys.splice(a,1);this._values.splice(a,1);this._lastKey=NaN;this._lastIndex=-1;return!0}};var Hc=ve,Sh=[function(){this.$get=[function(){return Hc}]}],mg=/^([^(]+?)=>/,og=/^[^(]*\(\s*([^)]*)\)/m,Th=/,/,Uh=/^\s*(_?)(\S+?)\1\s*$/,
lg=/((\/\/.*$)|(\/\*[\s\S]*?\*\/))/mg,Eb=va("$injector");fc.$$annotate=function(a,b,d){var c;if("function"===typeof a){if(!(c=a.$inject)){c=[];if(a.length){if(b)throw oa(d)&&d||(d=a.name||pg(a)),Eb("strictdi",d);b=we(a);J(b[1].split(Th),function(e){e.replace(Uh,function(f,g,k){c.push(k)})})}a.$inject=c}}else na(a)?(b=a.length-1,vc(a[b],"fn"),c=a.slice(0,b)):vc(a,"fn",!0);return c};var Af=va("$animate"),Vh=function(){this.$get=la},Wh=function(){var a=new Hc,b=[];this.$get=["$$AnimateRunner","$rootScope",
function(d,c){function e(g,k,h){var l=!1;k&&(k=oa(k)?k.split(" "):na(k)?k:[],J(k,function(n){n&&(l=!0,g[n]=h)}));return l}function f(){J(b,function(g){var k=a.get(g);if(k){var h=rg(g.attr("class")),l="",n="";J(k,function(r,u){r!==!!h[u]&&(r?l+=(l.length?" ":"")+u:n+=(n.length?" ":"")+u)});J(g,function(r){l&&Dc(r,l);n&&Cc(r,n)});a.delete(g)}});b.length=0}return{enabled:la,on:la,off:la,pin:la,push:function(g,k,h,l){l&&l();h=h||{};h.from&&g.css(h.from);h.to&&g.css(h.to);if(h.addClass||h.removeClass)if(k=
h.addClass,l=h.removeClass,h=a.get(g)||{},k=e(h,k,!0),l=e(h,l,!1),k||l)a.set(g,h),b.push(g),1===b.length&&c.$$postDigest(f);g=new d;g.complete();return g}}}]},Xh=["$provide",function(a){var b=this,d=null,c=null;this.$$registeredAnimations=Object.create(null);this.register=function(e,f){if(e&&"."!==e.charAt(0))throw Af("notcsel",e);var g=e+"-animation";b.$$registeredAnimations[e.substr(1)]=g;a.factory(g,f)};this.customFilter=function(e){1===arguments.length&&(c=ca(e)?e:null);return c};this.classNameFilter=
function(e){if(1===arguments.length&&(d=e instanceof RegExp?e:null)&&RegExp("[(\\s|\\/)]ng-animate[(\\s|\\/)]").test(d.toString()))throw d=null,Af("nongcls","ng-animate");return d};this.$get=["$$animateQueue",function(e){function f(g,k,h){if(h){var l;a:{for(l=0;l<h.length;l++){var n=h[l];if(1===n.nodeType){l=n;break a}}l=void 0}!l||l.parentNode||l.previousElementSibling||(h=null)}h?h.after(g):k.prepend(g)}return{on:e.on,off:e.off,pin:e.pin,enabled:e.enabled,cancel:function(g){g.end&&g.end()},enter:function(g,
k,h,l){k=k&&da(k);h=h&&da(h);k=k||h.parent();f(g,k,h);return e.push(g,"enter",Fb(l))},move:function(g,k,h,l){k=k&&da(k);h=h&&da(h);k=k||h.parent();f(g,k,h);return e.push(g,"move",Fb(l))},leave:function(g,k){return e.push(g,"leave",Fb(k),function(){g.remove()})},addClass:function(g,k,h){h=Fb(h);h.addClass=ic(h.addclass,k);return e.push(g,"addClass",h)},removeClass:function(g,k,h){h=Fb(h);h.removeClass=ic(h.removeClass,k);return e.push(g,"removeClass",h)},setClass:function(g,k,h,l){l=Fb(l);l.addClass=
ic(l.addClass,k);l.removeClass=ic(l.removeClass,h);return e.push(g,"setClass",l)},animate:function(g,k,h,l,n){n=Fb(n);n.from=n.from?Aa(n.from,k):k;n.to=n.to?Aa(n.to,h):h;n.tempClasses=ic(n.tempClasses,l||"ng-inline-animate");return e.push(g,"animate",n)}}}]}],Yh=function(){this.$get=["$$rAF",function(a){function b(c){d.push(c);1<d.length||a(function(){for(var e=0;e<d.length;e++)d[e]();d=[]})}var d=[];return function(){var c=!1;b(function(){c=!0});return function(e){c?e():b(e)}}}]},Zh=function(){this.$get=
["$q","$sniffer","$$animateAsyncRun","$$isDocumentHidden","$timeout",function(a,b,d,c,e){function f(g){this.setHost(g);var k=d();this._doneCallbacks=[];this._tick=function(h){c()?e(h,0,!1):k(h)};this._state=0}f.chain=function(g,k){function h(){if(l===g.length)k(!0);else g[l](function(n){!1===n?k(!1):(l++,h())})}var l=0;h()};f.all=function(g,k){function h(r){n=n&&r;++l===g.length&&k(n)}var l=0,n=!0;J(g,function(r){r.done(h)})};f.prototype={setHost:function(g){this.host=g||{}},done:function(g){2===
this._state?g():this._doneCallbacks.push(g)},progress:la,getPromise:function(){if(!this.promise){var g=this;this.promise=a(function(k,h){g.done(function(l){!1===l?h():k()})})}return this.promise},then:function(g,k){return this.getPromise().then(g,k)},"catch":function(g){return this.getPromise()["catch"](g)},"finally":function(g){return this.getPromise()["finally"](g)},pause:function(){this.host.pause&&this.host.pause()},resume:function(){this.host.resume&&this.host.resume()},end:function(){this.host.end&&
this.host.end();this._resolve(!0)},cancel:function(){this.host.cancel&&this.host.cancel();this._resolve(!1)},complete:function(g){var k=this;0===k._state&&(k._state=1,k._tick(function(){k._resolve(g)}))},_resolve:function(g){2!==this._state&&(J(this._doneCallbacks,function(k){k(g)}),this._doneCallbacks.length=0,this._state=2)}};return f}]},$h=function(){this.$get=["$$rAF","$q","$$AnimateRunner",function(a,b,d){return function(c,e){function f(){a(function(){g.addClass&&(c.addClass(g.addClass),g.addClass=
null);g.removeClass&&(c.removeClass(g.removeClass),g.removeClass=null);g.to&&(c.css(g.to),g.to=null);k||h.complete();k=!0});return h}var g=e||{};g.$$prepared||(g=Bb(g));g.cleanupStyles&&(g.from=g.to=null);g.from&&(c.css(g.from),g.from=null);var k,h=new d;return{start:f,end:f}}}]},Ja=va("$compile"),Jd=new function(){};xe.$inject=["$provide","$$sanitizeUriProvider"];Rc.prototype.isFirstChange=function(){return this.previousValue===Jd};var Be=/^((?:x|data)[:\-_])/i,Lg=/[:\-_]+(.)/g,Qe=va("$controller"),
Pe=/^(\S+)(\s+as\s+([\w$]+))?$/,ai=function(){this.$get=["$document",function(a){return function(b){b?!b.nodeType&&b instanceof da&&(b=b[0]):b=a[0].body;return b.offsetWidth+1}}]},Re="application/json",Md={"Content-Type":Re+";charset=utf-8"},Ug=/^\[|^\{(?!\{)/,Vg={"[":/]$/,"{":/}$/},Tg=/^\)]\}',?\n/,Sc=va("$http"),Ib=Va.$interpolateMinErr=va("$interpolate");Ib.throwNoconcat=function(a){throw Ib("noconcat",a);};Ib.interr=function(a,b){return Ib("interr",a,b.toString())};var bi=function(){this.$get=
function(){function a(c){var e=function(f){e.data=f;e.called=!0};e.id=c;return e}var b=Va.callbacks,d={};return{createCallback:function(c){c="_"+(b.$$counter++).toString(36);var e="angular.callbacks."+c,f=a(c);d[e]=b[c]=f;return e},wasCalled:function(c){return d[c].called},getResponse:function(c){return d[c].data},removeCallback:function(c){delete b[d[c].id];delete d[c]}}}},ci=/^([^?#]*)(\?([^#]*))?(#(.*))?$/,ch={http:80,https:443,ftp:21},lc=va("$location"),dh=/^\s*[\\/]{2,}/,di={$$absUrl:"",$$html5:!1,
$$replace:!1,absUrl:Uc("$$absUrl"),url:function(a){if(U(a))return this.$$url;var b=ci.exec(a);(b[1]||""===a)&&this.path(decodeURIComponent(b[1]));(b[2]||b[1]||""===a)&&this.search(b[3]||"");this.hash(b[5]||"");return this},protocol:Uc("$$protocol"),host:Uc("$$host"),port:Uc("$$port"),path:Ye("$$path",function(a){a=null!==a?a.toString():"";return"/"===a.charAt(0)?a:"/"+a}),search:function(a,b){switch(arguments.length){case 0:return this.$$search;case 1:if(oa(a)||Ra(a))a=a.toString(),this.$$search=
pd(a);else if(fa(a))a=Bb(a,{}),J(a,function(d,c){null==d&&delete a[c]}),this.$$search=a;else throw lc("isrcharg");break;default:U(b)||null===b?delete this.$$search[a]:this.$$search[a]=b}this.$$compose();return this},hash:Ye("$$hash",function(a){return null!==a?a.toString():""}),replace:function(){this.$$replace=!0;return this}};J([Xe,Qd,Pd],function(a){a.prototype=Object.create(di);a.prototype.state=function(b){if(!arguments.length)return this.$$state;if(a!==Pd||!this.$$html5)throw lc("nostate");
this.$$state=U(b)?null:b;this.$$urlUpdatedByLocation=!0;return this}});var rc=va("$parse"),jh={}.constructor.prototype.valueOf,cd=Ea();J("+ - * / % === !== == != < > <= >= && || ! = |".split(" "),function(a){cd[a]=!0});var ei={n:"\n",f:"\f",r:"\r",t:"\t",v:"\v","'":"'",'"':'"'},Wc=function(a){this.options=a};Wc.prototype={constructor:Wc,lex:function(a){this.text=a;this.index=0;for(this.tokens=[];this.index<this.text.length;)if(a=this.text.charAt(this.index),'"'===a||"'"===a)this.readString(a);else if(this.isNumber(a)||
"."===a&&this.isNumber(this.peek()))this.readNumber();else if(this.isIdentifierStart(this.peekMultichar()))this.readIdent();else if(this.is(a,"(){}[].,;:?"))this.tokens.push({index:this.index,text:a}),this.index++;else if(this.isWhitespace(a))this.index++;else{var b=a+this.peek(),d=b+this.peek(2),c=cd[b],e=cd[d];cd[a]||c||e?(a=e?d:c?b:a,this.tokens.push({index:this.index,text:a,operator:!0}),this.index+=a.length):this.throwError("Unexpected next character ",this.index,this.index+1)}return this.tokens},
is:function(a,b){return-1!==b.indexOf(a)},peek:function(a){a=a||1;return this.index+a<this.text.length?this.text.charAt(this.index+a):!1},isNumber:function(a){return"0"<=a&&"9">=a&&"string"===typeof a},isWhitespace:function(a){return" "===a||"\r"===a||"\t"===a||"\n"===a||"\v"===a||"\u00a0"===a},isIdentifierStart:function(a){return this.options.isIdentifierStart?this.options.isIdentifierStart(a,this.codePointAt(a)):this.isValidIdentifierStart(a)},isValidIdentifierStart:function(a){return"a"<=a&&"z">=
a||"A"<=a&&"Z">=a||"_"===a||"$"===a},isIdentifierContinue:function(a){return this.options.isIdentifierContinue?this.options.isIdentifierContinue(a,this.codePointAt(a)):this.isValidIdentifierContinue(a)},isValidIdentifierContinue:function(a,b){return this.isValidIdentifierStart(a,b)||this.isNumber(a)},codePointAt:function(a){return 1===a.length?a.charCodeAt(0):(a.charCodeAt(0)<<10)+a.charCodeAt(1)-56613888},peekMultichar:function(){var a=this.text.charAt(this.index),b=this.peek();if(!b)return a;var d=
a.charCodeAt(0),c=b.charCodeAt(0);return 55296<=d&&56319>=d&&56320<=c&&57343>=c?a+b:a},isExpOperator:function(a){return"-"===a||"+"===a||this.isNumber(a)},throwError:function(a,b,d){d=d||this.index;b=R(b)?"s "+b+"-"+this.index+" ["+this.text.substring(b,d)+"]":" "+d;throw rc("lexerr",a,b,this.text);},readNumber:function(){for(var a="",b=this.index;this.index<this.text.length;){var d=xa(this.text.charAt(this.index));if("."===d||this.isNumber(d))a+=d;else{var c=this.peek();if("e"===d&&this.isExpOperator(c))a+=
d;else if(this.isExpOperator(d)&&c&&this.isNumber(c)&&"e"===a.charAt(a.length-1))a+=d;else if(!this.isExpOperator(d)||c&&this.isNumber(c)||"e"!==a.charAt(a.length-1))break;else this.throwError("Invalid exponent")}this.index++}this.tokens.push({index:b,text:a,constant:!0,value:Number(a)})},readIdent:function(){var a=this.index;for(this.index+=this.peekMultichar().length;this.index<this.text.length;){var b=this.peekMultichar();if(!this.isIdentifierContinue(b))break;this.index+=b.length}this.tokens.push({index:a,
text:this.text.slice(a,this.index),identifier:!0})},readString:function(a){var b=this.index;this.index++;for(var d="",c=a,e=!1;this.index<this.text.length;){var f=this.text.charAt(this.index);c+=f;if(e)"u"===f?(e=this.text.substring(this.index+1,this.index+5),e.match(/[\da-f]{4}/i)||this.throwError("Invalid unicode escape [\\u"+e+"]"),this.index+=4,d+=String.fromCharCode(parseInt(e,16))):d+=ei[f]||f,e=!1;else if("\\"===f)e=!0;else{if(f===a){this.index++;this.tokens.push({index:b,text:c,constant:!0,
value:d});return}d+=f}this.index++}this.throwError("Unterminated quote",b)}};var Q=function(a,b){this.lexer=a;this.options=b};Q.Program="Program";Q.ExpressionStatement="ExpressionStatement";Q.AssignmentExpression="AssignmentExpression";Q.ConditionalExpression="ConditionalExpression";Q.LogicalExpression="LogicalExpression";Q.BinaryExpression="BinaryExpression";Q.UnaryExpression="UnaryExpression";Q.CallExpression="CallExpression";Q.MemberExpression="MemberExpression";Q.Identifier="Identifier";Q.Literal=
"Literal";Q.ArrayExpression="ArrayExpression";Q.Property="Property";Q.ObjectExpression="ObjectExpression";Q.ThisExpression="ThisExpression";Q.LocalsExpression="LocalsExpression";Q.NGValueParameter="NGValueParameter";Q.prototype={ast:function(a){this.text=a;this.tokens=this.lexer.lex(a);a=this.program();0!==this.tokens.length&&this.throwError("is an unexpected token",this.tokens[0]);return a},program:function(){for(var a=[];;)if(0<this.tokens.length&&!this.peek("}",")",";","]")&&a.push(this.expressionStatement()),
!this.expect(";"))return{type:Q.Program,body:a}},expressionStatement:function(){return{type:Q.ExpressionStatement,expression:this.filterChain()}},filterChain:function(){for(var a=this.expression();this.expect("|");)a=this.filter(a);return a},expression:function(){return this.assignment()},assignment:function(){var a=this.ternary();if(this.expect("=")){if(!$e(a))throw rc("lval");a={type:Q.AssignmentExpression,left:a,right:this.assignment(),operator:"="}}return a},ternary:function(){var a=this.logicalOR();
if(this.expect("?")){var b=this.expression();if(this.consume(":")){var d=this.expression();return{type:Q.ConditionalExpression,test:a,alternate:b,consequent:d}}}return a},logicalOR:function(){for(var a=this.logicalAND();this.expect("||");)a={type:Q.LogicalExpression,operator:"||",left:a,right:this.logicalAND()};return a},logicalAND:function(){for(var a=this.equality();this.expect("&&");)a={type:Q.LogicalExpression,operator:"&&",left:a,right:this.equality()};return a},equality:function(){for(var a=
this.relational(),b;b=this.expect("==","!=","===","!==");)a={type:Q.BinaryExpression,operator:b.text,left:a,right:this.relational()};return a},relational:function(){for(var a=this.additive(),b;b=this.expect("<",">","<=",">=");)a={type:Q.BinaryExpression,operator:b.text,left:a,right:this.additive()};return a},additive:function(){for(var a=this.multiplicative(),b;b=this.expect("+","-");)a={type:Q.BinaryExpression,operator:b.text,left:a,right:this.multiplicative()};return a},multiplicative:function(){for(var a=
this.unary(),b;b=this.expect("*","/","%");)a={type:Q.BinaryExpression,operator:b.text,left:a,right:this.unary()};return a},unary:function(){var a;return(a=this.expect("+","-","!"))?{type:Q.UnaryExpression,operator:a.text,prefix:!0,argument:this.unary()}:this.primary()},primary:function(){if(this.expect("(")){var a=this.filterChain();this.consume(")")}else this.expect("[")?a=this.arrayDeclaration():this.expect("{")?a=this.object():this.selfReferential.hasOwnProperty(this.peek().text)?a=Bb(this.selfReferential[this.consume().text]):
this.options.literals.hasOwnProperty(this.peek().text)?a={type:Q.Literal,value:this.options.literals[this.consume().text]}:this.peek().identifier?a=this.identifier():this.peek().constant?a=this.constant():this.throwError("not a primary expression",this.peek());for(var b;b=this.expect("(","[",".");)"("===b.text?(a={type:Q.CallExpression,callee:a,arguments:this.parseArguments()},this.consume(")")):"["===b.text?(a={type:Q.MemberExpression,object:a,property:this.expression(),computed:!0},this.consume("]")):
"."===b.text?a={type:Q.MemberExpression,object:a,property:this.identifier(),computed:!1}:this.throwError("IMPOSSIBLE");return a},filter:function(a){a=[a];for(var b={type:Q.CallExpression,callee:this.identifier(),arguments:a,filter:!0};this.expect(":");)a.push(this.expression());return b},parseArguments:function(){var a=[];if(")"!==this.peekToken().text){do a.push(this.filterChain());while(this.expect(","))}return a},identifier:function(){var a=this.consume();a.identifier||this.throwError("is not a valid identifier",
a);return{type:Q.Identifier,name:a.text}},constant:function(){return{type:Q.Literal,value:this.consume().value}},arrayDeclaration:function(){var a=[];if("]"!==this.peekToken().text){do{if(this.peek("]"))break;a.push(this.expression())}while(this.expect(","))}this.consume("]");return{type:Q.ArrayExpression,elements:a}},object:function(){var a=[];if("}"!==this.peekToken().text){do{if(this.peek("}"))break;var b={type:Q.Property,kind:"init"};this.peek().constant?(b.key=this.constant(),b.computed=!1,this.consume(":"),
b.value=this.expression()):this.peek().identifier?(b.key=this.identifier(),b.computed=!1,this.peek(":")?(this.consume(":"),b.value=this.expression()):b.value=b.key):this.peek("[")?(this.consume("["),b.key=this.expression(),this.consume("]"),b.computed=!0,this.consume(":"),b.value=this.expression()):this.throwError("invalid key",this.peek());a.push(b)}while(this.expect(","))}this.consume("}");return{type:Q.ObjectExpression,properties:a}},throwError:function(a,b){throw rc("syntax",b.text,a,b.index+
1,this.text,this.text.substring(b.index));},consume:function(a){if(0===this.tokens.length)throw rc("ueoe",this.text);var b=this.expect(a);b||this.throwError("is unexpected, expecting ["+a+"]",this.peek());return b},peekToken:function(){if(0===this.tokens.length)throw rc("ueoe",this.text);return this.tokens[0]},peek:function(a,b,d,c){return this.peekAhead(0,a,b,d,c)},peekAhead:function(a,b,d,c,e){if(this.tokens.length>a){a=this.tokens[a];var f=a.text;if(f===b||f===d||f===c||f===e||!(b||d||c||e))return a}return!1},
expect:function(a,b,d,c){return(a=this.peek(a,b,d,c))?(this.tokens.shift(),a):!1},selfReferential:{"this":{type:Q.ThisExpression},$locals:{type:Q.LocalsExpression}}};var Ze=2;af.prototype={compile:function(a){var b=this;Ma(a,b.$filter);var d;if(d=ih(a))var c=this.recurse(d);d=hh(a.body);if(d){var e=[];J(d,function(g,k){var h=b.recurse(g);h.isPure=g.isPure;g.input=h;e.push(h);g.watchId=k})}var f=[];J(a.body,function(g){f.push(b.recurse(g.expression))});a=0===a.body.length?la:1===a.body.length?f[0]:
function(g,k){var h;J(f,function(l){h=l(g,k)});return h};c&&(a.assign=function(g,k,h){return c(g,h,k)});e&&(a.inputs=e);return a},recurse:function(a,b,d){var c=this;if(a.input)return this.inputs(a.input,a.watchId);switch(a.type){case Q.Literal:return this.value(a.value,b);case Q.UnaryExpression:var e=this.recurse(a.argument);return this["unary"+a.operator](e,b);case Q.BinaryExpression:var f=this.recurse(a.left);e=this.recurse(a.right);return this["binary"+a.operator](f,e,b);case Q.LogicalExpression:return f=
this.recurse(a.left),e=this.recurse(a.right),this["binary"+a.operator](f,e,b);case Q.ConditionalExpression:return this["ternary?:"](this.recurse(a.test),this.recurse(a.alternate),this.recurse(a.consequent),b);case Q.Identifier:return c.identifier(a.name,b,d);case Q.MemberExpression:return f=this.recurse(a.object,!1,!!d),a.computed||(e=a.property.name),a.computed&&(e=this.recurse(a.property)),a.computed?this.computedMember(f,e,b,d):this.nonComputedMember(f,e,b,d);case Q.CallExpression:var g=[];J(a.arguments,
function(k){g.push(c.recurse(k))});a.filter&&(e=this.$filter(a.callee.name));a.filter||(e=this.recurse(a.callee,!0));return a.filter?function(k,h,l,n){for(var r=[],u=0;u<g.length;++u)r.push(g[u](k,h,l,n));k=e.apply(void 0,r,n);return b?{context:void 0,name:void 0,value:k}:k}:function(k,h,l,n){var r=e(k,h,l,n);if(null!=r.value){var u=[];for(var w=0;w<g.length;++w)u.push(g[w](k,h,l,n));u=r.value.apply(r.context,u)}return b?{value:u}:u};case Q.AssignmentExpression:return f=this.recurse(a.left,!0,1),
e=this.recurse(a.right),function(k,h,l,n){var r=f(k,h,l,n);k=e(k,h,l,n);r.context[r.name]=k;return b?{value:k}:k};case Q.ArrayExpression:return g=[],J(a.elements,function(k){g.push(c.recurse(k))}),function(k,h,l,n){for(var r=[],u=0;u<g.length;++u)r.push(g[u](k,h,l,n));return b?{value:r}:r};case Q.ObjectExpression:return g=[],J(a.properties,function(k){k.computed?g.push({key:c.recurse(k.key),computed:!0,value:c.recurse(k.value)}):g.push({key:k.key.type===Q.Identifier?k.key.name:""+k.key.value,computed:!1,
value:c.recurse(k.value)})}),function(k,h,l,n){for(var r={},u=0;u<g.length;++u)g[u].computed?r[g[u].key(k,h,l,n)]=g[u].value(k,h,l,n):r[g[u].key]=g[u].value(k,h,l,n);return b?{value:r}:r};case Q.ThisExpression:return function(k){return b?{value:k}:k};case Q.LocalsExpression:return function(k,h){return b?{value:h}:h};case Q.NGValueParameter:return function(k,h,l){return b?{value:l}:l}}},"unary+":function(a,b){return function(d,c,e,f){d=a(d,c,e,f);d=R(d)?+d:0;return b?{value:d}:d}},"unary-":function(a,
b){return function(d,c,e,f){d=a(d,c,e,f);d=R(d)?-d:-0;return b?{value:d}:d}},"unary!":function(a,b){return function(d,c,e,f){d=!a(d,c,e,f);return b?{value:d}:d}},"binary+":function(a,b,d){return function(c,e,f,g){var k=a(c,e,f,g);c=b(c,e,f,g);k="undefined"===typeof k?c:"undefined"===typeof c?k:k+c;return d?{value:k}:k}},"binary-":function(a,b,d){return function(c,e,f,g){var k=a(c,e,f,g);c=b(c,e,f,g);k=(R(k)?k:0)-(R(c)?c:0);return d?{value:k}:k}},"binary*":function(a,b,d){return function(c,e,f,g){c=
a(c,e,f,g)*b(c,e,f,g);return d?{value:c}:c}},"binary/":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)/b(c,e,f,g);return d?{value:c}:c}},"binary%":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)%b(c,e,f,g);return d?{value:c}:c}},"binary===":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)===b(c,e,f,g);return d?{value:c}:c}},"binary!==":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)!==b(c,e,f,g);return d?{value:c}:c}},"binary==":function(a,b,d){return function(c,e,f,g){c=a(c,
e,f,g)==b(c,e,f,g);return d?{value:c}:c}},"binary!=":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)!=b(c,e,f,g);return d?{value:c}:c}},"binary<":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)<b(c,e,f,g);return d?{value:c}:c}},"binary>":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)>b(c,e,f,g);return d?{value:c}:c}},"binary<=":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)<=b(c,e,f,g);return d?{value:c}:c}},"binary>=":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)>=
b(c,e,f,g);return d?{value:c}:c}},"binary&&":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)&&b(c,e,f,g);return d?{value:c}:c}},"binary||":function(a,b,d){return function(c,e,f,g){c=a(c,e,f,g)||b(c,e,f,g);return d?{value:c}:c}},"ternary?:":function(a,b,d,c){return function(e,f,g,k){e=a(e,f,g,k)?b(e,f,g,k):d(e,f,g,k);return c?{value:e}:e}},value:function(a,b){return function(){return b?{context:void 0,name:void 0,value:a}:a}},identifier:function(a,b,d){return function(c,e,f,g){c=e&&a in e?e:
c;d&&1!==d&&c&&null==c[a]&&(c[a]={});e=c?c[a]:void 0;return b?{context:c,name:a,value:e}:e}},computedMember:function(a,b,d,c){return function(e,f,g,k){var h=a(e,f,g,k);if(null!=h){var l=b(e,f,g,k);l+="";c&&1!==c&&h&&!h[l]&&(h[l]={});var n=h[l]}return d?{context:h,name:l,value:n}:n}},nonComputedMember:function(a,b,d,c){return function(e,f,g,k){e=a(e,f,g,k);c&&1!==c&&e&&null==e[b]&&(e[b]={});f=null!=e?e[b]:void 0;return d?{context:e,name:b,value:f}:f}},inputs:function(a,b){return function(d,c,e,f){return f?
f[b]:a(d,c,e)}}};Vc.prototype={constructor:Vc,parse:function(a){a=this.getAst(a);var b=this.astCompiler.compile(a.ast),d=a.ast;b.literal=0===d.body.length||1===d.body.length&&(d.body[0].expression.type===Q.Literal||d.body[0].expression.type===Q.ArrayExpression||d.body[0].expression.type===Q.ObjectExpression);b.constant=a.ast.constant;b.oneTime=a.oneTime;return b},getAst:function(a){var b=!1;a=a.trim();":"===a.charAt(0)&&":"===a.charAt(1)&&(b=!0,a=a.substring(2));return{ast:this.ast.ast(a),oneTime:b}}};
var Pa=ia.document.createElement("a"),cf=pb(ia.location.href);ef.$inject=["$document"];ff.$inject=["$provide"];var nf=22,mf=".",Td="0";gf.$inject=["$locale"];jf.$inject=["$locale"];var Fh={yyyy:Qa("FullYear",4,0,!1,!0),yy:Qa("FullYear",2,0,!0,!0),y:Qa("FullYear",1,0,!1,!0),MMMM:nc("Month"),MMM:nc("Month",!0),MM:Qa("Month",2,1),M:Qa("Month",1,1),LLLL:nc("Month",!1,!0),dd:Qa("Date",2),d:Qa("Date",1),HH:Qa("Hours",2),H:Qa("Hours",1),hh:Qa("Hours",2,-12),h:Qa("Hours",1,-12),mm:Qa("Minutes",2),m:Qa("Minutes",
1),ss:Qa("Seconds",2),s:Qa("Seconds",1),sss:Qa("Milliseconds",3),EEEE:nc("Day"),EEE:nc("Day",!0),a:function(a,b){return 12>a.getHours()?b.AMPMS[0]:b.AMPMS[1]},Z:function(a,b,d){a=-1*d;return(0<=a?"+":"")+(Xc(Math[0<a?"floor":"ceil"](a/60),2)+Xc(Math.abs(a%60),2))},ww:pf(2),w:pf(1),G:Ud,GG:Ud,GGG:Ud,GGGG:function(a,b){return 0>=a.getFullYear()?b.ERANAMES[0]:b.ERANAMES[1]}},Eh=/((?:[^yMLdHhmsaZEwG']+)|(?:'(?:[^']|'')*')|(?:E+|y+|M+|L+|d+|H+|h+|m+|s+|a|Z|G+|w+))([\s\S]*)/,Dh=/^-?\d+$/;hf.$inject=["$locale"];
var yh=cb(xa),zh=cb(Tc);kf.$inject=["$parse"];var fi=cb({restrict:"E",compile:function(a,b){if(!b.href&&!b.xlinkHref)return function(d,c){if("a"===c[0].nodeName.toLowerCase()){var e="[object SVGAnimatedString]"===Ta.call(c.prop("href"))?"xlink:href":"href";c.on("click",function(f){c.attr(e)||f.preventDefault()})}}}}),dd={};J(Gc,function(a,b){function d(f,g,k){f.$watch(k[c],function(h){k.$set(b,!!h)})}if("multiple"!==a){var c=lb("ng-"+b),e=d;"checked"===a&&(e=function(f,g,k){k.ngModel!==k[c]&&d(f,
g,k)});dd[c]=function(){return{restrict:"A",priority:100,link:e}}}});J(Me,function(a,b){dd[b]=function(){return{priority:100,link:function(d,c,e){if("ngPattern"===b&&"/"===e.ngPattern.charAt(0)&&(c=e.ngPattern.match(Nh))){e.$set("ngPattern",new RegExp(c[1],c[2]));return}d.$watch(e[b],function(f){e.$set(b,f)})}}}});J(["src","srcset","href"],function(a){var b=lb("ng-"+a);dd[b]=function(){return{priority:99,link:function(d,c,e){var f=a,g=a;"href"===a&&"[object SVGAnimatedString]"===Ta.call(c.prop("href"))&&
(g="xlinkHref",e.$attr[g]="xlink:href",f=null);e.$observe(b,function(k){k?(e.$set(g,k),qb&&f&&c.prop(f,e[g])):"href"===a&&e.$set(g,null)})}}}});var Zc={$addControl:la,$$renameControl:function(a,b){a.$name=b},$removeControl:la,$setValidity:la,$setDirty:la,$setPristine:la,$setSubmitted:la};Yc.$inject=["$element","$attrs","$scope","$animate","$interpolate"];Yc.prototype={$rollbackViewValue:function(){J(this.$$controls,function(a){a.$rollbackViewValue()})},$commitViewValue:function(){J(this.$$controls,
function(a){a.$commitViewValue()})},$addControl:function(a){Ob(a.$name,"input");this.$$controls.push(a);a.$name&&(this[a.$name]=a);a.$$parentForm=this},$$renameControl:function(a,b){var d=a.$name;this[d]===a&&delete this[d];this[b]=a;a.$name=b},$removeControl:function(a){a.$name&&this[a.$name]===a&&delete this[a.$name];J(this.$pending,function(b,d){this.$setValidity(d,null,a)},this);J(this.$error,function(b,d){this.$setValidity(d,null,a)},this);J(this.$$success,function(b,d){this.$setValidity(d,null,
a)},this);bc(this.$$controls,a);a.$$parentForm=Zc},$setDirty:function(){this.$$animate.removeClass(this.$$element,Zb);this.$$animate.addClass(this.$$element,ed);this.$dirty=!0;this.$pristine=!1;this.$$parentForm.$setDirty()},$setPristine:function(){this.$$animate.setClass(this.$$element,Zb,ed+" ng-submitted");this.$dirty=!1;this.$pristine=!0;this.$submitted=!1;J(this.$$controls,function(a){a.$setPristine()})},$setUntouched:function(){J(this.$$controls,function(a){a.$setUntouched()})},$setSubmitted:function(){this.$$animate.addClass(this.$$element,
"ng-submitted");this.$submitted=!0;this.$$parentForm.$setSubmitted()}};sf({clazz:Yc,set:function(a,b,d){var c=a[b];c?-1===c.indexOf(d)&&c.push(d):a[b]=[d]},unset:function(a,b,d){var c=a[b];c&&(bc(c,d),0===c.length&&delete a[b])}});var Bf=function(a){return["$timeout","$parse",function(b,d){function c(e){return""===e?d('this[""]').assign:d(e).assign||la}return{name:"form",restrict:a?"EAC":"E",require:["form","^^?form"],controller:Yc,compile:function(e,f){e.addClass(Zb).addClass(oc);var g=f.name?"name":
a&&f.ngForm?"ngForm":!1;return{pre:function(k,h,l,n){var r=n[0];if(!("action"in l)){var u=function(H){k.$apply(function(){r.$commitViewValue();r.$setSubmitted()});H.preventDefault()};h[0].addEventListener("submit",u);h.on("$destroy",function(){b(function(){h[0].removeEventListener("submit",u)},0,!1)})}(n[1]||r.$$parentForm).$addControl(r);var w=g?c(r.$name):la;g&&(w(k,r),l.$observe(g,function(H){r.$name!==H&&(w(k,void 0),r.$$parentForm.$$renameControl(r,H),w=c(r.$name),w(k,r))}));h.on("$destroy",
function(){r.$$parentForm.$removeControl(r);w(k,void 0);Aa(r,Zc)})}}}}}]},gi=Bf(),hi=Bf(!0),Gh=/^\d{4,}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+(?:[+-][0-2]\d:[0-5]\d|Z)$/,ii=/^[a-z][a-z\d.+-]*:\/*(?:[^:@]+(?::[^@]+)?@)?(?:[^\s:/?#]+|\[[a-f\d:]+])(?::\d+)?(?:\/[^?#]*)?(?:\?[^#]*)?(?:#.*)?$/i,ji=/^(?=.{1,254}$)(?=.{1,64}@)[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+(\.[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+)*@[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/,Hh=/^\s*(-|\+)?(\d+|(\d*(\.\d*)))([eE][+-]?\d+)?\s*$/,
Cf=/^(\d{4,})-(\d{2})-(\d{2})$/,Df=/^(\d{4,})-(\d\d)-(\d\d)T(\d\d):(\d\d)(?::(\d\d)(\.\d{1,3})?)?$/,ce=/^(\d{4,})-W(\d\d)$/,Ef=/^(\d{4,})-(\d\d)$/,Ff=/^(\d\d):(\d\d)(?::(\d\d)(\.\d{1,3})?)?$/,uf=Ea();J(["date","datetime-local","month","time","week"],function(a){uf[a]=!0});var Gf={text:function(a,b,d,c,e,f){Wb(a,b,d,c,e,f);Wd(c)},date:pc("date",Cf,$c(Cf,["yyyy","MM","dd"]),"yyyy-MM-dd"),"datetime-local":pc("datetimelocal",Df,$c(Df,"yyyy MM dd HH mm ss sss".split(" ")),"yyyy-MM-ddTHH:mm:ss.sss"),time:pc("time",
Ff,$c(Ff,["HH","mm","ss","sss"]),"HH:mm:ss.sss"),week:pc("week",ce,function(a,b){if(Xa(a))return a;if(oa(a)){ce.lastIndex=0;var d=ce.exec(a);if(d){a=+d[1];var c=+d[2],e=d=0,f=0,g=0,k=of(a);c=7*(c-1);b&&(d=b.getHours(),e=b.getMinutes(),f=b.getSeconds(),g=b.getMilliseconds());return new Date(a,0,k.getDate()+c,d,e,f,g)}}return NaN},"yyyy-Www"),month:pc("month",Ef,$c(Ef,["yyyy","MM"]),"yyyy-MM"),number:function(a,b,d,c,e,f){Xd(a,b,d,c);vf(c);Wb(a,b,d,c,e,f);var g,k;if(R(d.min)||d.ngMin)c.$validators.min=
function(l){return c.$isEmpty(l)||U(g)||l>=g},d.$observe("min",function(l){g=Xb(l);c.$validate()});if(R(d.max)||d.ngMax)c.$validators.max=function(l){return c.$isEmpty(l)||U(k)||l<=k},d.$observe("max",function(l){k=Xb(l);c.$validate()});if(R(d.step)||d.ngStep){var h;c.$validators.step=function(l,n){return c.$isEmpty(n)||U(h)||wf(n,g||0,h)};d.$observe("step",function(l){h=Xb(l);c.$validate()})}},url:function(a,b,d,c,e,f){Wb(a,b,d,c,e,f);Wd(c);c.$$parserName="url";c.$validators.url=function(g,k){g=
g||k;return c.$isEmpty(g)||ii.test(g)}},email:function(a,b,d,c,e,f){Wb(a,b,d,c,e,f);Wd(c);c.$$parserName="email";c.$validators.email=function(g,k){g=g||k;return c.$isEmpty(g)||ji.test(g)}},radio:function(a,b,d,c){var e=!d.ngTrim||"false"!==Ca(d.ngTrim);U(d.name)&&b.attr("name",++sc);b.on("click",function(f){if(b[0].checked){var g=d.value;e&&(g=Ca(g));c.$setViewValue(g,f&&f.type)}});c.$render=function(){var f=d.value;e&&(f=Ca(f));b[0].checked=f===c.$viewValue};d.$observe("value",c.$render)},range:function(a,
b,d,c,e,f){function g(C,D){b.attr(C,d[C]);d.$observe(C,D)}function k(C){r=Xb(C);Ua(c.$modelValue)||(n?(C=b.val(),r>C&&(C=r,b.val(C)),c.$setViewValue(C)):c.$validate())}function h(C){u=Xb(C);Ua(c.$modelValue)||(n?(C=b.val(),u<C&&(b.val(u),C=u<r?r:u),c.$setViewValue(C)):c.$validate())}function l(C){w=Xb(C);Ua(c.$modelValue)||(n&&c.$viewValue!==b.val()?c.$setViewValue(b.val()):c.$validate())}Xd(a,b,d,c);vf(c);Wb(a,b,d,c,e,f);var n=c.$$hasNativeValidators&&"range"===b[0].type,r=n?0:void 0,u=n?100:void 0,
w=n?1:void 0,H=b[0].validity;a=R(d.min);e=R(d.max);f=R(d.step);var F=c.$render;c.$render=n&&R(H.rangeUnderflow)&&R(H.rangeOverflow)?function(){F();c.$setViewValue(b.val())}:F;a&&(c.$validators.min=n?function(){return!0}:function(C,D){return c.$isEmpty(D)||U(r)||D>=r},g("min",k));e&&(c.$validators.max=n?function(){return!0}:function(C,D){return c.$isEmpty(D)||U(u)||D<=u},g("max",h));f&&(c.$validators.step=n?function(){return!H.stepMismatch}:function(C,D){return c.$isEmpty(D)||U(w)||wf(D,r||0,w)},g("step",
l))},checkbox:function(a,b,d,c,e,f,g,k){var h=xf(k,a,"ngTrueValue",d.ngTrueValue,!0),l=xf(k,a,"ngFalseValue",d.ngFalseValue,!1);b.on("click",function(n){c.$setViewValue(b[0].checked,n&&n.type)});c.$render=function(){b[0].checked=c.$viewValue};c.$isEmpty=function(n){return!1===n};c.$formatters.push(function(n){return db(n,h)});c.$parsers.push(function(n){return n?h:l})},hidden:la,button:la,submit:la,reset:la,file:la},Hf=["$browser","$sniffer","$filter","$parse",function(a,b,d,c){return{restrict:"E",
require:["?ngModel"],link:{pre:function(e,f,g,k){k[0]&&(Gf[xa(g.type)]||Gf.text)(e,f,g,k[0],b,a,d,c)}}}}],ki=function(){var a={configurable:!0,enumerable:!1,get:function(){return this.getAttribute("value")||""},set:function(b){this.setAttribute("value",b)}};return{restrict:"E",priority:200,compile:function(b,d){if("hidden"===xa(d.type))return{pre:function(c,e,f,g){c=e[0];c.parentNode&&c.parentNode.insertBefore(c,c.nextSibling);Object.defineProperty&&Object.defineProperty(c,"value",a)}}}}},li=/^(true|false|\d+)$/,
mi=function(){function a(b,d,c){var e=R(c)?c:9===qb?"":null;b.prop("value",e);d.$set("value",c)}return{restrict:"A",priority:100,compile:function(b,d){return li.test(d.ngValue)?function(c,e,f){c=c.$eval(f.ngValue);a(e,f,c)}:function(c,e,f){c.$watch(f.ngValue,function(g){a(e,f,g)})}}}},ni=["$compile",function(a){return{restrict:"AC",compile:function(b){a.$$addBindingClass(b);return function(d,c,e){a.$$addBindingInfo(c,e.ngBind);c=c[0];d.$watch(e.ngBind,function(f){c.textContent=rd(f)})}}}}],oi=["$interpolate",
"$compile",function(a,b){return{compile:function(d){b.$$addBindingClass(d);return function(c,e,f){c=a(e.attr(f.$attr.ngBindTemplate));b.$$addBindingInfo(e,c.expressions);e=e[0];f.$observe("ngBindTemplate",function(g){e.textContent=U(g)?"":g})}}}}],pi=["$sce","$parse","$compile",function(a,b,d){return{restrict:"A",compile:function(c,e){var f=b(e.ngBindHtml),g=b(e.ngBindHtml,function(k){return a.valueOf(k)});d.$$addBindingClass(c);return function(k,h,l){d.$$addBindingInfo(h,l.ngBindHtml);k.$watch(g,
function(){var n=f(k);h.html(a.getTrustedHtml(n)||"")})}}}}],qi=cb({restrict:"A",require:"ngModel",link:function(a,b,d,c){c.$viewChangeListeners.push(function(){a.$eval(d.ngChange)})}}),ri=Zd("",!0),si=Zd("Odd",0),ti=Zd("Even",1),ui=Vb({compile:function(a,b){b.$set("ngCloak",void 0);a.removeClass("ng-cloak")}}),vi=[function(){return{restrict:"A",scope:!0,controller:"@",priority:500}}],If={},wi={blur:!0,focus:!0};J("click dblclick mousedown mouseup mouseover mouseout mousemove mouseenter mouseleave keydown keyup keypress submit focus blur copy cut paste".split(" "),
function(a){var b=lb("ng-"+a);If[b]=["$parse","$rootScope",function(d,c){return{restrict:"A",compile:function(e,f){var g=d(f[b]);return function(k,h){h.on(a,function(l){var n=function(){g(k,{$event:l})};wi[a]&&c.$$phase?k.$evalAsync(n):k.$apply(n)})}}}}]});var xi=["$animate","$compile",function(a,b){return{multiElement:!0,transclude:"element",priority:600,terminal:!0,restrict:"A",$$tlb:!0,link:function(d,c,e,f,g){var k,h,l;d.$watch(e.ngIf,function(n){n?h||g(function(r,u){h=u;r[r.length++]=b.$$createComment("end ngIf",
e.ngIf);k={clone:r};a.enter(r,c.parent(),c)}):(l&&(l.remove(),l=null),h&&(h.$destroy(),h=null),k&&(l=wc(k.clone),a.leave(l).done(function(r){!1!==r&&(l=null)}),k=null))})}}}],yi=["$templateRequest","$anchorScroll","$animate",function(a,b,d){return{restrict:"ECA",priority:400,terminal:!0,transclude:"element",controller:Va.noop,compile:function(c,e){var f=e.ngInclude||e.src,g=e.onload||"",k=e.autoscroll;return function(h,l,n,r,u){var w=0,H,F,C,D=function(){F&&(F.remove(),F=null);H&&(H.$destroy(),H=
null);C&&(d.leave(C).done(function(y){!1!==y&&(F=null)}),F=C,C=null)};h.$watch(f,function(y){var v=function(q){!1===q||!R(k)||k&&!h.$eval(k)||b()},p=++w;y?(a(y,!0).then(function(q){if(!h.$$destroyed&&p===w){var m=h.$new();r.template=q;q=u(m,function(x){D();d.enter(x,null,l).done(v)});H=m;C=q;H.$emit("$includeContentLoaded",y);h.$eval(g)}},function(){h.$$destroyed||p!==w||(D(),h.$emit("$includeContentError",y))}),h.$emit("$includeContentRequested",y)):(D(),r.template=null)})}}}}],zi=["$compile",function(a){return{restrict:"ECA",
priority:-400,require:"ngInclude",link:function(b,d,c,e){Ta.call(d[0]).match(/SVG/)?(d.empty(),a(oe(e.template,ia.document).childNodes)(b,function(f){d.append(f)},{futureParentElement:d})):(d.html(e.template),a(d.contents())(b))}}}],Ai=Vb({priority:450,compile:function(){return{pre:function(a,b,d){a.$eval(d.ngInit)}}}}),Bi=function(){return{restrict:"A",priority:100,require:"ngModel",link:function(a,b,d,c){var e=d.ngList||", ",f="false"!==d.ngTrim,g=f?Ca(e):e;c.$parsers.push(function(k){if(!U(k)){var h=
[];k&&J(k.split(g),function(l){l&&h.push(f?Ca(l):l)});return h}});c.$formatters.push(function(k){if(na(k))return k.join(e)});c.$isEmpty=function(k){return!k||!k.length}}}},oc="ng-valid",rf="ng-invalid",Zb="ng-pristine",ed="ng-dirty",qc=va("ngModel");ad.$inject="$scope $exceptionHandler $attrs $element $parse $animate $timeout $q $interpolate".split(" ");ad.prototype={$$initGetterSetters:function(){if(this.$options.getOption("getterSetter")){var a=this.$$parse(this.$$attr.ngModel+"()"),b=this.$$parse(this.$$attr.ngModel+
"($$$p)");this.$$ngModelGet=function(d){var c=this.$$parsedNgModel(d);ca(c)&&(c=a(d));return c};this.$$ngModelSet=function(d,c){ca(this.$$parsedNgModel(d))?b(d,{$$$p:c}):this.$$parsedNgModelAssign(d,c)}}else if(!this.$$parsedNgModel.assign)throw qc("nonassign",this.$$attr.ngModel,jb(this.$$element));},$render:la,$isEmpty:function(a){return U(a)||""===a||null===a||a!==a},$$updateEmptyClasses:function(a){this.$isEmpty(a)?(this.$$animate.removeClass(this.$$element,"ng-not-empty"),this.$$animate.addClass(this.$$element,
"ng-empty")):(this.$$animate.removeClass(this.$$element,"ng-empty"),this.$$animate.addClass(this.$$element,"ng-not-empty"))},$setPristine:function(){this.$dirty=!1;this.$pristine=!0;this.$$animate.removeClass(this.$$element,ed);this.$$animate.addClass(this.$$element,Zb)},$setDirty:function(){this.$dirty=!0;this.$pristine=!1;this.$$animate.removeClass(this.$$element,Zb);this.$$animate.addClass(this.$$element,ed);this.$$parentForm.$setDirty()},$setUntouched:function(){this.$touched=!1;this.$untouched=
!0;this.$$animate.setClass(this.$$element,"ng-untouched","ng-touched")},$setTouched:function(){this.$touched=!0;this.$untouched=!1;this.$$animate.setClass(this.$$element,"ng-touched","ng-untouched")},$rollbackViewValue:function(){this.$$timeout.cancel(this.$$pendingDebounce);this.$viewValue=this.$$lastCommittedViewValue;this.$render()},$validate:function(){if(!Ua(this.$modelValue)){var a=this.$$lastCommittedViewValue,b=this.$$rawModelValue,d=this.$valid,c=this.$modelValue,e=this.$options.getOption("allowInvalid"),
f=this;this.$$runValidators(b,a,function(g){e||d===g||(f.$modelValue=g?b:void 0,f.$modelValue!==c&&f.$$writeModelToScope())})}},$$runValidators:function(a,b,d){function c(k,h){f===g.$$currentValidationRunId&&g.$setValidity(k,h)}function e(k){f===g.$$currentValidationRunId&&d(k)}this.$$currentValidationRunId++;var f=this.$$currentValidationRunId,g=this;(function(){var k=g.$$parserName||"parse";if(U(g.$$parserValid))c(k,null);else return g.$$parserValid||(J(g.$validators,function(h,l){c(l,null)}),J(g.$asyncValidators,
function(h,l){c(l,null)})),c(k,g.$$parserValid),g.$$parserValid;return!0})()?function(){var k=!0;J(g.$validators,function(h,l){h=!!h(a,b);k=k&&h;c(l,h)});return k?!0:(J(g.$asyncValidators,function(h,l){c(l,null)}),!1)}()?function(){var k=[],h=!0;J(g.$asyncValidators,function(l,n){l=l(a,b);if(!l||!ca(l.then))throw qc("nopromise",l);c(n,void 0);k.push(l.then(function(){c(n,!0)},function(){h=!1;c(n,!1)}))});k.length?g.$$q.all(k).then(function(){e(h)},la):e(!0)}():e(!1):e(!1)},$commitViewValue:function(){var a=
this.$viewValue;this.$$timeout.cancel(this.$$pendingDebounce);if(this.$$lastCommittedViewValue!==a||""===a&&this.$$hasNativeValidators)this.$$updateEmptyClasses(a),this.$$lastCommittedViewValue=a,this.$pristine&&this.$setDirty(),this.$$parseAndValidate()},$$parseAndValidate:function(){var a=this.$$lastCommittedViewValue,b=this;if(this.$$parserValid=U(a)?void 0:!0)for(var d=0;d<this.$parsers.length;d++)if(a=this.$parsers[d](a),U(a)){this.$$parserValid=!1;break}Ua(this.$modelValue)&&(this.$modelValue=
this.$$ngModelGet(this.$$scope));var c=this.$modelValue,e=this.$options.getOption("allowInvalid");this.$$rawModelValue=a;e&&(this.$modelValue=a,b.$modelValue!==c&&b.$$writeModelToScope());this.$$runValidators(a,this.$$lastCommittedViewValue,function(f){e||(b.$modelValue=f?a:void 0,b.$modelValue!==c&&b.$$writeModelToScope())})},$$writeModelToScope:function(){this.$$ngModelSet(this.$$scope,this.$modelValue);J(this.$viewChangeListeners,function(a){try{a()}catch(b){this.$$exceptionHandler(b)}},this)},
$setViewValue:function(a,b){this.$viewValue=a;this.$options.getOption("updateOnDefault")&&this.$$debounceViewValueCommit(b)},$$debounceViewValueCommit:function(a){var b=this.$options.getOption("debounce");Ra(b[a])?b=b[a]:Ra(b["default"])&&(b=b["default"]);this.$$timeout.cancel(this.$$pendingDebounce);var d=this;0<b?this.$$pendingDebounce=this.$$timeout(function(){d.$commitViewValue()},b):this.$$scope.$root.$$phase?this.$commitViewValue():this.$$scope.$apply(function(){d.$commitViewValue()})},$overrideModelOptions:function(a){this.$options=
this.$options.createChild(a);this.$$setUpdateOnEvents()},$processModelValue:function(){var a=this.$$format();this.$viewValue!==a&&(this.$$updateEmptyClasses(a),this.$viewValue=this.$$lastCommittedViewValue=a,this.$render(),this.$$runValidators(this.$modelValue,this.$viewValue,la))},$$format:function(){for(var a=this.$formatters,b=a.length,d=this.$modelValue;b--;)d=a[b](d);return d},$$setModelValue:function(a){this.$modelValue=this.$$rawModelValue=a;this.$$parserValid=void 0;this.$processModelValue()},
$$setUpdateOnEvents:function(){this.$$updateEvents&&this.$$element.off(this.$$updateEvents,this.$$updateEventHandler);if(this.$$updateEvents=this.$options.getOption("updateOn"))this.$$element.on(this.$$updateEvents,this.$$updateEventHandler)},$$updateEventHandler:function(a){this.$$debounceViewValueCommit(a&&a.type)}};sf({clazz:ad,set:function(a,b){a[b]=!0},unset:function(a,b){delete a[b]}});var Ci=["$rootScope",function(a){return{restrict:"A",require:["ngModel","^?form","^?ngModelOptions"],controller:ad,
priority:1,compile:function(b){b.addClass(Zb).addClass("ng-untouched").addClass(oc);return{pre:function(d,c,e,f){var g=f[0];c=f[1]||g.$$parentForm;if(f=f[2])g.$options=f.$options;g.$$initGetterSetters();c.$addControl(g);e.$observe("name",function(k){g.$name!==k&&g.$$parentForm.$$renameControl(g,k)});d.$on("$destroy",function(){g.$$parentForm.$removeControl(g)})},post:function(d,c,e,f){function g(){k.$setTouched()}var k=f[0];k.$$setUpdateOnEvents();c.on("blur",function(){k.$touched||(a.$$phase?d.$evalAsync(g):
d.$apply(g))})}}}}}],Di=/(\s+|^)default(\s+|$)/;ae.prototype={getOption:function(a){return this.$$options[a]},createChild:function(a){var b=!1;a=Aa({},a);J(a,function(d,c){"$inherit"===d?"*"===c?b=!0:(a[c]=this.$$options[c],"updateOn"===c&&(a.updateOnDefault=this.$$options.updateOnDefault)):"updateOn"===c&&(a.updateOnDefault=!1,a[c]=Ca(d.replace(Di,function(){a.updateOnDefault=!0;return" "})))},this);b&&(delete a["*"],yf(a,this.$$options));yf(a,$d.$$options);return new ae(a)}};var $d=new ae({updateOn:"",
updateOnDefault:!0,debounce:0,getterSetter:!1,allowInvalid:!1,timezone:null});var Ei=function(){function a(b,d){this.$$attrs=b;this.$$scope=d}a.$inject=["$attrs","$scope"];a.prototype={$onInit:function(){var b=this.parentCtrl?this.parentCtrl.$options:$d,d=this.$$scope.$eval(this.$$attrs.ngModelOptions);this.$options=b.createChild(d)}};return{restrict:"A",priority:10,require:{parentCtrl:"?^^ngModelOptions"},bindToController:!0,controller:a}},Fi=Vb({terminal:!0,priority:1E3}),Gi=va("ngOptions"),Hi=
/^\s*([\s\S]+?)(?:\s+as\s+([\s\S]+?))?(?:\s+group\s+by\s+([\s\S]+?))?(?:\s+disable\s+when\s+([\s\S]+?))?\s+for\s+(?:([$\w][$\w]*)|(?:\(\s*([$\w][$\w]*)\s*,\s*([$\w][$\w]*)\s*\)))\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?$/,Ii=["$compile","$document","$parse",function(a,b,d){function c(g,k,h){function l(B,A,E,L,P){this.selectValue=B;this.viewValue=A;this.label=E;this.group=L;this.disabled=P}function n(B){if(!w&&ub(B))var A=B;else{A=[];for(var E in B)B.hasOwnProperty(E)&&"$"!==E.charAt(0)&&A.push(E)}return A}
var r=g.match(Hi);if(!r)throw Gi("iexp",g,jb(k));var u=r[5]||r[7],w=r[6];g=/ as /.test(r[0])&&r[1];var H=r[9];k=d(r[2]?r[1]:u);var F=g&&d(g)||k,C=H&&d(H),D=H?function(B,A){return C(h,A)}:function(B){return Pb(B)},y=function(B,A){return D(B,G(B,A))},v=d(r[2]||r[1]),p=d(r[3]||""),q=d(r[4]||""),m=d(r[8]),x={},G=w?function(B,A){x[w]=A;x[u]=B;return x}:function(B){x[u]=B;return x};return{trackBy:H,getTrackByValue:y,getWatchables:d(m,function(B){var A=[];B=B||[];for(var E=n(B),L=E.length,P=0;P<L;P++){var S=
B===E?P:E[P],X=B[S];S=G(X,S);X=D(X,S);A.push(X);if(r[2]||r[1])X=v(h,S),A.push(X);r[4]&&(S=q(h,S),A.push(S))}return A}),getOptions:function(){for(var B=[],A={},E=m(h)||[],L=n(E),P=L.length,S=0;S<P;S++){var X=E===L?S:L[S],ha=G(E[X],X),ja=F(h,ha);X=D(ja,ha);var ea=v(h,ha),ma=p(h,ha);ha=q(h,ha);ja=new l(X,ja,ea,ma,ha);B.push(ja);A[X]=ja}return{items:B,selectValueMap:A,getOptionFromViewValue:function(ka){return A[y(ka)]},getViewValueFromOption:function(ka){return H?Bb(ka.viewValue):ka.viewValue}}}}}var e=
ia.document.createElement("option"),f=ia.document.createElement("optgroup");return{restrict:"A",terminal:!0,require:["select","ngModel"],link:{pre:function(g,k,h,l){l[0].registerOption=la},post:function(g,k,h,l){function n(p){var q=(p=D.getOptionFromViewValue(p))&&p.element;q&&!q.selected&&(q.selected=!0);return p}function r(p,q){p.element=q;q.disabled=p.disabled;p.label!==q.label&&(q.label=p.label,q.textContent=p.label);q.value=p.selectValue}var u=l[0],w=l[1],H=h.multiple;l=0;for(var F=k.children(),
C=F.length;l<C;l++)if(""===F[l].value){u.hasEmptyOption=!0;u.emptyOption=F.eq(l);break}k.empty();l=!!u.emptyOption;da(e.cloneNode(!1)).val("?");var D,y=c(h.ngOptions,k,g),v=b[0].createDocumentFragment();u.generateUnknownOptionValue=function(p){return"?"};H?(u.writeValue=function(p){if(D){var q=p&&p.map(n)||[];D.items.forEach(function(m){m.element.selected&&-1===Array.prototype.indexOf.call(q,m)&&(m.element.selected=!1)})}},u.readValue=function(){var p=k.val()||[],q=[];J(p,function(m){(m=D.selectValueMap[m])&&
!m.disabled&&q.push(D.getViewValueFromOption(m))});return q},y.trackBy&&g.$watchCollection(function(){if(na(w.$viewValue))return w.$viewValue.map(function(p){return y.getTrackByValue(p)})},function(){w.$render()})):(u.writeValue=function(p){if(D){var q=k[0].options[k[0].selectedIndex],m=D.getOptionFromViewValue(p);q&&q.removeAttribute("selected");m?(k[0].value!==m.selectValue&&(u.removeUnknownOption(),k[0].value=m.selectValue,m.element.selected=!0),m.element.setAttribute("selected","selected")):u.selectUnknownOrEmptyOption(p)}},
u.readValue=function(){var p=D.selectValueMap[k.val()];return p&&!p.disabled?(u.unselectEmptyOption(),u.removeUnknownOption(),D.getViewValueFromOption(p)):null},y.trackBy&&g.$watch(function(){return y.getTrackByValue(w.$viewValue)},function(){w.$render()}));l&&(a(u.emptyOption)(g),k.prepend(u.emptyOption),8===u.emptyOption[0].nodeType?(u.hasEmptyOption=!1,u.registerOption=function(p,q){""===q.val()&&(u.hasEmptyOption=!0,u.emptyOption=q,u.emptyOption.removeClass("ng-scope"),w.$render(),q.on("$destroy",
function(){var m=u.$isEmptyOptionSelected();u.hasEmptyOption=!1;u.emptyOption=void 0;m&&w.$render()}))}):u.emptyOption.removeClass("ng-scope"));g.$watchCollection(y.getWatchables,function(){var p=D&&u.readValue();if(D)for(var q=D.items.length-1;0<=q;q--){var m=D.items[q];R(m.group)?Fc(m.element.parentNode):Fc(m.element)}D=y.getOptions();var x={};D.items.forEach(function(G){if(R(G.group)){var B=x[G.group];B||(B=f.cloneNode(!1),v.appendChild(B),B.label=null===G.group?"null":G.group,x[G.group]=B);var A=
e.cloneNode(!1);B.appendChild(A);r(G,A)}else B=e.cloneNode(!1),v.appendChild(B),r(G,B)});k[0].appendChild(v);w.$render();w.$isEmpty(p)||(q=u.readValue(),(y.trackBy||H?db(p,q):p===q)||(w.$setViewValue(q),w.$render()))})}}}}],Ji=["$locale","$interpolate","$log",function(a,b,d){var c=/{}/g,e=/^when(Minus)?(.+)$/;return{link:function(f,g,k){function h(v){g.text(v||"")}var l=k.count,n=k.$attr.when&&g.attr(k.$attr.when),r=k.offset||0,u=f.$eval(n)||{},w={},H=b.startSymbol(),F=b.endSymbol(),C=H+l+"-"+r+F,
D=Va.noop,y;J(k,function(v,p){if(v=e.exec(p))v=(v[1]?"-":"")+xa(v[2]),u[v]=g.attr(k.$attr[p])});J(u,function(v,p){w[p]=b(v.replace(c,C))});f.$watch(l,function(v){var p=parseFloat(v),q=Ua(p);q||p in u||(p=a.pluralCat(p-r));p===y||q&&Ua(y)||(D(),q=w[p],U(q)?(null!=v&&d.debug("ngPluralize: no rule defined for '"+p+"' in "+n),D=la,h()):D=f.$watch(q,h),y=p)})}}}],Ki=["$parse","$animate","$compile",function(a,b,d){var c=va("ngRepeat"),e=function(f,g,k,h,l,n,r){f[k]=h;l&&(f[l]=n);f.$index=g;f.$first=0===
g;f.$last=g===r-1;f.$middle=!(f.$first||f.$last);f.$odd=!(f.$even=0===(g&1))};return{restrict:"A",multiElement:!0,transclude:"element",priority:1E3,terminal:!0,$$tlb:!0,compile:function(f,g){var k=g.ngRepeat,h=d.$$createComment("end ngRepeat",k);f=k.match(/^\s*([\s\S]+?)\s+in\s+([\s\S]+?)(?:\s+as\s+([\s\S]+?))?(?:\s+track\s+by\s+([\s\S]+?))?\s*$/);if(!f)throw c("iexp",k);g=f[1];var l=f[2],n=f[3],r=f[4];f=g.match(/^(?:(\s*[$\w]+)|\(\s*([$\w]+)\s*,\s*([$\w]+)\s*\))$/);if(!f)throw c("iidexp",g);var u=
f[3]||f[1],w=f[2];if(n&&(!/^[$a-zA-Z_][$a-zA-Z0-9_]*$/.test(n)||/^(null|undefined|this|\$index|\$first|\$middle|\$last|\$even|\$odd|\$parent|\$root|\$id)$/.test(n)))throw c("badident",n);var H,F={$id:Pb};if(r)var C=a(r);else{var D=function(v,p){return Pb(p)};var y=function(v){return v}}return function(v,p,q,m,x){C&&(H=function(B,A,E){w&&(F[w]=B);F[u]=A;F.$index=E;return C(v,F)});var G=Ea();v.$watchCollection(l,function(B){var A,E=p[0],L=Ea();n&&(v[n]=B);if(ub(B)){var P=B;var S=H||D}else for(ha in S=
H||y,P=[],B)bb.call(B,ha)&&"$"!==ha.charAt(0)&&P.push(ha);var X=P.length;var ha=Array(X);for(A=0;A<X;A++){var ja=B===P?A:P[A];var ea=B[ja];var ma=S(ja,ea,A);if(G[ma]){var ka=G[ma];delete G[ma];L[ma]=ka;ha[A]=ka}else{if(L[ma])throw J(ha,function(ua){ua&&ua.scope&&(G[ua.id]=ua)}),c("dupes",k,ma,ea);ha[A]={id:ma,scope:void 0,clone:void 0};L[ma]=!0}}for(ya in G){ka=G[ya];ma=wc(ka.clone);b.leave(ma);if(ma[0].parentNode)for(A=0,S=ma.length;A<S;A++)ma[A].$$NG_REMOVED=!0;ka.scope.$destroy()}for(A=0;A<X;A++)if(ja=
B===P?A:P[A],ea=B[ja],ka=ha[A],ka.scope){var ya=E;do ya=ya.nextSibling;while(ya&&ya.$$NG_REMOVED);ka.clone[0]!==ya&&b.move(wc(ka.clone),null,E);E=ka.clone[ka.clone.length-1];e(ka.scope,A,u,ea,w,ja,X)}else x(function(ua,mb){ka.scope=mb;mb=h.cloneNode(!1);ua[ua.length++]=mb;b.enter(ua,null,E);E=mb;ka.clone=ua;L[ka.id]=ka;e(ka.scope,A,u,ea,w,ja,X)});G=L})}}}}],Li=["$animate",function(a){return{restrict:"A",multiElement:!0,link:function(b,d,c){b.$watch(c.ngShow,function(e){a[e?"removeClass":"addClass"](d,
"ng-hide",{tempClasses:"ng-hide-animate"})})}}}],Mi=["$animate",function(a){return{restrict:"A",multiElement:!0,link:function(b,d,c){b.$watch(c.ngHide,function(e){a[e?"addClass":"removeClass"](d,"ng-hide",{tempClasses:"ng-hide-animate"})})}}}],Ni=Vb(function(a,b,d){a.$watch(d.ngStyle,function(c,e){e&&c!==e&&J(e,function(f,g){b.css(g,"")});c&&b.css(c)},!0)}),Oi=["$animate","$compile",function(a,b){return{require:"ngSwitch",controller:["$scope",function(){this.cases={}}],link:function(d,c,e,f){var g=
[],k=[],h=[],l=[],n=function(r,u){return function(w){!1!==w&&r.splice(u,1)}};d.$watch(e.ngSwitch||e.on,function(r){for(var u,w;h.length;)a.cancel(h.pop());u=0;for(w=l.length;u<w;++u){var H=wc(k[u].clone);l[u].$destroy();(h[u]=a.leave(H)).done(n(h,u))}k.length=0;l.length=0;(g=f.cases["!"+r]||f.cases["?"])&&J(g,function(F){F.transclude(function(C,D){l.push(D);D=F.element;C[C.length++]=b.$$createComment("end ngSwitchWhen");k.push({clone:C});a.enter(C,D.parent(),D)})})})}}}],Pi=Vb({transclude:"element",
priority:1200,require:"^ngSwitch",multiElement:!0,link:function(a,b,d,c,e){a=d.ngSwitchWhen.split(d.ngSwitchWhenSeparator).sort().filter(function(f,g,k){return k[g-1]!==f});J(a,function(f){c.cases["!"+f]=c.cases["!"+f]||[];c.cases["!"+f].push({transclude:e,element:b})})}}),Qi=Vb({transclude:"element",priority:1200,require:"^ngSwitch",multiElement:!0,link:function(a,b,d,c,e){c.cases["?"]=c.cases["?"]||[];c.cases["?"].push({transclude:e,element:b})}}),Ri=va("ngTransclude"),Si=["$compile",function(a){return{restrict:"EAC",
compile:function(b){var d=a(b.contents());b.empty();return function(c,e,f,g,k){function h(){d(c,function(l){e.append(l)})}if(!k)throw Ri("orphan",jb(e));f.ngTransclude===f.$attr.ngTransclude&&(f.ngTransclude="");f=f.ngTransclude||f.ngTranscludeSlot;k(function(l,n){var r;if(r=l.length)a:{r=0;for(var u=l.length;r<u;r++){var w=l[r];if(w.nodeType!==wb||w.nodeValue.trim()){r=!0;break a}}r=void 0}r?e.append(l):(h(),n.$destroy())},null,f);f&&!k.isSlotFilled(f)&&h()}}}}],Ti=["$templateCache",function(a){return{restrict:"E",
terminal:!0,compile:function(b,d){"text/ng-template"===d.type&&a.put(d.id,b[0].text)}}}],Ui={$setViewValue:la,$render:la},Vi=["$element","$scope",function(a,b){function d(){g||(g=!0,b.$$postDigest(function(){g=!1;e.ngModelCtrl.$render()}))}function c(h){k||(k=!0,b.$$postDigest(function(){b.$$destroyed||(k=!1,e.ngModelCtrl.$setViewValue(e.readValue()),h&&e.ngModelCtrl.$render())}))}var e=this,f=new Hc;e.selectValueMap={};e.ngModelCtrl=Ui;e.multiple=!1;e.unknownOption=da(ia.document.createElement("option"));
e.hasEmptyOption=!1;e.emptyOption=void 0;e.renderUnknownOption=function(h){h=e.generateUnknownOptionValue(h);e.unknownOption.val(h);a.prepend(e.unknownOption);Lb(e.unknownOption,!0);a.val(h)};e.updateUnknownOption=function(h){h=e.generateUnknownOptionValue(h);e.unknownOption.val(h);Lb(e.unknownOption,!0);a.val(h)};e.generateUnknownOptionValue=function(h){return"? "+Pb(h)+" ?"};e.removeUnknownOption=function(){e.unknownOption.parent()&&e.unknownOption.remove()};e.selectEmptyOption=function(){e.emptyOption&&
(a.val(""),Lb(e.emptyOption,!0))};e.unselectEmptyOption=function(){e.hasEmptyOption&&Lb(e.emptyOption,!1)};b.$on("$destroy",function(){e.renderUnknownOption=la});e.readValue=function(){var h=a.val();h=h in e.selectValueMap?e.selectValueMap[h]:h;return e.hasOption(h)?h:null};e.writeValue=function(h){var l=a[0].options[a[0].selectedIndex];l&&Lb(da(l),!1);e.hasOption(h)?(e.removeUnknownOption(),l=Pb(h),a.val(l in e.selectValueMap?l:h),Lb(da(a[0].options[a[0].selectedIndex]),!0)):e.selectUnknownOrEmptyOption(h)};
e.addOption=function(h,l){8!==l[0].nodeType&&(Ob(h,'"option value"'),""===h&&(e.hasEmptyOption=!0,e.emptyOption=l),l=f.get(h)||0,f.set(h,l+1),d())};e.removeOption=function(h){var l=f.get(h);l&&(1===l?(f.delete(h),""===h&&(e.hasEmptyOption=!1,e.emptyOption=void 0)):f.set(h,l-1))};e.hasOption=function(h){return!!f.get(h)};e.$hasEmptyOption=function(){return e.hasEmptyOption};e.$isUnknownOptionSelected=function(){return a[0].options[0]===e.unknownOption[0]};e.$isEmptyOptionSelected=function(){return e.hasEmptyOption&&
a[0].options[a[0].selectedIndex]===e.emptyOption[0]};e.selectUnknownOrEmptyOption=function(h){null==h&&e.emptyOption?(e.removeUnknownOption(),e.selectEmptyOption()):e.unknownOption.parent().length?e.updateUnknownOption(h):e.renderUnknownOption(h)};var g=!1,k=!1;e.registerOption=function(h,l,n,r,u){if(n.$attr.ngValue){var w,H=NaN;n.$observe("value",function(F){var C=l.prop("selected");if(R(H)){e.removeOption(w);delete e.selectValueMap[H];var D=!0}H=Pb(F);w=F;e.selectValueMap[H]=F;e.addOption(F,l);
l.attr("value",H);D&&C&&c()})}else r?n.$observe("value",function(F){e.readValue();var C=l.prop("selected");if(R(w)){e.removeOption(w);var D=!0}w=F;e.addOption(F,l);D&&C&&c()}):u?h.$watch(u,function(F,C){n.$set("value",F);var D=l.prop("selected");C!==F&&e.removeOption(C);e.addOption(F,l);C&&D&&c()}):e.addOption(n.value,l);n.$observe("disabled",function(F){if("true"===F||F&&l.prop("selected"))e.multiple?c(!0):(e.ngModelCtrl.$setViewValue(null),e.ngModelCtrl.$render())});l.on("$destroy",function(){var F=
e.readValue(),C=n.value;e.removeOption(C);d();(e.multiple&&F&&-1!==F.indexOf(C)||F===C)&&c(!0)})}}],Wi=function(){return{restrict:"E",require:["select","?ngModel"],controller:Vi,priority:1,link:{pre:function(a,b,d,c){var e=c[0],f=c[1];if(f){if(e.ngModelCtrl=f,b.on("change",function(){e.removeUnknownOption();a.$apply(function(){f.$setViewValue(e.readValue())})}),d.multiple){e.multiple=!0;e.readValue=function(){var h=[];J(b.find("option"),function(l){l.selected&&!l.disabled&&(l=l.value,h.push(l in e.selectValueMap?
e.selectValueMap[l]:l))});return h};e.writeValue=function(h){J(b.find("option"),function(l){var n=!!h&&(-1!==Array.prototype.indexOf.call(h,l.value)||-1!==Array.prototype.indexOf.call(h,e.selectValueMap[l.value]));n!==l.selected&&Lb(da(l),n)})};var g,k=NaN;a.$watch(function(){k!==f.$viewValue||db(g,f.$viewValue)||(g=kb(f.$viewValue),f.$render());k=f.$viewValue});f.$isEmpty=function(h){return!h||0===h.length}}}else e.registerOption=la},post:function(a,b,d,c){var e=c[1];if(e){var f=c[0];e.$render=function(){f.writeValue(e.$viewValue)}}}}}},
Xi=["$interpolate",function(a){return{restrict:"E",priority:100,compile:function(b,d){var c;if(!R(d.ngValue))if(R(d.value))var e=a(d.value,!0);else(c=a(b.text(),!0))||d.$set("value",b.text());return function(f,g,k){var h=g.parent();(h=h.data("$selectController")||h.parent().data("$selectController"))&&h.registerOption(f,g,k,e,c)}}}}],Jf=function(){return{restrict:"A",require:"?ngModel",link:function(a,b,d,c){c&&(d.required=!0,c.$validators.required=function(e,f){return!d.required||!c.$isEmpty(f)},
d.$observe("required",function(){c.$validate()}))}}},Kf=function(){return{restrict:"A",require:"?ngModel",link:function(a,b,d,c){if(c){var e,f=d.ngPattern||d.pattern;d.$observe("pattern",function(g){oa(g)&&0<g.length&&(g=new RegExp("^"+g+"$"));if(g&&!g.test)throw va("ngPattern")("noregexp",f,g,jb(b));e=g||void 0;c.$validate()});c.$validators.pattern=function(g,k){return c.$isEmpty(k)||U(e)||e.test(k)}}}}},Lf=function(){return{restrict:"A",require:"?ngModel",link:function(a,b,d,c){if(c){var e=-1;d.$observe("maxlength",
function(f){f=parseInt(f,10);e=Ua(f)?-1:f;c.$validate()});c.$validators.maxlength=function(f,g){return 0>e||c.$isEmpty(g)||g.length<=e}}}}},Mf=function(){return{restrict:"A",require:"?ngModel",link:function(a,b,d,c){if(c){var e=0;d.$observe("minlength",function(f){e=parseInt(f,10)||0;c.$validate()});c.$validators.minlength=function(f,g){return c.$isEmpty(g)||g.length>=e}}}}};if(ia.angular.bootstrap)ia.console&&console.log("WARNING: Tried to load AngularJS more than once.");else{(function(){if(!zf){var a=
bd();if((Ab=U(a)?ia.jQuery:a?ia[a]:void 0)&&Ab.fn.on){da=Ab;Aa(Ab.fn,{scope:Qb.scope,isolateScope:Qb.isolateScope,controller:Qb.controller,injector:Qb.injector,inheritedData:Qb.inheritedData});var b=Ab.cleanData;Ab.cleanData=function(d){for(var c,e=0,f;null!=(f=d[e]);e++)(c=Ab._data(f,"events"))&&c.$destroy&&Ab(f).triggerHandler("$destroy");b(d)}}else da=Ha;Va.element=da;zf=!0}})();(function(a){Aa(a,{errorHandlingConfig:Nf,bootstrap:le,copy:Bb,extend:Aa,merge:Pf,equals:db,element:da,forEach:J,injector:fc,
noop:la,bind:Mb,toJson:dc,fromJson:ie,identity:uc,isUndefined:U,isDefined:R,isString:oa,isFunction:ca,isObject:fa,isNumber:Ra,isElement:id,isArray:na,version:Ph,isDate:Xa,lowercase:xa,uppercase:Tc,callbacks:{$$counter:0},getTestability:Yf,reloadWithDebugInfo:Xf,$$minErr:va,$$csp:Jb,$$encodeUriSegment:ec,$$encodeUriQuery:Za,$$stringify:rd});zd=$f(ia);zd("ng",["ngLocale"],["$provide",function(b){b.provider({$$sanitizeUri:ph});b.provider("$compile",xe).directive({a:fi,input:Hf,textarea:Hf,form:gi,script:Ti,
select:Wi,option:Xi,ngBind:ni,ngBindHtml:pi,ngBindTemplate:oi,ngClass:ri,ngClassEven:ti,ngClassOdd:si,ngCloak:ui,ngController:vi,ngForm:hi,ngHide:Mi,ngIf:xi,ngInclude:yi,ngInit:Ai,ngNonBindable:Fi,ngPluralize:Ji,ngRepeat:Ki,ngShow:Li,ngStyle:Ni,ngSwitch:Oi,ngSwitchWhen:Pi,ngSwitchDefault:Qi,ngOptions:Ii,ngTransclude:Si,ngModel:Ci,ngList:Bi,ngChange:qi,pattern:Kf,ngPattern:Kf,required:Jf,ngRequired:Jf,minlength:Mf,ngMinlength:Mf,maxlength:Lf,ngMaxlength:Lf,ngValue:mi,ngModelOptions:Ei}).directive({ngInclude:zi,
input:ki}).directive(dd).directive(If);b.provider({$anchorScroll:qg,$animate:Xh,$animateCss:$h,$$animateJs:Vh,$$animateQueue:Wh,$$AnimateRunner:Zh,$$animateAsyncRun:Yh,$browser:tg,$cacheFactory:ug,$controller:Ng,$document:Og,$$isDocumentHidden:Pg,$exceptionHandler:Qg,$filter:ff,$$forceReflow:ai,$interpolate:ah,$interval:bh,$http:Wg,$httpParamSerializer:Rg,$httpParamSerializerJQLike:Sg,$httpBackend:Zg,$xhrFactory:Yg,$jsonpCallbacks:bi,$location:eh,$log:fh,$parse:kh,$rootScope:oh,$q:lh,$$q:mh,$sce:Kh,
$sceDelegate:Jh,$sniffer:qh,$templateCache:vg,$templateRequest:Lh,$$testability:rh,$timeout:sh,$window:th,$$rAF:nh,$$jqLite:kg,$$Map:Sh,$$cookieReader:uh})}]).info({angularVersion:"1.6.4-local+sha.617b36117"})})(Va);Va.module("ngLocale",[],["$provide",function(a){a.value("$locale",{DATETIME_FORMATS:{AMPMS:["AM","PM"],DAY:"Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),ERANAMES:["Before Christ","Anno Domini"],ERAS:["BC","AD"],FIRSTDAYOFWEEK:6,MONTH:"January February March April May June July August September October November December".split(" "),
SHORTDAY:"Sun Mon Tue Wed Thu Fri Sat".split(" "),SHORTMONTH:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),STANDALONEMONTH:"January February March April May June July August September October November December".split(" "),WEEKENDRANGE:[5,6],fullDate:"EEEE, MMMM d, y",longDate:"MMMM d, y",medium:"MMM d, y h:mm:ss a",mediumDate:"MMM d, y",mediumTime:"h:mm:ss a","short":"M/d/yy h:mm a",shortDate:"M/d/yy",shortTime:"h:mm a"},NUMBER_FORMATS:{CURRENCY_SYM:"$",DECIMAL_SEP:".",GROUP_SEP:",",
PATTERNS:[{gSize:3,lgSize:3,maxFrac:3,minFrac:0,minInt:1,negPre:"-",negSuf:"",posPre:"",posSuf:""},{gSize:3,lgSize:3,maxFrac:2,minFrac:2,minInt:1,negPre:"-\u00a4",negSuf:"",posPre:"\u00a4",posSuf:""}]},id:"en-us",localeID:"en_US",pluralCat:function(b,d){var c=b|0;if(void 0===d){d=Math;var e=d.min;b+="";var f=b.indexOf(".");d=e.call(d,-1==f?0:b.length-f-1,3)}return 1==c&&0==d?"one":"other"}})}]);var Ya=va("$sce"),Yb={HTML:"html",CSS:"css",URL:"url",RESOURCE_URL:"resourceUrl",TEMPLATE_URL:"templateUrl",
JS:"js"},be=/_([a-z])/g,Mh=va("$compile");da(function(){Vf(ia.document,le)})}})(window);angular.element(document).find("head").append(angular.element("<style>").text('@charset "UTF-8";\n\n[ng\\:cloak], [ng-cloak], [data-ng-cloak], [x-ng-cloak],\n.ng-cloak, .x-ng-cloak,\n.ng-hide:not(.ng-hide-animate) {\n  display: none !important;\n}\n\nng\\:form {\n  display: block;\n}\n\n.ng-animate-shim {\n  visibility:hidden;\n}\n\n.ng-anchor {\n  position:absolute;\n}\n'));

//third_party/javascript/angular/v1_6/angular-route.min.js
/*
 AngularJS v1.6.4-local+sha.617b36117
 (c) 2010-2018 Google, Inc. http://angularjs.org
 License: MIT
*/
(function(B,e){'use strict';function J(r){C&&r.get("$route")}function K(r,y,q){return{restrict:"ECA",terminal:!0,priority:400,transclude:"element",link:function(c,d,h,k,l){function p(){t&&(q.cancel(t),t=null);m&&(m.$destroy(),m=null);v&&(t=q.leave(v),t.done(function(u){!1!==u&&(t=null)}),v=null)}function z(){var u=r.current&&r.current.locals;if(e.isDefined(u&&u.$template)){u=c.$new();var G=r.current;v=l(u,function(H){q.enter(H,null,v||d).done(function(D){!1===D||!e.isDefined(A)||A&&!c.$eval(A)||y()});p()});m=
G.scope=u;m.$emit("$viewContentLoaded");m.$eval(I)}else p()}var m,v,t,A=h.autoscroll,I=h.onload||"";c.$on("$routeChangeSuccess",z);z()}}}function L(r,y,q){return{restrict:"ECA",priority:-400,link:function(c,d){var h=q.current,k=h.locals;d.html(k.$template);var l=r(d.contents());if(h.controller){k.$scope=c;var p=y(h.controller,k);h.controllerAs&&(c[h.controllerAs]=p);d.data("$ngControllerController",p);d.children().data("$ngControllerController",p)}c[h.resolveAs||"$resolve"]=k;l(c)}}}"use strict";
var M,N,O,P;B=e.module("ngRoute",[]).info({angularVersion:"1.6.4-local+sha.617b36117"}).provider("$route",function(){function r(c,d){return e.extend(Object.create(c),d)}function y(c,d){d=d.caseInsensitiveMatch;var h={originalPath:c,regexp:c},k=h.keys=[];c=c.replace(/([().])/g,"\\$1").replace(/(\/)?:(\w+)(\*\?|[?*])?/g,function(l,p,z,m){l="?"===m||"*?"===m?"?":null;m="*"===m||"*?"===m?"*":null;k.push({name:z,optional:!!l});p=p||"";return""+(l?"":p)+"(?:"+(l?p:"")+(m&&"(.+?)"||"([^/]+)")+(l||"")+")"+
(l||"")}).replace(/([/$*])/g,"\\$1");h.regexp=new RegExp("^"+c+"$",d?"i":"");return h}M=e.isArray;N=e.isObject;O=e.isDefined;P=e.noop;var q={};this.when=function(c,d){var h=void 0;if(M(d)){h=h||[];for(var k=0,l=d.length;k<l;k++)h[k]=d[k]}else if(N(d))for(k in h=h||{},d)if("$"!==k.charAt(0)||"$"!==k.charAt(1))h[k]=d[k];d=h||d;e.isUndefined(d.reloadOnSearch)&&(d.reloadOnSearch=!0);e.isUndefined(d.caseInsensitiveMatch)&&(d.caseInsensitiveMatch=this.caseInsensitiveMatch);q[c]=e.extend(d,c&&y(c,d));c&&
(h="/"===c[c.length-1]?c.substr(0,c.length-1):c+"/",q[h]=e.extend({redirectTo:c},y(h,d)));return this};this.caseInsensitiveMatch=!1;this.otherwise=function(c){"string"===typeof c&&(c={redirectTo:c});this.when(null,c);return this};C=!0;this.eagerInstantiationEnabled=function(c){return O(c)?(C=c,this):C};this.$get=["$rootScope","$location","$routeParams","$q","$injector","$templateRequest","$sce","$browser",function(c,d,h,k,l,p,z,m){function v(a){var b=w.current;(Q=(x=H())&&b&&x.$$route===b.$$route&&
e.equals(x.pathParams,b.pathParams)&&!x.reloadOnSearch&&!E)||!b&&!x||c.$broadcast("$routeChangeStart",x,b).defaultPrevented&&a&&a.preventDefault()}function t(){var a=w.current,b=x;if(Q)a.params=b.params,e.copy(a.params,h),c.$broadcast("$routeUpdate",a);else if(b||a){E=!1;w.current=b;var f=k.resolve(b);m.$$incOutstandingRequestCount();f.then(A).then(I).then(function(g){return g&&f.then(u).then(function(n){b===w.current&&(b&&(b.locals=n,e.copy(b.params,h)),c.$broadcast("$routeChangeSuccess",b,a))})}).catch(function(g){b===
w.current&&c.$broadcast("$routeChangeError",b,a,g)}).finally(function(){m.$$completeOutstandingRequest(P)})}}function A(a){var b={route:a,hasRedirection:!1};if(a)if(a.redirectTo)if(e.isString(a.redirectTo))b.path=D(a.redirectTo,a.params),b.search=a.params,b.hasRedirection=!0;else{var f=d.path(),g=d.search();a=a.redirectTo(a.pathParams,f,g);e.isDefined(a)&&(b.url=a,b.hasRedirection=!0)}else if(a.resolveRedirectTo)return k.resolve(l.invoke(a.resolveRedirectTo)).then(function(n){e.isDefined(n)&&(b.url=
n,b.hasRedirection=!0);return b});return b}function I(a){var b=!0;if(a.route!==w.current)b=!1;else if(a.hasRedirection){var f=d.url(),g=a.url;g?d.url(g).replace():g=d.path(a.path).search(a.search).replace().url();g!==f&&(b=!1)}return b}function u(a){if(a){var b=e.extend({},a.resolve);e.forEach(b,function(f,g){b[g]=e.isString(f)?l.get(f):l.invoke(f,null,null,g)});a=G(a);e.isDefined(a)&&(b.$template=a);return k.all(b)}}function G(a){var b,f;e.isDefined(b=a.template)?e.isFunction(b)&&(b=b(a.params)):
e.isDefined(f=a.templateUrl)&&(e.isFunction(f)&&(f=f(a.params)),e.isDefined(f)&&(a.loadedTemplateUrl=z.valueOf(f),b=p(f)));return b}function H(){var a,b;e.forEach(q,function(f,g){if(g=!b){var n=d.path();g=f.keys;var R={};if(f.regexp)if(n=f.regexp.exec(n)){for(var F=1,U=n.length;F<U;++F){var S=g[F-1],T=n[F];S&&T&&(R[S.name]=T)}g=R}else g=null;else g=null;g=a=g}g&&(b=r(f,{params:e.extend({},d.search(),a),pathParams:a}),b.$$route=f)});return b||q[null]&&r(q[null],{params:{},pathParams:{}})}function D(a,
b){var f=[];e.forEach((a||"").split(":"),function(g,n){0===n?f.push(g):(g=g.match(/(\w+)(?:[?*])?(.*)/),n=g[1],f.push(b[n]),f.push(g[2]||""),delete b[n])});return f.join("")}var E=!1,x,Q,w={routes:q,reload:function(){E=!0;var a={defaultPrevented:!1,preventDefault:function(){this.defaultPrevented=!0;E=!1}};c.$evalAsync(function(){v(a);a.defaultPrevented||t()})},updateParams:function(a){if(this.current&&this.current.$$route)a=e.extend({},this.current.params,a),d.path(D(this.current.$$route.originalPath,
a)),d.search(a);else throw V("norout");}};c.$on("$locationChangeStart",v);c.$on("$locationChangeSuccess",t);return w}]}).run(J);var V=e.$$minErr("ngRoute"),C;J.$inject=["$injector"];"use strict";B.provider("$routeParams",function(){this.$get=function(){return{}}});"use strict";B.directive("ngView",K);B.directive("ngView",L);K.$inject=["$route","$anchorScroll","$animate"];L.$inject=["$compile","$controller","$route"]})(window,window.angular);

//third_party/javascript/angular/v1_6/angular-cookies.min.js
/*
 AngularJS v1.6.4-local+sha.617b36117
 (c) 2010-2018 Google, Inc. http://angularjs.org
 License: MIT
*/
(function(p,c){'use strict';function m(d,e,k){var a=k.baseHref(),g=d[0];return function(h,f,b){b=b||{};var l=b.expires;var n=c.isDefined(b.path)?b.path:a;c.isUndefined(f)&&(l="Thu, 01 Jan 1970 00:00:00 GMT",f="");c.isString(l)&&(l=new Date(l));f=encodeURIComponent(h)+"="+encodeURIComponent(f);f=f+(n?";path="+n:"")+(b.domain?";domain="+b.domain:"");f+=l?";expires="+l.toUTCString():"";f+=b.secure?";secure":"";b=f.length+1;4096<b&&e.warn("Cookie '"+h+"' possibly not set or overflowed because it was too large ("+
b+" > 4096 bytes)!");g.cookie=f}}c.module("ngCookies",["ng"]).info({angularVersion:"1.6.4-local+sha.617b36117"}).provider("$cookies",[function(){var d=this.defaults={};this.$get=["$$cookieReader","$$cookieWriter",function(e,k){return{get:function(a){return e()[a]},getObject:function(a){return(a=this.get(a))?c.fromJson(a):a},getAll:function(){return e()},put:function(a,g,h){k(a,g,h?c.extend({},d,h):d)},putObject:function(a,g,h){this.put(a,c.toJson(g),h)},remove:function(a,g){k(a,void 0,g?c.extend({},
d,g):d)}}}]}]);"use strict";c.module("ngCookies").factory("$cookieStore",["$cookies",function(d){return{get:function(e){return d.getObject(e)},put:function(e,k){d.putObject(e,k)},remove:function(e){d.remove(e)}}}]);"use strict";m.$inject=["$document","$log","$browser"];c.module("ngCookies").provider("$$cookieWriter",function(){this.$get=m})})(window,window.angular);

//third_party/javascript/angular/v1_6/angular-sanitize.min.js
/*
 AngularJS v1.6.4-local+sha.617b36117
 (c) 2010-2018 Google, Inc. http://angularjs.org
 License: MIT
*/
(function(H,h){'use strict';var L=h.$$minErr("$sanitize"),O,r,P,Q,R,C,S,T,U,M;h.module("ngSanitize",[]).provider("$sanitize",function(){function m(a,b){return D(a.split(","),b)}function D(a,b){var d={},c;for(c=0;c<a.length;c++)d[b?C(a[c]):a[c]]=!0;return d}function z(a,b){b&&b.length&&r(a,D(b))}function I(a){return a.replace(/&/g,"&amp;").replace(g,function(b){var d=b.charCodeAt(0);b=b.charCodeAt(1);return"&#"+(1024*(d-55296)+(b-56320)+65536)+";"}).replace(J,function(b){return"&#"+b.charCodeAt(0)+";"}).replace(/</g,
"&lt;").replace(/>/g,"&gt;")}function K(a){for(;a;){if(a.nodeType===H.Node.ELEMENT_NODE)for(var b=a.attributes,d=0,c=b.length;d<c;d++){var e=b[d],k=e.name.toLowerCase();if("xmlns:ns1"===k||0===k.lastIndexOf("ns1:",0))a.removeAttributeNode(e),d--,c--}(b=a.firstChild)&&K(b);a=A("nextSibling",a)}}function A(a,b){if((a=b[a])&&T.call(b,a))throw L("elclob",b.outerHTML||b.outerText);return a}var E=!1,F=!1;this.$get=["$$sanitizeUri",function(a){E=!0;F&&r(n,u);return function(b){var d=[];U(b,M(d,function(c,
e){return!/^unsafe:/.test(a(c,e))}));return d.join("")}}];this.enableSvg=function(a){return R(a)?(F=a,this):F};this.addValidElements=function(a){E||(Q(a)&&(a={htmlElements:a}),z(u,a.svgElements),z(v,a.htmlVoidElements),z(n,a.htmlVoidElements),z(n,a.htmlElements));return this};this.addValidAttrs=function(a){E||r(p,D(a,!0));return this};O=h.bind;r=h.extend;P=h.forEach;Q=h.isArray;R=h.isDefined;C=h.lowercase;S=h.noop;U=function(a,b){null===a||void 0===a?a="":"string"!==typeof a&&(a=""+a);var d=y(a);
if(!d)return"";var c=5;do{if(0===c)throw L("uinput");c--;a=d.innerHTML;d=y(a)}while(a!==d.innerHTML);for(a=d.firstChild;a;){switch(a.nodeType){case 1:c=b;for(var e=c.start,k=a.nodeName.toLowerCase(),f=a.attributes,l={},q=0,N=f.length;q<N;q++){var V=f[q];l[V.name]=V.value}e.call(c,k,l);break;case 3:b.chars(a.textContent)}if(!(c=a.firstChild)&&(1===a.nodeType&&b.end(a.nodeName.toLowerCase()),c=A("nextSibling",a),!c))for(;null==c;){a=A("parentNode",a);if(a===d)break;c=A("nextSibling",a);1===a.nodeType&&
b.end(a.nodeName.toLowerCase())}a=c}for(;a=d.firstChild;)d.removeChild(a)};M=function(a,b){var d=!1,c=O(a,a.push);return{start:function(e,k){e=C(e);!d&&t[e]&&(d=e);d||!0!==n[e]||(c("<"),c(e),P(k,function(f,l){var q=C(l),N="img"===e&&"src"===q||"background"===q;!0!==p[q]||!0===B[q]&&!b(f,N)||(c(" "),c(l),c('="'),c(I(f)),c('"'))}),c(">"))},end:function(e){e=C(e);d||!0!==n[e]||!0===v[e]||(c("</"),c(e),c(">"));e==d&&(d=!1)},chars:function(e){d||c(I(e))}}};T=H.Node.prototype.contains||function(a){return!!(this.compareDocumentPosition(a)&
16)};var g=/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,J=/([^#-~ |!])/g,v=m("area,br,col,hr,img,wbr"),w=m("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"),x=m("rp,rt"),G=r({},x,w);w=r({},w,m("address,article,aside,blockquote,caption,center,del,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,map,menu,nav,ol,pre,section,table,ul"));x=r({},x,m("a,abbr,acronym,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,q,ruby,rp,rt,s,samp,small,span,strike,strong,sub,sup,time,tt,u,var"));
var u=m("circle,defs,desc,ellipse,font-face,font-face-name,font-face-src,g,glyph,hkern,image,linearGradient,line,marker,metadata,missing-glyph,mpath,path,polygon,polyline,radialGradient,rect,stop,svg,switch,text,title,tspan"),t=m("script,style"),n=r({},v,w,x,G),B=m("background,cite,href,longdesc,src,xlink:href,xml:base");G=m("abbr,align,alt,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,coords,dir,face,headers,height,hreflang,hspace,ismap,lang,language,nohref,nowrap,rel,rev,rows,rowspan,rules,scope,scrolling,shape,size,span,start,summary,tabindex,target,title,type,valign,value,vspace,width");
x=m("accent-height,accumulate,additive,alphabetic,arabic-form,ascent,baseProfile,bbox,begin,by,calcMode,cap-height,class,color,color-rendering,content,cx,cy,d,dx,dy,descent,display,dur,end,fill,fill-rule,font-family,font-size,font-stretch,font-style,font-variant,font-weight,from,fx,fy,g1,g2,glyph-name,gradientUnits,hanging,height,horiz-adv-x,horiz-origin-x,ideographic,k,keyPoints,keySplines,keyTimes,lang,marker-end,marker-mid,marker-start,markerHeight,markerUnits,markerWidth,mathematical,max,min,offset,opacity,orient,origin,overline-position,overline-thickness,panose-1,path,pathLength,points,preserveAspectRatio,r,refX,refY,repeatCount,repeatDur,requiredExtensions,requiredFeatures,restart,rotate,rx,ry,slope,stemh,stemv,stop-color,stop-opacity,strikethrough-position,strikethrough-thickness,stroke,stroke-dasharray,stroke-dashoffset,stroke-linecap,stroke-linejoin,stroke-miterlimit,stroke-opacity,stroke-width,systemLanguage,target,text-anchor,to,transform,type,u1,u2,underline-position,underline-thickness,unicode,unicode-range,units-per-em,values,version,viewBox,visibility,width,widths,x,x-height,x1,x2,xlink:actuate,xlink:arcrole,xlink:role,xlink:show,xlink:title,xlink:type,xml:base,xml:lang,xml:space,xmlns,xmlns:xlink,y,y1,y2,zoomAndPan",
!0);var p=r({},B,x,G),y=function(a,b){function d(f){f="<remove></remove>"+f;try{var l=(new a.DOMParser).parseFromString(f,"text/html").body;l.firstChild.remove();return l}catch(q){}}function c(f){k.innerHTML=f;b.documentMode&&K(k);return k}if(b&&b.implementation)var e=b.implementation.createHTMLDocument("inert");else throw L("noinert");var k=(e.documentElement||e.getDocumentElement()).querySelector("body");k.innerHTML='<svg><g onload="this.parentNode.remove()"></g></svg>';return k.querySelector("svg")?
(k.innerHTML='<svg><p><style><img src="</style><img src=x onerror=alert(1)//">',k.querySelector("svg img")?d:c):function(f){f="<remove></remove>"+f;try{f=encodeURI(f)}catch(q){return}var l=new a.XMLHttpRequest;l.responseType="document";l.open("GET","data:text/html;charset=utf-8,"+f,!1);l.send(null);f=l.response.body;f.firstChild.remove();return f}}(H,H.document)}).info({angularVersion:"1.6.4-local+sha.617b36117"});h.module("ngSanitize").filter("linky",["$sanitize",function(m){var D=/((s?ftp|https?):\/\/|(www\.)|(mailto:)?[A-Za-z0-9._%+-]+@)\S*[^\s.;,(){}<>"\u201d\u2019]/i,
z=/^mailto:/i,I=h.$$minErr("linky"),K=h.isDefined,A=h.isFunction,E=h.isObject,F=h.isString;return function(g,J,v){function w(p){if(p){var y=t,a=y.push,b=[];M(b,S).chars(p);p=b.join("");a.call(y,p)}}function x(p,y){var a,b=G(p);t.push("<a ");for(a in b)t.push(a+'="'+b[a]+'" ');!K(J)||"target"in b||t.push('target="',J,'" ');t.push('href="',p.replace(/"/g,"&quot;"),'">');w(y);t.push("</a>")}if(null==g||""===g)return g;if(!F(g))throw I("notstring",g);for(var G=A(v)?v:E(v)?function(){return v}:function(){return{}},
u=g,t=[],n,B;g=u.match(D);)n=g[0],g[2]||g[4]||(n=(g[3]?"http://":"mailto:")+n),B=g.index,w(u.substr(0,B)),x(n,g[0].replace(z,"")),u=u.substring(B+g[0].length);w(u);return m(t.join(""))}}])})(window,window.angular);

//third_party/javascript/angular/v1_6/angular-animate.min.js
/*
 AngularJS v1.6.4-local+sha.617b36117
 (c) 2010-2018 Google, Inc. http://angularjs.org
 License: MIT
*/
(function(Ba,ha){'use strict';function Va(a,b,d){if(!a)throw jb("areq",b||"?",d||"required");return a}function Wa(a,b){if(!a&&!b)return"";if(!a)return b;if(!b)return a;sa(a)&&(a=a.join(" "));sa(b)&&(b=b.join(" "));return a+" "+b}function kb(a){var b={};a&&(a.to||a.from)&&(b.to=a.to,b.from=a.from);return b}function ta(a,b,d){var k="";a=sa(a)?a:a&&pa(a)&&a.length?a.split(/\s+/):[];L(a,function(r,x){r&&0<r.length&&(k+=0<x?" ":"",k+=d?b+r:r+b)});return k}function Xa(a){if(a instanceof ja)switch(a.length){case 0:return a;
case 1:if(1===a[0].nodeType)return a;break;default:return ja(Na(a))}if(1===a.nodeType)return ja(a)}function Na(a){if(!a[0])return a;for(var b=0;b<a.length;b++){var d=a[b];if(1===d.nodeType)return d}}function lb(a,b,d){L(b,function(k){a.addClass(k,d)})}function mb(a,b,d){L(b,function(k){a.removeClass(k,d)})}function Ga(a){return function(b,d){d.addClass&&(lb(a,b,d.addClass),d.addClass=null);d.removeClass&&(mb(a,b,d.removeClass),d.removeClass=null)}}function Ha(a){a=a||{};if(!a.$$prepared){var b=a.domOperation||
ka;a.domOperation=function(){a.$$domOperationFired=!0;b();b=ka};a.$$prepared=!0}return a}function ya(a,b){Ya(a,b);Za(a,b)}function Ya(a,b){b.from&&(a.css(b.from),b.from=null)}function Za(a,b){b.to&&(a.css(b.to),b.to=null)}function Ca(a,b,d){var k=b.options||{};d=d.options||{};var r=(k.addClass||"")+" "+(d.addClass||""),x=(k.removeClass||"")+" "+(d.removeClass||"");a=nb(a.attr("class"),r,x);d.preparationClasses&&(k.preparationClasses=Ia(d.preparationClasses,k.preparationClasses),delete d.preparationClasses);
r=k.domOperation!==ka?k.domOperation:null;Oa(k,d);r&&(k.domOperation=r);k.addClass=a.addClass?a.addClass:null;k.removeClass=a.removeClass?a.removeClass:null;b.addClass=k.addClass;b.removeClass=k.removeClass;return k}function nb(a,b,d){function k(e){pa(e)&&(e=e.split(" "));var g={};L(e,function(y){y.length&&(g[y]=!0)});return g}var r={};a=k(a);b=k(b);L(b,function(e,g){r[g]=1});d=k(d);L(d,function(e,g){r[g]=1===r[g]?null:-1});var x={addClass:"",removeClass:""};L(r,function(e,g){if(1===e){var y="addClass";
var C=!a[g]||a[g+"-remove"]}else-1===e&&(y="removeClass",C=a[g]||a[g+"-add"]);C&&(x[y].length&&(x[y]+=" "),x[y]+=g)});return x}function ma(a){return a instanceof ja?a[0]:a}function ob(a,b,d){var k="";b&&(k=ta(b,"ng-",!0));d.addClass&&(k=Ia(k,ta(d.addClass,"-add")));d.removeClass&&(k=Ia(k,ta(d.removeClass,"-remove")));k.length&&(d.preparationClasses=k,a.addClass(k))}function Ja(a,b){b=b?"-"+b+"s":"";Da(a,[Ea,b]);return[Ea,b]}function Pa(a,b){b=b?"paused":"";var d=va+"PlayState";Da(a,[d,b]);return[d,
b]}function Da(a,b){a.style[b[0]]=b[1]}function Ia(a,b){return a?b?a+" "+b:a:b}function $a(a,b,d){var k=Object.create(null),r=a.getComputedStyle(b)||{};L(d,function(x,e){if(x=r[x]){var g=x.charAt(0);if("-"===g||"+"===g||0<=g)x=pb(x);0===x&&(x=null);k[e]=x}});return k}function pb(a){var b=0;a=a.split(/\s*,\s*/);L(a,function(d){"s"===d.charAt(d.length-1)&&(d=d.substring(0,d.length-1));d=parseFloat(d)||0;b=b?Math.max(d,b):d});return b}function Qa(a){return 0===a||null!=a}function ab(a,b){var d=qa;a+=
"s";b?d+="Duration":a+=" linear all";return[d,a]}function bb(){var a=Object.create(null);return{flush:function(){a=Object.create(null)},count:function(b){return(b=a[b])?b.total:0},get:function(b){return(b=a[b])&&b.value},put:function(b,d){a[b]?a[b].total++:a[b]={total:1,value:d}}}}function cb(a,b,d){L(d,function(k){a[k]=Ra(a[k])?a[k]:b.style.getPropertyValue(k)})}if(void 0===Ba.ontransitionend&&void 0!==Ba.onwebkittransitionend){var qa="WebkitTransition";var db="webkitTransitionEnd transitionend"}else qa=
"transition",db="transitionend";if(void 0===Ba.onanimationend&&void 0!==Ba.onwebkitanimationend){var va="WebkitAnimation";var eb="webkitAnimationEnd animationend"}else va="animation",eb="animationend";var Ka=va+"Delay",Sa=va+"Duration",Ea=qa+"Delay",fb=qa+"Duration",jb=ha.$$minErr("ng");"use strict";"use strict";"use strict";var qb={transitionDuration:fb,transitionDelay:Ea,transitionProperty:qa+"Property",animationDuration:Sa,animationDelay:Ka,animationIterationCount:va+"IterationCount"},rb={transitionDuration:fb,
transitionDelay:Ea,animationDuration:Sa,animationDelay:Ka};"use strict";"use strict";"use strict";"use strict";"use strict";"use strict";"use strict";var Ta,Oa,L,sa,Ra,La,Ua,Ma,pa,za,ja,ka;ha.module("ngAnimate",[],function(){ka=ha.noop;Ta=ha.copy;Oa=ha.extend;ja=ha.element;L=ha.forEach;sa=ha.isArray;pa=ha.isString;Ma=ha.isObject;za=ha.isUndefined;Ra=ha.isDefined;Ua=ha.isFunction;La=ha.isElement}).info({angularVersion:"1.6.4-local+sha.617b36117"}).directive("ngAnimateSwap",["$animate","$rootScope",
function(a,b){return{restrict:"A",transclude:"element",terminal:!0,priority:600,link:function(d,k,r,x,e){var g,y;d.$watchCollection(r.ngAnimateSwap||r["for"],function(C){g&&a.leave(g);y&&(y.$destroy(),y=null);if(C||0===C)y=d.$new(),e(y,function(T){g=T;a.enter(T,null,k)})})}}}]).directive("ngAnimateChildren",["$interpolate",function(a){return{link:function(b,d,k){function r(e){d.data("$$ngAnimateChildren","on"===e||"true"===e)}var x=k.ngAnimateChildren;pa(x)&&0===x.length?d.data("$$ngAnimateChildren",
!0):(r(a(x)(b)),k.$observe("ngAnimateChildren",r))}}}]).factory("$$rAFScheduler",["$$rAF",function(a){function b(x){r=r.concat(x);d()}function d(){if(r.length){for(var x=r.shift(),e=0;e<x.length;e++)x[e]();k||a(function(){k||d()})}}var k;var r=b.queue=[];b.waitUntilQuiet=function(x){k&&k();k=a(function(){k=null;x();d()})};return b}]).provider("$$animateQueue",["$animateProvider",function(a){function b(e){if(!e)return null;e=e.split(" ");var g=Object.create(null);L(e,function(y){g[y]=!0});return g}
function d(e,g){if(e&&g){var y=b(g);return e.split(" ").some(function(C){return y[C]})}}function k(e,g,y){return x[e].some(function(C){return C(g,y)})}function r(e,g){var y=0<(e.addClass||"").length;e=0<(e.removeClass||"").length;return g?y&&e:y||e}var x=this.rules={skip:[],cancel:[],join:[]};x.join.push(function(e,g){return!e.structural&&r(e)});x.skip.push(function(e,g){return!e.structural&&!r(e)});x.skip.push(function(e,g){return"leave"===g.event&&e.structural});x.skip.push(function(e,g){return g.structural&&
2===g.state&&!e.structural});x.cancel.push(function(e,g){return g.structural&&e.structural});x.cancel.push(function(e,g){return 2===g.state&&e.structural});x.cancel.push(function(e,g){if(g.structural)return!1;var y=e.addClass;e=e.removeClass;var C=g.addClass;g=g.removeClass;return za(y)&&za(e)||za(C)&&za(g)?!1:d(y,g)||d(e,C)});this.$get=["$$rAF","$rootScope","$rootElement","$document","$$Map","$$animation","$$AnimateRunner","$templateRequest","$$jqLite","$$forceReflow","$$isDocumentHidden",function(e,
g,y,C,T,I,Y,V,z,P,M){function N(){var h=!1;return function(l){h?l():g.$$postDigest(function(){h=!0;l()})}}function n(h,l,q){var G=[],W=f[q];W&&L(W,function(A){X.call(A.node,l)?G.push(A.callback):"leave"===q&&X.call(A.node,h)&&G.push(A.callback)});return G}function t(h,l,q){var G=Na(l);return h.filter(function(W){return!(W.node===G&&(!q||W.callback===q))})}function u(h,l,q){function G(p,ca,ba,ra){wa(function(){var ea=n(na,O,ca);ea.length?e(function(){L(ea,function(la){la(Q,ba,ra)});"close"!==ba||O.parentNode||
aa.off(O)}):"close"!==ba||O.parentNode||aa.off(O)});p.progress(ca,ba,ra)}function W(p){var ca=Q,ba=A;ba.preparationClasses&&(ca.removeClass(ba.preparationClasses),ba.preparationClasses=null);ba.activeClasses&&(ca.removeClass(ba.activeClasses),ba.activeClasses=null);R(Q,A);ya(Q,A);A.domOperation();U.complete(!p)}var A=Ta(q),Q=Xa(h),O=ma(Q),na=O&&O.parentNode;A=Ha(A);var U=new Y,wa=N();sa(A.addClass)&&(A.addClass=A.addClass.join(" "));A.addClass&&!pa(A.addClass)&&(A.addClass=null);sa(A.removeClass)&&
(A.removeClass=A.removeClass.join(" "));A.removeClass&&!pa(A.removeClass)&&(A.removeClass=null);A.from&&!Ma(A.from)&&(A.from=null);A.to&&!Ma(A.to)&&(A.to=null);if(!(c&&O&&J(O,l,q)&&B(O,A)))return W(),U;var ua=0<=["enter","move","leave"].indexOf(l),F=M(),ia=F||m.get(O);q=!ia&&D.get(O)||{};var oa=!!q.state;ia||oa&&1===q.state||(ia=!H(O,na,l));if(ia)return F&&G(U,l,"start"),W(),F&&G(U,l,"close"),U;ua&&S(O);F={structural:ua,element:Q,event:l,addClass:A.addClass,removeClass:A.removeClass,close:W,options:A,
runner:U};if(oa){if(k("skip",F,q)){if(2===q.state)return W(),U;Ca(Q,q,F);return q.runner}if(k("cancel",F,q))if(2===q.state)q.runner.end();else if(q.structural)q.close();else return Ca(Q,q,F),q.runner;else if(k("join",F,q))if(2===q.state)Ca(Q,F,{});else return ob(Q,ua?l:null,A),l=F.event=q.event,A=Ca(Q,q,F),q.runner}else Ca(Q,F,{});(oa=F.structural)||(oa="animate"===F.event&&0<Object.keys(F.options.to||{}).length||r(F));if(!oa)return W(),v(O),U;var da=(q.counter||0)+1;F.counter=da;w(O,1,F);g.$$postDigest(function(){Q=
Xa(h);var p=D.get(O),ca=!p;p=p||{};var ba=0<(Q.parent()||[]).length&&("animate"===p.event||p.structural||r(p));if(ca||p.counter!==da||!ba){ca&&(R(Q,A),ya(Q,A));if(ca||ua&&p.event!==l)A.domOperation(),U.end();ba||v(O)}else l=!p.structural&&r(p,!0)?"setClass":p.event,w(O,2),p=I(Q,l,p.options),U.setHost(p),G(U,l,"start",{}),p.done(function(ra){W(!ra);(ra=D.get(O))&&ra.counter===da&&v(O);G(U,l,"close",{})})});return U}function S(h){h=h.querySelectorAll("[data-ng-animate]");L(h,function(l){var q=parseInt(l.getAttribute("data-ng-animate"),
10),G=D.get(l);if(G)switch(q){case 2:G.runner.end();case 1:D.delete(l)}})}function v(h){h.removeAttribute("data-ng-animate");D.delete(h)}function H(h,l,q){q=C[0].body;var G=ma(y),W=h===q||"HTML"===h.nodeName,A=h===G,Q=!1,O=m.get(h),na;for((h=ja.data(h,"$ngAnimatePin"))&&(l=ma(h));l;){A||(A=l===G);if(1!==l.nodeType)break;h=D.get(l)||{};if(!Q){var U=m.get(l);if(!0===U&&!1!==O){O=!0;break}else!1===U&&(O=!1);Q=h.structural}if(za(na)||!0===na)h=ja.data(l,"$$ngAnimateChildren"),Ra(h)&&(na=h);if(Q&&!1===
na)break;W||(W=l===q);if(W&&A)break;if(!A&&(h=ja.data(l,"$ngAnimatePin"))){l=ma(h);continue}l=l.parentNode}return(!Q||na)&&!0!==O&&A&&W}function w(h,l,q){q=q||{};q.state=l;h.setAttribute("data-ng-animate",l);q=(l=D.get(h))?Oa(l,q):q;D.set(h,q)}var D=new T,m=new T,c=null,E=g.$watch(function(){return 0===V.totalPendingRequests},function(h){h&&(E(),g.$$postDigest(function(){g.$$postDigest(function(){null===c&&(c=!0)})}))}),f=Object.create(null);T=a.customFilter();var K=a.classNameFilter();P=function(){return!0};
var J=T||P,B=K?function(h,l){h=[h.getAttribute("class"),l.addClass,l.removeClass].join(" ");return K.test(h)}:P,R=Ga(z),X=Ba.Node.prototype.contains||function(h){return this===h||!!(this.compareDocumentPosition(h)&16)},aa={on:function(h,l,q){var G=Na(l);f[h]=f[h]||[];f[h].push({node:G,callback:q});ja(l).on("$destroy",function(){D.get(G)||aa.off(h,l,q)})},off:function(h,l,q){if(1!==arguments.length||pa(arguments[0])){var G=f[h];G&&(f[h]=1===arguments.length?null:t(G,l,q))}else for(G in l=arguments[0],
f)f[G]=t(f[G],l)},pin:function(h,l){Va(La(h),"element","not an element");Va(La(l),"parentElement","not an element");h.data("$ngAnimatePin",l)},push:function(h,l,q,G){q=q||{};q.domOperation=G;return u(h,l,q)},enabled:function(h,l){var q=arguments.length;if(0===q)l=!!c;else if(La(h)){var G=ma(h);1===q?l=!m.get(G):m.set(G,!l)}else l=c=!!h;return l}};return aa}]}]).provider("$$animation",["$animateProvider",function(a){var b=this.drivers=[];this.$get=["$$jqLite","$rootScope","$injector","$$AnimateRunner",
"$$Map","$$rAFScheduler",function(d,k,r,x,e,g){function y(I){function Y(N){if(N.processed)return N;N.processed=!0;var n=N.domNode,t=n.parentNode;P.set(n,N);for(var u;t;){if(u=P.get(t)){u.processed||(u=Y(u));break}t=t.parentNode}(u||V).children.push(N);return N}var V={children:[]},z,P=new e;for(z=0;z<I.length;z++){var M=I[z];P.set(M.domNode,I[z]={domNode:M.domNode,fn:M.fn,children:[]})}for(z=0;z<I.length;z++)Y(I[z]);return function(N){var n=[],t=[],u;for(u=0;u<N.children.length;u++)t.push(N.children[u]);
N=t.length;var S=0,v=[];for(u=0;u<t.length;u++){var H=t[u];0>=N&&(N=S,S=0,n.push(v),v=[]);v.push(H.fn);H.children.forEach(function(w){S++;t.push(w)});N--}v.length&&n.push(v);return n}(V)}var C=[],T=Ga(d);return function(I,Y,V){function z(m){m=m.hasAttribute("ng-animate-ref")?[m]:m.querySelectorAll("[ng-animate-ref]");var c=[];L(m,function(E){var f=E.getAttribute("ng-animate-ref");f&&f.length&&c.push(E)});return c}function P(m){var c=[],E={};L(m,function(J,B){var R=ma(J.element),X=0<=["enter","move"].indexOf(J.event);
R=J.structural?z(R):[];if(R.length){var aa=X?"to":"from";L(R,function(h){var l=h.getAttribute("ng-animate-ref");E[l]=E[l]||{};E[l][aa]={animationID:B,element:ja(h)}})}else c.push(J)});var f={},K={};L(E,function(J,B){B=J.from;J=J.to;if(B&&J){var R=m[B.animationID],X=m[J.animationID],aa=B.animationID.toString();if(!K[aa]){var h=K[aa]={structural:!0,beforeStart:function(){R.beforeStart();X.beforeStart()},close:function(){R.close();X.close()},classes:M(R.classes,X.classes),from:R,to:X,anchors:[]};h.classes.length?
c.push(h):(c.push(R),c.push(X))}K[aa].anchors.push({out:B.element,"in":J.element})}else B=B?B.animationID:J.animationID,J=B.toString(),f[J]||(f[J]=!0,c.push(m[B]))});return c}function M(m,c){m=m.split(" ");c=c.split(" ");for(var E=[],f=0;f<m.length;f++){var K=m[f];if("ng-"!==K.substring(0,3))for(var J=0;J<c.length;J++)if(K===c[J]){E.push(K);break}}return E.join(" ")}function N(m){for(var c=b.length-1;0<=c;c--){var E=r.get(b[c])(m);if(E)return E}}function n(m,c){function E(f){(f=f.data("$$animationRunner"))&&
f.setHost(c)}m.from&&m.to?(E(m.from.element),E(m.to.element)):E(m.element)}function t(){var m=I.data("$$animationRunner");!m||"leave"===Y&&V.$$domOperationFired||m.end()}function u(m){I.off("$destroy",t);I.removeData("$$animationRunner");T(I,V);ya(I,V);V.domOperation();w&&d.removeClass(I,w);I.removeClass("ng-animate");v.complete(!m)}V=Ha(V);var S=0<=["enter","move","leave"].indexOf(Y),v=new x({end:function(){u()},cancel:function(){u(!0)}});if(!b.length)return u(),v;I.data("$$animationRunner",v);var H=
Wa(I.attr("class"),Wa(V.addClass,V.removeClass)),w=V.tempClasses;w&&(H+=" "+w,V.tempClasses=null);if(S){var D="ng-"+Y+"-prepare";d.addClass(I,D)}C.push({element:I,classes:H,event:Y,structural:S,options:V,beforeStart:function(){I.addClass("ng-animate");w&&d.addClass(I,w);D&&(d.removeClass(I,D),D=null)},close:u});I.on("$destroy",t);if(1<C.length)return v;k.$$postDigest(function(){var m=[];L(C,function(f){f.element.data("$$animationRunner")?m.push(f):f.close()});C.length=0;var c=P(m),E=[];L(c,function(f){E.push({domNode:ma(f.from?
f.from.element:f.element),fn:function(){f.beforeStart();var K=f.close;if((f.anchors?f.from.element||f.to.element:f.element).data("$$animationRunner")){var J=N(f);if(J)var B=J.start}B?(B=B(),B.done(function(R){K(!R)}),n(f,B)):K()}})});g(y(E))});return v}}]}]).provider("$animateCss",["$animateProvider",function(a){var b=bb(),d=bb();this.$get=["$window","$$jqLite","$$AnimateRunner","$timeout","$$forceReflow","$sniffer","$$rAFScheduler","$$animateQueue",function(k,r,x,e,g,y,C,T){function I(n,t){var u=
n.parentNode;return(u.$$ngAnimateParentKey||(u.$$ngAnimateParentKey=++M))+"-"+n.getAttribute("class")+"-"+t}function Y(n,t,u,S){if(0<b.count(u)){var v=d.get(u);v||(t=ta(t,"-stagger"),r.addClass(n,t),v=$a(k,n,S),v.animationDuration=Math.max(v.animationDuration,0),v.transitionDuration=Math.max(v.transitionDuration,0),r.removeClass(n,t),d.put(u,v))}return v||{}}function V(n){N.push(n);C.waitUntilQuiet(function(){b.flush();d.flush();for(var t=g(),u=0;u<N.length;u++)N[u](t);N.length=0})}function z(n,t,
u){t=b.get(u);t||(t=$a(k,n,qb),"infinite"===t.animationIterationCount&&(t.animationIterationCount=1));b.put(u,t);n=t;u=n.animationDelay;t=n.transitionDelay;n.maxDelay=u&&t?Math.max(u,t):u||t;n.maxDuration=Math.max(n.animationDuration*n.animationIterationCount,n.transitionDuration);return n}var P=Ga(r),M=0,N=[];return function(n,t){function u(){v()}function S(){v(!0)}function v(ea){if(!(R||aa&&X)){R=!0;X=!1;c.$$skipPreparationClasses||r.removeClass(n,Q);r.removeClass(n,na);Pa(f,!1);Ja(f,!1);L(K,function(xa){f.style[xa[0]]=
""});P(n,c);ya(n,c);Object.keys(E).length&&L(E,function(xa,Fa){xa?f.style.setProperty(Fa,xa):f.style.removeProperty(Fa)});if(c.onDone)c.onDone();G&&G.length&&n.off(G.join(" "),D);var la=n.data("$$animateCss");la&&(e.cancel(la[0].timer),n.removeData("$$animateCss"));h&&h.complete(!ea)}}function H(ea){p.blockTransition&&Ja(f,ea);p.blockKeyframeAnimation&&Pa(f,!!ea)}function w(){h=new x({end:u,cancel:S});V(ka);v();return{$$willAnimate:!1,start:function(){return h},end:u}}function D(ea){ea.stopPropagation();
var la=ea.originalEvent||ea;la.target===f&&(ea=la.$manualTimeStamp||Date.now(),la=parseFloat(la.elapsedTime.toFixed(3)),Math.max(ea-q,0)>=ba&&la>=da&&(aa=!0,v()))}function m(){function ea(){if(!R){H(!1);L(K,function(gb){f.style[gb[0]]=gb[1]});P(n,c);r.addClass(n,na);if(p.recalculateTimingStyles){O=f.getAttribute("class")+" "+Q;wa=I(f,O);F=z(f,O,wa);ia=F.maxDelay;oa=Math.max(ia,0);da=F.maxDuration;if(0===da){v();return}p.hasTransitions=0<F.transitionDuration;p.hasAnimations=0<F.animationDuration}p.applyAnimationDelay&&
(ia="boolean"!==typeof c.delay&&Qa(c.delay)?parseFloat(c.delay):ia,oa=Math.max(ia,0),F.animationDelay=ia,ca=[Ka,ia+"s"],K.push(ca),f.style[ca[0]]=ca[1]);ba=1E3*oa;ra=1E3*da;if(c.easing){var Z=c.easing;if(p.hasTransitions){var fa=qa+"TimingFunction";K.push([fa,Z]);f.style[fa]=Z}p.hasAnimations&&(fa=va+"TimingFunction",K.push([fa,Z]),f.style[fa]=Z)}F.transitionDuration&&G.push(db);F.animationDuration&&G.push(eb);q=Date.now();var Aa=ba+1.5*ra;fa=q+Aa;Z=n.data("$$animateCss")||[];var hb=!0;if(Z.length){var ib=
Z[0];(hb=fa>ib.expectedEndTime)?e.cancel(ib.timer):Z.push(v)}hb&&(Aa=e(la,Aa,!1),Z[0]={timer:Aa,expectedEndTime:fa},Z.push(v),n.data("$$animateCss",Z));if(G.length)n.on(G.join(" "),D);c.to&&(c.cleanupStyles&&cb(E,f,Object.keys(c.to)),Za(n,c))}}function la(){var Z=n.data("$$animateCss");if(Z){for(var fa=1;fa<Z.length;fa++)Z[fa]();n.removeData("$$animateCss")}}if(!R)if(f.parentNode){var xa=function(Z){if(aa)X&&Z&&(X=!1,v());else if(X=!Z,F.animationDuration)if(Z=Pa(f,X),X)K.push(Z);else{var fa=K,Aa=
fa.indexOf(Z);0<=Z&&fa.splice(Aa,1)}},Fa=0<ua&&(F.transitionDuration&&0===U.transitionDuration||F.animationDuration&&0===U.animationDuration)&&Math.max(U.animationDelay,U.transitionDelay);Fa?e(ea,Math.floor(Fa*ua*1E3),!1):ea();l.resume=function(){xa(!0)};l.pause=function(){xa(!1)}}else v()}var c=t||{};c.$$prepared||(c=Ha(Ta(c)));var E={},f=ma(n);if(!f||!f.parentNode||!T.enabled())return w();var K=[],J=n.attr("class"),B=kb(c),R,X,aa,h,l,q,G=[];if(0===c.duration||!y.animations&&!y.transitions)return w();
var W=c.event&&sa(c.event)?c.event.join(" "):c.event,A="";t="";W&&c.structural?A=ta(W,"ng-",!0):W&&(A=W);c.addClass&&(t+=ta(c.addClass,"-add"));c.removeClass&&(t.length&&(t+=" "),t+=ta(c.removeClass,"-remove"));c.applyClassesEarly&&t.length&&P(n,c);var Q=[A,t].join(" ").trim(),O=J+" "+Q,na=ta(Q,"-active");J=B.to&&0<Object.keys(B.to).length;if(!(0<(c.keyframeStyle||"").length||J||Q))return w();if(0<c.stagger){B=parseFloat(c.stagger);var U={transitionDelay:B,animationDelay:B,transitionDuration:0,animationDuration:0}}else{var wa=
I(f,O);U=Y(f,Q,wa,rb)}c.$$skipPreparationClasses||r.addClass(n,Q);c.transitionStyle&&(B=[qa,c.transitionStyle],Da(f,B),K.push(B));0<=c.duration&&(B=0<f.style[qa].length,B=ab(c.duration,B),Da(f,B),K.push(B));c.keyframeStyle&&(B=[va,c.keyframeStyle],Da(f,B),K.push(B));var ua=U?0<=c.staggerIndex?c.staggerIndex:b.count(wa):0;(W=0===ua)&&!c.skipBlocking&&Ja(f,9999);var F=z(f,O,wa),ia=F.maxDelay;var oa=Math.max(ia,0);var da=F.maxDuration;var p={};p.hasTransitions=0<F.transitionDuration;p.hasAnimations=
0<F.animationDuration;p.hasTransitionAll=p.hasTransitions&&"all"===F.transitionProperty;p.applyTransitionDuration=J&&(p.hasTransitions&&!p.hasTransitionAll||p.hasAnimations&&!p.hasTransitions);p.applyAnimationDuration=c.duration&&p.hasAnimations;p.applyTransitionDelay=Qa(c.delay)&&(p.applyTransitionDuration||p.hasTransitions);p.applyAnimationDelay=Qa(c.delay)&&p.hasAnimations;p.recalculateTimingStyles=0<t.length;if(p.applyTransitionDuration||p.applyAnimationDuration)da=c.duration?parseFloat(c.duration):
da,p.applyTransitionDuration&&(p.hasTransitions=!0,F.transitionDuration=da,B=0<f.style[qa+"Property"].length,K.push(ab(da,B))),p.applyAnimationDuration&&(p.hasAnimations=!0,F.animationDuration=da,K.push([Sa,da+"s"]));if(0===da&&!p.recalculateTimingStyles)return w();if(null!=c.delay){if("boolean"!==typeof c.delay){var ca=parseFloat(c.delay);oa=Math.max(ca,0)}p.applyTransitionDelay&&K.push([Ea,ca+"s"]);p.applyAnimationDelay&&K.push([Ka,ca+"s"])}null==c.duration&&0<F.transitionDuration&&(p.recalculateTimingStyles=
p.recalculateTimingStyles||W);var ba=1E3*oa;var ra=1E3*da;c.skipBlocking||(p.blockTransition=0<F.transitionDuration,p.blockKeyframeAnimation=0<F.animationDuration&&0<U.animationDelay&&0===U.animationDuration);c.from&&(c.cleanupStyles&&cb(E,f,Object.keys(c.from)),Ya(n,c));p.blockTransition||p.blockKeyframeAnimation?H(da):c.skipBlocking||Ja(f,!1);return{$$willAnimate:!0,end:u,start:function(){if(!R)return l={end:u,cancel:S,resume:null,pause:null},h=new x(l),V(m),h}}}}]}]).provider("$$animateCssDriver",
["$$animationProvider",function(a){a.drivers.push("$$animateCssDriver");this.$get=["$animateCss","$rootScope","$$AnimateRunner","$rootElement","$sniffer","$$jqLite","$document",function(b,d,k,r,x,e,g){function y(z,P){pa(z)&&(z=z.split(" "));pa(P)&&(P=P.split(" "));return z.filter(function(M){return-1===P.indexOf(M)}).join(" ")}function C(z,P,M){function N(w){var D={},m=ma(w).getBoundingClientRect();L(["width","height","top","left"],function(c){var E=m[c];switch(c){case "top":E+=Y.scrollTop;break;
case "left":E+=Y.scrollLeft}D[c]=Math.floor(E)+"px"});return D}function n(){var w=(M.attr("class")||"").replace(/\bng-\S+\b/g,""),D=y(w,S);w=y(S,w);D=b(u,{to:N(M),addClass:"ng-anchor-in "+D,removeClass:"ng-anchor-out "+w,delay:!0});return D.$$willAnimate?D:null}function t(){u.remove();P.removeClass("ng-animate-shim");M.removeClass("ng-animate-shim")}var u=ja(ma(P).cloneNode(!0)),S=(u.attr("class")||"").replace(/\bng-\S+\b/g,"");P.addClass("ng-animate-shim");M.addClass("ng-animate-shim");u.addClass("ng-anchor");
V.append(u);z=function(){var w=b(u,{addClass:"ng-anchor-out",delay:!0,from:N(P)});return w.$$willAnimate?w:null}();if(!z){var v=n();if(!v)return t()}var H=z||v;return{start:function(){function w(){m&&m.end()}var D,m=H.start();m.done(function(){m=null;if(!v&&(v=n()))return m=v.start(),m.done(function(){m=null;t();D.complete()}),m;t();D.complete()});return D=new k({end:w,cancel:w})}}}function T(z,P,M,N){var n=I(z,ka),t=I(P,ka),u=[];L(N,function(S){(S=C(M,S.out,S["in"]))&&u.push(S)});if(n||t||0!==u.length)return{start:function(){function S(){L(v,
function(w){w.end()})}var v=[];n&&v.push(n.start());t&&v.push(t.start());L(u,function(w){v.push(w.start())});var H=new k({end:S,cancel:S});k.all(v,function(w){H.complete(w)});return H}}}function I(z){var P=z.element,M=z.options||{};z.structural&&(M.event=z.event,M.structural=!0,M.applyClassesEarly=!0,"leave"===z.event&&(M.onDone=M.domOperation));M.preparationClasses&&(M.event=Ia(M.event,M.preparationClasses));z=b(P,M);return z.$$willAnimate?z:null}if(!x.animations&&!x.transitions)return ka;var Y=
g[0].body;d=ma(r);var V=ja(d.parentNode&&11===d.parentNode.nodeType||Y.contains(d)?d:Y);return function(z){return z.from&&z.to?T(z.from,z.to,z.classes,z.anchors):I(z)}}]}]).provider("$$animateJs",["$animateProvider",function(a){this.$get=["$injector","$$AnimateRunner","$$jqLite",function(b,d,k){function r(e){e=sa(e)?e:e.split(" ");for(var g=[],y={},C=0;C<e.length;C++){var T=e[C],I=a.$$registeredAnimations[T];I&&!y[T]&&(g.push(b.get(I)),y[T]=!0)}return g}var x=Ga(k);return function(e,g,y,C){function T(){C.domOperation();
x(e,C)}function I(H,w,D,m,c){switch(D){case "animate":w=[w,m.from,m.to,c];break;case "setClass":w=[w,P,M,c];break;case "addClass":w=[w,P,c];break;case "removeClass":w=[w,M,c];break;default:w=[w,c]}w.push(m);if(H=H.apply(H,w))if(Ua(H.start)&&(H=H.start()),H instanceof d)H.done(c);else if(Ua(H))return H;return ka}function Y(H,w,D,m,c){var E=[];L(m,function(f){var K=f[c];K&&E.push(function(){var J=!1,B=function(aa){J||(J=!0,(X||ka)(aa),R.complete(!aa))};var R=new d({end:function(){B()},cancel:function(){B(!0)}});
var X=I(K,H,w,D,function(aa){B(!1===aa)});return R})});return E}function V(H,w,D,m,c){var E=Y(H,w,D,m,c);if(0===E.length){if("beforeSetClass"===c){var f=Y(H,"removeClass",D,m,"beforeRemoveClass");var K=Y(H,"addClass",D,m,"beforeAddClass")}else"setClass"===c&&(f=Y(H,"removeClass",D,m,"removeClass"),K=Y(H,"addClass",D,m,"addClass"));f&&(E=E.concat(f));K&&(E=E.concat(K))}if(0!==E.length)return function(J){var B=[];E.length&&L(E,function(R){B.push(R())});B.length?d.all(B,J):J();return function(R){L(B,
function(X){R?X.cancel():X.end()})}}}var z=!1;3===arguments.length&&Ma(y)&&(C=y,y=null);C=Ha(C);y||(y=e.attr("class")||"",C.addClass&&(y+=" "+C.addClass),C.removeClass&&(y+=" "+C.removeClass));var P=C.addClass,M=C.removeClass,N=r(y),n;if(N.length){if("leave"===g){var t="leave";var u="afterLeave"}else t="before"+g.charAt(0).toUpperCase()+g.substr(1),u=g;"enter"!==g&&"move"!==g&&(n=V(e,g,C,N,t));var S=V(e,g,C,N,u)}if(n||S){var v;return{$$willAnimate:!0,end:function(){v?v.end():(z=!0,T(),ya(e,C),v=new d,
v.complete(!0));return v},start:function(){function H(m){z=!0;T();ya(e,C);v.complete(m)}if(v)return v;v=new d;var w,D=[];n&&D.push(function(m){w=n(m)});D.length?D.push(function(m){T();m(!0)}):T();S&&D.push(function(m){w=S(m)});v.setHost({end:function(){z||((w||ka)(void 0),H(void 0))},cancel:function(){z||((w||ka)(!0),H(!0))}});d.chain(D,H);return v}}}}}]}]).provider("$$animateJsDriver",["$$animationProvider",function(a){a.drivers.push("$$animateJsDriver");this.$get=["$$animateJs","$$AnimateRunner",
function(b,d){function k(r){return b(r.element,r.event,r.classes,r.options)}return function(r){if(r.from&&r.to){var x=k(r.from),e=k(r.to);return x||e?{start:function(){function g(){return function(){L(y,function(T){T.end()})}}var y=[];x&&y.push(x.start());e&&y.push(e.start());d.all(y,function(T){C.complete(T)});var C=new d({end:g(),cancel:g()});return C}}:void 0}return k(r)}}]}])})(window,window.angular);

//third_party/javascript/angular/v1_6/angular-aria.min.js
/*
 AngularJS v1.6.4-local+sha.617b36117
 (c) 2010-2018 Google, Inc. http://angularjs.org
 License: MIT
*/
(function(A,r){'use strict';var m="BUTTON A INPUT TEXTAREA SELECT DETAILS SUMMARY".split(" "),q=function(b,d){if(-1!==d.indexOf(b[0].nodeName))return!0};r.module("ngAria",["ng"]).info({angularVersion:"1.6.4-local+sha.617b36117"}).provider("$aria",function(){function b(h,n,c,e){return function(f,l,a){var g=a.$normalize(n);!d[g]||q(l,c)||a[g]||f.$watch(a[h],function(k){k=e?!k:!!k;l.attr(n,k)})}}var d={ariaHidden:!0,ariaChecked:!0,ariaReadonly:!0,ariaDisabled:!0,ariaRequired:!0,ariaInvalid:!0,ariaValue:!0,tabindex:!0,
bindKeydown:!0,bindRoleForClick:!0};this.config=function(h){d=r.extend(d,h)};this.$get=function(){return{config:function(h){return d[h]},$$watchExpr:b}}}).directive("ngShow",["$aria",function(b){return b.$$watchExpr("ngShow","aria-hidden",[],!0)}]).directive("ngHide",["$aria",function(b){return b.$$watchExpr("ngHide","aria-hidden",[],!1)}]).directive("ngValue",["$aria",function(b){return b.$$watchExpr("ngValue","aria-checked",m,!1)}]).directive("ngChecked",["$aria",function(b){return b.$$watchExpr("ngChecked",
"aria-checked",m,!1)}]).directive("ngReadonly",["$aria",function(b){return b.$$watchExpr("ngReadonly","aria-readonly",m,!1)}]).directive("ngRequired",["$aria",function(b){return b.$$watchExpr("ngRequired","aria-required",m,!1)}]).directive("ngModel",["$aria",function(b){function d(c,e,f,l){return b.config(e)&&!f.attr(c)&&(l||!q(f,m))}function h(c,e){return!e.attr("role")&&e.attr("type")===c&&!q(e,m)}function n(c,e){e=c.type;c=c.role;return"checkbox"===(e||c)||"menuitemcheckbox"===c?"checkbox":"radio"===
(e||c)||"menuitemradio"===c?"radio":"range"===e||"progressbar"===c||"slider"===c?"range":""}return{restrict:"A",require:"ngModel",priority:200,compile:function(c,e){var f=n(e,c);return{post:function(l,a,g,k){function t(){return k.$modelValue}function v(p){a.attr("aria-checked",g.value==k.$viewValue)}function w(){a.attr("aria-checked",!k.$isEmpty(k.$viewValue))}var u=d("tabindex","tabindex",a,!1);switch(f){case "radio":case "checkbox":h(f,a)&&a.attr("role",f);d("aria-checked","ariaChecked",a,!1)&&
l.$watch(t,"radio"===f?v:w);u&&a.attr("tabindex",0);break;case "range":h(f,a)&&a.attr("role","slider");if(b.config("ariaValue")){var x=!a.attr("aria-valuemin")&&(g.hasOwnProperty("min")||g.hasOwnProperty("ngMin")),y=!a.attr("aria-valuemax")&&(g.hasOwnProperty("max")||g.hasOwnProperty("ngMax")),z=!a.attr("aria-valuenow");x&&g.$observe("min",function(p){a.attr("aria-valuemin",p)});y&&g.$observe("max",function(p){a.attr("aria-valuemax",p)});z&&l.$watch(t,function(p){a.attr("aria-valuenow",p)})}u&&a.attr("tabindex",
0)}!g.hasOwnProperty("ngRequired")&&k.$validators.required&&d("aria-required","ariaRequired",a,!1)&&g.$observe("required",function(){a.attr("aria-required",!!g.required)});d("aria-invalid","ariaInvalid",a,!0)&&l.$watch(function(){return k.$invalid},function(p){a.attr("aria-invalid",!!p)})}}}}}]).directive("ngDisabled",["$aria",function(b){return b.$$watchExpr("ngDisabled","aria-disabled",m,!1)}]).directive("ngMessages",function(){return{restrict:"A",require:"?ngMessages",link:function(b,d,h,n){d.attr("aria-live")||
d.attr("aria-live","assertive")}}}).directive("ngClick",["$aria","$parse",function(b,d){return{restrict:"A",compile:function(h,n){var c=d(n.ngClick);return function(e,f,l){if(!q(f,m)&&(b.config("bindRoleForClick")&&!f.attr("role")&&f.attr("role","button"),b.config("tabindex")&&!f.attr("tabindex")&&f.attr("tabindex",0),b.config("bindKeydown")&&!l.ngKeydown&&!l.ngKeypress&&!l.ngKeyup))f.on("keydown",function(a){function g(){c(e,{$event:a})}var k=a.which||a.keyCode;32!==k&&13!==k||e.$apply(g)})}}}}]).directive("ngDblclick",
["$aria",function(b){return function(d,h,n){!b.config("tabindex")||h.attr("tabindex")||q(h,m)||h.attr("tabindex",0)}}])})(window,window.angular);

//third_party/javascript/closure/debug/error.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Provides a base class for custom Error objects such that the
 * stack is correctly maintained.
 *
 * You should never need to throw DebugError(msg) directly, Error(msg) is
 * sufficient.
 */

goog.module('goog.debug.Error');
goog.module.declareLegacyNamespace();



/**
 * Base class for custom error objects.
 * @param {*=} msg The message associated with the error.
 * @param {{
 *    message: (?|undefined),
 *    name: (?|undefined),
 *    lineNumber: (?|undefined),
 *    fileName: (?|undefined),
 *    stack: (?|undefined),
 *    cause: (?|undefined),
 * }=} cause The original error object to chain with.
 * @constructor
 * @extends {Error}
 */
function DebugError(msg = undefined, cause = undefined) {
  // Attempt to ensure there is a stack trace.
  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, DebugError);
  } else {
    const stack = new Error().stack;
    if (stack) {
      /** @override @type {string} */
      this.stack = stack;
    }
  }

  if (msg) {
    /** @override @type {string} */
    this.message = String(msg);
  }

  if (cause !== undefined) {
    /** @type {?} */
    this.cause = cause;
  }

  /**
   * Whether to report this error to the server. Setting this to false will
   * cause the error reporter to not report the error back to the server,
   * which can be useful if the client knows that the error has already been
   * logged on the server.
   * @type {boolean}
   */
  this.reportErrorToServer = true;
}
goog.inherits(DebugError, Error);


/** @override @type {string} */
DebugError.prototype.name = 'CustomError';


exports = DebugError;

;return exports;});

//third_party/javascript/closure/dom/nodetype.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Definition of goog.dom.NodeType.
 */

goog.provide('goog.dom.NodeType');


/**
 * Constants for the nodeType attribute in the Node interface.
 *
 * These constants match those specified in the Node interface. These are
 * usually present on the Node object in recent browsers, but not in older
 * browsers (specifically, early IEs) and thus are given here.
 *
 * In some browsers (early IEs), these are not defined on the Node object,
 * so they are provided here.
 *
 * See http://www.w3.org/TR/DOM-Level-2-Core/core.html#ID-1950641247
 * @enum {number}
 */
goog.dom.NodeType = {
  ELEMENT: 1,
  ATTRIBUTE: 2,
  TEXT: 3,
  CDATA_SECTION: 4,
  ENTITY_REFERENCE: 5,
  ENTITY: 6,
  PROCESSING_INSTRUCTION: 7,
  COMMENT: 8,
  DOCUMENT: 9,
  DOCUMENT_TYPE: 10,
  DOCUMENT_FRAGMENT: 11,
  NOTATION: 12
};

//third_party/javascript/closure/asserts/asserts.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Utilities to check the preconditions, postconditions and
 * invariants runtime.
 *
 * Methods in this package are given special treatment by the compiler
 * for type-inference. For example, <code>goog.asserts.assert(foo)</code>
 * will make the compiler treat <code>foo</code> as non-nullable. Similarly,
 * <code>goog.asserts.assertNumber(foo)</code> informs the compiler about the
 * type of <code>foo</code>. Where applicable, such assertions are preferable to
 * casts by jsdoc with <code>@type</code>.
 *
 * The compiler has an option to disable asserts. So code like:
 * <code>
 * var x = goog.asserts.assert(foo());
 * goog.asserts.assert(bar());
 * </code>
 * will be transformed into:
 * <code>
 * var x = foo();
 * </code>
 * The compiler will leave in foo() (because its return value is used),
 * but it will remove bar() because it assumes it does not have side-effects.
 *
 * Additionally, note the compiler will consider the type to be "tightened" for
 * all statements <em>after</em> the assertion. For example:
 * <code>
 * const /** ?Object &#ast;/ value = foo();
 * goog.asserts.assert(value);
 * // "value" is of type {!Object} at this point.
 * </code>
 */

goog.module('goog.asserts');
goog.module.declareLegacyNamespace();

const DebugError = goog.require('goog.debug.Error');
const NodeType = goog.require('goog.dom.NodeType');


// NOTE: this needs to be exported directly and referenced via the exports
// object because unit tests stub it out.
/**
 * @define {boolean} Whether to strip out asserts or to leave them in.
 */
exports.ENABLE_ASSERTS = goog.define('goog.asserts.ENABLE_ASSERTS', goog.DEBUG);



/**
 * Error object for failed assertions.
 * @param {string} messagePattern The pattern that was used to form message.
 * @param {!Array<*>} messageArgs The items to substitute into the pattern.
 * @constructor
 * @extends {DebugError}
 * @final
 */
function AssertionError(messagePattern, messageArgs) {
  DebugError.call(this, subs(messagePattern, messageArgs));

  /**
   * The message pattern used to format the error message. Error handlers can
   * use this to uniquely identify the assertion.
   * @type {string}
   */
  this.messagePattern = messagePattern;
}
goog.inherits(AssertionError, DebugError);
exports.AssertionError = AssertionError;

/** @override @type {string} */
AssertionError.prototype.name = 'AssertionError';


/**
 * The default error handler.
 * @param {!AssertionError} e The exception to be handled.
 * @return {void}
 */
exports.DEFAULT_ERROR_HANDLER = function(e) {
  throw e;
};


/**
 * The handler responsible for throwing or logging assertion errors.
 * @type {function(!AssertionError)}
 */
let errorHandler_ = exports.DEFAULT_ERROR_HANDLER;


/**
 * Does simple python-style string substitution.
 * subs("foo%s hot%s", "bar", "dog") becomes "foobar hotdog".
 * @param {string} pattern The string containing the pattern.
 * @param {!Array<*>} subs The items to substitute into the pattern.
 * @return {string} A copy of `str` in which each occurrence of
 *     `%s` has been replaced an argument from `var_args`.
 */
function subs(pattern, subs) {
  const splitParts = pattern.split('%s');
  let returnString = '';

  // Replace up to the last split part. We are inserting in the
  // positions between split parts.
  const subLast = splitParts.length - 1;
  for (let i = 0; i < subLast; i++) {
    // keep unsupplied as '%s'
    const sub = (i < subs.length) ? subs[i] : '%s';
    returnString += splitParts[i] + sub;
  }
  return returnString + splitParts[subLast];
}


/**
 * Throws an exception with the given message and "Assertion failed" prefixed
 * onto it.
 * @param {string} defaultMessage The message to use if givenMessage is empty.
 * @param {?Array<*>} defaultArgs The substitution arguments for defaultMessage.
 * @param {string|undefined} givenMessage Message supplied by the caller.
 * @param {!Array<*>} givenArgs The substitution arguments for givenMessage.
 * @throws {AssertionError} When the value is not a number.
 */
function doAssertFailure(defaultMessage, defaultArgs, givenMessage, givenArgs) {
  let message = 'Assertion failed';
  let args;
  if (givenMessage) {
    message += ': ' + givenMessage;
    args = givenArgs;
  } else if (defaultMessage) {
    message += ': ' + defaultMessage;
    args = defaultArgs;
  }
  // The '' + works around an Opera 10 bug in the unit tests. Without it,
  // a stack trace is added to var message above. With this, a stack trace is
  // not added until this line (it causes the extra garbage to be added after
  // the assertion message instead of in the middle of it).
  const e = new AssertionError('' + message, args || []);
  errorHandler_(e);
}


/**
 * Sets a custom error handler that can be used to customize the behavior of
 * assertion failures, for example by turning all assertion failures into log
 * messages.
 * @param {function(!AssertionError)} errorHandler
 * @return {void}
 */
exports.setErrorHandler = function(errorHandler) {
  if (exports.ENABLE_ASSERTS) {
    errorHandler_ = errorHandler;
  }
};


/**
 * Checks if the condition evaluates to true if ENABLE_ASSERTS is
 * true.
 * @template T
 * @param {T} condition The condition to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {T} The value of the condition.
 * @throws {AssertionError} When the condition evaluates to false.
 * @closurePrimitive {asserts.truthy}
 */
exports.assert = function(condition, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && !condition) {
    doAssertFailure(
        '', null, opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return condition;
};


/**
 * Checks if `value` is `null` or `undefined` if goog.asserts.ENABLE_ASSERTS is
 * true.
 *
 * @param {T} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {R} `value` with its type narrowed to exclude `null` and `undefined`.
 *
 * @template T
 * @template R :=
 *     mapunion(T, (V) =>
 *         cond(eq(V, 'null'),
 *             none(),
 *             cond(eq(V, 'undefined'),
 *                 none(),
 *                 V)))
 *  =:
 *
 * @throws {!AssertionError} When `value` is `null` or `undefined`.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertExists = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && value == null) {
    doAssertFailure(
        'Expected to exist: %s.', [value], opt_message,
        Array.prototype.slice.call(arguments, 2));
  }
  return value;
};


/**
 * Fails if goog.asserts.ENABLE_ASSERTS is true. This function is useful in case
 * when we want to add a check in the unreachable area like switch-case
 * statement:
 *
 * <pre>
 *  switch(type) {
 *    case FOO: doSomething(); break;
 *    case BAR: doSomethingElse(); break;
 *    default: goog.asserts.fail('Unrecognized type: ' + type);
 *      // We have only 2 types - "default:" section is unreachable code.
 *  }
 * </pre>
 *
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {void}
 * @throws {AssertionError} Failure.
 * @closurePrimitive {asserts.fail}
 */
exports.fail = function(opt_message, var_args) {
  if (exports.ENABLE_ASSERTS) {
    errorHandler_(new AssertionError(
        'Failure' + (opt_message ? ': ' + opt_message : ''),
        Array.prototype.slice.call(arguments, 1)));
  }
};


/**
 * Checks if the value is a number if goog.asserts.ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {number} The value, guaranteed to be a number when asserts enabled.
 * @throws {AssertionError} When the value is not a number.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertNumber = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && typeof value !== 'number') {
    doAssertFailure(
        'Expected number but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {number} */ (value);
};


/**
 * Checks if the value is a string if goog.asserts.ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {string} The value, guaranteed to be a string when asserts enabled.
 * @throws {AssertionError} When the value is not a string.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertString = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && typeof value !== 'string') {
    doAssertFailure(
        'Expected string but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {string} */ (value);
};


/**
 * Checks if the value is a function if goog.asserts.ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {!Function} The value, guaranteed to be a function when asserts
 *     enabled.
 * @throws {AssertionError} When the value is not a function.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertFunction = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && typeof value !== 'function') {
    doAssertFailure(
        'Expected function but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {!Function} */ (value);
};


/**
 * Checks if the value is an Object if goog.asserts.ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {!Object} The value, guaranteed to be a non-null object.
 * @throws {AssertionError} When the value is not an object.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertObject = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && !goog.isObject(value)) {
    doAssertFailure(
        'Expected object but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {!Object} */ (value);
};


/**
 * Checks if the value is an Array if ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {!Array<?>} The value, guaranteed to be a non-null array.
 * @throws {AssertionError} When the value is not an array.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertArray = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && !Array.isArray(value)) {
    doAssertFailure(
        'Expected array but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {!Array<?>} */ (value);
};


/**
 * Checks if the value is a boolean if goog.asserts.ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {boolean} The value, guaranteed to be a boolean when asserts are
 *     enabled.
 * @throws {AssertionError} When the value is not a boolean.
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertBoolean = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && typeof value !== 'boolean') {
    doAssertFailure(
        'Expected boolean but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {boolean} */ (value);
};


/**
 * Checks if the value is a DOM Element if goog.asserts.ENABLE_ASSERTS is true.
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @return {!Element} The value, likely to be a DOM Element when asserts are
 *     enabled.
 * @throws {AssertionError} When the value is not an Element.
 * @closurePrimitive {asserts.matchesReturn}
 * @deprecated Use goog.asserts.dom.assertIsElement instead.
 */
exports.assertElement = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS &&
      (!goog.isObject(value) ||
       /** @type {!Node} */ (value).nodeType != NodeType.ELEMENT)) {
    doAssertFailure(
        'Expected Element but got %s: %s.', [goog.typeOf(value), value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {!Element} */ (value);
};


/**
 * Checks if the value is an instance of the user-defined type if
 * goog.asserts.ENABLE_ASSERTS is true.
 *
 * The compiler may tighten the type returned by this function.
 *
 * Do not use this to ensure a value is an HTMLElement or a subclass! Cross-
 * document DOM inherits from separate - though identical - browser classes, and
 * such a check will unexpectedly fail. Please use the methods in
 * goog.asserts.dom for these purposes.
 *
 * @param {?} value The value to check.
 * @param {function(new: T, ...)} type A user-defined constructor.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @throws {AssertionError} When the value is not an instance of
 *     type.
 * @return {T}
 * @template T
 * @closurePrimitive {asserts.matchesReturn}
 */
exports.assertInstanceof = function(value, type, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS && !(value instanceof type)) {
    doAssertFailure(
        'Expected instanceof %s but got %s.', [getType(type), getType(value)],
        opt_message, Array.prototype.slice.call(arguments, 3));
  }
  return value;
};


/**
 * Checks whether the value is a finite number, if ENABLE_ASSERTS
 * is true.
 *
 * @param {*} value The value to check.
 * @param {string=} opt_message Error message in case of failure.
 * @param {...*} var_args The items to substitute into the failure message.
 * @throws {AssertionError} When the value is not a number, or is
 *     a non-finite number such as NaN, Infinity or -Infinity.
 * @return {number} The value initially passed in.
 */
exports.assertFinite = function(value, opt_message, var_args) {
  if (exports.ENABLE_ASSERTS &&
      (typeof value != 'number' || !isFinite(value))) {
    doAssertFailure(
        'Expected %s to be a finite number but it is not.', [value],
        opt_message, Array.prototype.slice.call(arguments, 2));
  }
  return /** @type {number} */ (value);
};

/**
 * Returns the type of a value. If a constructor is passed, and a suitable
 * string cannot be found, 'unknown type name' will be returned.
 * @param {*} value A constructor, object, or primitive.
 * @return {string} The best display name for the value, or 'unknown type name'.
 */
function getType(value) {
  if (value instanceof Function) {
    return value.displayName || value.name || 'unknown type name';
  } else if (value instanceof Object) {
    return /** @type {string} */ (value.constructor.displayName) ||
        value.constructor.name || Object.prototype.toString.call(value);
  } else {
    return value === null ? 'null' : typeof value;
  }
}

;return exports;});

//third_party/javascript/closure/array/array.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Utilities for manipulating arrays.
 */


goog.module('goog.array');
goog.module.declareLegacyNamespace();

const asserts = goog.require('goog.asserts');


/**
 * @define {boolean} NATIVE_ARRAY_PROTOTYPES indicates whether the code should
 * rely on Array.prototype functions, if available.
 *
 * The Array.prototype functions can be defined by external libraries like
 * Prototype and setting this flag to false forces closure to use its own
 * goog.array implementation.
 *
 * If your javascript can be loaded by a third party site and you are wary about
 * relying on the prototype functions, specify
 * "--define goog.NATIVE_ARRAY_PROTOTYPES=false" to the JSCompiler.
 *
 * Setting goog.TRUSTED_SITE to false will automatically set
 * NATIVE_ARRAY_PROTOTYPES to false.
 */
goog.NATIVE_ARRAY_PROTOTYPES =
    goog.define('goog.NATIVE_ARRAY_PROTOTYPES', goog.TRUSTED_SITE);


/**
 * @define {boolean} If true, JSCompiler will use the native implementation of
 * array functions where appropriate (e.g., `Array#filter`) and remove the
 * unused pure JS implementation.
 */
const ASSUME_NATIVE_FUNCTIONS = goog.define(
    'goog.array.ASSUME_NATIVE_FUNCTIONS', goog.FEATURESET_YEAR > 2012);
exports.ASSUME_NATIVE_FUNCTIONS = ASSUME_NATIVE_FUNCTIONS;


/**
 * Returns the last element in an array without removing it.
 * Same as {@link goog.array.last}.
 * @param {IArrayLike<T>|string} array The array.
 * @return {T} Last item in array.
 * @template T
 */
function peek(array) {
  return array[array.length - 1];
}
exports.peek = peek;


/**
 * Returns the last element in an array without removing it.
 * Same as {@link goog.array.peek}.
 * @param {IArrayLike<T>|string} array The array.
 * @return {T} Last item in array.
 * @template T
 */
exports.last = peek;

// NOTE(arv): Since most of the array functions are generic it allows you to
// pass an array-like object. Strings have a length and are considered array-
// like. However, the 'in' operator does not work on strings so we cannot just
// use the array path even if the browser supports indexing into strings. We
// therefore end up splitting the string.


/**
 * Returns the index of the first element of an array with a specified value, or
 * -1 if the element is not present in the array.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-indexof}
 *
 * @param {IArrayLike<T>|string} arr The array to be searched.
 * @param {T} obj The object for which we are searching.
 * @param {number=} opt_fromIndex The index at which to start the search. If
 *     omitted the search starts at index 0.
 * @return {number} The index of the first matching array element.
 * @template T
 */
const indexOf = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.indexOf) ?
    function(arr, obj, opt_fromIndex) {
      asserts.assert(arr.length != null);

      return Array.prototype.indexOf.call(arr, obj, opt_fromIndex);
    } :
    function(arr, obj, opt_fromIndex) {
      const fromIndex = opt_fromIndex == null ?
          0 :
          (opt_fromIndex < 0 ? Math.max(0, arr.length + opt_fromIndex) :
                               opt_fromIndex);

      if (typeof arr === 'string') {
        // Array.prototype.indexOf uses === so only strings should be found.
        if (typeof obj !== 'string' || obj.length != 1) {
          return -1;
        }
        return arr.indexOf(obj, fromIndex);
      }

      for (let i = fromIndex; i < arr.length; i++) {
        if (i in arr && arr[i] === obj) return i;
      }
      return -1;
    };
exports.indexOf = indexOf;


/**
 * Returns the index of the last element of an array with a specified value, or
 * -1 if the element is not present in the array.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-lastindexof}
 *
 * @param {!IArrayLike<T>|string} arr The array to be searched.
 * @param {T} obj The object for which we are searching.
 * @param {?number=} opt_fromIndex The index at which to start the search. If
 *     omitted the search starts at the end of the array.
 * @return {number} The index of the last matching array element.
 * @template T
 */
const lastIndexOf = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.lastIndexOf) ?
    function(arr, obj, opt_fromIndex) {
      asserts.assert(arr.length != null);

      // Firefox treats undefined and null as 0 in the fromIndex argument which
      // leads it to always return -1
      const fromIndex = opt_fromIndex == null ? arr.length - 1 : opt_fromIndex;
      return Array.prototype.lastIndexOf.call(arr, obj, fromIndex);
    } :
    function(arr, obj, opt_fromIndex) {
      let fromIndex = opt_fromIndex == null ? arr.length - 1 : opt_fromIndex;

      if (fromIndex < 0) {
        fromIndex = Math.max(0, arr.length + fromIndex);
      }

      if (typeof arr === 'string') {
        // Array.prototype.lastIndexOf uses === so only strings should be found.
        if (typeof obj !== 'string' || obj.length != 1) {
          return -1;
        }
        return arr.lastIndexOf(obj, fromIndex);
      }

      for (let i = fromIndex; i >= 0; i--) {
        if (i in arr && arr[i] === obj) return i;
      }
      return -1;
    };
exports.lastIndexOf = lastIndexOf;


/**
 * Calls a function for each element in an array. Skips holes in the array.
 * See {@link http://tinyurl.com/developer-mozilla-org-array-foreach}
 *
 * @param {IArrayLike<T>|string} arr Array or array like object over
 *     which to iterate.
 * @param {?function(this: S, T, number, ?): ?} f The function to call for every
 *     element. This function takes 3 arguments (the element, the index and the
 *     array). The return value is ignored.
 * @param {S=} opt_obj The object to be used as the value of 'this' within f.
 * @template T,S
 */
const forEach = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.forEach) ?
    function(arr, f, opt_obj) {
      asserts.assert(arr.length != null);

      Array.prototype.forEach.call(arr, f, opt_obj);
    } :
    function(arr, f, opt_obj) {
      const l = arr.length;  // must be fixed during loop... see docs
      const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
      for (let i = 0; i < l; i++) {
        if (i in arr2) {
          f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr);
        }
      }
    };
exports.forEach = forEach;


/**
 * Calls a function for each element in an array, starting from the last
 * element rather than the first.
 *
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this: S, T, number, ?): ?} f The function to call for every
 *     element. This function
 *     takes 3 arguments (the element, the index and the array). The return
 *     value is ignored.
 * @param {S=} opt_obj The object to be used as the value of 'this'
 *     within f.
 * @template T,S
 */
function forEachRight(arr, f, opt_obj) {
  const l = arr.length;  // must be fixed during loop... see docs
  const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
  for (let i = l - 1; i >= 0; --i) {
    if (i in arr2) {
      f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr);
    }
  }
}
exports.forEachRight = forEachRight;


/**
 * Calls a function for each element in an array, and if the function returns
 * true adds the element to a new array.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-filter}
 *
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?):boolean} f The function to call for
 *     every element. This function
 *     takes 3 arguments (the element, the index and the array) and must
 *     return a Boolean. If the return value is true the element is added to the
 *     result array. If it is false the element is not included.
 * @param {S=} opt_obj The object to be used as the value of 'this'
 *     within f.
 * @return {!Array<T>} a new array in which only elements that passed the test
 *     are present.
 * @template T,S
 */
const filter = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.filter) ?
    function(arr, f, opt_obj) {
      asserts.assert(arr.length != null);

      return Array.prototype.filter.call(arr, f, opt_obj);
    } :
    function(arr, f, opt_obj) {
      const l = arr.length;  // must be fixed during loop... see docs
      const res = [];
      let resLength = 0;
      const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
      for (let i = 0; i < l; i++) {
        if (i in arr2) {
          const val = arr2[i];  // in case f mutates arr2
          if (f.call(/** @type {?} */ (opt_obj), val, i, arr)) {
            res[resLength++] = val;
          }
        }
      }
      return res;
    };
exports.filter = filter;


/**
 * Calls a function for each element in an array and inserts the result into a
 * new array.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-map}
 *
 * @param {IArrayLike<VALUE>|string} arr Array or array like object
 *     over which to iterate.
 * @param {function(this:THIS, VALUE, number, ?): RESULT} f The function to call
 *     for every element. This function takes 3 arguments (the element,
 *     the index and the array) and should return something. The result will be
 *     inserted into a new array.
 * @param {THIS=} opt_obj The object to be used as the value of 'this' within f.
 * @return {!Array<RESULT>} a new array with the results from f.
 * @template THIS, VALUE, RESULT
 */
const map = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.map) ?
    function(arr, f, opt_obj) {
      asserts.assert(arr.length != null);

      return Array.prototype.map.call(arr, f, opt_obj);
    } :
    function(arr, f, opt_obj) {
      const l = arr.length;  // must be fixed during loop... see docs
      const res = new Array(l);
      const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
      for (let i = 0; i < l; i++) {
        if (i in arr2) {
          res[i] = f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr);
        }
      }
      return res;
    };
exports.map = map;


/**
 * Passes every element of an array into a function and accumulates the result.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-reduce}
 * Note that this implementation differs from the native Array.prototype.reduce
 * in that the initial value is assumed to be defined (the MDN docs linked above
 * recommend not omitting this parameter, although it is technically optional).
 *
 * For example:
 * var a = [1, 2, 3, 4];
 * reduce(a, function(r, v, i, arr) {return r + v;}, 0);
 * returns 10
 *
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {function(this:S, R, T, number, ?) : R} f The function to call for
 *     every element. This function
 *     takes 4 arguments (the function's previous result or the initial value,
 *     the value of the current array element, the current array index, and the
 *     array itself)
 *     function(previousValue, currentValue, index, array).
 * @param {?} val The initial value to pass into the function on the first call.
 * @param {S=} opt_obj  The object to be used as the value of 'this'
 *     within f.
 * @return {R} Result of evaluating f repeatedly across the values of the array.
 * @template T,S,R
 */
const reduce = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.reduce) ?
    function(arr, f, val, opt_obj) {
      asserts.assert(arr.length != null);
      if (opt_obj) {
        f = goog.bind(f, opt_obj);
      }
      return Array.prototype.reduce.call(arr, f, val);
    } :
    function(arr, f, val, opt_obj) {
      let rval = val;
      forEach(arr, function(val, index) {
        rval = f.call(/** @type {?} */ (opt_obj), rval, val, index, arr);
      });
      return rval;
    };
exports.reduce = reduce;


/**
 * Passes every element of an array into a function and accumulates the result,
 * starting from the last element and working towards the first.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-reduceright}
 *
 * For example:
 * var a = ['a', 'b', 'c'];
 * reduceRight(a, function(r, v, i, arr) {return r + v;}, '');
 * returns 'cba'
 *
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, R, T, number, ?) : R} f The function to call for
 *     every element. This function
 *     takes 4 arguments (the function's previous result or the initial value,
 *     the value of the current array element, the current array index, and the
 *     array itself)
 *     function(previousValue, currentValue, index, array).
 * @param {?} val The initial value to pass into the function on the first call.
 * @param {S=} opt_obj The object to be used as the value of 'this'
 *     within f.
 * @return {R} Object returned as a result of evaluating f repeatedly across the
 *     values of the array.
 * @template T,S,R
 */
const reduceRight = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.reduceRight) ?
    function(arr, f, val, opt_obj) {
      asserts.assert(arr.length != null);
      asserts.assert(f != null);
      if (opt_obj) {
        f = goog.bind(f, opt_obj);
      }
      return Array.prototype.reduceRight.call(arr, f, val);
    } :
    function(arr, f, val, opt_obj) {
      let rval = val;
      forEachRight(arr, function(val, index) {
        rval = f.call(/** @type {?} */ (opt_obj), rval, val, index, arr);
      });
      return rval;
    };
exports.reduceRight = reduceRight;


/**
 * Calls f for each element of an array. If any call returns true, some()
 * returns true (without checking the remaining elements). If all calls
 * return false, some() returns false.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-some}
 *
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call for
 *     for every element. This function takes 3 arguments (the element, the
 *     index and the array) and should return a boolean.
 * @param {S=} opt_obj  The object to be used as the value of 'this'
 *     within f.
 * @return {boolean} true if any element passes the test.
 * @template T,S
 */
const some = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.some) ?
    function(arr, f, opt_obj) {
      asserts.assert(arr.length != null);

      return Array.prototype.some.call(arr, f, opt_obj);
    } :
    function(arr, f, opt_obj) {
      const l = arr.length;  // must be fixed during loop... see docs
      const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
      for (let i = 0; i < l; i++) {
        if (i in arr2 && f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr)) {
          return true;
        }
      }
      return false;
    };
exports.some = some;


/**
 * Call f for each element of an array. If all calls return true, every()
 * returns true. If any call returns false, every() returns false and
 * does not continue to check the remaining elements.
 *
 * See {@link http://tinyurl.com/developer-mozilla-org-array-every}
 *
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call for
 *     for every element. This function takes 3 arguments (the element, the
 *     index and the array) and should return a boolean.
 * @param {S=} opt_obj The object to be used as the value of 'this'
 *     within f.
 * @return {boolean} false if any element fails the test.
 * @template T,S
 */
const every = goog.NATIVE_ARRAY_PROTOTYPES &&
        (ASSUME_NATIVE_FUNCTIONS || Array.prototype.every) ?
    function(arr, f, opt_obj) {
      asserts.assert(arr.length != null);

      return Array.prototype.every.call(arr, f, opt_obj);
    } :
    function(arr, f, opt_obj) {
      const l = arr.length;  // must be fixed during loop... see docs
      const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
      for (let i = 0; i < l; i++) {
        if (i in arr2 && !f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr)) {
          return false;
        }
      }
      return true;
    };
exports.every = every;


/**
 * Counts the array elements that fulfill the predicate, i.e. for which the
 * callback function returns true. Skips holes in the array.
 *
 * @param {!IArrayLike<T>|string} arr Array or array like object
 *     over which to iterate.
 * @param {function(this: S, T, number, ?): boolean} f The function to call for
 *     every element. Takes 3 arguments (the element, the index and the array).
 * @param {S=} opt_obj The object to be used as the value of 'this' within f.
 * @return {number} The number of the matching elements.
 * @template T,S
 */
function count(arr, f, opt_obj) {
  let count = 0;
  forEach(arr, function(element, index, arr) {
    if (f.call(/** @type {?} */ (opt_obj), element, index, arr)) {
      ++count;
    }
  }, opt_obj);
  return count;
}
exports.count = count;


/**
 * Search an array for the first element that satisfies a given condition and
 * return that element.
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call
 *     for every element. This function takes 3 arguments (the element, the
 *     index and the array) and should return a boolean.
 * @param {S=} opt_obj An optional "this" context for the function.
 * @return {T|null} The first array element that passes the test, or null if no
 *     element is found.
 * @template T,S
 */
function find(arr, f, opt_obj) {
  const i = findIndex(arr, f, opt_obj);
  return i < 0 ? null : typeof arr === 'string' ? arr.charAt(i) : arr[i];
}
exports.find = find;


/**
 * Search an array for the first element that satisfies a given condition and
 * return its index.
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call for
 *     every element. This function
 *     takes 3 arguments (the element, the index and the array) and should
 *     return a boolean.
 * @param {S=} opt_obj An optional "this" context for the function.
 * @return {number} The index of the first array element that passes the test,
 *     or -1 if no element is found.
 * @template T,S
 */
function findIndex(arr, f, opt_obj) {
  const l = arr.length;  // must be fixed during loop... see docs
  const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
  for (let i = 0; i < l; i++) {
    if (i in arr2 && f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr)) {
      return i;
    }
  }
  return -1;
}
exports.findIndex = findIndex;


/**
 * Search an array (in reverse order) for the last element that satisfies a
 * given condition and return that element.
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call
 *     for every element. This function
 *     takes 3 arguments (the element, the index and the array) and should
 *     return a boolean.
 * @param {S=} opt_obj An optional "this" context for the function.
 * @return {T|null} The last array element that passes the test, or null if no
 *     element is found.
 * @template T,S
 */
function findRight(arr, f, opt_obj) {
  const i = findIndexRight(arr, f, opt_obj);
  return i < 0 ? null : typeof arr === 'string' ? arr.charAt(i) : arr[i];
}
exports.findRight = findRight;


/**
 * Search an array (in reverse order) for the last element that satisfies a
 * given condition and return its index.
 * @param {IArrayLike<T>|string} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call
 *     for every element. This function
 *     takes 3 arguments (the element, the index and the array) and should
 *     return a boolean.
 * @param {S=} opt_obj An optional "this" context for the function.
 * @return {number} The index of the last array element that passes the test,
 *     or -1 if no element is found.
 * @template T,S
 */
function findIndexRight(arr, f, opt_obj) {
  const l = arr.length;  // must be fixed during loop... see docs
  const arr2 = (typeof arr === 'string') ? arr.split('') : arr;
  for (let i = l - 1; i >= 0; i--) {
    if (i in arr2 && f.call(/** @type {?} */ (opt_obj), arr2[i], i, arr)) {
      return i;
    }
  }
  return -1;
}
exports.findIndexRight = findIndexRight;


/**
 * Whether the array contains the given object.
 * @param {IArrayLike<?>|string} arr The array to test for the presence of the
 *     element.
 * @param {*} obj The object for which to test.
 * @return {boolean} true if obj is present.
 */
function contains(arr, obj) {
  return indexOf(arr, obj) >= 0;
}
exports.contains = contains;


/**
 * Whether the array is empty.
 * @param {IArrayLike<?>|string} arr The array to test.
 * @return {boolean} true if empty.
 */
function isEmpty(arr) {
  return arr.length == 0;
}
exports.isEmpty = isEmpty;


/**
 * Clears the array.
 * @param {IArrayLike<?>} arr Array or array like object to clear.
 */
function clear(arr) {
  // For non real arrays we don't have the magic length so we delete the
  // indices.
  if (!Array.isArray(arr)) {
    for (let i = arr.length - 1; i >= 0; i--) {
      delete arr[i];
    }
  }
  arr.length = 0;
}
exports.clear = clear;


/**
 * Pushes an item into an array, if it's not already in the array.
 * @param {Array<T>} arr Array into which to insert the item.
 * @param {T} obj Value to add.
 * @template T
 */
function insert(arr, obj) {
  if (!contains(arr, obj)) {
    arr.push(obj);
  }
}
exports.insert = insert;


/**
 * Inserts an object at the given index of the array.
 * @param {IArrayLike<?>} arr The array to modify.
 * @param {*} obj The object to insert.
 * @param {number=} opt_i The index at which to insert the object. If omitted,
 *      treated as 0. A negative index is counted from the end of the array.
 */
function insertAt(arr, obj, opt_i) {
  splice(arr, opt_i, 0, obj);
}
exports.insertAt = insertAt;


/**
 * Inserts at the given index of the array, all elements of another array.
 * @param {IArrayLike<?>} arr The array to modify.
 * @param {IArrayLike<?>} elementsToAdd The array of elements to add.
 * @param {number=} opt_i The index at which to insert the object. If omitted,
 *      treated as 0. A negative index is counted from the end of the array.
 */
function insertArrayAt(arr, elementsToAdd, opt_i) {
  goog.partial(splice, arr, opt_i, 0).apply(null, elementsToAdd);
}
exports.insertArrayAt = insertArrayAt;


/**
 * Inserts an object into an array before a specified object.
 * @param {Array<T>} arr The array to modify.
 * @param {T} obj The object to insert.
 * @param {T=} opt_obj2 The object before which obj should be inserted. If obj2
 *     is omitted or not found, obj is inserted at the end of the array.
 * @template T
 */
function insertBefore(arr, obj, opt_obj2) {
  let i;
  if (arguments.length == 2 || (i = indexOf(arr, opt_obj2)) < 0) {
    arr.push(obj);
  } else {
    insertAt(arr, obj, i);
  }
}
exports.insertBefore = insertBefore;


/**
 * Removes the first occurrence of a particular value from an array.
 * @param {IArrayLike<T>} arr Array from which to remove
 *     value.
 * @param {T} obj Object to remove.
 * @return {boolean} True if an element was removed.
 * @template T
 */
function remove(arr, obj) {
  const i = indexOf(arr, obj);
  let rv;
  if ((rv = i >= 0)) {
    removeAt(arr, i);
  }
  return rv;
}
exports.remove = remove;


/**
 * Removes the last occurrence of a particular value from an array.
 * @param {!IArrayLike<T>} arr Array from which to remove value.
 * @param {T} obj Object to remove.
 * @return {boolean} True if an element was removed.
 * @template T
 */
function removeLast(arr, obj) {
  const i = lastIndexOf(arr, obj);
  if (i >= 0) {
    removeAt(arr, i);
    return true;
  }
  return false;
}
exports.removeLast = removeLast;


/**
 * Removes from an array the element at index i
 * @param {IArrayLike<?>} arr Array or array like object from which to
 *     remove value.
 * @param {number} i The index to remove.
 * @return {boolean} True if an element was removed.
 */
function removeAt(arr, i) {
  asserts.assert(arr.length != null);

  // use generic form of splice
  // splice returns the removed items and if successful the length of that
  // will be 1
  return Array.prototype.splice.call(arr, i, 1).length == 1;
}
exports.removeAt = removeAt;


/**
 * Removes the first value that satisfies the given condition.
 * @param {IArrayLike<T>} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call
 *     for every element. This function
 *     takes 3 arguments (the element, the index and the array) and should
 *     return a boolean.
 * @param {S=} opt_obj An optional "this" context for the function.
 * @return {boolean} True if an element was removed.
 * @template T,S
 */
function removeIf(arr, f, opt_obj) {
  const i = findIndex(arr, f, opt_obj);
  if (i >= 0) {
    removeAt(arr, i);
    return true;
  }
  return false;
}
exports.removeIf = removeIf;


/**
 * Removes all values that satisfy the given condition.
 * @param {IArrayLike<T>} arr Array or array
 *     like object over which to iterate.
 * @param {?function(this:S, T, number, ?) : boolean} f The function to call
 *     for every element. This function
 *     takes 3 arguments (the element, the index and the array) and should
 *     return a boolean.
 * @param {S=} opt_obj An optional "this" context for the function.
 * @return {number} The number of items removed
 * @template T,S
 */
function removeAllIf(arr, f, opt_obj) {
  let removedCount = 0;
  forEachRight(arr, function(val, index) {
    if (f.call(/** @type {?} */ (opt_obj), val, index, arr)) {
      if (removeAt(arr, index)) {
        removedCount++;
      }
    }
  });
  return removedCount;
}
exports.removeAllIf = removeAllIf;


/**
 * Returns a new array that is the result of joining the arguments.  If arrays
 * are passed then their items are added, however, if non-arrays are passed they
 * will be added to the return array as is.
 *
 * Note that ArrayLike objects will be added as is, rather than having their
 * items added.
 *
 * concat([1, 2], [3, 4]) -> [1, 2, 3, 4]
 * concat(0, [1, 2]) -> [0, 1, 2]
 * concat([1, 2], null) -> [1, 2, null]
 *
 * There is bug in all current versions of IE (6, 7 and 8) where arrays created
 * in an iframe become corrupted soon (not immediately) after the iframe is
 * destroyed. This is common if loading data via goog.net.IframeIo, for example.
 * This corruption only affects the concat method which will start throwing
 * Catastrophic Errors (#-2147418113).
 *
 * See http://endoflow.com/scratch/corrupted-arrays.html for a test case.
 *
 * Internally goog.array should use this, so that all methods will continue to
 * work on these broken array objects.
 *
 * @param {...*} var_args Items to concatenate.  Arrays will have each item
 *     added, while primitives and objects will be added as is.
 * @return {!Array<?>} The new resultant array.
 */
function concat(var_args) {
  return Array.prototype.concat.apply([], arguments);
}
exports.concat = concat;


/**
 * Returns a new array that contains the contents of all the arrays passed.
 * @param {...!Array<T>} var_args
 * @return {!Array<T>}
 * @template T
 */
function join(var_args) {
  return Array.prototype.concat.apply([], arguments);
}
exports.join = join;


/**
 * Converts an object to an array.
 * @param {IArrayLike<T>|string} object  The object to convert to an
 *     array.
 * @return {!Array<T>} The object converted into an array. If object has a
 *     length property, every property indexed with a non-negative number
 *     less than length will be included in the result. If object does not
 *     have a length property, an empty array will be returned.
 * @template T
 */
function toArray(object) {
  const length = object.length;

  // If length is not a number the following is false. This case is kept for
  // backwards compatibility since there are callers that pass objects that are
  // not array like.
  if (length > 0) {
    const rv = new Array(length);
    for (let i = 0; i < length; i++) {
      rv[i] = object[i];
    }
    return rv;
  }
  return [];
}
exports.toArray = toArray;


/**
 * Does a shallow copy of an array.
 * @param {IArrayLike<T>|string} arr  Array or array-like object to
 *     clone.
 * @return {!Array<T>} Clone of the input array.
 * @template T
 */
const clone = toArray;
exports.clone = clone;


/**
 * Extends an array with another array, element, or "array like" object.
 * This function operates 'in-place', it does not create a new Array.
 *
 * Example:
 * var a = [];
 * extend(a, [0, 1]);
 * a; // [0, 1]
 * extend(a, 2);
 * a; // [0, 1, 2]
 *
 * @param {Array<VALUE>} arr1  The array to modify.
 * @param {...(IArrayLike<VALUE>|VALUE)} var_args The elements or arrays of
 *     elements to add to arr1.
 * @template VALUE
 */
function extend(arr1, var_args) {
  for (let i = 1; i < arguments.length; i++) {
    const arr2 = arguments[i];
    if (goog.isArrayLike(arr2)) {
      const len1 = arr1.length || 0;
      const len2 = arr2.length || 0;
      arr1.length = len1 + len2;
      for (let j = 0; j < len2; j++) {
        arr1[len1 + j] = arr2[j];
      }
    } else {
      arr1.push(arr2);
    }
  }
}
exports.extend = extend;


/**
 * Adds or removes elements from an array. This is a generic version of Array
 * splice. This means that it might work on other objects similar to arrays,
 * such as the arguments object.
 *
 * @param {IArrayLike<T>} arr The array to modify.
 * @param {number|undefined} index The index at which to start changing the
 *     array. If not defined, treated as 0.
 * @param {number} howMany How many elements to remove (0 means no removal. A
 *     value below 0 is treated as zero and so is any other non number. Numbers
 *     are floored).
 * @param {...T} var_args Optional, additional elements to insert into the
 *     array.
 * @return {!Array<T>} the removed elements.
 * @template T
 */
function splice(arr, index, howMany, var_args) {
  asserts.assert(arr.length != null);

  return Array.prototype.splice.apply(arr, slice(arguments, 1));
}
exports.splice = splice;


/**
 * Returns a new array from a segment of an array. This is a generic version of
 * Array slice. This means that it might work on other objects similar to
 * arrays, such as the arguments object.
 *
 * @param {IArrayLike<T>|string} arr The array from
 * which to copy a segment.
 * @param {number} start The index of the first element to copy.
 * @param {number=} opt_end The index after the last element to copy.
 * @return {!Array<T>} A new array containing the specified segment of the
 *     original array.
 * @template T
 */
function slice(arr, start, opt_end) {
  asserts.assert(arr.length != null);

  // passing 1 arg to slice is not the same as passing 2 where the second is
  // null or undefined (in that case the second argument is treated as 0).
  // we could use slice on the arguments object and then use apply instead of
  // testing the length
  if (arguments.length <= 2) {
    return Array.prototype.slice.call(arr, start);
  } else {
    return Array.prototype.slice.call(arr, start, opt_end);
  }
}
exports.slice = slice;


/**
 * Removes all duplicates from an array (retaining only the first
 * occurrence of each array element).  This function modifies the
 * array in place and doesn't change the order of the non-duplicate items.
 *
 * For objects, duplicates are identified as having the same unique ID as
 * defined by {@link goog.getUid}.
 *
 * Alternatively you can specify a custom hash function that returns a unique
 * value for each item in the array it should consider unique.
 *
 * Runtime: N,
 * Worstcase space: 2N (no dupes)
 *
 * @param {IArrayLike<T>} arr The array from which to remove
 *     duplicates.
 * @param {Array=} opt_rv An optional array in which to return the results,
 *     instead of performing the removal inplace.  If specified, the original
 *     array will remain unchanged.
 * @param {function(T):string=} opt_hashFn An optional function to use to
 *     apply to every item in the array. This function should return a unique
 *     value for each item in the array it should consider unique.
 * @template T
 */
function removeDuplicates(arr, opt_rv, opt_hashFn) {
  const returnArray = opt_rv || arr;
  const defaultHashFn = function(item) {
    // Prefix each type with a single character representing the type to
    // prevent conflicting keys (e.g. true and 'true').
    return goog.isObject(item) ? 'o' + goog.getUid(item) :
                                 (typeof item).charAt(0) + item;
  };
  const hashFn = opt_hashFn || defaultHashFn;

  let cursorInsert = 0;
  let cursorRead = 0;
  const seen = {};

  while (cursorRead < arr.length) {
    const current = arr[cursorRead++];
    const key = hashFn(current);
    if (!Object.prototype.hasOwnProperty.call(seen, key)) {
      seen[key] = true;
      returnArray[cursorInsert++] = current;
    }
  }
  returnArray.length = cursorInsert;
}
exports.removeDuplicates = removeDuplicates;


/**
 * Searches the specified array for the specified target using the binary
 * search algorithm.  If no opt_compareFn is specified, elements are compared
 * using <code>defaultCompare</code>, which compares the elements
 * using the built in < and > operators.  This will produce the expected
 * behavior for homogeneous arrays of String(s) and Number(s). The array
 * specified <b>must</b> be sorted in ascending order (as defined by the
 * comparison function).  If the array is not sorted, results are undefined.
 * If the array contains multiple instances of the specified target value, the
 * left-most instance will be found.
 *
 * Runtime: O(log n)
 *
 * @param {IArrayLike<VALUE>} arr The array to be searched.
 * @param {TARGET} target The sought value.
 * @param {function(TARGET, VALUE): number=} opt_compareFn Optional comparison
 *     function by which the array is ordered. Should take 2 arguments to
 *     compare, the target value and an element from your array, and return a
 *     negative number, zero, or a positive number depending on whether the
 *     first argument is less than, equal to, or greater than the second.
 * @return {number} Lowest index of the target value if found, otherwise
 *     (-(insertion point) - 1). The insertion point is where the value should
 *     be inserted into arr to preserve the sorted property.  Return value >= 0
 *     iff target is found.
 * @template TARGET, VALUE
 */
function binarySearch(arr, target, opt_compareFn) {
  return binarySearch_(
      arr, opt_compareFn || defaultCompare, false /* isEvaluator */, target);
}
exports.binarySearch = binarySearch;


/**
 * Selects an index in the specified array using the binary search algorithm.
 * The evaluator receives an element and determines whether the desired index
 * is before, at, or after it.  The evaluator must be consistent (formally,
 * map(map(arr, evaluator, opt_obj), goog.math.sign)
 * must be monotonically non-increasing).
 *
 * Runtime: O(log n)
 *
 * @param {IArrayLike<VALUE>} arr The array to be searched.
 * @param {function(this:THIS, VALUE, number, ?): number} evaluator
 *     Evaluator function that receives 3 arguments (the element, the index and
 *     the array). Should return a negative number, zero, or a positive number
 *     depending on whether the desired index is before, at, or after the
 *     element passed to it.
 * @param {THIS=} opt_obj The object to be used as the value of 'this'
 *     within evaluator.
 * @return {number} Index of the leftmost element matched by the evaluator, if
 *     such exists; otherwise (-(insertion point) - 1). The insertion point is
 *     the index of the first element for which the evaluator returns negative,
 *     or arr.length if no such element exists. The return value is non-negative
 *     iff a match is found.
 * @template THIS, VALUE
 */
function binarySelect(arr, evaluator, opt_obj) {
  return binarySearch_(
      arr, evaluator, true /* isEvaluator */, undefined /* opt_target */,
      opt_obj);
}
exports.binarySelect = binarySelect;


/**
 * Implementation of a binary search algorithm which knows how to use both
 * comparison functions and evaluators. If an evaluator is provided, will call
 * the evaluator with the given optional data object, conforming to the
 * interface defined in binarySelect. Otherwise, if a comparison function is
 * provided, will call the comparison function against the given data object.
 *
 * This implementation purposefully does not use goog.bind or goog.partial for
 * performance reasons.
 *
 * Runtime: O(log n)
 *
 * @param {IArrayLike<?>} arr The array to be searched.
 * @param {function(?, ?, ?): number | function(?, ?): number} compareFn
 *     Either an evaluator or a comparison function, as defined by binarySearch
 *     and binarySelect above.
 * @param {boolean} isEvaluator Whether the function is an evaluator or a
 *     comparison function.
 * @param {?=} opt_target If the function is a comparison function, then
 *     this is the target to binary search for.
 * @param {Object=} opt_selfObj If the function is an evaluator, this is an
 *     optional this object for the evaluator.
 * @return {number} Lowest index of the target value if found, otherwise
 *     (-(insertion point) - 1). The insertion point is where the value should
 *     be inserted into arr to preserve the sorted property.  Return value >= 0
 *     iff target is found.
 * @private
 */
function binarySearch_(arr, compareFn, isEvaluator, opt_target, opt_selfObj) {
  let left = 0;            // inclusive
  let right = arr.length;  // exclusive
  let found;
  while (left < right) {
    const middle = left + ((right - left) >>> 1);
    let compareResult;
    if (isEvaluator) {
      compareResult = compareFn.call(opt_selfObj, arr[middle], middle, arr);
    } else {
      // NOTE(dimvar): To avoid this cast, we'd have to use function overloading
      // for the type of binarySearch_, which the type system can't express yet.
      compareResult = /** @type {function(?, ?): number} */ (compareFn)(
          opt_target, arr[middle]);
    }
    if (compareResult > 0) {
      left = middle + 1;
    } else {
      right = middle;
      // We are looking for the lowest index so we can't return immediately.
      found = !compareResult;
    }
  }
  // left is the index if found, or the insertion point otherwise.
  // Avoiding bitwise not operator, as that causes a loss in precision for array
  // indexes outside the bounds of a 32-bit signed integer.  Array indexes have
  // a maximum value of 2^32-2 https://tc39.es/ecma262/#array-index
  return found ? left : -left - 1;
}


/**
 * Sorts the specified array into ascending order.  If no opt_compareFn is
 * specified, elements are compared using
 * <code>defaultCompare</code>, which compares the elements using
 * the built in < and > operators.  This will produce the expected behavior
 * for homogeneous arrays of String(s) and Number(s), unlike the native sort,
 * but will give unpredictable results for heterogeneous lists of strings and
 * numbers with different numbers of digits.
 *
 * This sort is not guaranteed to be stable.
 *
 * Runtime: Same as `Array.prototype.sort`
 *
 * @param {Array<T>} arr The array to be sorted.
 * @param {?function(T,T):number=} opt_compareFn Optional comparison
 *     function by which the
 *     array is to be ordered. Should take 2 arguments to compare, and return a
 *     negative number, zero, or a positive number depending on whether the
 *     first argument is less than, equal to, or greater than the second.
 * @template T
 */
function sort(arr, opt_compareFn) {
  // TODO(arv): Update type annotation since null is not accepted.
  arr.sort(opt_compareFn || defaultCompare);
}
exports.sort = sort;


/**
 * Sorts the specified array into ascending order in a stable way.  If no
 * opt_compareFn is specified, elements are compared using
 * <code>defaultCompare</code>, which compares the elements using
 * the built in < and > operators.  This will produce the expected behavior
 * for homogeneous arrays of String(s) and Number(s).
 *
 * Runtime: Same as `Array.prototype.sort`, plus an additional
 * O(n) overhead of copying the array twice.
 *
 * @param {Array<T>} arr The array to be sorted.
 * @param {?function(T, T): number=} opt_compareFn Optional comparison function
 *     by which the array is to be ordered. Should take 2 arguments to compare,
 *     and return a negative number, zero, or a positive number depending on
 *     whether the first argument is less than, equal to, or greater than the
 *     second.
 * @template T
 */
function stableSort(arr, opt_compareFn) {
  const compArr = new Array(arr.length);
  for (let i = 0; i < arr.length; i++) {
    compArr[i] = {index: i, value: arr[i]};
  }
  const valueCompareFn = opt_compareFn || defaultCompare;
  function stableCompareFn(obj1, obj2) {
    return valueCompareFn(obj1.value, obj2.value) || obj1.index - obj2.index;
  }
  sort(compArr, stableCompareFn);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = compArr[i].value;
  }
}
exports.stableSort = stableSort;


/**
 * Sort the specified array into ascending order based on item keys
 * returned by the specified key function.
 * If no opt_compareFn is specified, the keys are compared in ascending order
 * using <code>defaultCompare</code>.
 *
 * Runtime: O(S(f(n)), where S is runtime of <code>sort</code>
 * and f(n) is runtime of the key function.
 *
 * @param {Array<T>} arr The array to be sorted.
 * @param {function(T): K} keyFn Function taking array element and returning
 *     a key used for sorting this element.
 * @param {?function(K, K): number=} opt_compareFn Optional comparison function
 *     by which the keys are to be ordered. Should take 2 arguments to compare,
 *     and return a negative number, zero, or a positive number depending on
 *     whether the first argument is less than, equal to, or greater than the
 *     second.
 * @template T,K
 */
function sortByKey(arr, keyFn, opt_compareFn) {
  const keyCompareFn = opt_compareFn || defaultCompare;
  sort(arr, function(a, b) {
    return keyCompareFn(keyFn(a), keyFn(b));
  });
}
exports.sortByKey = sortByKey;


/**
 * Sorts an array of objects by the specified object key and compare
 * function. If no compare function is provided, the key values are
 * compared in ascending order using <code>defaultCompare</code>.
 * This won't work for keys that get renamed by the compiler. So use
 * {'foo': 1, 'bar': 2} rather than {foo: 1, bar: 2}.
 * @param {Array<Object>} arr An array of objects to sort.
 * @param {string} key The object key to sort by.
 * @param {Function=} opt_compareFn The function to use to compare key
 *     values.
 */
function sortObjectsByKey(arr, key, opt_compareFn) {
  sortByKey(arr, function(obj) {
    return obj[key];
  }, opt_compareFn);
}
exports.sortObjectsByKey = sortObjectsByKey;


/**
 * Tells if the array is sorted.
 * @param {!IArrayLike<T>} arr The array.
 * @param {?function(T,T):number=} opt_compareFn Function to compare the
 *     array elements.
 *     Should take 2 arguments to compare, and return a negative number, zero,
 *     or a positive number depending on whether the first argument is less
 *     than, equal to, or greater than the second.
 * @param {boolean=} opt_strict If true no equal elements are allowed.
 * @return {boolean} Whether the array is sorted.
 * @template T
 */
function isSorted(arr, opt_compareFn, opt_strict) {
  const compare = opt_compareFn || defaultCompare;
  for (let i = 1; i < arr.length; i++) {
    const compareResult = compare(arr[i - 1], arr[i]);
    if (compareResult > 0 || compareResult == 0 && opt_strict) {
      return false;
    }
  }
  return true;
}
exports.isSorted = isSorted;


/**
 * Compares two arrays for equality. Two arrays are considered equal if they
 * have the same length and their corresponding elements are equal according to
 * the comparison function.
 *
 * @param {IArrayLike<A>} arr1 The first array to compare.
 * @param {IArrayLike<B>} arr2 The second array to compare.
 * @param {?function(A,B):boolean=} opt_equalsFn Optional comparison function.
 *     Should take 2 arguments to compare, and return true if the arguments
 *     are equal. Defaults to {@link goog.array.defaultCompareEquality} which
 *     compares the elements using the built-in '===' operator.
 * @return {boolean} Whether the two arrays are equal.
 * @template A
 * @template B
 */
function equals(arr1, arr2, opt_equalsFn) {
  if (!goog.isArrayLike(arr1) || !goog.isArrayLike(arr2) ||
      arr1.length != arr2.length) {
    return false;
  }
  const l = arr1.length;
  const equalsFn = opt_equalsFn || defaultCompareEquality;
  for (let i = 0; i < l; i++) {
    if (!equalsFn(arr1[i], arr2[i])) {
      return false;
    }
  }
  return true;
}
exports.equals = equals;


/**
 * 3-way array compare function.
 * @param {!IArrayLike<VALUE>} arr1 The first array to
 *     compare.
 * @param {!IArrayLike<VALUE>} arr2 The second array to
 *     compare.
 * @param {function(VALUE, VALUE): number=} opt_compareFn Optional comparison
 *     function by which the array is to be ordered. Should take 2 arguments to
 *     compare, and return a negative number, zero, or a positive number
 *     depending on whether the first argument is less than, equal to, or
 *     greater than the second.
 * @return {number} Negative number, zero, or a positive number depending on
 *     whether the first argument is less than, equal to, or greater than the
 *     second.
 * @template VALUE
 */
function compare3(arr1, arr2, opt_compareFn) {
  const compare = opt_compareFn || defaultCompare;
  const l = Math.min(arr1.length, arr2.length);
  for (let i = 0; i < l; i++) {
    const result = compare(arr1[i], arr2[i]);
    if (result != 0) {
      return result;
    }
  }
  return defaultCompare(arr1.length, arr2.length);
}
exports.compare3 = compare3;


/**
 * Compares its two arguments for order, using the built in < and >
 * operators.
 * @param {VALUE} a The first object to be compared.
 * @param {VALUE} b The second object to be compared.
 * @return {number} A negative number, zero, or a positive number as the first
 *     argument is less than, equal to, or greater than the second,
 *     respectively.
 * @template VALUE
 */
function defaultCompare(a, b) {
  return a > b ? 1 : a < b ? -1 : 0;
}
exports.defaultCompare = defaultCompare;


/**
 * Compares its two arguments for inverse order, using the built in < and >
 * operators.
 * @param {VALUE} a The first object to be compared.
 * @param {VALUE} b The second object to be compared.
 * @return {number} A negative number, zero, or a positive number as the first
 *     argument is greater than, equal to, or less than the second,
 *     respectively.
 * @template VALUE
 */
function inverseDefaultCompare(a, b) {
  return -defaultCompare(a, b);
}
exports.inverseDefaultCompare = inverseDefaultCompare;


/**
 * Compares its two arguments for equality, using the built in === operator.
 * @param {*} a The first object to compare.
 * @param {*} b The second object to compare.
 * @return {boolean} True if the two arguments are equal, false otherwise.
 */
function defaultCompareEquality(a, b) {
  return a === b;
}
exports.defaultCompareEquality = defaultCompareEquality;


/**
 * Inserts a value into a sorted array. The array is not modified if the
 * value is already present.
 * @param {IArrayLike<VALUE>} array The array to modify.
 * @param {VALUE} value The object to insert.
 * @param {function(VALUE, VALUE): number=} opt_compareFn Optional comparison
 *     function by which the array is ordered. Should take 2 arguments to
 *     compare, and return a negative number, zero, or a positive number
 *     depending on whether the first argument is less than, equal to, or
 *     greater than the second.
 * @return {boolean} True if an element was inserted.
 * @template VALUE
 */
function binaryInsert(array, value, opt_compareFn) {
  const index = binarySearch(array, value, opt_compareFn);
  if (index < 0) {
    insertAt(array, value, -(index + 1));
    return true;
  }
  return false;
}
exports.binaryInsert = binaryInsert;


/**
 * Removes a value from a sorted array.
 * @param {!IArrayLike<VALUE>} array The array to modify.
 * @param {VALUE} value The object to remove.
 * @param {function(VALUE, VALUE): number=} opt_compareFn Optional comparison
 *     function by which the array is ordered. Should take 2 arguments to
 *     compare, and return a negative number, zero, or a positive number
 *     depending on whether the first argument is less than, equal to, or
 *     greater than the second.
 * @return {boolean} True if an element was removed.
 * @template VALUE
 */
function binaryRemove(array, value, opt_compareFn) {
  const index = binarySearch(array, value, opt_compareFn);
  return (index >= 0) ? removeAt(array, index) : false;
}
exports.binaryRemove = binaryRemove;


/**
 * Splits an array into disjoint buckets according to a splitting function.
 * @param {IArrayLike<T>} array The array.
 * @param {function(this:S, T, number, !IArrayLike<T>):?} sorter Function to
 *     call for every element.  This takes 3 arguments (the element, the index
 *     and the array) and must return a valid object key (a string, number,
 *     etc), or undefined, if that object should not be placed in a bucket.
 * @param {S=} opt_obj The object to be used as the value of 'this' within
 *     sorter.
 * @return {!Object<!Array<T>>} An object, with keys being all of the unique
 *     return values of sorter, and values being arrays containing the items for
 *     which the splitter returned that key.
 * @template T,S
 */
function bucket(array, sorter, opt_obj) {
  const buckets = {};

  for (let i = 0; i < array.length; i++) {
    const value = array[i];
    const key = sorter.call(/** @type {?} */ (opt_obj), value, i, array);
    if (key !== undefined) {
      // Push the value to the right bucket, creating it if necessary.
      const bucket = buckets[key] || (buckets[key] = []);
      bucket.push(value);
    }
  }

  return buckets;
}
exports.bucket = bucket;


/**
 * Splits an array into disjoint buckets according to a splitting function.
 * @param {!IArrayLike<V>} array The array.
 * @param {function(V, number, !IArrayLike<V>):(K|undefined)} sorter Function to
 *     call for every element.  This takes 3 arguments (the element, the index,
 *     and the array) and must return a value to use as a key, or undefined, if
 *     that object should not be placed in a bucket.
 * @return {!Map<K, !Array<V>>} A map, with keys being all of the unique
 *     return values of sorter, and values being arrays containing the items for
 *     which the splitter returned that key.
 * @template K,V
 */
function bucketToMap(array, sorter) {
  const /** !Map<K, !Array<V>> */ buckets = new Map();

  for (let i = 0; i < array.length; i++) {
    const value = array[i];
    const key = sorter(value, i, array);
    if (key !== undefined) {
      // Push the value to the right bucket, creating it if necessary.
      let bucket = buckets.get(key);
      if (!bucket) {
        bucket = [];
        buckets.set(key, bucket);
      }
      bucket.push(value);
    }
  }

  return buckets;
}
exports.bucketToMap = bucketToMap;


/**
 * Creates a new object built from the provided array and the key-generation
 * function.
 * @param {IArrayLike<T>} arr Array or array like object over
 *     which to iterate whose elements will be the values in the new object.
 * @param {?function(this:S, T, number, ?) : string} keyFunc The function to
 *     call for every element. This function takes 3 arguments (the element, the
 *     index and the array) and should return a string that will be used as the
 *     key for the element in the new object. If the function returns the same
 *     key for more than one element, the value for that key is
 *     implementation-defined.
 * @param {S=} opt_obj The object to be used as the value of 'this'
 *     within keyFunc.
 * @return {!Object<T>} The new object.
 * @template T,S
 */
function toObject(arr, keyFunc, opt_obj) {
  const ret = {};
  forEach(arr, function(element, index) {
    ret[keyFunc.call(/** @type {?} */ (opt_obj), element, index, arr)] =
        element;
  });
  return ret;
}
exports.toObject = toObject;


/**
 * Creates a new ES6 Map built from the provided array and the key-generation
 * function.
 * @param {!IArrayLike<V>} arr Array or array like object over which to iterate
 *     whose elements will be the values in the new object.
 * @param {?function(V, number, ?) : K} keyFunc The function to call for every
 *     element. This function takes 3 arguments (the element, the index, and the
 *     array) and should return a value that will be used as the key for the
 *     element in the new object. If the function returns the same key for more
 *     than one element, the value for that key is implementation-defined.
 * @return {!Map<K, V>} The new map.
 * @template K,V
 */
function toMap(arr, keyFunc) {
  const /** !Map<K, V> */ map = new Map();

  for (let i = 0; i < arr.length; i++) {
    const element = arr[i];
    map.set(keyFunc(element, i, arr), element);
  }

  return map;
}
exports.toMap = toMap;


/**
 * Creates a range of numbers in an arithmetic progression.
 *
 * Range takes 1, 2, or 3 arguments:
 * <pre>
 * range(5) is the same as range(0, 5, 1) and produces [0, 1, 2, 3, 4]
 * range(2, 5) is the same as range(2, 5, 1) and produces [2, 3, 4]
 * range(-2, -5, -1) produces [-2, -3, -4]
 * range(-2, -5, 1) produces [], since stepping by 1 wouldn't ever reach -5.
 * </pre>
 *
 * @param {number} startOrEnd The starting value of the range if an end argument
 *     is provided. Otherwise, the start value is 0, and this is the end value.
 * @param {number=} opt_end The optional end value of the range.
 * @param {number=} opt_step The step size between range values. Defaults to 1
 *     if opt_step is undefined or 0.
 * @return {!Array<number>} An array of numbers for the requested range. May be
 *     an empty array if adding the step would not converge toward the end
 *     value.
 */
function range(startOrEnd, opt_end, opt_step) {
  const array = [];
  let start = 0;
  let end = startOrEnd;
  const step = opt_step || 1;
  if (opt_end !== undefined) {
    start = startOrEnd;
    end = opt_end;
  }

  if (step * (end - start) < 0) {
    // Sign mismatch: start + step will never reach the end value.
    return [];
  }

  if (step > 0) {
    for (let i = start; i < end; i += step) {
      array.push(i);
    }
  } else {
    for (let i = start; i > end; i += step) {
      array.push(i);
    }
  }
  return array;
}
exports.range = range;


/**
 * Returns an array consisting of the given value repeated N times.
 *
 * @param {VALUE} value The value to repeat.
 * @param {number} n The repeat count.
 * @return {!Array<VALUE>} An array with the repeated value.
 * @template VALUE
 */
function repeat(value, n) {
  const array = [];
  for (let i = 0; i < n; i++) {
    array[i] = value;
  }
  return array;
}
exports.repeat = repeat;


/**
 * Returns an array consisting of every argument with all arrays
 * expanded in-place recursively.
 *
 * @param {...*} var_args The values to flatten.
 * @return {!Array<?>} An array containing the flattened values.
 */
function flatten(var_args) {
  const CHUNK_SIZE = 8192;

  const result = [];
  for (let i = 0; i < arguments.length; i++) {
    const element = arguments[i];
    if (Array.isArray(element)) {
      for (let c = 0; c < element.length; c += CHUNK_SIZE) {
        const chunk = slice(element, c, c + CHUNK_SIZE);
        const recurseResult = flatten.apply(null, chunk);
        for (let r = 0; r < recurseResult.length; r++) {
          result.push(recurseResult[r]);
        }
      }
    } else {
      result.push(element);
    }
  }
  return result;
}
exports.flatten = flatten;


/**
 * Rotates an array in-place. After calling this method, the element at
 * index i will be the element previously at index (i - n) %
 * array.length, for all values of i between 0 and array.length - 1,
 * inclusive.
 *
 * For example, suppose list comprises [t, a, n, k, s]. After invoking
 * rotate(array, 1) (or rotate(array, -4)), array will comprise [s, t, a, n, k].
 *
 * @param {!Array<T>} array The array to rotate.
 * @param {number} n The amount to rotate.
 * @return {!Array<T>} The array.
 * @template T
 */
function rotate(array, n) {
  asserts.assert(array.length != null);

  if (array.length) {
    n %= array.length;
    if (n > 0) {
      Array.prototype.unshift.apply(array, array.splice(-n, n));
    } else if (n < 0) {
      Array.prototype.push.apply(array, array.splice(0, -n));
    }
  }
  return array;
}
exports.rotate = rotate;


/**
 * Moves one item of an array to a new position keeping the order of the rest
 * of the items. Example use case: keeping a list of JavaScript objects
 * synchronized with the corresponding list of DOM elements after one of the
 * elements has been dragged to a new position.
 * @param {!IArrayLike<?>} arr The array to modify.
 * @param {number} fromIndex Index of the item to move between 0 and
 *     `arr.length - 1`.
 * @param {number} toIndex Target index between 0 and `arr.length - 1`.
 */
function moveItem(arr, fromIndex, toIndex) {
  asserts.assert(fromIndex >= 0 && fromIndex < arr.length);
  asserts.assert(toIndex >= 0 && toIndex < arr.length);
  // Remove 1 item at fromIndex.
  const removedItems = Array.prototype.splice.call(arr, fromIndex, 1);
  // Insert the removed item at toIndex.
  Array.prototype.splice.call(arr, toIndex, 0, removedItems[0]);
  // We don't use goog.array.insertAt and goog.array.removeAt, because they're
  // significantly slower than splice.
}
exports.moveItem = moveItem;


/**
 * Creates a new array for which the element at position i is an array of the
 * ith element of the provided arrays.  The returned array will only be as long
 * as the shortest array provided; additional values are ignored.  For example,
 * the result of zipping [1, 2] and [3, 4, 5] is [[1,3], [2, 4]].
 *
 * This is similar to the zip() function in Python.  See {@link
 * http://docs.python.org/library/functions.html#zip}
 *
 * @param {...!IArrayLike<?>} var_args Arrays to be combined.
 * @return {!Array<!Array<?>>} A new array of arrays created from
 *     provided arrays.
 */
function zip(var_args) {
  if (!arguments.length) {
    return [];
  }
  const result = [];
  let minLen = arguments[0].length;
  for (let i = 1; i < arguments.length; i++) {
    if (arguments[i].length < minLen) {
      minLen = arguments[i].length;
    }
  }
  for (let i = 0; i < minLen; i++) {
    const value = [];
    for (let j = 0; j < arguments.length; j++) {
      value.push(arguments[j][i]);
    }
    result.push(value);
  }
  return result;
}
exports.zip = zip;


/**
 * Shuffles the values in the specified array using the Fisher-Yates in-place
 * shuffle (also known as the Knuth Shuffle). By default, calls Math.random()
 * and so resets the state of that random number generator. Similarly, may reset
 * the state of any other specified random number generator.
 *
 * Runtime: O(n)
 *
 * @param {!Array<?>} arr The array to be shuffled.
 * @param {function():number=} opt_randFn Optional random function to use for
 *     shuffling.
 *     Takes no arguments, and returns a random number on the interval [0, 1).
 *     Defaults to Math.random() using JavaScript's built-in Math library.
 */
function shuffle(arr, opt_randFn) {
  const randFn = opt_randFn || Math.random;

  for (let i = arr.length - 1; i > 0; i--) {
    // Choose a random array index in [0, i] (inclusive with i).
    const j = Math.floor(randFn() * (i + 1));

    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
}
exports.shuffle = shuffle;


/**
 * Returns a new array of elements from arr, based on the indexes of elements
 * provided by index_arr. For example, the result of index copying
 * ['a', 'b', 'c'] with index_arr [1,0,0,2] is ['b', 'a', 'a', 'c'].
 *
 * @param {!IArrayLike<T>} arr The array to get a indexed copy from.
 * @param {!IArrayLike<number>} index_arr An array of indexes to get from arr.
 * @return {!Array<T>} A new array of elements from arr in index_arr order.
 * @template T
 */
function copyByIndex(arr, index_arr) {
  const result = [];
  forEach(index_arr, function(index) {
    result.push(arr[index]);
  });
  return result;
}
exports.copyByIndex = copyByIndex;


/**
 * Maps each element of the input array into zero or more elements of the output
 * array.
 *
 * @param {!IArrayLike<VALUE>|string} arr Array or array like object
 *     over which to iterate.
 * @param {function(this:THIS, VALUE, number, ?): !Array<RESULT>} f The function
 *     to call for every element. This function takes 3 arguments (the element,
 *     the index and the array) and should return an array. The result will be
 *     used to extend a new array.
 * @param {THIS=} opt_obj The object to be used as the value of 'this' within f.
 * @return {!Array<RESULT>} a new array with the concatenation of all arrays
 *     returned from f.
 * @template THIS, VALUE, RESULT
 */
function concatMap(arr, f, opt_obj) {
  return concat.apply([], map(arr, f, opt_obj));
}
exports.concatMap = concatMap;

;return exports;});

//third_party/javascript/closure/dom/htmlelement.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

goog.provide('goog.dom.HtmlElement');



/**
 * This subclass of HTMLElement is used when only a HTMLElement is possible and
 * not any of its subclasses. Normally, a type can refer to an instance of
 * itself or an instance of any subtype. More concretely, if HTMLElement is used
 * then the compiler must assume that it might still be e.g. HTMLScriptElement.
 * With this, the type check knows that it couldn't be any special element.
 *
 * @constructor
 * @extends {HTMLElement}
 */
goog.dom.HtmlElement = function() {};

//third_party/javascript/closure/dom/tagname.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Defines the goog.dom.TagName class. Its constants enumerate
 * all HTML tag names specified in either the W3C HTML 4.01 index of elements
 * or the HTML5.1 specification.
 *
 * References:
 * https://www.w3.org/TR/html401/index/elements.html
 * https://www.w3.org/TR/html51/dom.html#elements
 */
goog.provide('goog.dom.TagName');

goog.require('goog.dom.HtmlElement');

/**
 * A tag name for an HTML element.
 *
 * This type is a lie. All instances are actually strings. Do not implement it.
 *
 * It exists because we need an object type to host the template type parameter,
 * and that's not possible with literal or enum types. It is a record type so
 * that runtime type checks don't try to validate the lie.
 *
 * @template T
 * @record
 */
goog.dom.TagName = class {
  /**
   * Cast a string into the tagname for the associated constructor.
   *
   * @template T
   * @param {string} name
   * @param {function(new:T, ...?)} type
   * @return {!goog.dom.TagName<T>}
   */
  static cast(name, type) {
    return /** @type {?} */ (name);
  }

  /** @suppress {unusedPrivateMembers} */
  constructor() {
    /** @private {null} */
    this.googDomTagName_doNotImplementThisTypeOrElse_;

    /** @private {T} */
    this.ensureTypeScriptRemembersTypeT_;
  }

  /**
   * Appease the compiler that instances are stringafiable for the
   * purpose of being a dictionary key.
   *
   * Never implemented; always backed by `String::toString`.
   *
   * @override
   * @return {string}
   */
  toString() {}
};



/** @const {!goog.dom.TagName<!HTMLAnchorElement>} */
goog.dom.TagName.A = /** @type {?} */ ('A');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.ABBR = /** @type {?} */ ('ABBR');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.ACRONYM = /** @type {?} */ ('ACRONYM');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.ADDRESS = /** @type {?} */ ('ADDRESS');

/** @const {!goog.dom.TagName<!HTMLAppletElement>} */
goog.dom.TagName.APPLET = /** @type {?} */ ('APPLET');

/** @const {!goog.dom.TagName<!HTMLAreaElement>} */
goog.dom.TagName.AREA = /** @type {?} */ ('AREA');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.ARTICLE = /** @type {?} */ ('ARTICLE');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.ASIDE = /** @type {?} */ ('ASIDE');

/** @const {!goog.dom.TagName<!HTMLAudioElement>} */
goog.dom.TagName.AUDIO = /** @type {?} */ ('AUDIO');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.B = /** @type {?} */ ('B');

/** @const {!goog.dom.TagName<!HTMLBaseElement>} */
goog.dom.TagName.BASE = /** @type {?} */ ('BASE');

/** @const {!goog.dom.TagName<!HTMLBaseFontElement>} */
goog.dom.TagName.BASEFONT = /** @type {?} */ ('BASEFONT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.BDI = /** @type {?} */ ('BDI');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.BDO = /** @type {?} */ ('BDO');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.BIG = /** @type {?} */ ('BIG');

/** @const {!goog.dom.TagName<!HTMLQuoteElement>} */
goog.dom.TagName.BLOCKQUOTE = /** @type {?} */ ('BLOCKQUOTE');

/** @const {!goog.dom.TagName<!HTMLBodyElement>} */
goog.dom.TagName.BODY = /** @type {?} */ ('BODY');

/** @const {!goog.dom.TagName<!HTMLBRElement>} */
goog.dom.TagName.BR = /** @type {?} */ ('BR');

/** @const {!goog.dom.TagName<!HTMLButtonElement>} */
goog.dom.TagName.BUTTON = /** @type {?} */ ('BUTTON');

/** @const {!goog.dom.TagName<!HTMLCanvasElement>} */
goog.dom.TagName.CANVAS = /** @type {?} */ ('CANVAS');

/** @const {!goog.dom.TagName<!HTMLTableCaptionElement>} */
goog.dom.TagName.CAPTION = /** @type {?} */ ('CAPTION');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.CENTER = /** @type {?} */ ('CENTER');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.CITE = /** @type {?} */ ('CITE');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.CODE = /** @type {?} */ ('CODE');

/** @const {!goog.dom.TagName<!HTMLTableColElement>} */
goog.dom.TagName.COL = /** @type {?} */ ('COL');

/** @const {!goog.dom.TagName<!HTMLTableColElement>} */
goog.dom.TagName.COLGROUP = /** @type {?} */ ('COLGROUP');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.COMMAND = /** @type {?} */ ('COMMAND');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.DATA = /** @type {?} */ ('DATA');

/** @const {!goog.dom.TagName<!HTMLDataListElement>} */
goog.dom.TagName.DATALIST = /** @type {?} */ ('DATALIST');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.DD = /** @type {?} */ ('DD');

/** @const {!goog.dom.TagName<!HTMLModElement>} */
goog.dom.TagName.DEL = /** @type {?} */ ('DEL');

/** @const {!goog.dom.TagName<!HTMLDetailsElement>} */
goog.dom.TagName.DETAILS = /** @type {?} */ ('DETAILS');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.DFN = /** @type {?} */ ('DFN');

/** @const {!goog.dom.TagName<!HTMLDialogElement>} */
goog.dom.TagName.DIALOG = /** @type {?} */ ('DIALOG');

/** @const {!goog.dom.TagName<!HTMLDirectoryElement>} */
goog.dom.TagName.DIR = /** @type {?} */ ('DIR');

/** @const {!goog.dom.TagName<!HTMLDivElement>} */
goog.dom.TagName.DIV = /** @type {?} */ ('DIV');

/** @const {!goog.dom.TagName<!HTMLDListElement>} */
goog.dom.TagName.DL = /** @type {?} */ ('DL');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.DT = /** @type {?} */ ('DT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.EM = /** @type {?} */ ('EM');

/** @const {!goog.dom.TagName<!HTMLEmbedElement>} */
goog.dom.TagName.EMBED = /** @type {?} */ ('EMBED');

/** @const {!goog.dom.TagName<!HTMLFieldSetElement>} */
goog.dom.TagName.FIELDSET = /** @type {?} */ ('FIELDSET');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.FIGCAPTION = /** @type {?} */ ('FIGCAPTION');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.FIGURE = /** @type {?} */ ('FIGURE');

/** @const {!goog.dom.TagName<!HTMLFontElement>} */
goog.dom.TagName.FONT = /** @type {?} */ ('FONT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.FOOTER = /** @type {?} */ ('FOOTER');

/** @const {!goog.dom.TagName<!HTMLFormElement>} */
goog.dom.TagName.FORM = /** @type {?} */ ('FORM');

/** @const {!goog.dom.TagName<!HTMLFrameElement>} */
goog.dom.TagName.FRAME = /** @type {?} */ ('FRAME');

/** @const {!goog.dom.TagName<!HTMLFrameSetElement>} */
goog.dom.TagName.FRAMESET = /** @type {?} */ ('FRAMESET');

/** @const {!goog.dom.TagName<!HTMLHeadingElement>} */
goog.dom.TagName.H1 = /** @type {?} */ ('H1');

/** @const {!goog.dom.TagName<!HTMLHeadingElement>} */
goog.dom.TagName.H2 = /** @type {?} */ ('H2');

/** @const {!goog.dom.TagName<!HTMLHeadingElement>} */
goog.dom.TagName.H3 = /** @type {?} */ ('H3');

/** @const {!goog.dom.TagName<!HTMLHeadingElement>} */
goog.dom.TagName.H4 = /** @type {?} */ ('H4');

/** @const {!goog.dom.TagName<!HTMLHeadingElement>} */
goog.dom.TagName.H5 = /** @type {?} */ ('H5');

/** @const {!goog.dom.TagName<!HTMLHeadingElement>} */
goog.dom.TagName.H6 = /** @type {?} */ ('H6');

/** @const {!goog.dom.TagName<!HTMLHeadElement>} */
goog.dom.TagName.HEAD = /** @type {?} */ ('HEAD');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.HEADER = /** @type {?} */ ('HEADER');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.HGROUP = /** @type {?} */ ('HGROUP');

/** @const {!goog.dom.TagName<!HTMLHRElement>} */
goog.dom.TagName.HR = /** @type {?} */ ('HR');

/** @const {!goog.dom.TagName<!HTMLHtmlElement>} */
goog.dom.TagName.HTML = /** @type {?} */ ('HTML');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.I = /** @type {?} */ ('I');

/** @const {!goog.dom.TagName<!HTMLIFrameElement>} */
goog.dom.TagName.IFRAME = /** @type {?} */ ('IFRAME');

/** @const {!goog.dom.TagName<!HTMLImageElement>} */
goog.dom.TagName.IMG = /** @type {?} */ ('IMG');

/** @const {!goog.dom.TagName<!HTMLInputElement>} */
goog.dom.TagName.INPUT = /** @type {?} */ ('INPUT');

/** @const {!goog.dom.TagName<!HTMLModElement>} */
goog.dom.TagName.INS = /** @type {?} */ ('INS');

/** @const {!goog.dom.TagName<!HTMLIsIndexElement>} */
goog.dom.TagName.ISINDEX = /** @type {?} */ ('ISINDEX');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.KBD = /** @type {?} */ ('KBD');

// HTMLKeygenElement is deprecated.
/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.KEYGEN = /** @type {?} */ ('KEYGEN');

/** @const {!goog.dom.TagName<!HTMLLabelElement>} */
goog.dom.TagName.LABEL = /** @type {?} */ ('LABEL');

/** @const {!goog.dom.TagName<!HTMLLegendElement>} */
goog.dom.TagName.LEGEND = /** @type {?} */ ('LEGEND');

/** @const {!goog.dom.TagName<!HTMLLIElement>} */
goog.dom.TagName.LI = /** @type {?} */ ('LI');

/** @const {!goog.dom.TagName<!HTMLLinkElement>} */
goog.dom.TagName.LINK = /** @type {?} */ ('LINK');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.MAIN = /** @type {?} */ ('MAIN');

/** @const {!goog.dom.TagName<!HTMLMapElement>} */
goog.dom.TagName.MAP = /** @type {?} */ ('MAP');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.MARK = /** @type {?} */ ('MARK');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.MATH = /** @type {?} */ ('MATH');

/** @const {!goog.dom.TagName<!HTMLMenuElement>} */
goog.dom.TagName.MENU = /** @type {?} */ ('MENU');

/** @const {!goog.dom.TagName<!HTMLMenuItemElement>} */
goog.dom.TagName.MENUITEM = /** @type {?} */ ('MENUITEM');

/** @const {!goog.dom.TagName<!HTMLMetaElement>} */
goog.dom.TagName.META = /** @type {?} */ ('META');

/** @const {!goog.dom.TagName<!HTMLMeterElement>} */
goog.dom.TagName.METER = /** @type {?} */ ('METER');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.NAV = /** @type {?} */ ('NAV');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.NOFRAMES = /** @type {?} */ ('NOFRAMES');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.NOSCRIPT = /** @type {?} */ ('NOSCRIPT');

/** @const {!goog.dom.TagName<!HTMLObjectElement>} */
goog.dom.TagName.OBJECT = /** @type {?} */ ('OBJECT');

/** @const {!goog.dom.TagName<!HTMLOListElement>} */
goog.dom.TagName.OL = /** @type {?} */ ('OL');

/** @const {!goog.dom.TagName<!HTMLOptGroupElement>} */
goog.dom.TagName.OPTGROUP = /** @type {?} */ ('OPTGROUP');

/** @const {!goog.dom.TagName<!HTMLOptionElement>} */
goog.dom.TagName.OPTION = /** @type {?} */ ('OPTION');

/** @const {!goog.dom.TagName<!HTMLOutputElement>} */
goog.dom.TagName.OUTPUT = /** @type {?} */ ('OUTPUT');

/** @const {!goog.dom.TagName<!HTMLParagraphElement>} */
goog.dom.TagName.P = /** @type {?} */ ('P');

/** @const {!goog.dom.TagName<!HTMLParamElement>} */
goog.dom.TagName.PARAM = /** @type {?} */ ('PARAM');

/** @const {!goog.dom.TagName<!HTMLPictureElement>} */
goog.dom.TagName.PICTURE = /** @type {?} */ ('PICTURE');

/** @const {!goog.dom.TagName<!HTMLPreElement>} */
goog.dom.TagName.PRE = /** @type {?} */ ('PRE');

/** @const {!goog.dom.TagName<!HTMLProgressElement>} */
goog.dom.TagName.PROGRESS = /** @type {?} */ ('PROGRESS');

/** @const {!goog.dom.TagName<!HTMLQuoteElement>} */
goog.dom.TagName.Q = /** @type {?} */ ('Q');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.RP = /** @type {?} */ ('RP');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.RT = /** @type {?} */ ('RT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.RTC = /** @type {?} */ ('RTC');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.RUBY = /** @type {?} */ ('RUBY');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.S = /** @type {?} */ ('S');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SAMP = /** @type {?} */ ('SAMP');

/** @const {!goog.dom.TagName<!HTMLScriptElement>} */
goog.dom.TagName.SCRIPT = /** @type {?} */ ('SCRIPT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SECTION = /** @type {?} */ ('SECTION');

/** @const {!goog.dom.TagName<!HTMLSelectElement>} */
goog.dom.TagName.SELECT = /** @type {?} */ ('SELECT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SMALL = /** @type {?} */ ('SMALL');

/** @const {!goog.dom.TagName<!HTMLSourceElement>} */
goog.dom.TagName.SOURCE = /** @type {?} */ ('SOURCE');

/** @const {!goog.dom.TagName<!HTMLSpanElement>} */
goog.dom.TagName.SPAN = /** @type {?} */ ('SPAN');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.STRIKE = /** @type {?} */ ('STRIKE');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.STRONG = /** @type {?} */ ('STRONG');

/** @const {!goog.dom.TagName<!HTMLStyleElement>} */
goog.dom.TagName.STYLE = /** @type {?} */ ('STYLE');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SUB = /** @type {?} */ ('SUB');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SUMMARY = /** @type {?} */ ('SUMMARY');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SUP = /** @type {?} */ ('SUP');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.SVG = /** @type {?} */ ('SVG');

/** @const {!goog.dom.TagName<!HTMLTableElement>} */
goog.dom.TagName.TABLE = /** @type {?} */ ('TABLE');

/** @const {!goog.dom.TagName<!HTMLTableSectionElement>} */
goog.dom.TagName.TBODY = /** @type {?} */ ('TBODY');

/** @const {!goog.dom.TagName<!HTMLTableCellElement>} */
goog.dom.TagName.TD = /** @type {?} */ ('TD');

/** @const {!goog.dom.TagName<!HTMLTemplateElement>} */
goog.dom.TagName.TEMPLATE = /** @type {?} */ ('TEMPLATE');

/** @const {!goog.dom.TagName<!HTMLTextAreaElement>} */
goog.dom.TagName.TEXTAREA = /** @type {?} */ ('TEXTAREA');

/** @const {!goog.dom.TagName<!HTMLTableSectionElement>} */
goog.dom.TagName.TFOOT = /** @type {?} */ ('TFOOT');

/** @const {!goog.dom.TagName<!HTMLTableCellElement>} */
goog.dom.TagName.TH = /** @type {?} */ ('TH');

/** @const {!goog.dom.TagName<!HTMLTableSectionElement>} */
goog.dom.TagName.THEAD = /** @type {?} */ ('THEAD');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.TIME = /** @type {?} */ ('TIME');

/** @const {!goog.dom.TagName<!HTMLTitleElement>} */
goog.dom.TagName.TITLE = /** @type {?} */ ('TITLE');

/** @const {!goog.dom.TagName<!HTMLTableRowElement>} */
goog.dom.TagName.TR = /** @type {?} */ ('TR');

/** @const {!goog.dom.TagName<!HTMLTrackElement>} */
goog.dom.TagName.TRACK = /** @type {?} */ ('TRACK');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.TT = /** @type {?} */ ('TT');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.U = /** @type {?} */ ('U');

/** @const {!goog.dom.TagName<!HTMLUListElement>} */
goog.dom.TagName.UL = /** @type {?} */ ('UL');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.VAR = /** @type {?} */ ('VAR');

/** @const {!goog.dom.TagName<!HTMLVideoElement>} */
goog.dom.TagName.VIDEO = /** @type {?} */ ('VIDEO');

/** @const {!goog.dom.TagName<!goog.dom.HtmlElement>} */
goog.dom.TagName.WBR = /** @type {?} */ ('WBR');

//third_party/javascript/closure/object/object.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Utilities for manipulating objects/maps/hashes.
 */
goog.module('goog.object');
goog.module.declareLegacyNamespace();

/**
 * Calls a function for each element in an object/map/hash.
 * @param {?Object<K,V>} obj The object over which to iterate.
 * @param {function(this:T,V,?,?Object<K,V>):?} f The function to call for every
 *     element. This function takes 3 arguments (the value, the key and the
 *     object) and the return value is ignored.
 * @param {T=} opt_obj This is used as the 'this' object within f.
 * @return {void}
 * @template T,K,V
 */
function forEach(obj, f, opt_obj) {
  for (const key in obj) {
    f.call(/** @type {?} */ (opt_obj), obj[key], key, obj);
  }
}

/**
 * Calls a function for each element in an object/map/hash. If that call returns
 * true, adds the element to a new object.
 * @param {?Object<K,V>} obj The object over which to iterate.
 * @param {function(this:T,V,?,?Object<K,V>):boolean} f The function to call for
 *     every element. This function takes 3 arguments (the value, the key and
 *     the object) and should return a boolean. If the return value is true the
 *     element is added to the result object. If it is false the element is not
 *     included.
 * @param {T=} opt_obj This is used as the 'this' object within f.
 * @return {!Object<K,V>} a new object in which only elements that passed the
 *     test are present.
 * @template T,K,V
 */
function filter(obj, f, opt_obj) {
  const res = {};
  for (const key in obj) {
    if (f.call(/** @type {?} */ (opt_obj), obj[key], key, obj)) {
      res[key] = obj[key];
    }
  }
  return res;
}

/**
 * For every element in an object/map/hash calls a function and inserts the
 * result into a new object.
 * @param {?Object<K,V>} obj The object over which to iterate.
 * @param {function(this:T,V,?,?Object<K,V>):R} f The function to call for every
 *     element. This function takes 3 arguments (the value, the key and the
 *     object) and should return something. The result will be inserted into a
 *     new object.
 * @param {T=} opt_obj This is used as the 'this' object within f.
 * @return {!Object<K,R>} a new object with the results from f.
 * @template T,K,V,R
 */
function map(obj, f, opt_obj) {
  const res = {};
  for (const key in obj) {
    res[key] = f.call(/** @type {?} */ (opt_obj), obj[key], key, obj);
  }
  return res;
}

/**
 * Calls a function for each element in an object/map/hash. If any
 * call returns true, returns true (without checking the rest). If
 * all calls return false, returns false.
 * @param {?Object<K,V>} obj The object to check.
 * @param {function(this:T,V,?,?Object<K,V>):boolean} f The function to call for
 *     every element. This function takes 3 arguments (the value, the key and
 *     the object) and should return a boolean.
 * @param {T=} opt_obj This is used as the 'this' object within f.
 * @return {boolean} true if any element passes the test.
 * @template T,K,V
 */
function some(obj, f, opt_obj) {
  for (const key in obj) {
    if (f.call(/** @type {?} */ (opt_obj), obj[key], key, obj)) {
      return true;
    }
  }
  return false;
}

/**
 * Calls a function for each element in an object/map/hash. If
 * all calls return true, returns true. If any call returns false, returns
 * false at this point and does not continue to check the remaining elements.
 * @param {?Object<K,V>} obj The object to check.
 * @param {?function(this:T,V,?,?Object<K,V>):boolean} f The function to call
 *     for every element. This function takes 3 arguments (the value, the key
 *     and the object) and should return a boolean.
 * @param {T=} opt_obj This is used as the 'this' object within f.
 * @return {boolean} false if any element fails the test.
 * @template T,K,V
 */
function every(obj, f, opt_obj) {
  for (const key in obj) {
    if (!f.call(/** @type {?} */ (opt_obj), obj[key], key, obj)) {
      return false;
    }
  }
  return true;
}

/**
 * Returns the number of key-value pairs in the object map.
 * @param {?Object} obj The object for which to get the number of key-value
 *     pairs.
 * @return {number} The number of key-value pairs in the object map.
 */
function getCount(obj) {
  let rv = 0;
  for (const key in obj) {
    rv++;
  }
  return rv;
}

/**
 * Returns one key from the object map, if any exists.
 * For map literals the returned key will be the first one in most of the
 * browsers (a know exception is Konqueror).
 * @param {?Object} obj The object to pick a key from.
 * @return {string|undefined} The key or undefined if the object is empty.
 */
function getAnyKey(obj) {
  for (const key in obj) {
    return key;
  }
}

/**
 * Returns one value from the object map, if any exists.
 * For map literals the returned value will be the first one in most of the
 * browsers (a know exception is Konqueror).
 * @param {?Object<K,V>} obj The object to pick a value from.
 * @return {V|undefined} The value or undefined if the object is empty.
 * @template K,V
 */
function getAnyValue(obj) {
  for (const key in obj) {
    return obj[key];
  }
}

/**
 * Whether the object/hash/map contains the given object as a value.
 * An alias for containsValue(obj, val).
 * @param {?Object<K,V>} obj The object in which to look for val.
 * @param {V} val The object for which to check.
 * @return {boolean} true if val is present.
 * @template K,V
 */
function contains(obj, val) {
  return containsValue(obj, val);
}

/**
 * Returns the values of the object/map/hash.
 * @param {?Object<K,V>} obj The object from which to get the values.
 * @return {!Array<V>} The values in the object/map/hash.
 * @template K,V
 */
function getValues(obj) {
  const res = [];
  let i = 0;
  for (const key in obj) {
    res[i++] = obj[key];
  }
  return res;
}

/**
 * Returns the keys of the object/map/hash.
 * @param {?Object} obj The object from which to get the keys.
 * @return {!Array<string>} Array of property keys.
 */
function getKeys(obj) {
  const res = [];
  let i = 0;
  for (const key in obj) {
    res[i++] = key;
  }
  return res;
}

/**
 * Get a value from an object multiple levels deep.  This is useful for
 * pulling values from deeply nested objects, such as JSON responses.
 * Example usage: getValueByKeys(jsonObj, 'foo', 'entries', 3)
 * @param {?Object} obj An object to get the value from. Can be array-like.
 * @param {...(string|number|!IArrayLike<number|string>)} var_args A number of
 *     keys (as strings, or numbers, for array-like objects). Can also be
 *     specified as a single array of keys.
 * @return {*} The resulting value. If, at any point, the value for a key in the
 *     current object is null or undefined, returns undefined.
 */
function getValueByKeys(obj, var_args) {
  const isArrayLike = goog.isArrayLike(var_args);
  const keys = isArrayLike ?
      /** @type {!IArrayLike<number|string>} */ (var_args) :
      arguments;

  // Start with the 2nd parameter for the variable parameters syntax.
  for (let i = isArrayLike ? 0 : 1; i < keys.length; i++) {
    if (obj == null) return undefined;
    obj = obj[keys[i]];
  }

  return obj;
}

/**
 * Whether the object/map/hash contains the given key.
 * @param {?Object} obj The object in which to look for key.
 * @param {?} key The key for which to check.
 * @return {boolean} true If the map contains the key.
 */
function containsKey(obj, key) {
  return obj !== null && key in obj;
}

/**
 * Whether the object/map/hash contains the given value. This is O(n).
 * @param {?Object<K,V>} obj The object in which to look for val.
 * @param {V} val The value for which to check.
 * @return {boolean} true If the map contains the value.
 * @template K,V
 */
function containsValue(obj, val) {
  for (const key in obj) {
    if (obj[key] == val) {
      return true;
    }
  }
  return false;
}

/**
 * Searches an object for an element that satisfies the given condition and
 * returns its key.
 * @param {?Object<K,V>} obj The object to search in.
 * @param {function(this:T,V,string,?Object<K,V>):boolean} f The function to
 *     call for every element. Takes 3 arguments (the value, the key and the
 *     object) and should return a boolean.
 * @param {T=} thisObj An optional "this" context for the function.
 * @return {string|undefined} The key of an element for which the function
 *     returns true or undefined if no such element is found.
 * @template T,K,V
 */
function findKey(obj, f, thisObj = undefined) {
  for (const key in obj) {
    if (f.call(/** @type {?} */ (thisObj), obj[key], key, obj)) {
      return key;
    }
  }
  return undefined;
}

/**
 * Searches an object for an element that satisfies the given condition and
 * returns its value.
 * @param {?Object<K,V>} obj The object to search in.
 * @param {function(this:T,V,string,?Object<K,V>):boolean} f The function to
 *     call for every element. Takes 3 arguments (the value, the key and the
 *     object) and should return a boolean.
 * @param {T=} thisObj An optional "this" context for the function.
 * @return {V} The value of an element for which the function returns true or
 *     undefined if no such element is found.
 * @template T,K,V
 */
function findValue(obj, f, thisObj = undefined) {
  const key = findKey(obj, f, thisObj);
  return key && obj[key];
}

/**
 * Whether the object/map/hash is empty.
 * @param {?Object} obj The object to test.
 * @return {boolean} true if obj is empty.
 */
function isEmpty(obj) {
  for (const key in obj) {
    return false;
  }
  return true;
}

/**
 * Removes all key value pairs from the object/map/hash.
 * @param {?Object} obj The object to clear.
 * @return {void}
 */
function clear(obj) {
  for (const i in obj) {
    delete obj[i];
  }
}

/**
 * Removes a key-value pair based on the key.
 * @param {?Object} obj The object from which to remove the key.
 * @param {?} key The key to remove.
 * @return {boolean} Whether an element was removed.
 */
function remove(obj, key) {
  let rv;
  if (rv = key in /** @type {!Object} */ (obj)) {
    delete obj[key];
  }
  return rv;
}

/**
 * Adds a key-value pair to the object. Throws an exception if the key is
 * already in use. Use set if you want to change an existing pair.
 * @param {?Object<K,V>} obj The object to which to add the key-value pair.
 * @param {string} key The key to add.
 * @param {V} val The value to add.
 * @return {void}
 * @template K,V
 */
function add(obj, key, val) {
  if (obj !== null && key in obj) {
    throw new Error(`The object already contains the key "${key}"`);
  }
  set(obj, key, val);
}

/**
 * Returns the value for the given key.
 * @param {?Object<K,V>} obj The object from which to get the value.
 * @param {string} key The key for which to get the value.
 * @param {R=} val The value to return if no item is found for the given key
 *     (default is undefined).
 * @return {V|R|undefined} The value for the given key.
 * @template K,V,R
 */
function get(obj, key, val = undefined) {
  if (obj !== null && key in obj) {
    return obj[key];
  }
  return val;
}

/**
 * Adds a key-value pair to the object/map/hash.
 * @param {?Object<K,V>} obj The object to which to add the key-value pair.
 * @param {string} key The key to add.
 * @param {V} value The value to add.
 * @template K,V
 * @return {void}
 */
function set(obj, key, value) {
  obj[key] = value;
}

/**
 * Adds a key-value pair to the object/map/hash if it doesn't exist yet.
 * @param {?Object<K,V>} obj The object to which to add the key-value pair.
 * @param {string} key The key to add.
 * @param {V} value The value to add if the key wasn't present.
 * @return {V} The value of the entry at the end of the function.
 * @template K,V
 */
function setIfUndefined(obj, key, value) {
  return key in /** @type {!Object} */ (obj) ? obj[key] : (obj[key] = value);
}

/**
 * Sets a key and value to an object if the key is not set. The value will be
 * the return value of the given function. If the key already exists, the
 * object will not be changed and the function will not be called (the function
 * will be lazily evaluated -- only called if necessary).
 * This function is particularly useful when used with an `Object` which is
 * acting as a cache.
 * @param {?Object<K,V>} obj The object to which to add the key-value pair.
 * @param {string} key The key to add.
 * @param {function():V} f The value to add if the key wasn't present.
 * @return {V} The value of the entry at the end of the function.
 * @template K,V
 */
function setWithReturnValueIfNotSet(obj, key, f) {
  if (key in obj) {
    return obj[key];
  }

  const val = f();
  obj[key] = val;
  return val;
}

/**
 * Compares two objects for equality using === on the values.
 * @param {!Object<K,V>} a
 * @param {!Object<K,V>} b
 * @return {boolean}
 * @template K,V
 */
function equals(a, b) {
  for (const k in a) {
    if (!(k in b) || a[k] !== b[k]) {
      return false;
    }
  }
  for (const k in b) {
    if (!(k in a)) {
      return false;
    }
  }
  return true;
}

/**
 * Returns a shallow clone of the object.
 * @param {?Object<K,V>} obj Object to clone.
 * @return {!Object<K,V>} Clone of the input object.
 * @template K,V
 */
function clone(obj) {
  const res = {};
  for (const key in obj) {
    res[key] = obj[key];
  }
  return res;
}

/**
 * Clones a value. The input may be an Object, Array, or basic type. Objects and
 * arrays will be cloned recursively.
 * WARNINGS:
 * <code>unsafeClone</code> does not detect reference loops. Objects
 * that refer to themselves will cause infinite recursion.
 * <code>unsafeClone</code> is unaware of unique identifiers, and
 * copies UIDs created by <code>getUid</code> into cloned results.
 * @param {T} obj The value to clone.
 * @return {T} A clone of the input value.
 * @template T
 */
function unsafeClone(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (typeof obj.clone === 'function') return obj.clone();
  if (typeof Map !== 'undefined' && obj instanceof Map) {
    return new Map(obj);
  } else if (typeof Set !== 'undefined' && obj instanceof Set) {
    return new Set(obj);
  }
  const clone = Array.isArray(obj) ? [] :
      typeof ArrayBuffer === 'function' &&
          typeof ArrayBuffer.isView === 'function' && ArrayBuffer.isView(obj) &&
          !(obj instanceof DataView) ?
                                     new obj.constructor(obj.length) :
                                     {};
  for (const key in obj) {
    clone[key] = unsafeClone(obj[key]);
  }
  return clone;
}

/**
 * Returns a new object in which all the keys and values are interchanged
 * (keys become values and values become keys). If multiple keys map to the
 * same value, the chosen transposed value is implementation-dependent.
 * @param {?Object} obj The object to transpose.
 * @return {!Object} The transposed object.
 */
function transpose(obj) {
  const transposed = {};
  for (const key in obj) {
    transposed[obj[key]] = key;
  }
  return transposed;
}

/**
 * The names of the fields that are defined on Object.prototype.
 * @type {!Array<string>}
 */
const PROTOTYPE_FIELDS = [
  'constructor',
  'hasOwnProperty',
  'isPrototypeOf',
  'propertyIsEnumerable',
  'toLocaleString',
  'toString',
  'valueOf',
];

/**
 * Extends an object with another object.
 * This operates 'in-place'; it does not create a new Object.
 * Example:
 * var o = {};
 * extend(o, {a: 0, b: 1});
 * o; // {a: 0, b: 1}
 * extend(o, {b: 2, c: 3});
 * o; // {a: 0, b: 2, c: 3}
 * @param {?Object} target The object to modify. Existing properties will be
 *     overwritten if they are also present in one of the objects in `var_args`.
 * @param {...(?Object|undefined)} var_args The objects from which values
 *     will be copied.
 * @return {void}
 * @deprecated Prefer Object.assign
 */
function extend(target, var_args) {
  let key;
  let source;
  for (let i = 1; i < arguments.length; i++) {
    source = arguments[i];
    for (key in source) {
      target[key] = source[key];
    }

    // For IE the for-in-loop does not contain any properties that are not
    // enumerable on the prototype object (for example isPrototypeOf from
    // Object.prototype) and it will also not include 'replace' on objects that
    // extend String and change 'replace' (not that it is common for anyone to
    // extend anything except Object).

    for (let j = 0; j < PROTOTYPE_FIELDS.length; j++) {
      key = PROTOTYPE_FIELDS[j];
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
}

/**
 * Creates a new object built from the key-value pairs provided as arguments.
 * @param {...*} var_args If only one argument is provided and it is an array
 *     then this is used as the arguments, otherwise even arguments are used as
 *     the property names and odd arguments are used as the property values.
 * @return {!Object} The new object.
 * @throws {!Error} If there are uneven number of arguments or there is only one
 *     non array argument.
 */
function create(var_args) {
  const argLength = arguments.length;
  if (argLength == 1 && Array.isArray(arguments[0])) {
    return create.apply(null, arguments[0]);
  }

  if (argLength % 2) {
    throw new Error('Uneven number of arguments');
  }

  const rv = {};
  for (let i = 0; i < argLength; i += 2) {
    rv[arguments[i]] = arguments[i + 1];
  }
  return rv;
}

/**
 * Creates a new object where the property names come from the arguments but
 * the value is always set to true
 * @param {...*} var_args If only one argument is provided and it is an array
 *     then this is used as the arguments, otherwise the arguments are used as
 *     the property names.
 * @return {!Object} The new object.
 */
function createSet(var_args) {
  const argLength = arguments.length;
  if (argLength == 1 && Array.isArray(arguments[0])) {
    return createSet.apply(null, arguments[0]);
  }

  const rv = {};
  for (let i = 0; i < argLength; i++) {
    rv[arguments[i]] = true;
  }
  return rv;
}

/**
 * Creates an immutable view of the underlying object, if the browser
 * supports immutable objects.
 * In default mode, writes to this view will fail silently. In strict mode,
 * they will throw an error.
 * @param {!Object<K,V>} obj An object.
 * @return {!Object<K,V>} An immutable view of that object, or the original
 *     object if this browser does not support immutables.
 * @template K,V
 */
function createImmutableView(obj) {
  let result = obj;
  if (Object.isFrozen && !Object.isFrozen(obj)) {
    result = Object.create(obj);
    Object.freeze(result);
  }
  return result;
}

/**
 * @param {!Object} obj An object.
 * @return {boolean} Whether this is an immutable view of the object.
 */
function isImmutableView(obj) {
  return !!Object.isFrozen && Object.isFrozen(obj);
}

/**
 * Get all properties names on a given Object regardless of enumerability.
 * <p> If the browser does not support `Object.getOwnPropertyNames` nor
 * `Object.getPrototypeOf` then this is equivalent to using
 * `getKeys`
 * @param {?Object} obj The object to get the properties of.
 * @param {boolean=} includeObjectPrototype Whether properties defined on
 *     `Object.prototype` should be included in the result.
 * @param {boolean=} includeFunctionPrototype Whether properties defined on
 *     `Function.prototype` should be included in the result.
 * @return {!Array<string>}
 * @public
 */
function getAllPropertyNames(
    obj, includeObjectPrototype = undefined,
    includeFunctionPrototype = undefined) {
  if (!obj) {
    return [];
  }

  // Naively use a for..in loop to get the property names if the browser doesn't
  // support any other APIs for getting it.
  if (!Object.getOwnPropertyNames || !Object.getPrototypeOf) {
    return getKeys(obj);
  }

  const visitedSet = {};

  // Traverse the prototype chain and add all properties to the visited set.
  let proto = obj;
  while (proto && (proto !== Object.prototype || !!includeObjectPrototype) &&
         (proto !== Function.prototype || !!includeFunctionPrototype)) {
    const names = Object.getOwnPropertyNames(proto);
    for (let i = 0; i < names.length; i++) {
      visitedSet[names[i]] = true;
    }
    proto = Object.getPrototypeOf(proto);
  }

  return getKeys(visitedSet);
}

/**
 * Given a ES5 or ES6 class reference, return its super class / super
 * constructor.
 * This should be used in rare cases where you need to walk up the inheritance
 * tree (this is generally a bad idea). But this work with ES5 and ES6 classes,
 * unlike relying on the superClass_ property.
 * Note: To start walking up the hierarchy from an instance call this with its
 * `constructor` property; e.g. `getSuperClass(instance.constructor)`.
 * @param {function(new: ?)} constructor
 * @return {?Object}
 */
function getSuperClass(constructor) {
  const proto = Object.getPrototypeOf(constructor.prototype);
  return proto && proto.constructor;
}

exports = {
  add,
  clear,
  clone,
  contains,
  containsKey,
  containsValue,
  create,
  createImmutableView,
  createSet,
  equals,
  every,
  extend,
  filter,
  findKey,
  findValue,
  forEach,
  get,
  getAllPropertyNames,
  getAnyKey,
  getAnyValue,
  getCount,
  getKeys,
  getSuperClass,
  getValueByKeys,
  getValues,
  isEmpty,
  isImmutableView,
  map,
  remove,
  set,
  setIfUndefined,
  setWithReturnValueIfNotSet,
  some,
  transpose,
  unsafeClone,
};

;return exports;});

//third_party/javascript/closure/dom/tags.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Utilities for HTML element tag names.
 */
goog.provide('goog.dom.tags');

goog.require('goog.object');


/**
 * The void elements specified by
 * http://www.w3.org/TR/html-markup/syntax.html#void-elements.
 * @const @private {!Object<string, boolean>}
 */
goog.dom.tags.VOID_TAGS_ = goog.object.createSet(
    'area', 'base', 'br', 'col', 'command', 'embed', 'hr', 'img', 'input',
    'keygen', 'link', 'meta', 'param', 'source', 'track', 'wbr');


/**
 * Checks whether the tag is void (with no contents allowed and no legal end
 * tag), for example 'br'.
 * @param {string} tagName The tag name in lower case.
 * @return {boolean}
 */
goog.dom.tags.isVoidTag = function(tagName) {
  'use strict';
  return goog.dom.tags.VOID_TAGS_[tagName] === true;
};

//third_party/javascript/closure/html/trustedtypes.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Policy to convert strings to Trusted Types. See
 * https://github.com/WICG/trusted-types for details.
 */

goog.provide('goog.html.trustedtypes');


/**
 * @define {string} Name for the Trusted Types policy used in Closure Safe
 * Types. Differs from `goog.TRUSTED_TYPES_POLICY_NAME` in that the latter is
 * also used for other purposes like the debug loader. If empty, Closure Safe
 * Types will not use Trusted Types. Default is `goog.TRUSTED_TYPES_POLICY_NAME`
 * plus the suffix `#html`, unless `goog.TRUSTED_TYPES_POLICY_NAME` is empty.
 * // MOE:insert @package
 */
goog.html.trustedtypes.POLICY_NAME = goog.define(
    'goog.html.trustedtypes.POLICY_NAME',
    goog.TRUSTED_TYPES_POLICY_NAME ? goog.TRUSTED_TYPES_POLICY_NAME + '#html' :
                                     '');


/**
 * Cached result of goog.createTrustedTypesPolicy.
 * @type {?TrustedTypePolicy|undefined}
 * @private
 */
goog.html.trustedtypes.cachedPolicy_;


/**
 * Creates a (singleton) Trusted Type Policy for Safe HTML Types.
 * @return {?TrustedTypePolicy}
 * // MOE:insert @package
 */
goog.html.trustedtypes.getPolicyPrivateDoNotAccessOrElse = function() {
  'use strict';
  if (!goog.html.trustedtypes.POLICY_NAME) {
    // Binary not configured for Trusted Types.
    return null;
  }

  if (goog.html.trustedtypes.cachedPolicy_ === undefined) {
    goog.html.trustedtypes.cachedPolicy_ =
        goog.createTrustedTypesPolicy(goog.html.trustedtypes.POLICY_NAME);
  }

  return goog.html.trustedtypes.cachedPolicy_;
};

//third_party/javascript/closure/string/typedstring.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

goog.provide('goog.string.TypedString');



/**
 * Wrapper for strings that conform to a data type or language.
 *
 * Implementations of this interface are wrappers for strings, and typically
 * associate a type contract with the wrapped string.  Concrete implementations
 * of this interface may choose to implement additional run-time type checking,
 * see for example `goog.html.SafeHtml`. If available, client code that
 * needs to ensure type membership of an object should use the type's function
 * to assert type membership, such as `goog.html.SafeHtml.unwrap`.
 * @interface
 */
goog.string.TypedString = function() {};


/**
 * Interface marker of the TypedString interface.
 *
 * This property can be used to determine at runtime whether or not an object
 * implements this interface.  All implementations of this interface set this
 * property to `true`.
 * @type {boolean}
 */
goog.string.TypedString.prototype.implementsGoogStringTypedString;


/**
 * Retrieves this wrapped string's value.
 * @return {string} The wrapped string's value.
 */
goog.string.TypedString.prototype.getTypedStringValue;

//third_party/javascript/closure/string/const.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

goog.provide('goog.string.Const');

goog.require('goog.asserts');
goog.require('goog.string.TypedString');



/**
 * Wrapper for compile-time-constant strings.
 *
 * Const is a wrapper for strings that can only be created from program
 * constants (i.e., string literals).  This property relies on a custom Closure
 * compiler check that `goog.string.Const.from` is only invoked on
 * compile-time-constant expressions.
 *
 * Const is useful in APIs whose correct and secure use requires that certain
 * arguments are not attacker controlled: Compile-time constants are inherently
 * under the control of the application and not under control of external
 * attackers, and hence are safe to use in such contexts.
 *
 * Instances of this type must be created via its factory method
 * `goog.string.Const.from` and not by invoking its constructor.  The
 * constructor intentionally takes no parameters and the type is immutable;
 * hence only a default instance corresponding to the empty string can be
 * obtained via constructor invocation.  Use goog.string.Const.EMPTY
 * instead of using this constructor to get an empty Const string.
 *
 * @see goog.string.Const#from
 * @constructor
 * @final
 * @struct
 * @implements {goog.string.TypedString}
 * @param {Object=} opt_token package-internal implementation detail.
 * @param {string=} opt_content package-internal implementation detail.
 */
goog.string.Const = function(opt_token, opt_content) {
  'use strict';
  /**
   * The wrapped value of this Const object.  The field has a purposely ugly
   * name to make (non-compiled) code that attempts to directly access this
   * field stand out.
   * @private {string}
   */
  this.stringConstValueWithSecurityContract__googStringSecurityPrivate_ =
      ((opt_token ===
        goog.string.Const.GOOG_STRING_CONSTRUCTOR_TOKEN_PRIVATE_) &&
       opt_content) ||
      '';

  /**
   * A type marker used to implement additional run-time type checking.
   * @see goog.string.Const#unwrap
   * @const {!Object}
   * @private
   */
  this.STRING_CONST_TYPE_MARKER__GOOG_STRING_SECURITY_PRIVATE_ =
      goog.string.Const.TYPE_MARKER_;
};


/**
 * @override
 * @const
 */
goog.string.Const.prototype.implementsGoogStringTypedString = true;


/**
 * Returns this Const's value as a string.
 *
 * IMPORTANT: In code where it is security-relevant that an object's type is
 * indeed `goog.string.Const`, use `goog.string.Const.unwrap`
 * instead of this method.
 *
 * @see goog.string.Const#unwrap
 * @override
 * @return {string}
 */
goog.string.Const.prototype.getTypedStringValue = function() {
  'use strict';
  return this.stringConstValueWithSecurityContract__googStringSecurityPrivate_;
};


if (goog.DEBUG) {
  /**
   * Returns a debug-string representation of this value.
   *
   * To obtain the actual string value wrapped inside an object of this type,
   * use `goog.string.Const.unwrap`.
   *
   * @see goog.string.Const#unwrap
   * @override
   * @return {string}
   */
  goog.string.Const.prototype.toString = function() {
    'use strict';
    return 'Const{' +
        this.stringConstValueWithSecurityContract__googStringSecurityPrivate_ +
        '}';
  };
}


/**
 * Performs a runtime check that the provided object is indeed an instance
 * of `goog.string.Const`, and returns its value.
 * @param {!goog.string.Const} stringConst The object to extract from.
 * @return {string} The Const object's contained string, unless the run-time
 *     type check fails. In that case, `unwrap` returns an innocuous
 *     string, or, if assertions are enabled, throws
 *     `goog.asserts.AssertionError`.
 */
goog.string.Const.unwrap = function(stringConst) {
  'use strict';
  // Perform additional run-time type-checking to ensure that stringConst is
  // indeed an instance of the expected type.  This provides some additional
  // protection against security bugs due to application code that disables type
  // checks.
  if (stringConst instanceof goog.string.Const &&
      stringConst.constructor === goog.string.Const &&
      stringConst.STRING_CONST_TYPE_MARKER__GOOG_STRING_SECURITY_PRIVATE_ ===
          goog.string.Const.TYPE_MARKER_) {
    return stringConst
        .stringConstValueWithSecurityContract__googStringSecurityPrivate_;
  } else {
    goog.asserts.fail(
        'expected object of type Const, got \'' + stringConst + '\'');
    return 'type_error:Const';
  }
};


/**
 * Creates a Const object from a compile-time constant string.
 *
 * It is illegal to invoke this function on an expression whose
 * compile-time-constant value cannot be determined by the Closure compiler.
 *
 * Correct invocations include,
 * <pre>
 *   var s = goog.string.Const.from('hello');
 *   var t = goog.string.Const.from('hello' + 'world');
 * </pre>
 *
 * In contrast, the following are illegal:
 * <pre>
 *   var s = goog.string.Const.from(getHello());
 *   var t = goog.string.Const.from('hello' + world);
 * </pre>
 *
 * @param {string} s A constant string from which to create a Const.
 * @return {!goog.string.Const} A Const object initialized to stringConst.
 */
goog.string.Const.from = function(s) {
  'use strict';
  return new goog.string.Const(
      goog.string.Const.GOOG_STRING_CONSTRUCTOR_TOKEN_PRIVATE_, s);
};

/**
 * Type marker for the Const type, used to implement additional run-time
 * type checking.
 * @const {!Object}
 * @private
 */
goog.string.Const.TYPE_MARKER_ = {};

/**
 * @type {!Object}
 * @private
 * @const
 */
goog.string.Const.GOOG_STRING_CONSTRUCTOR_TOKEN_PRIVATE_ = {};

/**
 * A Const instance wrapping the empty string.
 * @const {!goog.string.Const}
 */
goog.string.Const.EMPTY = goog.string.Const.from('');

//third_party/javascript/closure/html/safescript.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview The SafeScript type and its builders.
 *
 * TODO(xtof): Link to document stating type contract.
 */

goog.module('goog.html.SafeScript');
goog.module.declareLegacyNamespace();

const Const = goog.require('goog.string.Const');
const TypedString = goog.require('goog.string.TypedString');
const trustedtypes = goog.require('goog.html.trustedtypes');
const {fail} = goog.require('goog.asserts');

/**
 * Token used to ensure that object is created only from this file. No code
 * outside of this file can access this token.
 * @const {!Object}
 */
const CONSTRUCTOR_TOKEN_PRIVATE = {};

/**
 * A string-like object which represents JavaScript code and that carries the
 * security type contract that its value, as a string, will not cause execution
 * of unconstrained attacker controlled code (XSS) when evaluated as JavaScript
 * in a browser.
 *
 * Instances of this type must be created via the factory method
 * `SafeScript.fromConstant` and not by invoking its constructor. The
 * constructor intentionally takes an extra parameter that cannot be constructed
 * outside of this file and the type is immutable; hence only a default instance
 * corresponding to the empty string can be obtained via constructor invocation.
 *
 * A SafeScript's string representation can safely be interpolated as the
 * content of a script element within HTML. The SafeScript string should not be
 * escaped before interpolation.
 *
 * Note that the SafeScript might contain text that is attacker-controlled but
 * that text should have been interpolated with appropriate escaping,
 * sanitization and/or validation into the right location in the script, such
 * that it is highly constrained in its effect (for example, it had to match a
 * set of whitelisted words).
 *
 * A SafeScript can be constructed via security-reviewed unchecked
 * conversions. In this case producers of SafeScript must ensure themselves that
 * the SafeScript does not contain unsafe script. Note in particular that
 * `&lt;` is dangerous, even when inside JavaScript strings, and so should
 * always be forbidden or JavaScript escaped in user controlled input. For
 * example, if `&lt;/script&gt;&lt;script&gt;evil&lt;/script&gt;"` were
 * interpolated inside a JavaScript string, it would break out of the context
 * of the original script element and `evil` would execute. Also note
 * that within an HTML script (raw text) element, HTML character references,
 * such as "&lt;" are not allowed. See
 * http://www.w3.org/TR/html5/scripting-1.html#restrictions-for-contents-of-script-elements.
 * Creating SafeScript objects HAS SIDE-EFFECTS due to calling Trusted Types Web
 * API.
 *
 * @see SafeScript#fromConstant
 * @final
 * @implements {TypedString}
 */
class SafeScript {
  /**
   * @param {!TrustedScript|string} value
   * @param {!Object} token package-internal implementation detail.
   */
  constructor(value, token) {
    /**
     * The contained value of this SafeScript.  The field has a purposely ugly
     * name to make (non-compiled) code that attempts to directly access this
     * field stand out.
     * @private {!TrustedScript|string}
     */
    this.privateDoNotAccessOrElseSafeScriptWrappedValue_ =
        (token === CONSTRUCTOR_TOKEN_PRIVATE) ? value : '';

    /**
     * @override
     * @const
     */
    this.implementsGoogStringTypedString = true;
  }

  /**
   * Returns a string-representation of this value.
   *
   * To obtain the actual string value wrapped in a SafeScript, use
   * `SafeScript.unwrap`.
   *
   * @return {string}
   * @see SafeScript#unwrap
   * @override
   */
  toString() {
    return this.privateDoNotAccessOrElseSafeScriptWrappedValue_.toString();
  }

  /**
   * Creates a SafeScript object from a compile-time constant string.
   *
   * @param {!Const} script A compile-time-constant string from which to create
   *     a SafeScript.
   * @return {!SafeScript} A SafeScript object initialized to `script`.
   */
  static fromConstant(script) {
    const scriptString = Const.unwrap(script);
    if (scriptString.length === 0) {
      return SafeScript.EMPTY;
    }
    return SafeScript.createSafeScriptSecurityPrivateDoNotAccessOrElse(
        scriptString);
  }

  /**
   * Creates a SafeScript JSON representation from anything that could be passed
   * to JSON.stringify.
   * @param {*} val
   * @return {!SafeScript}
   * MOE:begin_intracomment_strip
   * @deprecated Use safevalues.scriptFromJson instead.
   * @package
   * MOE:end_intracomment_strip
   */
  static fromJson(val) {
    return SafeScript.createSafeScriptSecurityPrivateDoNotAccessOrElse(
        SafeScript.stringify_(val));
  }

  /**
   * Returns this SafeScript's value as a string.
   *
   * IMPORTANT: In code where it is security relevant that an object's type is
   * indeed `SafeScript`, use `SafeScript.unwrap` instead of
   * this method. If in doubt, assume that it's security relevant. In
   * particular, note that goog.html functions which return a goog.html type do
   * not guarantee the returned instance is of the right type. For example:
   *
   * <pre>
   * var fakeSafeHtml = new String('fake');
   * fakeSafeHtml.__proto__ = goog.html.SafeHtml.prototype;
   * var newSafeHtml = goog.html.SafeHtml.htmlEscape(fakeSafeHtml);
   * // newSafeHtml is just an alias for fakeSafeHtml, it's passed through by
   * // goog.html.SafeHtml.htmlEscape() as fakeSafeHtml
   * // instanceof goog.html.SafeHtml.
   * </pre>
   *
   * @see SafeScript#unwrap
   * @override
   */
  getTypedStringValue() {
    return this.privateDoNotAccessOrElseSafeScriptWrappedValue_.toString();
  }

  /**
   * Performs a runtime check that the provided object is indeed a
   * SafeScript object, and returns its value.
   *
   * @param {!SafeScript} safeScript The object to extract from.
   * @return {string} The safeScript object's contained string, unless
   *     the run-time type check fails. In that case, `unwrap` returns an
   *     innocuous string, or, if assertions are enabled, throws
   *     `asserts.AssertionError`.
   */
  static unwrap(safeScript) {
    return SafeScript.unwrapTrustedScript(safeScript).toString();
  }

  /**
   * Unwraps value as TrustedScript if supported or as a string if not.
   * @param {!SafeScript} safeScript
   * @return {!TrustedScript|string}
   * @see SafeScript.unwrap
   */
  static unwrapTrustedScript(safeScript) {
    // Perform additional Run-time type-checking to ensure that
    // safeScript is indeed an instance of the expected type.  This
    // provides some additional protection against security bugs due to
    // application code that disables type checks.
    // Specifically, the following checks are performed:
    // 1. The object is an instance of the expected type.
    // 2. The object is not an instance of a subclass.
    if (safeScript instanceof SafeScript &&
        safeScript.constructor === SafeScript) {
      return safeScript.privateDoNotAccessOrElseSafeScriptWrappedValue_;
    } else {
      fail(
          'expected object of type SafeScript, got \'' + safeScript +
          '\' of type ' + goog.typeOf(safeScript));
      return 'type_error:SafeScript';
    }
  }

  /**
   * Converts the given value to an embeddable JSON string and returns it. The
   * resulting string can be embedded in HTML because the '<' character is
   * encoded.
   *
   * @param {*} val
   * @return {string}
   * @private
   */
  static stringify_(val) {
    const json = JSON.stringify(val);
    return json.replace(/</g, '\\x3c');
  }

  /**
   * Package-internal utility method to create SafeScript instances.
   *
   * @param {string} script The string to initialize the SafeScript object with.
   * @return {!SafeScript} The initialized SafeScript object.
   * @package
   */
  static createSafeScriptSecurityPrivateDoNotAccessOrElse(script) {
    /** @noinline */
    const noinlineScript = script;
    const policy = trustedtypes.getPolicyPrivateDoNotAccessOrElse();
    const trustedScript =
        policy ? policy.createScript(noinlineScript) : noinlineScript;
    return new SafeScript(trustedScript, CONSTRUCTOR_TOKEN_PRIVATE);
  }
}

/**
 * A SafeScript instance corresponding to the empty string.
 * @const {!SafeScript}
 */
SafeScript.EMPTY = /** @type {!SafeScript} */ ({
  // NOTE: this compiles to nothing, but hides the possible side effect of
  // SafeScript creation (due to calling trustedTypes.createPolicy) from the
  // compiler so that the entire call can be removed if the result is not used.
  // MOE:begin_strip
  // TODO(b/155299094): Refactor after adding compiler support.
  // MOE:end_strip
  valueOf: function() {
    return SafeScript.createSafeScriptSecurityPrivateDoNotAccessOrElse('');
  },
}.valueOf());


exports = SafeScript;

;return exports;});

//third_party/javascript/closure/fs/url.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Wrapper for URL and its createObjectUrl and revokeObjectUrl
 * methods that are part of the HTML5 File API.
 */

goog.provide('goog.fs.url');


/**
 * Creates a blob URL for a blob object.
 * Throws an error if the browser does not support Object Urls.
 *
 * @param {!File|!Blob|!MediaSource|!MediaStream} obj The object for which
 *   to create the URL.
 * @return {string} The URL for the object.
 */
goog.fs.url.createObjectUrl = function(obj) {
  'use strict';
  return goog.fs.url.getUrlObject_().createObjectURL(obj);
};


/**
 * Revokes a URL created by {@link goog.fs.url.createObjectUrl}.
 * Throws an error if the browser does not support Object Urls.
 *
 * @param {string} url The URL to revoke.
 * @return {void}
 */
goog.fs.url.revokeObjectUrl = function(url) {
  'use strict';
  goog.fs.url.getUrlObject_().revokeObjectURL(url);
};


/**
 * @record
 * @private
 */
goog.fs.url.UrlObject_ = function() {};

/**
 * @param {!File|!Blob|!MediaSource|!MediaStream} arg
 * @return {string}
 */
goog.fs.url.UrlObject_.prototype.createObjectURL = function(arg) {};

/**
 * @param {string} s
 * @return {void}
 */
goog.fs.url.UrlObject_.prototype.revokeObjectURL = function(s) {};


/**
 * Get the object that has the createObjectURL and revokeObjectURL functions for
 * this browser.
 *
 * @return {!goog.fs.url.UrlObject_} The object for this browser.
 * @private
 */
goog.fs.url.getUrlObject_ = function() {
  'use strict';
  const urlObject = goog.fs.url.findUrlObject_();
  if (urlObject != null) {
    return urlObject;
  } else {
    throw new Error('This browser doesn\'t seem to support blob URLs');
  }
};


/**
 * Finds the object that has the createObjectURL and revokeObjectURL functions
 * for this browser.
 *
 * @return {?goog.fs.url.UrlObject_} The object for this browser or null if the
 *     browser does not support Object Urls.
 * @private
 */
goog.fs.url.findUrlObject_ = function() {
  'use strict';
  // This is what the spec says to do
  // http://dev.w3.org/2006/webapi/FileAPI/#dfn-createObjectURL
  if (goog.global.URL !== undefined &&
      goog.global.URL.createObjectURL !== undefined) {
    return /** @type {!goog.fs.url.UrlObject_} */ (goog.global.URL);
    // This is what the spec used to say to do
  } else if (goog.global.createObjectURL !== undefined) {
    return /** @type {!goog.fs.url.UrlObject_} */ (goog.global);
  } else {
    return null;
  }
};


/**
 * Checks whether this browser supports Object Urls. If not, calls to
 * createObjectUrl and revokeObjectUrl will result in an error.
 *
 * @return {boolean} True if this browser supports Object Urls.
 */
goog.fs.url.browserSupportsObjectUrls = function() {
  'use strict';
  return goog.fs.url.findUrlObject_() != null;
};

//third_party/javascript/closure/fs/blob.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Wrappers for the HTML5 File API. These wrappers closely mirror
 * the underlying APIs, but use Closure-style events and Deferred return values.
 * Their existence also makes it possible to mock the FileSystem API for testing
 * in browsers that don't support it natively.
 *
 * When adding public functions to anything under this namespace, be sure to add
 * its mock counterpart to goog.testing.fs.
 */

goog.provide('goog.fs.blob');



/**
 * Concatenates one or more values together and converts them to a Blob.
 *
 * @param {...(string|!Blob|!ArrayBuffer)} var_args The values that will make up
 *     the resulting blob.
 * @return {!Blob} The blob.
 */
goog.fs.blob.getBlob = function(var_args) {
  'use strict';
  const BlobBuilder = goog.global.BlobBuilder || goog.global.WebKitBlobBuilder;

  if (BlobBuilder !== undefined) {
    const bb = new BlobBuilder();
    for (let i = 0; i < arguments.length; i++) {
      bb.append(arguments[i]);
    }
    return bb.getBlob();
  } else {
    return goog.fs.blob.getBlobWithProperties(
        Array.prototype.slice.call(arguments));
  }
};


/**
 * Creates a blob with the given properties.
 * See https://developer.mozilla.org/en-US/docs/Web/API/Blob for more details.
 *
 * @param {!Array<string|!Blob|!ArrayBuffer>} parts The values that will make up
 *     the resulting blob (subset supported by both BlobBuilder.append() and
 *     Blob constructor).
 * @param {string=} opt_type The MIME type of the Blob.
 * @param {string=} opt_endings Specifies how strings containing newlines are to
 *     be written out.
 * @return {!Blob} The blob.
 */
goog.fs.blob.getBlobWithProperties = function(parts, opt_type, opt_endings) {
  'use strict';
  const BlobBuilder = goog.global.BlobBuilder || goog.global.WebKitBlobBuilder;

  if (BlobBuilder !== undefined) {
    const bb = new BlobBuilder();
    for (let i = 0; i < parts.length; i++) {
      bb.append(parts[i], opt_endings);
    }
    return bb.getBlob(opt_type);
  } else if (goog.global.Blob !== undefined) {
    const properties = {};
    if (opt_type) {
      properties['type'] = opt_type;
    }
    if (opt_endings) {
      properties['endings'] = opt_endings;
    }
    return new Blob(parts, properties);
  } else {
    throw new Error('This browser doesn\'t seem to support creating Blobs');
  }
};

//third_party/javascript/closure/html/trustedresourceurl.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview The TrustedResourceUrl type and its builders.
 *
 * TODO(xtof): Link to document stating type contract.
 */

goog.provide('goog.html.TrustedResourceUrl');

goog.require('goog.asserts');
goog.require('goog.fs.blob');
goog.require('goog.fs.url');
goog.require('goog.html.SafeScript');
goog.require('goog.html.trustedtypes');
goog.require('goog.string.Const');
goog.require('goog.string.TypedString');



/**
 * A URL which is under application control and from which script, CSS, and
 * other resources that represent executable code, can be fetched.
 *
 * Given that the URL can only be constructed from strings under application
 * control and is used to load resources, bugs resulting in a malformed URL
 * should not have a security impact and are likely to be easily detectable
 * during testing. Given the wide number of non-RFC compliant URLs in use,
 * stricter validation could prevent some applications from being able to use
 * this type.
 *
 * Instances of this type must be created via the factory method,
 * (`fromConstant`, `fromConstants`, `format` or `formatWithParams`), and not by
 * invoking its constructor. The constructor intentionally takes an extra
 * parameter that cannot be constructed outside of this file and the type is
 * immutable; hence only a default instance corresponding to the empty string
 * can be obtained via constructor invocation.
 *
 * Creating TrustedResourceUrl objects HAS SIDE-EFFECTS due to calling
 * Trusted Types Web API.
 *
 * @see goog.html.TrustedResourceUrl#fromConstant
 * @final
 * @struct
 * @implements {goog.string.TypedString}
 */
goog.html.TrustedResourceUrl = class {
  /**
   * @param {!TrustedScriptURL|string} value
   * @param {!Object} token package-internal implementation detail.
   */
  constructor(value, token) {
    /**
     * The contained value of this TrustedResourceUrl.  The field has a
     * purposely ugly name to make (non-compiled) code that attempts to directly
     * access this field stand out.
     * @const
     * @private {!TrustedScriptURL|string}
     */
    this.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue_ =
        (token === goog.html.TrustedResourceUrl.CONSTRUCTOR_TOKEN_PRIVATE_) ?
        value :
        '';
  }

  /**
   * Returns a string-representation of this value.
   *
   * To obtain the actual string value wrapped in a TrustedResourceUrl, use
   * `goog.html.TrustedResourceUrl.unwrap`.
   *
   * @return {string}
   * @see goog.html.TrustedResourceUrl#unwrap
   * @override
   */
  toString() {
    return this.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue_ + '';
  }
};


/**
 * @override
 * @const
 */
goog.html.TrustedResourceUrl.prototype.implementsGoogStringTypedString = true;


/**
 * Returns this TrustedResourceUrl's value as a string.
 *
 * IMPORTANT: In code where it is security relevant that an object's type is
 * indeed `TrustedResourceUrl`, use
 * `goog.html.TrustedResourceUrl.unwrap` instead of this method. If in
 * doubt, assume that it's security relevant. In particular, note that
 * goog.html functions which return a goog.html type do not guarantee that
 * the returned instance is of the right type. For example:
 *
 * <pre>
 * var fakeSafeHtml = new String('fake');
 * fakeSafeHtml.__proto__ = goog.html.SafeHtml.prototype;
 * var newSafeHtml = goog.html.SafeHtml.htmlEscape(fakeSafeHtml);
 * // newSafeHtml is just an alias for fakeSafeHtml, it's passed through by
 * // goog.html.SafeHtml.htmlEscape() as fakeSafeHtml instanceof
 * // goog.html.SafeHtml.
 * </pre>
 *
 * @see goog.html.TrustedResourceUrl#unwrap
 * @override
 */
goog.html.TrustedResourceUrl.prototype.getTypedStringValue = function() {
  'use strict';
  return this.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue_
      .toString();
};


/**
 * Creates a new TrustedResourceUrl with params added to URL. Both search and
 * hash params can be specified.
 *
 * @param {string|?Object<string, *>|undefined} searchParams Search parameters
 *     to add to URL. See goog.html.TrustedResourceUrl.stringifyParams_ for
 *     exact format definition.
 * @param {(string|?Object<string, *>)=} opt_hashParams Hash parameters to add
 *     to URL. See goog.html.TrustedResourceUrl.stringifyParams_ for exact
 *     format definition.
 * @return {!goog.html.TrustedResourceUrl} New TrustedResourceUrl with params.
 */
goog.html.TrustedResourceUrl.prototype.cloneWithParams = function(
    searchParams, opt_hashParams) {
  'use strict';
  var url = goog.html.TrustedResourceUrl.unwrap(this);
  var parts = goog.html.TrustedResourceUrl.URL_PARAM_PARSER_.exec(url);
  var urlBase = parts[1];
  var urlSearch = parts[2] || '';
  var urlHash = parts[3] || '';

  return goog.html.TrustedResourceUrl
      .createTrustedResourceUrlSecurityPrivateDoNotAccessOrElse(
          urlBase +
          goog.html.TrustedResourceUrl.stringifyParams_(
              '?', urlSearch, searchParams) +
          goog.html.TrustedResourceUrl.stringifyParams_(
              '#', urlHash, opt_hashParams));
};

/**
 * Performs a runtime check that the provided object is indeed a
 * TrustedResourceUrl object, and returns its value.
 *
 * @param {!goog.html.TrustedResourceUrl} trustedResourceUrl The object to
 *     extract from.
 * @return {string} The trustedResourceUrl object's contained string, unless
 *     the run-time type check fails. In that case, `unwrap` returns an
 *     innocuous string, or, if assertions are enabled, throws
 *     `goog.asserts.AssertionError`.
 */
goog.html.TrustedResourceUrl.unwrap = function(trustedResourceUrl) {
  'use strict';
  return goog.html.TrustedResourceUrl.unwrapTrustedScriptURL(trustedResourceUrl)
      .toString();
};


/**
 * Unwraps value as TrustedScriptURL if supported or as a string if not.
 * @param {!goog.html.TrustedResourceUrl} trustedResourceUrl
 * @return {!TrustedScriptURL|string}
 * @see goog.html.TrustedResourceUrl.unwrap
 */
goog.html.TrustedResourceUrl.unwrapTrustedScriptURL = function(
    trustedResourceUrl) {
  'use strict';
  // Perform additional Run-time type-checking to ensure that
  // trustedResourceUrl is indeed an instance of the expected type.  This
  // provides some additional protection against security bugs due to
  // application code that disables type checks.
  // Specifically, the following checks are performed:
  // 1. The object is an instance of the expected type.
  // 2. The object is not an instance of a subclass.
  if (trustedResourceUrl instanceof goog.html.TrustedResourceUrl &&
      trustedResourceUrl.constructor === goog.html.TrustedResourceUrl) {
    return trustedResourceUrl
        .privateDoNotAccessOrElseTrustedResourceUrlWrappedValue_;
  } else {
    goog.asserts.fail('expected object of type TrustedResourceUrl, got \'' +
        trustedResourceUrl + '\' of type ' + goog.typeOf(trustedResourceUrl));
    return 'type_error:TrustedResourceUrl';
  }
};


/**
 * Creates a TrustedResourceUrl from a format string and arguments.
 *
 * The arguments for interpolation into the format string map labels to values.
 * Values of type `goog.string.Const` are interpolated without modifcation.
 * Values of other types are cast to string and encoded with
 * encodeURIComponent.
 *
 * `%{<label>}` markers are used in the format string to indicate locations
 * to be interpolated with the valued mapped to the given label. `<label>`
 * must contain only alphanumeric and `_` characters.
 *
 * The format string must match goog.html.TrustedResourceUrl.BASE_URL_.
 *
 * Example usage:
 *
 *    var url = goog.html.TrustedResourceUrl.format(goog.string.Const.from(
 *        'https://www.google.com/search?q=%{query}'), {'query': searchTerm});
 *
 *    var url = goog.html.TrustedResourceUrl.format(goog.string.Const.from(
 *        '//www.youtube.com/v/%{videoId}?hl=en&fs=1%{autoplay}'), {
 *        'videoId': videoId,
 *        'autoplay': opt_autoplay ?
 *            goog.string.Const.from('&autoplay=1') : goog.string.Const.EMPTY
 *    });
 *
 * While this function can be used to create a TrustedResourceUrl from only
 * constants, fromConstant() and fromConstants() are generally preferable for
 * that purpose.
 *
 * @param {!goog.string.Const} format The format string.
 * @param {!Object<string, (string|number|!goog.string.Const)>} args Mapping
 *     of labels to values to be interpolated into the format string.
 *     goog.string.Const values are interpolated without encoding.
 * @return {!goog.html.TrustedResourceUrl}
 * @throws {!Error} On an invalid format string or if a label used in the
 *     the format string is not present in args.
 */
goog.html.TrustedResourceUrl.format = function(format, args) {
  'use strict';
  var formatStr = goog.string.Const.unwrap(format);
  if (!goog.html.TrustedResourceUrl.BASE_URL_.test(formatStr)) {
    throw new Error('Invalid TrustedResourceUrl format: ' + formatStr);
  }
  var result = formatStr.replace(
      goog.html.TrustedResourceUrl.FORMAT_MARKER_, function(match, id) {
        'use strict';
        if (!Object.prototype.hasOwnProperty.call(args, id)) {
          throw new Error(
              'Found marker, "' + id + '", in format string, "' + formatStr +
              '", but no valid label mapping found ' +
              'in args: ' + JSON.stringify(args));
        }
        var arg = args[id];
        if (arg instanceof goog.string.Const) {
          return goog.string.Const.unwrap(arg);
        } else {
          return encodeURIComponent(String(arg));
        }
      });
  return goog.html.TrustedResourceUrl
      .createTrustedResourceUrlSecurityPrivateDoNotAccessOrElse(result);
};


/**
 * @private @const {!RegExp}
 */
goog.html.TrustedResourceUrl.FORMAT_MARKER_ = /%{(\w+)}/g;


/**
 * The URL must be absolute, scheme-relative or path-absolute. So it must
 * start with:
 * - https:// followed by allowed origin characters.
 * - // followed by allowed origin characters.
 * - Any absolute or relative path.
 *
 * Based on
 * https://url.spec.whatwg.org/commit-snapshots/56b74ce7cca8883eab62e9a12666e2fac665d03d/#url-parsing
 * an initial / which is not followed by another / or \ will end up in the "path
 * state" and from there it can only go to "fragment state" and "query state".
 *
 * We don't enforce a well-formed domain name. So '.' or '1.2' are valid.
 * That's ok because the origin comes from a compile-time constant.
 *
 * A regular expression is used instead of goog.uri for several reasons:
 * - Strictness. E.g. we don't want any userinfo component and we don't
 *   want '/./, nor \' in the first path component.
 * - Small trusted base. goog.uri is generic and might need to change,
 *   reasoning about all the ways it can parse a URL now and in the future
 *   is error-prone.
 * - Code size. We expect many calls to .format(), many of which might
 *   not be using goog.uri.
 * - Simplicity. Using goog.uri would likely not result in simpler nor shorter
 *   code.
 * @private @const {!RegExp}
 */
goog.html.TrustedResourceUrl.BASE_URL_ = new RegExp(
    '^((https:)?//[0-9a-z.:[\\]-]+/'  // Origin.
        + '|/[^/\\\\]'                // Absolute path.
        + '|[^:/\\\\%]+/'             // Relative path.
        + '|[^:/\\\\%]*[?#]'          // Query string or fragment.
        + '|about:blank#'             // about:blank with fragment.
        + ')',
    'i');

/**
 * RegExp for splitting a URL into the base, search field, and hash field.
 *
 * @private @const {!RegExp}
 */
goog.html.TrustedResourceUrl.URL_PARAM_PARSER_ =
    /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;


/**
 * Formats the URL same as TrustedResourceUrl.format and then adds extra URL
 * parameters.
 *
 * Example usage:
 *
 *     // Creates '//www.youtube.com/v/abc?autoplay=1' for videoId='abc' and
 *     // opt_autoplay=1. Creates '//www.youtube.com/v/abc' for videoId='abc'
 *     // and opt_autoplay=undefined.
 *     var url = goog.html.TrustedResourceUrl.formatWithParams(
 *         goog.string.Const.from('//www.youtube.com/v/%{videoId}'),
 *         {'videoId': videoId},
 *         {'autoplay': opt_autoplay});
 *
 * @param {!goog.string.Const} format The format string.
 * @param {!Object<string, (string|number|!goog.string.Const)>} args Mapping
 *     of labels to values to be interpolated into the format string.
 *     goog.string.Const values are interpolated without encoding.
 * @param {string|?Object<string, *>|undefined} searchParams Parameters to add
 *     to URL. See goog.html.TrustedResourceUrl.stringifyParams_ for exact
 *     format definition.
 * @param {(string|?Object<string, *>)=} opt_hashParams Hash parameters to add
 *     to URL. See goog.html.TrustedResourceUrl.stringifyParams_ for exact
 *     format definition.
 * @return {!goog.html.TrustedResourceUrl}
 * @throws {!Error} On an invalid format string or if a label used in the
 *     the format string is not present in args.
 */
goog.html.TrustedResourceUrl.formatWithParams = function(
    format, args, searchParams, opt_hashParams) {
  'use strict';
  var url = goog.html.TrustedResourceUrl.format(format, args);
  return url.cloneWithParams(searchParams, opt_hashParams);
};


/**
 * Creates a TrustedResourceUrl object from a compile-time constant string.
 *
 * Compile-time constant strings are inherently program-controlled and hence
 * trusted.
 *
 * @param {!goog.string.Const} url A compile-time-constant string from which to
 *     create a TrustedResourceUrl.
 * @return {!goog.html.TrustedResourceUrl} A TrustedResourceUrl object
 *     initialized to `url`.
 */
goog.html.TrustedResourceUrl.fromConstant = function(url) {
  'use strict';
  return goog.html.TrustedResourceUrl
      .createTrustedResourceUrlSecurityPrivateDoNotAccessOrElse(
          goog.string.Const.unwrap(url));
};


/**
 * Creates a TrustedResourceUrl object from a compile-time constant strings.
 *
 * Compile-time constant strings are inherently program-controlled and hence
 * trusted.
 *
 * @param {!Array<!goog.string.Const>} parts Compile-time-constant strings from
 *     which to create a TrustedResourceUrl.
 * @return {!goog.html.TrustedResourceUrl} A TrustedResourceUrl object
 *     initialized to concatenation of `parts`.
 */
goog.html.TrustedResourceUrl.fromConstants = function(parts) {
  'use strict';
  var unwrapped = '';
  for (var i = 0; i < parts.length; i++) {
    unwrapped += goog.string.Const.unwrap(parts[i]);
  }
  return goog.html.TrustedResourceUrl
      .createTrustedResourceUrlSecurityPrivateDoNotAccessOrElse(unwrapped);
};

/**
 * Creates a TrustedResourceUrl object by generating a Blob from a SafeScript
 * object and then calling createObjectURL with that blob.
 *
 * SafeScript objects are trusted to contain executable JavaScript code.
 *
 * Caller must call goog.fs.url.revokeObjectUrl() on the unwrapped url to
 * release the underlying blob.
 *
 * Throws if browser doesn't support blob construction.
 *
 * @param {!goog.html.SafeScript} safeScript A script from which to create a
 *     TrustedResourceUrl.
 * @return {!goog.html.TrustedResourceUrl} A TrustedResourceUrl object
 *     initialized to a new blob URL.
 */
goog.html.TrustedResourceUrl.fromSafeScript = function(safeScript) {
  'use strict';
  var blob = goog.fs.blob.getBlobWithProperties(
      [goog.html.SafeScript.unwrap(safeScript)], 'text/javascript');
  var url = goog.fs.url.createObjectUrl(blob);
  return goog.html.TrustedResourceUrl
      .createTrustedResourceUrlSecurityPrivateDoNotAccessOrElse(url);
};


/**
 * Token used to ensure that object is created only from this file. No code
 * outside of this file can access this token.
 * @private {!Object}
 * @const
 */
goog.html.TrustedResourceUrl.CONSTRUCTOR_TOKEN_PRIVATE_ = {};


/**
 * Package-internal utility method to create TrustedResourceUrl instances.
 *
 * @param {string} url The string to initialize the TrustedResourceUrl object
 *     with.
 * @return {!goog.html.TrustedResourceUrl} The initialized TrustedResourceUrl
 *     object.
 * @package
 */
goog.html.TrustedResourceUrl
    .createTrustedResourceUrlSecurityPrivateDoNotAccessOrElse = function(url) {
  'use strict';
  /** @noinline */
  const noinlineUrl = url;
  const policy = goog.html.trustedtypes.getPolicyPrivateDoNotAccessOrElse();
  const value = policy ? policy.createScriptURL(noinlineUrl) : noinlineUrl;
  return new goog.html.TrustedResourceUrl(
      value, goog.html.TrustedResourceUrl.CONSTRUCTOR_TOKEN_PRIVATE_);
};


/**
 * Stringifies the passed params to be used as either a search or hash field of
 * a URL.
 *
 * @param {string} prefix The prefix character for the given field ('?' or '#').
 * @param {string} currentString The existing field value (including the prefix
 *     character, if the field is present).
 * @param {string|?Object<string, *>|undefined} params The params to set or
 *     append to the field.
 * - If `undefined` or `null`, the field remains unchanged.
 * - If a string, then the string will be escaped and the field will be
 *   overwritten with that value.
 * - If an Object, that object is treated as a set of key-value pairs to be
 *   appended to the current field. Note that JavaScript doesn't guarantee the
 *   order of values in an object which might result in non-deterministic order
 *   of the parameters. However, browsers currently preserve the order. The
 *   rules for each entry:
 *   - If an array, it will be processed as if each entry were an additional
 *     parameter with exactly the same key, following the same logic below.
 *   - If `undefined` or `null`, it will be skipped.
 *   - Otherwise, it will be turned into a string, escaped, and appended.
 * @return {string}
 * @private
 */
goog.html.TrustedResourceUrl.stringifyParams_ = function(
    prefix, currentString, params) {
  'use strict';
  if (params == null) {
    // Do not modify the field.
    return currentString;
  }
  if (typeof params === 'string') {
    // Set field to the passed string.
    return params ? prefix + encodeURIComponent(params) : '';
  }
  // Add on parameters to field from key-value object.
  for (var key in params) {
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty#Using_hasOwnProperty_as_a_property_name
    if (Object.prototype.hasOwnProperty.call(params, key)) {
      var value = params[key];
      var outputValues = Array.isArray(value) ? value : [value];
      for (var i = 0; i < outputValues.length; i++) {
        var outputValue = outputValues[i];
        if (outputValue != null) {
          if (!currentString) {
            currentString = prefix;
          }
          currentString += (currentString.length > prefix.length ? '&' : '') +
              encodeURIComponent(key) + '=' +
              encodeURIComponent(String(outputValue));
        }
      }
    }
  }
  return currentString;
};

//third_party/javascript/closure/string/internal.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview String functions called from Closure packages that couldn't
 * depend on each other. Outside Closure, use goog.string function which
 * delegate to these.
 */


goog.provide('goog.string.internal');


/**
 * Fast prefix-checker.
 * @param {string} str The string to check.
 * @param {string} prefix A string to look for at the start of `str`.
 * @return {boolean} True if `str` begins with `prefix`.
 * @see goog.string.startsWith
 */
goog.string.internal.startsWith = function(str, prefix) {
  'use strict';
  return str.lastIndexOf(prefix, 0) == 0;
};


/**
 * Fast suffix-checker.
 * @param {string} str The string to check.
 * @param {string} suffix A string to look for at the end of `str`.
 * @return {boolean} True if `str` ends with `suffix`.
 * @see goog.string.endsWith
 */
goog.string.internal.endsWith = function(str, suffix) {
  'use strict';
  const l = str.length - suffix.length;
  return l >= 0 && str.indexOf(suffix, l) == l;
};


/**
 * Case-insensitive prefix-checker.
 * @param {string} str The string to check.
 * @param {string} prefix  A string to look for at the end of `str`.
 * @return {boolean} True if `str` begins with `prefix` (ignoring
 *     case).
 * @see goog.string.caseInsensitiveStartsWith
 */
goog.string.internal.caseInsensitiveStartsWith = function(str, prefix) {
  'use strict';
  return (
      goog.string.internal.caseInsensitiveCompare(
          prefix, str.slice(0, prefix.length)) == 0);
};


/**
 * Case-insensitive suffix-checker.
 * @param {string} str The string to check.
 * @param {string} suffix A string to look for at the end of `str`.
 * @return {boolean} True if `str` ends with `suffix` (ignoring
 *     case).
 * @see goog.string.caseInsensitiveEndsWith
 */
goog.string.internal.caseInsensitiveEndsWith = function(str, suffix) {
  'use strict';
  return (
      goog.string.internal.caseInsensitiveCompare(
          suffix, str.slice(str.length - suffix.length)) == 0);
};


/**
 * Case-insensitive equality checker.
 * @param {string} str1 First string to check.
 * @param {string} str2 Second string to check.
 * @return {boolean} True if `str1` and `str2` are the same string,
 *     ignoring case.
 * @see goog.string.caseInsensitiveEquals
 */
goog.string.internal.caseInsensitiveEquals = function(str1, str2) {
  'use strict';
  return str1.toLowerCase() == str2.toLowerCase();
};


/**
 * Checks if a string is empty or contains only whitespaces.
 * @param {string} str The string to check.
 * @return {boolean} Whether `str` is empty or whitespace only.
 * @see goog.string.isEmptyOrWhitespace
 */
goog.string.internal.isEmptyOrWhitespace = function(str) {
  'use strict';
  // testing length == 0 first is actually slower in all browsers (about the
  // same in Opera).
  // Since IE doesn't include non-breaking-space (0xa0) in their \s character
  // class (as required by section 7.2 of the ECMAScript spec), we explicitly
  // include it in the regexp to enforce consistent cross-browser behavior.
  return /^[\s\xa0]*$/.test(str);
};


/**
 * Trims white spaces to the left and right of a string.
 * @param {string} str The string to trim.
 * @return {string} A trimmed copy of `str`.
 */
goog.string.internal.trim =
    (goog.TRUSTED_SITE && String.prototype.trim) ? function(str) {
      'use strict';
      return str.trim();
    } : function(str) {
      'use strict';
      // Since IE doesn't include non-breaking-space (0xa0) in their \s
      // character class (as required by section 7.2 of the ECMAScript spec),
      // we explicitly include it in the regexp to enforce consistent
      // cross-browser behavior.
      // NOTE: We don't use String#replace because it might have side effects
      // causing this function to not compile to 0 bytes.
      return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(str)[1];
    };


/**
 * A string comparator that ignores case.
 * -1 = str1 less than str2
 *  0 = str1 equals str2
 *  1 = str1 greater than str2
 *
 * @param {string} str1 The string to compare.
 * @param {string} str2 The string to compare `str1` to.
 * @return {number} The comparator result, as described above.
 * @see goog.string.caseInsensitiveCompare
 */
goog.string.internal.caseInsensitiveCompare = function(str1, str2) {
  'use strict';
  const test1 = String(str1).toLowerCase();
  const test2 = String(str2).toLowerCase();

  if (test1 < test2) {
    return -1;
  } else if (test1 == test2) {
    return 0;
  } else {
    return 1;
  }
};


/**
 * Converts \n to <br>s or <br />s.
 * @param {string} str The string in which to convert newlines.
 * @param {boolean=} opt_xml Whether to use XML compatible tags.
 * @return {string} A copy of `str` with converted newlines.
 * @see goog.string.newLineToBr
 */
goog.string.internal.newLineToBr = function(str, opt_xml) {
  'use strict';
  return str.replace(/(\r\n|\r|\n)/g, opt_xml ? '<br />' : '<br>');
};


/**
 * Escapes double quote '"' and single quote '\'' characters in addition to
 * '&', '<', and '>' so that a string can be included in an HTML tag attribute
 * value within double or single quotes.
 * @param {string} str string to be escaped.
 * @param {boolean=} opt_isLikelyToContainHtmlChars
 * @return {string} An escaped copy of `str`.
 * @see goog.string.htmlEscape
 */
goog.string.internal.htmlEscape = function(
    str, opt_isLikelyToContainHtmlChars) {
  'use strict';
  if (opt_isLikelyToContainHtmlChars) {
    str = str.replace(goog.string.internal.AMP_RE_, '&amp;')
              .replace(goog.string.internal.LT_RE_, '&lt;')
              .replace(goog.string.internal.GT_RE_, '&gt;')
              .replace(goog.string.internal.QUOT_RE_, '&quot;')
              .replace(goog.string.internal.SINGLE_QUOTE_RE_, '&#39;')
              .replace(goog.string.internal.NULL_RE_, '&#0;');
    return str;

  } else {
    // quick test helps in the case when there are no chars to replace, in
    // worst case this makes barely a difference to the time taken
    if (!goog.string.internal.ALL_RE_.test(str)) return str;

    // str.indexOf is faster than regex.test in this case
    if (str.indexOf('&') != -1) {
      str = str.replace(goog.string.internal.AMP_RE_, '&amp;');
    }
    if (str.indexOf('<') != -1) {
      str = str.replace(goog.string.internal.LT_RE_, '&lt;');
    }
    if (str.indexOf('>') != -1) {
      str = str.replace(goog.string.internal.GT_RE_, '&gt;');
    }
    if (str.indexOf('"') != -1) {
      str = str.replace(goog.string.internal.QUOT_RE_, '&quot;');
    }
    if (str.indexOf('\'') != -1) {
      str = str.replace(goog.string.internal.SINGLE_QUOTE_RE_, '&#39;');
    }
    if (str.indexOf('\x00') != -1) {
      str = str.replace(goog.string.internal.NULL_RE_, '&#0;');
    }
    return str;
  }
};


/**
 * Regular expression that matches an ampersand, for use in escaping.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.AMP_RE_ = /&/g;


/**
 * Regular expression that matches a less than sign, for use in escaping.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.LT_RE_ = /</g;


/**
 * Regular expression that matches a greater than sign, for use in escaping.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.GT_RE_ = />/g;


/**
 * Regular expression that matches a double quote, for use in escaping.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.QUOT_RE_ = /"/g;


/**
 * Regular expression that matches a single quote, for use in escaping.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.SINGLE_QUOTE_RE_ = /'/g;


/**
 * Regular expression that matches null character, for use in escaping.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.NULL_RE_ = /\x00/g;


/**
 * Regular expression that matches any character that needs to be escaped.
 * @const {!RegExp}
 * @private
 */
goog.string.internal.ALL_RE_ = /[\x00&<>"']/;


/**
 * Do escaping of whitespace to preserve spatial formatting. We use character
 * entity #160 to make it safer for xml.
 * @param {string} str The string in which to escape whitespace.
 * @param {boolean=} opt_xml Whether to use XML compatible tags.
 * @return {string} An escaped copy of `str`.
 * @see goog.string.whitespaceEscape
 */
goog.string.internal.whitespaceEscape = function(str, opt_xml) {
  'use strict';
  // This doesn't use goog.string.preserveSpaces for backwards compatibility.
  return goog.string.internal.newLineToBr(
      str.replace(/  /g, ' &#160;'), opt_xml);
};


/**
 * Determines whether a string contains a substring.
 * @param {string} str The string to search.
 * @param {string} subString The substring to search for.
 * @return {boolean} Whether `str` contains `subString`.
 * @see goog.string.contains
 */
goog.string.internal.contains = function(str, subString) {
  'use strict';
  return str.indexOf(subString) != -1;
};


/**
 * Determines whether a string contains a substring, ignoring case.
 * @param {string} str The string to search.
 * @param {string} subString The substring to search for.
 * @return {boolean} Whether `str` contains `subString`.
 * @see goog.string.caseInsensitiveContains
 */
goog.string.internal.caseInsensitiveContains = function(str, subString) {
  'use strict';
  return goog.string.internal.contains(
      str.toLowerCase(), subString.toLowerCase());
};


/**
 * Compares two version numbers.
 *
 * @param {string|number} version1 Version of first item.
 * @param {string|number} version2 Version of second item.
 *
 * @return {number}  1 if `version1` is higher.
 *                   0 if arguments are equal.
 *                  -1 if `version2` is higher.
 * @see goog.string.compareVersions
 */
goog.string.internal.compareVersions = function(version1, version2) {
  'use strict';
  let order = 0;
  // Trim leading and trailing whitespace and split the versions into
  // subversions.
  const v1Subs = goog.string.internal.trim(String(version1)).split('.');
  const v2Subs = goog.string.internal.trim(String(version2)).split('.');
  const subCount = Math.max(v1Subs.length, v2Subs.length);

  // Iterate over the subversions, as long as they appear to be equivalent.
  for (let subIdx = 0; order == 0 && subIdx < subCount; subIdx++) {
    let v1Sub = v1Subs[subIdx] || '';
    let v2Sub = v2Subs[subIdx] || '';

    do {
      // Split the subversions into pairs of numbers and qualifiers (like 'b').
      // Two different RegExp objects are use to make it clear the code
      // is side-effect free
      const v1Comp = /(\d*)(\D*)(.*)/.exec(v1Sub) || ['', '', '', ''];
      const v2Comp = /(\d*)(\D*)(.*)/.exec(v2Sub) || ['', '', '', ''];
      // Break if there are no more matches.
      if (v1Comp[0].length == 0 && v2Comp[0].length == 0) {
        break;
      }

      // Parse the numeric part of the subversion. A missing number is
      // equivalent to 0.
      const v1CompNum = v1Comp[1].length == 0 ? 0 : parseInt(v1Comp[1], 10);
      const v2CompNum = v2Comp[1].length == 0 ? 0 : parseInt(v2Comp[1], 10);

      // Compare the subversion components. The number has the highest
      // precedence. Next, if the numbers are equal, a subversion without any
      // qualifier is always higher than a subversion with any qualifier. Next,
      // the qualifiers are compared as strings.
      order = goog.string.internal.compareElements_(v1CompNum, v2CompNum) ||
          goog.string.internal.compareElements_(
              v1Comp[2].length == 0, v2Comp[2].length == 0) ||
          goog.string.internal.compareElements_(v1Comp[2], v2Comp[2]);
      // Stop as soon as an inequality is discovered.

      v1Sub = v1Comp[3];
      v2Sub = v2Comp[3];
    } while (order == 0);
  }

  return order;
};


/**
 * Compares elements of a version number.
 *
 * @param {string|number|boolean} left An element from a version number.
 * @param {string|number|boolean} right An element from a version number.
 *
 * @return {number}  1 if `left` is higher.
 *                   0 if arguments are equal.
 *                  -1 if `right` is higher.
 * @private
 */
goog.string.internal.compareElements_ = function(left, right) {
  'use strict';
  if (left < right) {
    return -1;
  } else if (left > right) {
    return 1;
  }
  return 0;
};

//third_party/javascript/closure/html/safeurl.js
/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview The SafeUrl type and its builders.
 *
 * TODO(xtof): Link to document stating type contract.
 */

goog.provide('goog.html.SafeUrl');

goog.require('goog.asserts');
goog.require('goog.fs.url');
goog.require('goog.html.TrustedResourceUrl');
goog.require('goog.string.Const');
goog.require('goog.string.TypedString');
goog.require('goog.string.internal');



/**
 * A string that is safe to use in URL context in DOM APIs and HTML documents.
 *
 * A SafeUrl is a string-like object that carries the security type contract
 * that its value as a string will not cause untrusted script execution
 * when evaluated as a hyperlink URL in a browser.
 *
 * Values of this type are guaranteed to be safe to use in URL/hyperlink
 * contexts, such as assignment to URL-valued DOM properties, in the sense that
 * the use will not result in a Cross-Site-Scripting vulnerability. Similarly,
 * SafeUrls can be interpolated into the URL context of an HTML template (e.g.,
 * inside a href attribute). However, appropriate HTML-escaping must still be
 * applied.
 *
 * Note that, as documented in `goog.html.SafeUrl.unwrap`, this type's
 * contract does not guarantee that instances are safe to interpolate into HTML
 * without appropriate escaping.
 *
 * Note also that this type's contract does not imply any guarantees regarding
 * the resource the URL refers to.  In particular, SafeUrls are <b>not</b>
 * safe to use in a context where the referred-to resource is interpreted as
 * trusted code, e.g., as the src of a script tag.
 *
 * Instances of this type must be created via the factory methods
 * (`goog.html.SafeUrl.fromConstant`, `goog.html.SafeUrl.sanitize`),
 * etc and not by invoking its constructor. The constructor intentionally takes
 * an extra parameter that cannot be constructed outside of this file and the
 * type is immutable; hence only a default instance corresponding to the empty
 * string can be obtained via constructor invocation.
 *
 * @see goog.html.SafeUrl#fromConstant
 * @see goog.html.SafeUrl#from
 * @see goog.html.SafeUrl#sanitize
 * @final
 * @struct
 * @implements {goog.string.TypedString}
 */
goog.html.SafeUrl = class {
  /**
   * @param {string} value
   * @param {!Object} token package-internal implementation detail.
   */
  constructor(value, token) {
    /**
     * The contained value of this SafeUrl.  The field has a purposely ugly
     * name to make (non-compiled) code that attempts to directly access this
     * field stand out.
     * @private {string}
     */
    this.privateDoNotAccessOrElseSafeUrlWrappedValue_ =
        (token === goog.html.SafeUrl.CONSTRUCTOR_TOKEN_PRIVATE_) ? value : '';
  }

  /**
   * Returns a string-representation of this value.
   *
   * To obtain the actual string value wrapped in a SafeUrl, use
   * `goog.html.SafeUrl.unwrap`.
   *
   * @return {string}
   * @see goog.html.SafeUrl#unwrap
   * @override
   */
  toString() {
    return this.privateDoNotAccessOrElseSafeUrlWrappedValue_.toString();
  }
};


/**
 * The innocuous string generated by goog.html.SafeUrl.sanitize when passed
 * an unsafe URL.
 *
 * about:invalid is registered in
 * http://www.w3.org/TR/css3-values/#about-invalid.
 * http://tools.ietf.org/html/rfc6694#section-2.2.1 permits about URLs to
 * contain a fragment, which is not to be considered when determining if an
 * about URL is well-known.
 *
 * Using about:invalid seems preferable to using a fixed data URL, since
 * browsers might choose to not report CSP violations on it, as legitimate
 * CSS function calls to attr() can result in this URL being produced. It is
 * also a standard URL which matches exactly the semantics we need:
 * "The about:invalid URI references a non-existent document with a generic
 * error condition. It can be used when a URI is necessary, but the default
 * value shouldn't be resolveable as any type of document".
 *
 * @const {string}
 */
goog.html.SafeUrl.INNOCUOUS_STRING = 'about:invalid#zClosurez';


/**
 * @override
 * @const
 */
goog.html.SafeUrl.prototype.implementsGoogStringTypedString = true;


/**
 * Returns this SafeUrl's value as a string.
 *
 * IMPORTANT: In code where it is security relevant that an object's type is
 * indeed `SafeUrl`, use `goog.html.SafeUrl.unwrap` instead of this
 * method. If in doubt, assume that it's security relevant. In particular, note
 * that goog.html functions which return a goog.html type do not guarantee that
 * the returned instance is of the right type.
 *
 * IMPORTANT: The guarantees of the SafeUrl type contract only extend to the
 * behavior of browsers when interpreting URLs. Values of SafeUrl objects MUST
 * be appropriately escaped before embedding in a HTML document. Note that the
 * required escaping is context-sensitive (e.g. a different escaping is
 * required for embedding a URL in a style property within a style
 * attribute, as opposed to embedding in a href attribute).
 *
 * @see goog.html.SafeUrl#unwrap
 * @override
 */
goog.html.SafeUrl.prototype.getTypedStringValue = function() {
  'use strict';
  return this.privateDoNotAccessOrElseSafeUrlWrappedValue_.toString();
};

/**
 * Performs a runtime check that the provided object is indeed a SafeUrl
 * object, and returns its value.
 *
 * IMPORTANT: The guarantees of the SafeUrl type contract only extend to the
 * behavior of  browsers when interpreting URLs. Values of SafeUrl objects MUST
 * be appropriately escaped before embedding in a HTML document. Note that the
 * required escaping is context-sensitive (e.g. a different escaping is
 * required for embedding a URL in a style property within a style
 * attribute, as opposed to embedding in a href attribute).
 *
 * @param {!goog.html.SafeUrl} safeUrl The object to extract from.
 * @return {string} The SafeUrl object's contained string, unless the run-time
 *     type check fails. In that case, `unwrap` returns an innocuous
 *     string, or, if assertions are enabled, throws
 *     `goog.asserts.AssertionError`.
 */
goog.html.SafeUrl.unwrap = function(safeUrl) {
  'use strict';
  // Perform additional Run-time type-checking to ensure that safeUrl is indeed
  // an instance of the expected type.  This provides some additional protection
  // against security bugs due to application code that disables type checks.
  // Specifically, the following checks are performed:
  // 1. The object is an instance of the expected type.
  // 2. The object is not an instance of a subclass.
  if (safeUrl instanceof goog.html.SafeUrl &&
      safeUrl.constructor === goog.html.SafeUrl) {
    return safeUrl.privateDoNotAccessOrElseSafeUrlWrappedValue_;
  } else {
    goog.asserts.fail(
        'expected object of type SafeUrl, got \'' + safeUrl + '\' of type ' +
        goog.typeOf(safeUrl));
    return 'type_error:SafeUrl';
  }
};


/**
 * Creates a SafeUrl object from a compile-time constant string.
 *
 * Compile-time constant strings are inherently program-controlled and hence
 * trusted.
 *
 * @param {!goog.string.Const} url A compile-time-constant string from which to
 *         create a SafeUrl.
 * @return {!goog.html.SafeUrl} A SafeUrl object initialized to `url`.
 */
goog.html.SafeUrl.fromConstant = function(url) {
  'use strict';
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      goog.string.Const.unwrap(url));
};


/**
 * A pattern that matches Blob or data types that can have SafeUrls created
 * from URL.createObjectURL(blob) or via a data: URI.
 *
 * This has some parameter support (most notably, we haven't implemented the
 * more complex parts like %-encoded characters or non-alphanumerical ones for
 * simplicity's sake). The specs are fairly complex, and they don't
 * always match Chrome's behavior: we settled on a subset where we're confident
 * all parties involved agree.
 *
 * The spec is available at https://mimesniff.spec.whatwg.org/ (and see
 * https://tools.ietf.org/html/rfc2397 for data: urls, which override some of
 * it).
 * @const
 * @private
 */
goog.html.SAFE_MIME_TYPE_PATTERN_ = new RegExp(
    // Note: Due to content-sniffing concerns, only add MIME types for
    // media formats.
    '^(?:audio/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-matroska|x-wav|wav|webm)|' +
        'font/\\w+|' +
        'image/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon|heic|heif)|' +
        'video/(?:mpeg|mp4|ogg|webm|quicktime|x-matroska))' +
        '(?:;\\w+=(?:\\w+|"[\\w;,= ]+"))*$',  // MIME type parameters
    'i');


/**
 * @param {string} mimeType The MIME type to check if safe.
 * @return {boolean} True if the MIME type is safe and creating a Blob via
 *   `SafeUrl.fromBlob()` with that type will not fail due to the type. False
 *   otherwise.
 */
goog.html.SafeUrl.isSafeMimeType = function(mimeType) {
  'use strict';
  return goog.html.SAFE_MIME_TYPE_PATTERN_.test(mimeType);
};


/**
 * Creates a SafeUrl wrapping a blob URL for the given `blob`.
 *
 * The blob URL is created with `URL.createObjectURL`. If the MIME type
 * for `blob` is not of a known safe audio, image or video MIME type,
 * then the SafeUrl will wrap {@link #INNOCUOUS_STRING}.
 *
 * Note: Call {@link revokeObjectUrl} on the URL after it's used
 * to prevent memory leaks.
 *
 * @see http://www.w3.org/TR/FileAPI/#url
 * @param {!Blob} blob
 * @return {!goog.html.SafeUrl} The blob URL, or an innocuous string wrapped
 *   as a SafeUrl.
 */
goog.html.SafeUrl.fromBlob = function(blob) {
  'use strict';
  var url = goog.html.SafeUrl.isSafeMimeType(blob.type) ?
      goog.fs.url.createObjectUrl(blob) :
      goog.html.SafeUrl.INNOCUOUS_STRING;
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(url);
};


/**
 * Revokes an object URL created for a safe URL created {@link fromBlob()}.
 * @param {!goog.html.SafeUrl} safeUrl SafeUrl wrapping a blob object.
 * @return {void}
 */
goog.html.SafeUrl.revokeObjectUrl = function(safeUrl) {
  'use strict';
  var url = safeUrl.getTypedStringValue();
  if (url !== goog.html.SafeUrl.INNOCUOUS_STRING) {
    goog.fs.url.revokeObjectUrl(url);
  }
};


/**
 * Creates a SafeUrl wrapping a blob URL created for a MediaSource.
 * @param {!MediaSource} mediaSource
 * @return {!goog.html.SafeUrl} The blob URL.
 */
goog.html.SafeUrl.fromMediaSource = function(mediaSource) {
  'use strict';
  goog.asserts.assert(
      'MediaSource' in goog.global, 'No support for MediaSource');
  const url = mediaSource instanceof MediaSource ?
      goog.fs.url.createObjectUrl(mediaSource) :
      goog.html.SafeUrl.INNOCUOUS_STRING;
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(url);
};


/**
 * Matches a base-64 data URL, with the first match group being the MIME type.
 * @const
 * @private
 */
goog.html.DATA_URL_PATTERN_ = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;


/**
 * Attempts to create a SafeUrl wrapping a `data:` URL, after validating it
 * matches a known-safe media MIME type. If it doesn't match, return `null`.
 *
 * @param {string} dataUrl A valid base64 data URL with one of the whitelisted
 *     media MIME types.
 * @return {?goog.html.SafeUrl} A matching safe URL, or `null` if it does not
 *     pass.
 */
goog.html.SafeUrl.tryFromDataUrl = function(dataUrl) {
  'use strict';
  // For defensive purposes, in case users cast around the parameter type.
  dataUrl = String(dataUrl);
  // RFC4648 suggest to ignore CRLF in base64 encoding.
  // See https://tools.ietf.org/html/rfc4648.
  // Remove the CR (%0D) and LF (%0A) from the dataUrl.
  var filteredDataUrl = dataUrl.replace(/(%0A|%0D)/g, '');
  var match = filteredDataUrl.match(goog.html.DATA_URL_PATTERN_);
  // Note: The only risk of XSS here is if the `data:` URL results in a
  // same-origin document. In which case content-sniffing might cause the
  // browser to interpret the contents as html.
  // All modern browsers consider `data:` URL documents to have unique empty
  // origins. Only Firefox for versions prior to v57 behaves differently:
  // https://blog.mozilla.org/security/2017/10/04/treating-data-urls-unique-origins-firefox-57/
  // Older versions of IE don't understand `data:` urls, so it is not an issue.
  if (match) {
    return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
        filteredDataUrl);
  }
  return null;
};


/**
 * Creates a SafeUrl wrapping a `data:` URL, after validating it matches a
 * known-safe media MIME type. If it doesn't match, return
 * `goog.html.SafeUrl.INNOCUOUS_URL`.
 *
 * @param {string} dataUrl A valid base64 data URL with one of the whitelisted
 *     media MIME types.
 * @return {!goog.html.SafeUrl} A matching safe URL, or
 *     `goog.html.SafeUrl.INNOCUOUS_URL` if it does not pass.
 */
goog.html.SafeUrl.fromDataUrl = function(dataUrl) {
  'use strict';
  return goog.html.SafeUrl.tryFromDataUrl(dataUrl) ||
      goog.html.SafeUrl.INNOCUOUS_URL;
};


/**
 * Creates a SafeUrl wrapping a tel: URL.
 *
 * @param {string} telUrl A tel URL.
 * @return {!goog.html.SafeUrl} A matching safe URL, or {@link INNOCUOUS_STRING}
 *     wrapped as a SafeUrl if it does not pass.
 */
goog.html.SafeUrl.fromTelUrl = function(telUrl) {
  'use strict';
  // There's a risk that a tel: URL could immediately place a call once
  // clicked, without requiring user confirmation. For that reason it is
  // handled in this separate function.
  if (!goog.string.internal.caseInsensitiveStartsWith(telUrl, 'tel:')) {
    telUrl = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      telUrl);
};


/**
 * Matches a sip/sips URL. We only allow urls that consist of an email address.
 * The characters '?' and '#' are not allowed in the local part of the email
 * address.
 * @const
 * @private
 */
goog.html.SIP_URL_PATTERN_ = new RegExp(
    '^sip[s]?:[+a-z0-9_.!$%&\'*\\/=^`{|}~-]+@([a-z0-9-]+\\.)+[a-z0-9]{2,63}$',
    'i');


/**
 * Creates a SafeUrl wrapping a sip: URL. We only allow urls that consist of an
 * email address. The characters '?' and '#' are not allowed in the local part
 * of the email address.
 *
 * @param {string} sipUrl A sip URL.
 * @return {!goog.html.SafeUrl} A matching safe URL, or {@link INNOCUOUS_STRING}
 *     wrapped as a SafeUrl if it does not pass.
 */
goog.html.SafeUrl.fromSipUrl = function(sipUrl) {
  'use strict';
  if (!goog.html.SIP_URL_PATTERN_.test(decodeURIComponent(sipUrl))) {
    sipUrl = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      sipUrl);
};


/**
 * Creates a SafeUrl wrapping a fb-messenger://share URL.
 *
 * @param {string} facebookMessengerUrl A facebook messenger URL.
 * @return {!goog.html.SafeUrl} A matching safe URL, or {@link INNOCUOUS_STRING}
 *     wrapped as a SafeUrl if it does not pass.
 */
goog.html.SafeUrl.fromFacebookMessengerUrl = function(facebookMessengerUrl) {
  'use strict';
  if (!goog.string.internal.caseInsensitiveStartsWith(
          facebookMessengerUrl, 'fb-messenger://share')) {
    facebookMessengerUrl = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      facebookMessengerUrl);
};

/**
 * Creates a SafeUrl wrapping a whatsapp://send URL.
 *
 * @param {string} whatsAppUrl A WhatsApp URL.
 * @return {!goog.html.SafeUrl} A matching safe URL, or {@link INNOCUOUS_STRING}
 *     wrapped as a SafeUrl if it does not pass.
 */
goog.html.SafeUrl.fromWhatsAppUrl = function(whatsAppUrl) {
  'use strict';
  if (!goog.string.internal.caseInsensitiveStartsWith(
          whatsAppUrl, 'whatsapp://send')) {
    whatsAppUrl = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      whatsAppUrl);
};

/**
 * Creates a SafeUrl wrapping a sms: URL.
 *
 * @param {string} smsUrl A sms URL.
 * @return {!goog.html.SafeUrl} A matching safe URL, or {@link INNOCUOUS_STRING}
 *     wrapped as a SafeUrl if it does not pass.
 */
goog.html.SafeUrl.fromSmsUrl = function(smsUrl) {
  'use strict';
  if (!goog.string.internal.caseInsensitiveStartsWith(smsUrl, 'sms:') ||
      !goog.html.SafeUrl.isSmsUrlBodyValid_(smsUrl)) {
    smsUrl = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      smsUrl);
};


/**
 * Validates SMS URL `body` parameter, which is optional and should appear at
 * most once and should be percent-encoded if present. Rejects many malformed
 * bodies, but may spuriously reject some URLs and does not reject all malformed
 * sms: URLs.
 *
 * @param {string} smsUrl A sms URL.
 * @return {boolean} Whether SMS URL has a valid `body` parameter if it exists.
 * @private
 */
goog.html.SafeUrl.isSmsUrlBodyValid_ = function(smsUrl) {
  'use strict';
  var hash = smsUrl.indexOf('#');
  if (hash > 0) {
    smsUrl = smsUrl.substring(0, hash);
  }
  var bodyParams = smsUrl.match(/[?&]body=/gi);
  // "body" param is optional
  if (!bodyParams) {
    return true;
  }
  // "body" MUST only appear once
  if (bodyParams.length > 1) {
    return false;
  }
  // Get the encoded `body` parameter value.
  var bodyValue = smsUrl.match(/[?&]body=([^&]*)/)[1];
  if (!bodyValue) {
    return true;
  }
  try {
    decodeURIComponent(bodyValue);
  } catch (error) {
    return false;
  }
  return /^(?:[a-z0-9\-_.~]|%[0-9a-f]{2})+$/i.test(bodyValue);
};


/**
 * Creates a SafeUrl wrapping a ssh: URL.
 *
 * @param {string} sshUrl A ssh URL.
 * @return {!goog.html.SafeUrl} A matching safe URL, or {@link INNOCUOUS_STRING}
 *     wrapped as a SafeUrl if it does not pass.
 */
goog.html.SafeUrl.fromSshUrl = function(sshUrl) {
  'use strict';
  if (!goog.string.internal.caseInsensitiveStartsWith(sshUrl, 'ssh://')) {
    sshUrl = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      sshUrl);
};

/**
 * Sanitizes a Chrome extension URL to SafeUrl, given a compile-time-constant
 * extension identifier. Can also be restricted to chrome extensions.
 *
 * @param {string} url The url to sanitize. Should start with the extension
 *     scheme and the extension identifier.
 * @param {!goog.string.Const|!Array<!goog.string.Const>} extensionId The
 *     extension id to accept, as a compile-time constant or an array of those.
 *
 * @return {!goog.html.SafeUrl} Either `url` if it's deemed safe, or
 *     `INNOCUOUS_STRING` if it's not.
 */
goog.html.SafeUrl.sanitizeChromeExtensionUrl = function(url, extensionId) {
  'use strict';
  return goog.html.SafeUrl.sanitizeExtensionUrl_(
      /^chrome-extension:\/\/([^\/]+)\//, url, extensionId);
};

/**
 * Sanitizes a Firefox extension URL to SafeUrl, given a compile-time-constant
 * extension identifier. Can also be restricted to chrome extensions.
 *
 * @param {string} url The url to sanitize. Should start with the extension
 *     scheme and the extension identifier.
 * @param {!goog.string.Const|!Array<!goog.string.Const>} extensionId The
 *     extension id to accept, as a compile-time constant or an array of those.
 *
 * @return {!goog.html.SafeUrl} Either `url` if it's deemed safe, or
 *     `INNOCUOUS_STRING` if it's not.
 */
goog.html.SafeUrl.sanitizeFirefoxExtensionUrl = function(url, extensionId) {
  'use strict';
  return goog.html.SafeUrl.sanitizeExtensionUrl_(
      /^moz-extension:\/\/([^\/]+)\//, url, extensionId);
};

/**
 * Sanitizes a Edge extension URL to SafeUrl, given a compile-time-constant
 * extension identifier. Can also be restricted to chrome extensions.
 *
 * @param {string} url The url to sanitize. Should start with the extension
 *     scheme and the extension identifier.
 * @param {!goog.string.Const|!Array<!goog.string.Const>} extensionId The
 *     extension id to accept, as a compile-time constant or an array of those.
 *
 * @return {!goog.html.SafeUrl} Either `url` if it's deemed safe, or
 *     `INNOCUOUS_STRING` if it's not.
 */
goog.html.SafeUrl.sanitizeEdgeExtensionUrl = function(url, extensionId) {
  'use strict';
  return goog.html.SafeUrl.sanitizeExtensionUrl_(
      /^ms-browser-extension:\/\/([^\/]+)\//, url, extensionId);
};

/**
 * Private helper for converting extension URLs to SafeUrl, given the scheme for
 * that particular extension type. Use the sanitizeFirefoxExtensionUrl,
 * sanitizeChromeExtensionUrl or sanitizeEdgeExtensionUrl unless you're building
 * new helpers.
 *
 * @private
 * @param {!RegExp} scheme The scheme to accept as a RegExp extracting the
 *     extension identifier.
 * @param {string} url The url to sanitize. Should start with the extension
 *     scheme and the extension identifier.
 * @param {!goog.string.Const|!Array<!goog.string.Const>} extensionId The
 *     extension id to accept, as a compile-time constant or an array of those.
 *
 * @return {!goog.html.SafeUrl} Either `url` if it's deemed safe, or
 *     `INNOCUOUS_STRING` if it's not.
 */
goog.html.SafeUrl.sanitizeExtensionUrl_ = function(scheme, url, extensionId) {
  'use strict';
  var matches = scheme.exec(url);
  if (!matches) {
    url = goog.html.SafeUrl.INNOCUOUS_STRING;
  } else {
    var extractedExtensionId = matches[1];
    var acceptedExtensionIds;
    if (extensionId instanceof goog.string.Const) {
      acceptedExtensionIds = [goog.string.Const.unwrap(extensionId)];
    } else {
      acceptedExtensionIds = extensionId.map(function unwrap(x) {
        'use strict';
        return goog.string.Const.unwrap(x);
      });
    }
    if (acceptedExtensionIds.indexOf(extractedExtensionId) == -1) {
      url = goog.html.SafeUrl.INNOCUOUS_STRING;
    }
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(url);
};


/**
 * Creates a SafeUrl from TrustedResourceUrl. This is safe because
 * TrustedResourceUrl is more tightly restricted than SafeUrl.
 *
 * @param {!goog.html.TrustedResourceUrl} trustedResourceUrl
 * @return {!goog.html.SafeUrl}
 */
goog.html.SafeUrl.fromTrustedResourceUrl = function(trustedResourceUrl) {
  'use strict';
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
      goog.html.TrustedResourceUrl.unwrap(trustedResourceUrl));
};


/**
 * A pattern that recognizes a commonly useful subset of URLs that satisfy
 * the SafeUrl contract.
 *
 * This regular expression matches a subset of URLs that will not cause script
 * execution if used in URL context within a HTML document. Specifically, this
 * regular expression matches if (comment from here on and regex copied from
 * Soy's EscapingConventions):
 * (1) Either a protocol in a whitelist (http, https, mailto or ftp).
 * (2) or no protocol.  A protocol must be followed by a colon. The below
 *     allows that by allowing colons only after one of the characters [/?#].
 *     A colon after a hash (#) must be in the fragment.
 *     Otherwise, a colon after a (?) must be in a query.
 *     Otherwise, a colon after a single solidus (/) must be in a path.
 *     Otherwise, a colon after a double solidus (//) must be in the authority
 *     (before port).
 *
 * @private
 * @const {!RegExp}
 */
goog.html.SAFE_URL_PATTERN_ =
    /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

/**
 * Public version of goog.html.SAFE_URL_PATTERN_. Updating
 * goog.html.SAFE_URL_PATTERN_ doesn't seem to be backward compatible.
 * Namespace is also changed to goog.html.SafeUrl so it can be imported using
 * goog.require('goog.dom.SafeUrl').
 *
 * TODO(bangert): Remove SAFE_URL_PATTERN_
 * @const {!RegExp}
 */
goog.html.SafeUrl.SAFE_URL_PATTERN = goog.html.SAFE_URL_PATTERN_;

/**
 * Attempts to create a SafeUrl object from `url`. The input string is validated
 * to match a pattern of commonly used safe URLs. If validation fails, `null` is
 * returned.
 *
 * `url` may be a URL with the `http:`, `https:`, `mailto:`, `ftp:` or `data`
 * scheme, or a relative URL (i.e., a URL without a scheme; specifically, a
 * scheme-relative, absolute-path-relative, or path-relative URL).
 *
 * @see http://url.spec.whatwg.org/#concept-relative-url
 * @param {string|!goog.string.TypedString} url The URL to validate.
 * @return {?goog.html.SafeUrl} The validated URL, wrapped as a SafeUrl, or null
 *     if validation fails.
 */
goog.html.SafeUrl.trySanitize = function(url) {
  'use strict';
  if (url instanceof goog.html.SafeUrl) {
    return url;
  }
  if (typeof url == 'object' && url.implementsGoogStringTypedString) {
    url = /** @type {!goog.string.TypedString} */ (url).getTypedStringValue();
  } else {
    // For defensive purposes, in case users cast around the parameter type.
    url = String(url);
  }
  if (!goog.html.SAFE_URL_PATTERN_.test(url)) {
    return goog.html.SafeUrl.tryFromDataUrl(url);
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(url);
};

/**
 * Creates a SafeUrl object from `url`. If `url` is a
 * `goog.html.SafeUrl` then it is simply returned. Otherwise the input string is
 * validated to match a pattern of commonly used safe URLs. If validation fails,
 * `goog.html.SafeUrl.INNOCUOUS_URL` is returned.
 *
 * `url` may be a URL with the `http:`, `https:`, `mailto:`, `ftp:` or `data`
 * scheme, or a relative URL (i.e., a URL without a scheme; specifically, a
 * scheme-relative, absolute-path-relative, or path-relative URL).
 *
 * @see http://url.spec.whatwg.org/#concept-relative-url
 * @param {string|!goog.string.TypedString} url The URL to validate.
 * @return {!goog.html.SafeUrl} The validated URL, wrapped as a SafeUrl.
 */
goog.html.SafeUrl.sanitize = function(url) {
  'use strict';
  return goog.html.SafeUrl.trySanitize(url) || goog.html.SafeUrl.INNOCUOUS_URL;
};

/**
 * Creates a SafeUrl object from `url`. If `url` is a
 * `goog.html.SafeUrl` then it is simply returned. Otherwise the input string is
 * validated to match a pattern of commonly used safe URLs.
 *
 * `url` may be a URL with the http, https, mailto or ftp scheme,
 * or a relative URL (i.e., a URL without a scheme; specifically, a
 * scheme-relative, absolute-path-relative, or path-relative URL).
 *
 * This function asserts (using goog.asserts) that the URL matches this pattern.
 * If it does not, in addition to failing the assert, an innocuous URL will be
 * returned.
 *
 * @see http://url.spec.whatwg.org/#concept-relative-url
 * @param {string|!goog.string.TypedString} url The URL to validate.
 * @param {boolean=} opt_allowDataUrl Whether to allow valid data: URLs.
 * @return {!goog.html.SafeUrl} The validated URL, wrapped as a SafeUrl.
 */
goog.html.SafeUrl.sanitizeAssertUnchanged = function(url, opt_allowDataUrl) {
  'use strict';
  if (url instanceof goog.html.SafeUrl) {
    return url;
  } else if (typeof url == 'object' && url.implementsGoogStringTypedString) {
    url = /** @type {!goog.string.TypedString} */ (url).getTypedStringValue();
  } else {
    url = String(url);
  }
  if (opt_allowDataUrl && /^data:/i.test(url)) {
    var safeUrl = goog.html.SafeUrl.fromDataUrl(url);
    if (safeUrl.getTypedStringValue() == url) {
      return safeUrl;
    }
  }
  if (!goog.asserts.assert(
          goog.html.SAFE_URL_PATTERN_.test(url),
          '%s does not match the safe URL pattern', url)) {
    url = goog.html.SafeUrl.INNOCUOUS_STRING;
  }
  return goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(url);
};

/**
 * Token used to ensure that object is created only from this file. No code
 * outside of this file can access this token.
 * @private {!Object}
 * @const
 */
goog.html.SafeUrl.CONSTRUCTOR_TOKEN_PRIVATE_ = {};

/**
 * Package-internal utility method to create SafeUrl instances.
 *
 * @param {string} url The string to initialize the SafeUrl object with.
 * @return {!goog.html.SafeUrl} The initialized SafeUrl object.
 * @package
 */
goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse = function(
    url) {
  'use strict';
  return new goog.html.SafeUrl(
      url, goog.html.SafeUrl.CONSTRUCTOR_TOKEN_PRIVATE_);
};


/**
 * `INNOCUOUS_STRING` wrapped in a `SafeUrl`.
 * @const {!goog.html.SafeUrl}
 */
goog.html.SafeUrl.INNOCUOUS_URL =
    goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
        goog.html.SafeUrl.INNOCUOUS_STRING);


/**
 * A SafeUrl corresponding to the special about:blank url.
 * @const {!goog.html.SafeUrl}
 */
goog.html.SafeUrl.ABOUT_BLANK =
    goog.html.SafeUrl.createSafeUrlSecurityPrivateDoNotAccessOrElse(
        'about:blank');

//third_party/javascript/closure/html/safestyle.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview The SafeStyle type and its builders.
 *
 * TODO(xtof): Link to document stating type contract.
 */

goog.module('goog.html.SafeStyle');
goog.module.declareLegacyNamespace();

const Const = goog.require('goog.string.Const');
const SafeUrl = goog.require('goog.html.SafeUrl');
const TypedString = goog.require('goog.string.TypedString');
const {AssertionError, assert, fail} = goog.require('goog.asserts');
const {contains, endsWith} = goog.require('goog.string.internal');

/**
 * Token used to ensure that object is created only from this file. No code
 * outside of this file can access this token.
 * @type {!Object}
 * @const
 */
const CONSTRUCTOR_TOKEN_PRIVATE = {};

/**
 * A string-like object which represents a sequence of CSS declarations
 * (`propertyName1: propertyvalue1; propertyName2: propertyValue2; ...`)
 * and that carries the security type contract that its value, as a string,
 * will not cause untrusted script execution (XSS) when evaluated as CSS in a
 * browser.
 *
 * Instances of this type must be created via the factory methods
 * (`SafeStyle.create` or `SafeStyle.fromConstant`)
 * and not by invoking its constructor. The constructor intentionally takes an
 * extra parameter that cannot be constructed outside of this file and the type
 * is immutable; hence only a default instance corresponding to the empty string
 * can be obtained via constructor invocation.
 *
 * SafeStyle's string representation can safely be:
 * <ul>
 *   <li>Interpolated as the content of a *quoted* HTML style attribute.
 *       However, the SafeStyle string *must be HTML-attribute-escaped* before
 *       interpolation.
 *   <li>Interpolated as the content of a {}-wrapped block within a stylesheet.
 *       '<' characters in the SafeStyle string *must be CSS-escaped* before
 *       interpolation. The SafeStyle string is also guaranteed not to be able
 *       to introduce new properties or elide existing ones.
 *   <li>Interpolated as the content of a {}-wrapped block within an HTML
 *       &lt;style&gt; element. '<' characters in the SafeStyle string
 *       *must be CSS-escaped* before interpolation.
 *   <li>Assigned to the style property of a DOM node. The SafeStyle string
 *       should not be escaped before being assigned to the property.
 * </ul>
 *
 * A SafeStyle may never contain literal angle brackets. Otherwise, it could
 * be unsafe to place a SafeStyle into a &lt;style&gt; tag (where it can't
 * be HTML escaped). For example, if the SafeStyle containing
 * `font: 'foo &lt;style/&gt;&lt;script&gt;evil&lt;/script&gt;'` were
 * interpolated within a &lt;style&gt; tag, this would then break out of the
 * style context into HTML.
 *
 * A SafeStyle may contain literal single or double quotes, and as such the
 * entire style string must be escaped when used in a style attribute (if
 * this were not the case, the string could contain a matching quote that
 * would escape from the style attribute).
 *
 * Values of this type must be composable, i.e. for any two values
 * `style1` and `style2` of this type,
 * `SafeStyle.unwrap(style1) +
 * SafeStyle.unwrap(style2)` must itself be a value that satisfies
 * the SafeStyle type constraint. This requirement implies that for any value
 * `style` of this type, `SafeStyle.unwrap(style)` must
 * not end in a "property value" or "property name" context. For example,
 * a value of `background:url("` or `font-` would not satisfy the
 * SafeStyle contract. This is because concatenating such strings with a
 * second value that itself does not contain unsafe CSS can result in an
 * overall string that does. For example, if `javascript:evil())"` is
 * appended to `background:url("}, the resulting string may result in
 * the execution of a malicious script.
 *
 * TODO(mlourenco): Consider whether we should implement UTF-8 interchange
 * validity checks and blacklisting of newlines (including Unicode ones) and
 * other whitespace characters (\t, \f). Document here if so and also update
 * SafeStyle.fromConstant().
 *
 * The following example values comply with this type's contract:
 * <ul>
 *   <li><pre>width: 1em;</pre>
 *   <li><pre>height:1em;</pre>
 *   <li><pre>width: 1em;height: 1em;</pre>
 *   <li><pre>background:url('http://url');</pre>
 * </ul>
 * In addition, the empty string is safe for use in a CSS attribute.
 *
 * The following example values do NOT comply with this type's contract:
 * <ul>
 *   <li><pre>background: red</pre> (missing a trailing semi-colon)
 *   <li><pre>background:</pre> (missing a value and a trailing semi-colon)
 *   <li><pre>1em</pre> (missing an attribute name, which provides context for
 *       the value)
 * </ul>
 *
 * @see SafeStyle#create
 * @see SafeStyle#fromConstant
 * @see http://www.w3.org/TR/css3-syntax/
 * @final
 * @struct
 * @implements {TypedString}
 */
class SafeStyle {
  /**
   * @param {string} value
   * @param {!Object} token package-internal implementation detail.
   */
  constructor(value, token) {
    /**
     * The contained value of this SafeStyle.  The field has a purposely
     * ugly name to make (non-compiled) code that attempts to directly access
     * this field stand out.
     * @private {string}
     */
    this.privateDoNotAccessOrElseSafeStyleWrappedValue_ =
        (token === CONSTRUCTOR_TOKEN_PRIVATE) ? value : '';

    /**
     * @override
     * @const {boolean}
     */
    this.implementsGoogStringTypedString = true;
  }


  /**
   * Creates a SafeStyle object from a compile-time constant string.
   *
   * `style` should be in the format
   * `name: value; [name: value; ...]` and must not have any < or >
   * characters in it. This is so that SafeStyle's contract is preserved,
   * allowing the SafeStyle to correctly be interpreted as a sequence of CSS
   * declarations and without affecting the syntactic structure of any
   * surrounding CSS and HTML.
   *
   * This method performs basic sanity checks on the format of `style`
   * but does not constrain the format of `name` and `value`, except
   * for disallowing tag characters.
   *
   * @param {!Const} style A compile-time-constant string from which
   *     to create a SafeStyle.
   * @return {!SafeStyle} A SafeStyle object initialized to
   *     `style`.
   */
  static fromConstant(style) {
    'use strict';
    const styleString = Const.unwrap(style);
    if (styleString.length === 0) {
      return SafeStyle.EMPTY;
    }
    assert(
        endsWith(styleString, ';'),
        `Last character of style string is not ';': ${styleString}`);
    assert(
        contains(styleString, ':'),
        'Style string must contain at least one \':\', to ' +
            'specify a "name: value" pair: ' + styleString);
    return SafeStyle.createSafeStyleSecurityPrivateDoNotAccessOrElse(
        styleString);
  };


  /**
   * Returns this SafeStyle's value as a string.
   *
   * IMPORTANT: In code where it is security relevant that an object's type is
   * indeed `SafeStyle`, use `SafeStyle.unwrap` instead of
   * this method. If in doubt, assume that it's security relevant. In
   * particular, note that goog.html functions which return a goog.html type do
   * not guarantee the returned instance is of the right type. For example:
   *
   * <pre>
   * var fakeSafeHtml = new String('fake');
   * fakeSafeHtml.__proto__ = goog.html.SafeHtml.prototype;
   * var newSafeHtml = goog.html.SafeHtml.htmlEscape(fakeSafeHtml);
   * // newSafeHtml is just an alias for fakeSafeHtml, it's passed through by
   * // goog.html.SafeHtml.htmlEscape() as fakeSafeHtml
   * // instanceof goog.html.SafeHtml.
   * </pre>
   *
   * @return {string}
   * @see SafeStyle#unwrap
   * @override
   */
  getTypedStringValue() {
    'use strict';
    return this.privateDoNotAccessOrElseSafeStyleWrappedValue_;
  }


  /**
   * Returns a string-representation of this value.
   *
   * To obtain the actual string value wrapped in a SafeStyle, use
   * `SafeStyle.unwrap`.
   *
   * @return {string}
   * @see SafeStyle#unwrap
   * @override
   */
  toString() {
    return this.privateDoNotAccessOrElseSafeStyleWrappedValue_.toString();
  }


  /**
   * Performs a runtime check that the provided object is indeed a
   * SafeStyle object, and returns its value.
   *
   * @param {!SafeStyle} safeStyle The object to extract from.
   * @return {string} The safeStyle object's contained string, unless
   *     the run-time type check fails. In that case, `unwrap` returns an
   *     innocuous string, or, if assertions are enabled, throws
   *     `AssertionError`.
   */
  static unwrap(safeStyle) {
    'use strict';
    // Perform additional Run-time type-checking to ensure that
    // safeStyle is indeed an instance of the expected type.  This
    // provides some additional protection against security bugs due to
    // application code that disables type checks.
    // Specifically, the following checks are performed:
    // 1. The object is an instance of the expected type.
    // 2. The object is not an instance of a subclass.
    if (safeStyle instanceof SafeStyle && safeStyle.constructor === SafeStyle) {
      return safeStyle.privateDoNotAccessOrElseSafeStyleWrappedValue_;
    } else {
      fail(
          `expected object of type SafeStyle, got '${safeStyle}` +
          '\' of type ' + goog.typeOf(safeStyle));
      return 'type_error:SafeStyle';
    }
  }


  /**
   * Package-internal utility method to create SafeStyle instances.
   *
   * @param {string} style The string to initialize the SafeStyle object with.
   * @return {!SafeStyle} The initialized SafeStyle object.
   * @package
   */
  static createSafeStyleSecurityPrivateDoNotAccessOrElse(style) {
    'use strict';
    return new SafeStyle(style, CONSTRUCTOR_TOKEN_PRIVATE);
  }

  /**
   * Creates a new SafeStyle object from the properties specified in the map.
   * @param {!SafeStyle.PropertyMap} map Mapping of property names to
   *     their values, for example {'margin': '1px'}. Names must consist of
   *     [-_a-zA-Z0-9]. Values might be strings consisting of
   *     [-,.'"%_!# a-zA-Z0-9[\]], where ", ', and [] must be properly balanced.
   *     We also allow simple functions like rgb() and url() which sanitizes its
   *     contents. Other values must be wrapped in Const. URLs might
   *     be passed as SafeUrl which will be wrapped into url(""). We
   *     also support array whose elements are joined with ' '. Null value
   * causes skipping the property.
   * @return {!SafeStyle}
   * @throws {!Error} If invalid name is provided.
   * @throws {!AssertionError} If invalid value is provided. With
   *     disabled assertions, invalid value is replaced by
   *     SafeStyle.INNOCUOUS_STRING.
   */
  static create(map) {
    'use strict';
    let style = '';
    for (let name in map) {
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty#Using_hasOwnProperty_as_a_property_name
      if (Object.prototype.hasOwnProperty.call(map, name)) {
        if (!/^[-_a-zA-Z0-9]+$/.test(name)) {
          throw new Error(`Name allows only [-_a-zA-Z0-9], got: ${name}`);
        }
        let value = map[name];
        if (value == null) {
          continue;
        }
        if (Array.isArray(value)) {
          value = value.map(sanitizePropertyValue).join(' ');
        } else {
          value = sanitizePropertyValue(value);
        }
        style += `${name}:${value};`;
      }
    }
    if (!style) {
      return SafeStyle.EMPTY;
    }
    return SafeStyle.createSafeStyleSecurityPrivateDoNotAccessOrElse(style);
  };

  /**
   * Creates a new SafeStyle object by concatenating the values.
   * @param {...(!SafeStyle|!Array<!SafeStyle>)} var_args
   *     SafeStyles to concatenate.
   * @return {!SafeStyle}
   */
  static concat(var_args) {
    'use strict';
    let style = '';

    /**
     * @param {!SafeStyle|!Array<!SafeStyle>} argument
     */
    const addArgument = argument => {
      'use strict';
      if (Array.isArray(argument)) {
        argument.forEach(addArgument);
      } else {
        style += SafeStyle.unwrap(argument);
      }
    };

    Array.prototype.forEach.call(arguments, addArgument);
    if (!style) {
      return SafeStyle.EMPTY;
    }
    return SafeStyle.createSafeStyleSecurityPrivateDoNotAccessOrElse(style);
  };
}

/**
 * A SafeStyle instance corresponding to the empty string.
 * @const {!SafeStyle}
 */
SafeStyle.EMPTY = SafeStyle.createSafeStyleSecurityPrivateDoNotAccessOrElse('');


/**
 * The innocuous string generated by SafeStyle.create when passed
 * an unsafe value.
 * @const {string}
 */
SafeStyle.INNOCUOUS_STRING = 'zClosurez';


/**
 * A single property value.
 * @typedef {string|!Const|!SafeUrl}
 */
SafeStyle.PropertyValue;


/**
 * Mapping of property names to their values.
 * We don't support numbers even though some values might be numbers (e.g.
 * line-height or 0 for any length). The reason is that most numeric values need
 * units (e.g. '1px') and allowing numbers could cause users forgetting about
 * them.
 * @typedef {!Object<string, ?SafeStyle.PropertyValue|
 *     ?Array<!SafeStyle.PropertyValue>>}
 */
SafeStyle.PropertyMap;



/**
 * Checks and converts value to string.
 * @param {!SafeStyle.PropertyValue} value
 * @return {string}
 */
function sanitizePropertyValue(value) {
  'use strict';
  if (value instanceof SafeUrl) {
    const url = SafeUrl.unwrap(value);
    return 'url("' + url.replace(/</g, '%3c').replace(/[\\"]/g, '\\$&') + '")';
  }
  const result = value instanceof Const ?
      Const.unwrap(value) :
      sanitizePropertyValueString(String(value));
  // These characters can be used to change context and we don't want that even
  // with const values.
  if (/[{;}]/.test(result)) {
    throw new AssertionError('Value does not allow [{;}], got: %s.', [result]);
  }
  return result;
}


/**
 * Checks string value.
 * @param {string} value
 * @return {string}
 */
function sanitizePropertyValueString(value) {
  'use strict';
  // Some CSS property values permit nested functions. We allow one level of
  // nesting, and all nested functions must also be in the FUNCTIONS_RE_ list.
  const valueWithoutFunctions = value.replace(FUNCTIONS_RE, '$1')
                                    .replace(FUNCTIONS_RE, '$1')
                                    .replace(URL_RE, 'url');
  if (!VALUE_RE.test(valueWithoutFunctions)) {
    fail(
        `String value allows only ${VALUE_ALLOWED_CHARS}` +
        ' and simple functions, got: ' + value);
    return SafeStyle.INNOCUOUS_STRING;
  } else if (COMMENT_RE.test(value)) {
    fail(`String value disallows comments, got: ${value}`);
    return SafeStyle.INNOCUOUS_STRING;
  } else if (!hasBalancedQuotes(value)) {
    fail(`String value requires balanced quotes, got: ${value}`);
    return SafeStyle.INNOCUOUS_STRING;
  } else if (!hasBalancedSquareBrackets(value)) {
    fail(
        'String value requires balanced square brackets and one' +
        ' identifier per pair of brackets, got: ' + value);
    return SafeStyle.INNOCUOUS_STRING;
  }
  return sanitizeUrl(value);
}


/**
 * Checks that quotes (" and ') are properly balanced inside a string. Assumes
 * that neither escape (\) nor any other character that could result in
 * breaking out of a string parsing context are allowed;
 * see http://www.w3.org/TR/css3-syntax/#string-token-diagram.
 * @param {string} value Untrusted CSS property value.
 * @return {boolean} True if property value is safe with respect to quote
 *     balancedness.
 */
function hasBalancedQuotes(value) {
  'use strict';
  let outsideSingle = true;
  let outsideDouble = true;
  for (let i = 0; i < value.length; i++) {
    const c = value.charAt(i);
    if (c == '\'' && outsideDouble) {
      outsideSingle = !outsideSingle;
    } else if (c == '"' && outsideSingle) {
      outsideDouble = !outsideDouble;
    }
  }
  return outsideSingle && outsideDouble;
}


/**
 * Checks that square brackets ([ and ]) are properly balanced inside a string,
 * and that the content in the square brackets is one ident-token;
 * see https://www.w3.org/TR/css-syntax-3/#ident-token-diagram.
 * For practicality, and in line with other restrictions posed on SafeStyle
 * strings, we restrict the character set allowable in the ident-token to
 * [-_a-zA-Z0-9].
 * @param {string} value Untrusted CSS property value.
 * @return {boolean} True if property value is safe with respect to square
 *     bracket balancedness.
 */
function hasBalancedSquareBrackets(value) {
  'use strict';
  let outside = true;
  const tokenRe = /^[-_a-zA-Z0-9]$/;
  for (let i = 0; i < value.length; i++) {
    const c = value.charAt(i);
    if (c == ']') {
      if (outside) return false;  // Unbalanced ].
      outside = true;
    } else if (c == '[') {
      if (!outside) return false;  // No nesting.
      outside = false;
    } else if (!outside && !tokenRe.test(c)) {
      return false;
    }
  }
  return outside;
}


/**
 * Characters allowed in VALUE_RE.
 * @type {string}
 */
const VALUE_ALLOWED_CHARS = '[-,."\'%_!#/ a-zA-Z0-9\\[\\]]';


/**
 * Regular expression for safe values.
 * Quotes (" and ') are allowed, but a check must be done elsewhere to ensure
 * they're balanced.
 * Square brackets ([ and ]) are allowed, but a check must be done elsewhere
 * to ensure they're balanced. The content inside a pair of square brackets must
 * be one alphanumeric identifier.
 * ',' allows multiple values to be assigned to the same property
 * (e.g. background-attachment or font-family) and hence could allow
 * multiple values to get injected, but that should pose no risk of XSS.
 * The expression checks only for XSS safety, not for CSS validity.
 * @const {!RegExp}
 */
const VALUE_RE = new RegExp(`^${VALUE_ALLOWED_CHARS}+\$`);


/**
 * Regular expression for url(). We support URLs allowed by
 * https://www.w3.org/TR/css-syntax-3/#url-token-diagram without using escape
 * sequences. Use percent-encoding if you need to use special characters like
 * backslash.
 * @const {!RegExp}
 */
const URL_RE = new RegExp(
    '\\b(url\\([ \t\n]*)(' +
        '\'[ -&(-\\[\\]-~]*\'' +  // Printable characters except ' and \.
        '|"[ !#-\\[\\]-~]*"' +    // Printable characters except " and \.
        '|[!#-&*-\\[\\]-~]*' +    // Printable characters except [ "'()\\].
        ')([ \t\n]*\\))',
    'g');

/**
 * Names of functions allowed in FUNCTIONS_RE.
 * @const {!Array<string>}
 */
const ALLOWED_FUNCTIONS = [
  'calc',
  'cubic-bezier',
  'fit-content',
  'hsl',
  'hsla',
  'linear-gradient',
  'matrix',
  'minmax',
  'radial-gradient',
  'repeat',
  'rgb',
  'rgba',
  '(rotate|scale|translate)(X|Y|Z|3d)?',
  'var',
];


/**
 * Regular expression for simple functions.
 * @const {!RegExp}
 */
const FUNCTIONS_RE = new RegExp(
    '\\b(' + ALLOWED_FUNCTIONS.join('|') + ')' +
        '\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)',
    'g');


/**
 * Regular expression for comments. These are disallowed in CSS property values.
 * @const {!RegExp}
 */
const COMMENT_RE = /\/\*/;


/**
 * Sanitize URLs inside url().
 * NOTE: We could also consider using CSS.escape once that's available in the
 * browsers. However, loosely matching URL e.g. with url\(.*\) and then escaping
 * the contents would result in a slightly different language than CSS leading
 * to confusion of users. E.g. url(")") is valid in CSS but it would be invalid
 * as seen by our parser. On the other hand, url(\) is invalid in CSS but our
 * parser would be fine with it.
 * @param {string} value Untrusted CSS property value.
 * @return {string}
 */
function sanitizeUrl(value) {
  'use strict';
  return value.replace(URL_RE, (match, before, url, after) => {
    'use strict';
    let quote = '';
    url = url.replace(/^(['"])(.*)\1$/, (match, start, inside) => {
      'use strict';
      quote = start;
      return inside;
    });
    const sanitized = SafeUrl.sanitize(url).getTypedStringValue();
    return before + quote + sanitized + quote + after;
  });
}


exports = SafeStyle;

;return exports;});

//third_party/javascript/closure/html/safestylesheet.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview The SafeStyleSheet type and its builders.
 *
 * TODO(xtof): Link to document stating type contract.
 */

goog.module('goog.html.SafeStyleSheet');
goog.module.declareLegacyNamespace();

const Const = goog.require('goog.string.Const');
const SafeStyle = goog.require('goog.html.SafeStyle');
const TypedString = goog.require('goog.string.TypedString');
const googObject = goog.require('goog.object');
const {assert, fail} = goog.require('goog.asserts');
const {contains} = goog.require('goog.string.internal');

/**
 * Token used to ensure that object is created only from this file. No code
 * outside of this file can access this token.
 * @const {!Object}
 */
const CONSTRUCTOR_TOKEN_PRIVATE = {};

/**
 * A string-like object which represents a CSS style sheet and that carries the
 * security type contract that its value, as a string, will not cause untrusted
 * script execution (XSS) when evaluated as CSS in a browser.
 *
 * Instances of this type must be created via the factory method
 * `SafeStyleSheet.fromConstant` and not by invoking its constructor. The
 * constructor intentionally takes an extra parameter that cannot be constructed
 * outside of this file and the type is immutable; hence only a default instance
 * corresponding to the empty string can be obtained via constructor invocation.
 *
 * A SafeStyleSheet's string representation can safely be interpolated as the
 * content of a style element within HTML. The SafeStyleSheet string should
 * not be escaped before interpolation.
 *
 * Values of this type must be composable, i.e. for any two values
 * `styleSheet1` and `styleSheet2` of this type,
 * `SafeStyleSheet.unwrap(styleSheet1) + SafeStyleSheet.unwrap(styleSheet2)`
 * must itself be a value that satisfies the SafeStyleSheet type constraint.
 * This requirement implies that for any value `styleSheet` of this type,
 * `SafeStyleSheet.unwrap(styleSheet1)` must end in
 * "beginning of rule" context.
 *
 * A SafeStyleSheet can be constructed via security-reviewed unchecked
 * conversions. In this case producers of SafeStyleSheet must ensure themselves
 * that the SafeStyleSheet does not contain unsafe script. Note in particular
 * that `&lt;` is dangerous, even when inside CSS strings, and so should
 * always be forbidden or CSS-escaped in user controlled input. For example, if
 * `&lt;/style&gt;&lt;script&gt;evil&lt;/script&gt;"` were interpolated
 * inside a CSS string, it would break out of the context of the original
 * style element and `evil` would execute. Also note that within an HTML
 * style (raw text) element, HTML character references, such as
 * `&amp;lt;`, are not allowed. See
 * http://www.w3.org/TR/html5/scripting-1.html#restrictions-for-contents-of-script-elements
 * (similar considerations apply to the style element).
 *
 * @see SafeStyleSheet#fromConstant
 * @final
 * @implements {TypedString}
 */
class SafeStyleSheet {
  /**
   * @param {string} value
   * @param {!Object} token package-internal implementation detail.
   */
  constructor(value, token) {
    /**
     * The contained value of this SafeStyleSheet.  The field has a purposely
     * ugly name to make (non-compiled) code that attempts to directly access
     * this field stand out.
     * @private {string}
     */
    this.privateDoNotAccessOrElseSafeStyleSheetWrappedValue_ =
        (token === CONSTRUCTOR_TOKEN_PRIVATE) ? value : '';

    /**
     * @override
     * @const
     */
    this.implementsGoogStringTypedString = true;
  }

  /**
   * Returns a string-representation of this value.
   *
   * To obtain the actual string value wrapped in a SafeStyleSheet, use
   * `SafeStyleSheet.unwrap`.
   *
   * @return {string}
   * @see SafeStyleSheet#unwrap
   * @override
   */
  toString() {
    return this.privateDoNotAccessOrElseSafeStyleSheetWrappedValue_.toString();
  }

  /**
   * Creates a style sheet consisting of one selector and one style definition.
   * Use {@link SafeStyleSheet.concat} to create longer style sheets.
   * This function doesn't support @import, @media and similar constructs.
   * @param {string} selector CSS selector, e.g. '#id' or 'tag .class, #id'. We
   *     support CSS3 selectors: https://w3.org/TR/css3-selectors/#selectors.
   * @param {!SafeStyle.PropertyMap|!SafeStyle} style Style
   *     definition associated with the selector.
   * @return {!SafeStyleSheet}
   * @throws {!Error} If invalid selector is provided.
   */
  static createRule(selector, style) {
    if (contains(selector, '<')) {
      throw new Error(`Selector does not allow '<', got: ${selector}`);
    }

    // Remove strings.
    const selectorToCheck =
        selector.replace(/('|")((?!\1)[^\r\n\f\\]|\\[\s\S])*\1/g, '');

    // Check characters allowed in CSS3 selectors.
    if (!/^[-_a-zA-Z0-9#.:* ,>+~[\]()=^$|]+$/.test(selectorToCheck)) {
      throw new Error(
          'Selector allows only [-_a-zA-Z0-9#.:* ,>+~[\\]()=^$|] and ' +
          'strings, got: ' + selector);
    }

    // Check balanced () and [].
    if (!SafeStyleSheet.hasBalancedBrackets_(selectorToCheck)) {
      throw new Error(
          '() and [] in selector must be balanced, got: ' + selector);
    }

    if (!(style instanceof SafeStyle)) {
      style = SafeStyle.create(style);
    }
    const styleSheet =
        `${selector}{` + SafeStyle.unwrap(style).replace(/</g, '\\3C ') + '}';
    return SafeStyleSheet.createSafeStyleSheetSecurityPrivateDoNotAccessOrElse(
        styleSheet);
  }

  /**
   * Checks if a string has balanced () and [] brackets.
   * @param {string} s String to check.
   * @return {boolean}
   * @private
   */
  static hasBalancedBrackets_(s) {
    const brackets = {'(': ')', '[': ']'};
    const expectedBrackets = [];
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if (brackets[ch]) {
        expectedBrackets.push(brackets[ch]);
      } else if (googObject.contains(brackets, ch)) {
        if (expectedBrackets.pop() != ch) {
          return false;
        }
      }
    }
    return expectedBrackets.length == 0;
  }

  /**
   * Creates a new SafeStyleSheet object by concatenating values.
   * @param {...(!SafeStyleSheet|!Array<!SafeStyleSheet>)}
   *     var_args Values to concatenate.
   * @return {!SafeStyleSheet}
   */
  static concat(var_args) {
    let result = '';

    /**
     * @param {!SafeStyleSheet|!Array<!SafeStyleSheet>}
     *     argument
     */
    const addArgument = argument => {
      if (Array.isArray(argument)) {
        argument.forEach(addArgument);
      } else {
        result += SafeStyleSheet.unwrap(argument);
      }
    };

    Array.prototype.forEach.call(arguments, addArgument);
    return SafeStyleSheet.createSafeStyleSheetSecurityPrivateDoNotAccessOrElse(
        result);
  }

  /**
   * Creates a SafeStyleSheet object from a compile-time constant string.
   *
   * `styleSheet` must not have any &lt; characters in it, so that
   * the syntactic structure of the surrounding HTML is not affected.
   *
   * @param {!Const} styleSheet A compile-time-constant string from
   *     which to create a SafeStyleSheet.
   * @return {!SafeStyleSheet} A SafeStyleSheet object initialized to
   *     `styleSheet`.
   */
  static fromConstant(styleSheet) {
    const styleSheetString = Const.unwrap(styleSheet);
    if (styleSheetString.length === 0) {
      return SafeStyleSheet.EMPTY;
    }
    // > is a valid character in CSS selectors and there's no strict need to
    // block it if we already block <.
    assert(
        !contains(styleSheetString, '<'),
        `Forbidden '<' character in style sheet string: ${styleSheetString}`);
    return SafeStyleSheet.createSafeStyleSheetSecurityPrivateDoNotAccessOrElse(
        styleSheetString);
  }

  /**
   * Returns this SafeStyleSheet's value as a string.
   *
   * IMPORTANT: In code where it is security relevant that an object's type is
   * indeed `SafeStyleSheet`, use `SafeStyleSheet.unwrap`
   * instead of this method. If in doubt, assume that it's security relevant. In
   * particular, note that goog.html functions which return a goog.html type do
   * not guarantee the returned instance is of the right type. For example:
   *
   * <pre>
   * var fakeSafeHtml = new String('fake');
   * fakeSafeHtml.__proto__ = goog.html.SafeHtml.prototype;
   * var newSafeHtml = goog.html.SafeHtml.htmlEscape(fakeSafeHtml);
   * // newSafeHtml is just an alias for fakeSafeHtml, it's passed through by
   * // goog.html.SafeHtml.htmlEscape() as fakeSafeHtml
   * // instanceof goog.html.SafeHtml.
   * </pre>
   *
   * @see SafeStyleSheet#unwrap
   * @override
   */
  getTypedStringValue() {
    return this.privateDoNotAccessOrElseSafeStyleSheetWrappedValue_;
  }

  /**
   * Performs a runtime check that the provided object is indeed a
   * SafeStyleSheet object, and returns its value.
   *
   * @param {!SafeStyleSheet} safeStyleSheet The object to extract from.
   * @return {string} The safeStyleSheet object's contained string, unless
   *     the run-time type check fails. In that case, `unwrap` returns an
   *     innocuous string, or, if assertions are enabled, throws
   *     `asserts.AssertionError`.
   */
  static unwrap(safeStyleSheet) {
    // Perform additional Run-time type-checking to ensure that
    // safeStyleSheet is indeed an instance of the expected type.  This
    // provides some additional protection against security bugs due to
    // application code that disables type checks.
    // Specifically, the following checks are performed:
    // 1. The object is an instance of the expected type.
    // 2. The object is not an instance of a subclass.
    if (safeStyleSheet instanceof SafeStyleSheet &&
        safeStyleSheet.constructor === SafeStyleSheet) {
      return safeStyleSheet.privateDoNotAccessOrElseSafeStyleSheetWrappedValue_;
    } else {
      fail(
          'expected object of type SafeStyleSheet, got \'' + safeStyleSheet +
          '\' of type ' + goog.typeOf(safeStyleSheet));
      return 'type_error:SafeStyleSheet';
    }
  }

  /**
   * Package-internal utility method to create SafeStyleSheet instances.
   *
   * @param {string} styleSheet The string to initialize the SafeStyleSheet
   *     object with.
   * @return {!SafeStyleSheet} The initialized SafeStyleSheet object.
   * @package
   */
  static createSafeStyleSheetSecurityPrivateDoNotAccessOrElse(styleSheet) {
    return new SafeStyleSheet(styleSheet, CONSTRUCTOR_TOKEN_PRIVATE);
  }
}

/**
 * A SafeStyleSheet instance corresponding to the empty string.
 * @const {!SafeStyleSheet}
 */
SafeStyleSheet.EMPTY =
    SafeStyleSheet.createSafeStyleSheetSecurityPrivateDoNotAccessOrElse('');


exports = SafeStyleSheet;

;return exports;});

//third_party/javascript/closure/labs/useragent/useragent.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Defines for goog.labs.userAgent.
 */

goog.module('goog.labs.userAgent');

/**
 * @define {string} Optional runtime override for the USE_CLIENT_HINTS flag.
 * If this is set (for example, to 'foo.bar') then any value of USE_CLIENT_HINTS
 * will be overridden by `globalThis.foo.bar` if it is non-null.
 * This flag will be removed in December 2021.
 */
const USE_CLIENT_HINTS_OVERRIDE =
    goog.define('goog.labs.userAgent.USE_CLIENT_HINTS_OVERRIDE', '');

/**
 * @define {boolean} If true, use navigator.userAgentData
 * TODO(b/195558239) Flip flag in 2021/12.
 */
const USE_CLIENT_HINTS =
    goog.define('goog.labs.userAgent.USE_CLIENT_HINTS', false);

// TODO(b/200758745): Replace the IIFE with a simple null-coalescing operator.
// NOTE: This can't be done with a helper function, or else we risk an inlining
// back-off causing a huge code size regression if a non-inlined helper function
// prevents the optimizer from detecting the (possibly large) dead code paths.
/** @const {boolean} */
exports.USE_CLIENT_HINTS = (() => {
  const override = USE_CLIENT_HINTS_OVERRIDE ?
         goog.getObjectByName(USE_CLIENT_HINTS_OVERRIDE) :
         null;
  return override != null ? override : USE_CLIENT_HINTS;
})();

;return exports;});

//third_party/javascript/closure/labs/useragent/util.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Utilities used by goog.labs.userAgent tools. These functions
 * should not be used outside of goog.labs.userAgent.*.
 *
 */

goog.module('goog.labs.userAgent.util');
goog.module.declareLegacyNamespace();

const {USE_CLIENT_HINTS} = goog.require('goog.labs.userAgent');
const {caseInsensitiveContains, contains} = goog.require('goog.string.internal');

/**
 * @const {boolean} If true, use navigator.userAgentData without check.
 * TODO(b/215262824): FEATURESET_YEAR >= 2023 if it supports mobile and all the
 * brands we need.  See https://caniuse.com/mdn-api_navigator_useragentdata.
 */
const ASSUME_CLIENT_HINTS_SUPPORT = false;

/**
 * Gets the native userAgent string from navigator if it exists.
 * If navigator or navigator.userAgent string is missing, returns an empty
 * string.
 * @return {string}
 */
function getNativeUserAgentString() {
  const navigator = getNavigator();
  if (navigator) {
    const userAgent = navigator.userAgent;
    if (userAgent) {
      return userAgent;
    }
  }
  return '';
}

/**
 * Gets the native userAgentData object from navigator if it exists.
 * If navigator.userAgentData object is missing or USE_CLIENT_HINTS is set to
 * false, returns null.
 * @return {?NavigatorUAData}
 */
function getNativeUserAgentData() {
  if (!USE_CLIENT_HINTS) {
    return null;
  }
  const navigator = getNavigator();
  // TODO(b/195343593): Use navigator?.userAgent ?? null once it's supported.
  if (navigator) {
    return navigator.userAgentData || null;
  }
  return null;
}

/**
 * Getter for the native navigator.
 * @return {!Navigator}
 */
function getNavigator() {
  return goog.global.navigator;
}

/**
 * A possible override for applications which wish to not check
 * navigator.userAgent but use a specified value for detection instead.
 * @type {?string}
 */
let userAgentInternal = null;

/**
 * A possible override for applications which wish to not check
 * navigator.userAgentData but use a specified value for detection instead.
 * @type {?NavigatorUAData}
 */
let userAgentDataInternal = getNativeUserAgentData();

/**
 * Override the user agent string with the given value.
 * This should only be used for testing within the goog.labs.userAgent
 * namespace.
 * Pass `null` to use the native browser object instead.
 * @param {?string=} userAgent The userAgent override.
 * @return {void}
 */
function setUserAgent(userAgent = undefined) {
  userAgentInternal =
      typeof userAgent === 'string' ? userAgent : getNativeUserAgentString();
}

/** @return {string} The user agent string. */
function getUserAgent() {
  return userAgentInternal == null ? getNativeUserAgentString() :
                                     userAgentInternal;
}

/**
 * Override the user agent data object with the given value.
 * This should only be used for testing within the goog.labs.userAgent
 * namespace.
 * Pass `null` to specify the absence of userAgentData. Note that this behavior
 * is different from setUserAgent.
 * @param {?NavigatorUAData} userAgentData The userAgentData override.
 */
function setUserAgentData(userAgentData) {
  userAgentDataInternal = userAgentData;
}

/**
 * If the user agent data object was overridden using setUserAgentData,
 * reset it so that it uses the native browser object instead, if it exists.
 */
function resetUserAgentData() {
  userAgentDataInternal = getNativeUserAgentData();
}

/** @return {?NavigatorUAData} Navigator.userAgentData if exist */
function getUserAgentData() {
  return userAgentDataInternal;
}

/**
 * Checks if any string in userAgentData.brands matches str.
 * Returns false if userAgentData is not supported.
 * @param {string} str
 * @return {boolean} Whether any brand string from userAgentData contains the
 *     given string.
 */
function matchUserAgentDataBrand(str) {
  const data = getUserAgentData();
  if (!data) return false;
  return data.brands.some(({brand}) => brand && contains(brand, str));
}

/**
 * @param {string} str
 * @return {boolean} Whether the user agent contains the given string.
 */
function matchUserAgent(str) {
  const userAgent = getUserAgent();
  return contains(userAgent, str);
}

/**
 * @param {string} str
 * @return {boolean} Whether the user agent contains the given string, ignoring
 *     case.
 */
function matchUserAgentIgnoreCase(str) {
  const userAgent = getUserAgent();
  return caseInsensitiveContains(userAgent, str);
}

/**
 * Parses the user agent into tuples for each section.
 * @param {string} userAgent
 * @return {!Array<!Array<string>>} Tuples of key, version, and the contents of
 *     the parenthetical.
 */
function extractVersionTuples(userAgent) {
  // Matches each section of a user agent string.
  // Example UA:
  // Mozilla/5.0 (iPad; U; CPU OS 3_2_1 like Mac OS X; en-us)
  // AppleWebKit/531.21.10 (KHTML, like Gecko) Mobile/7B405
  // This has three version tuples: Mozilla, AppleWebKit, and Mobile.

  const versionRegExp = new RegExp(
      // Key. Note that a key may have a space.
      // (i.e. 'Mobile Safari' in 'Mobile Safari/5.0')
      '([A-Z][\\w ]+)' +

          '/' +                // slash
          '([^\\s]+)' +        // version (i.e. '5.0b')
          '\\s*' +             // whitespace
          '(?:\\((.*?)\\))?',  // parenthetical info. parentheses not matched.
      'g');

  const data = [];
  let match;

  // Iterate and collect the version tuples.  Each iteration will be the
  // next regex match.
  while (match = versionRegExp.exec(userAgent)) {
    data.push([
      match[1],  // key
      match[2],  // value
      // || undefined as this is not undefined in IE7 and IE8
      match[3] || undefined  // info
    ]);
  }

  return data;
}

exports = {
  ASSUME_CLIENT_HINTS_SUPPORT,
  extractVersionTuples,
  getNativeUserAgentString,
  getUserAgent,
  getUserAgentData,
  matchUserAgent,
  matchUserAgentDataBrand,
  matchUserAgentIgnoreCase,
  resetUserAgentData,
  setUserAgent,
  setUserAgentData,
};

;return exports;});

//third_party/javascript/closure/labs/useragent/highentropy/highentropyvalue.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Provides helper classes and objects to work with High Entropy
 * user agent values.
 */

goog.module('goog.labs.userAgent.highEntropy.highEntropyValue');

const util = goog.require('goog.labs.userAgent.util');
const {compareVersions} = goog.require('goog.string.internal');

/**
 * Represents a value that can be asynchronously loaded.
 * @interface
 * @template VALUE_TYPE
 */
class AsyncValue {
  /**
   * Get the value represented by this AsyncValue instance, if it was
   * previously requested.
   * @return {VALUE_TYPE|undefined}
   */
  getIfLoaded() {}

  /**
   * Request the value represented by this AsyncValue instance.
   * @return {!Promise<VALUE_TYPE>}
   */
  load() {}
}
exports.AsyncValue = AsyncValue;

/**
 * Represents a high-entropy value.
 * High-entropy values must be specifically requested from the Promise-based
 * Client Hints API.
 * @template VALUE_TYPE The type of the value wrapped by this HighEntropyValue
 *     instance.
 * @implements {AsyncValue<VALUE_TYPE>}
 */
class HighEntropyValue {
  /**
   * Constructs a new HighEntropyValue instance.
   * @param {string} key The name of the high-entropy value, used when
   * requesting it from the browser.
   */
  constructor(key) {
    /**
     * The key used to request the high-entropy value from the browser.
     * @const {string}
     * @private
     */
    this.key_ = key;

    /**
     * The value represented by this HighEntropyValue instance. If it hasn't
     * been successfully requested yet, its value will be undefined.
     * @type {VALUE_TYPE|undefined}
     * @protected
     */
    this.value_ = undefined;

    /**
     * The high-entropy value request. If it hasn't been requested yet, this
     * value will be undefined.
     * @type {!Promise<VALUE_TYPE>|undefined}
     * @private
     */
    this.promise_ = undefined;

    this.pending_ = false;
  }

  /**
   * @return {VALUE_TYPE|undefined}
   * @override
   */
  getIfLoaded() {
    const userAgentData = util.getUserAgentData();
    if (!userAgentData) {
      return undefined;
    }
    return this.value_;
  }

  /**
   * @return {!Promise<VALUE_TYPE>}
   * @override
   */
  async load() {
    const userAgentData = util.getUserAgentData();
    if (!userAgentData) {
      return undefined;
    }
    if (!this.promise_) {
      this.pending_ = true;
      this.promise_ = (async () => {
        try {
          const dataValues =
              await userAgentData.getHighEntropyValues([this.key_]);
          this.value_ =
              /** @type {!Object<string, VALUE_TYPE>} */ (
                  dataValues)[this.key_];
          return this.value_;
        } finally {
          this.pending_ = false;
        }
      })();
    }
    return await this.promise_;
  }

  resetForTesting() {
    if (this.pending_) {
      // There is a pending request that may set this.value_ at any time.
      // Therefore, it can't be guaranteed that this object is actually in a
      // clean state.
      throw new Error('Unsafe call to resetForTesting');
    }
    this.promise_ = undefined;
    this.value_ = undefined;
    this.pending_ = false;
  }
}
exports.HighEntropyValue = HighEntropyValue;

/**
 * An object that wraps a version string.
 * This allows for easy version comparisons.
 */
class Version {
  /**
   * @param {string} versionString The underlying version string.
   */
  constructor(versionString) {
    /**
     * @const {string}
     * @private
     */
    this.versionString_ = versionString;
  }

  /**
   * Returns the underlying version string.
   * @return {string}
   */
  toVersionStringForLogging() {
    return this.versionString_;
  }

  /**
   * Returns true if the underlying version string is equal to or greater than
   * the given version.
   * @param {string} version The version to compare against.
   * @return {boolean}
   */
  isAtLeast(version) {
    return compareVersions(this.versionString_, version) >= 0;
  }
}
exports.Version = Version;

;return exports;});

//third_party/javascript/closure/labs/useragent/highentropy/highentropydata.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Provides access to high-entropy user agent values.
 */

goog.module('goog.labs.userAgent.highEntropy.highEntropyData');

const {HighEntropyValue} = goog.require('goog.labs.userAgent.highEntropy.highEntropyValue');

/**
 * fullVersionList is currently not implemented in Chromium.
 * TODO(b/203129821): When fullVersionList is added, remove this value.
 */
let fullVersionListAvailable = false;

/**
 * A helper function to check whether fullVersionList is available in the
 * current browser.
 * TODO(b/203129821): When fullVersionList is added, move hasFullVersionList()
 * to browser.js, and inline the browser version check. For example, if it is
 * implemented in Chromium 101, have hasFullVersionList simply return
 * `browser.isAtLeast(browser.Brand.CHROMIUM, 101)`.
 * @return {boolean}
 */
function hasFullVersionList() {
  return fullVersionListAvailable;
}
exports.hasFullVersionList = hasFullVersionList;

/**
 * A test-only function to set whether it should be assumed fullVersionList is
 * available in the browser.
 * TODO(b/203129821): When fullVersionList is added, remove this function, as
 * behavior when fullVersionList is either present or absent would be testable
 * by setting the user agent and user agent data accordingly.
 * @param {boolean} value
 */
function setHasFullVersionListForTesting(value) {
  fullVersionListAvailable = value;
}
exports.setHasFullVersionListForTesting = setHasFullVersionListForTesting;

/**
 * @type {!HighEntropyValue<!Array<!NavigatorUABrandVersion>>}
 */
const fullVersionList = new HighEntropyValue('fullVersionList');
exports.fullVersionList = fullVersionList;

/**
 * @type {!HighEntropyValue<string>}
 */
const platformVersion = new HighEntropyValue('platformVersion');
exports.platformVersion = platformVersion;

/**
 * Reset all high-entropy values to their initial state.
 */
function resetAllForTesting() {
  fullVersionList.resetForTesting();
  platformVersion.resetForTesting();
}
exports.resetAllForTesting = resetAllForTesting;

;return exports;});

//third_party/javascript/closure/labs/useragent/browser.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Closure user agent detection (Browser).
 * @see <a href="http://www.useragentstring.com/">User agent strings</a>
 * For more information on rendering engine, platform, or device see the other
 * sub-namespaces in goog.labs.userAgent, goog.labs.userAgent.platform,
 * goog.labs.userAgent.device respectively.)
 */

goog.module('goog.labs.userAgent.browser');
goog.module.declareLegacyNamespace();

const googAsserts = goog.require('goog.asserts');
const util = goog.require('goog.labs.userAgent.util');
const {AsyncValue, Version} = goog.require('goog.labs.userAgent.highEntropy.highEntropyValue');
const {compareVersions} = goog.require('goog.string.internal');
const {fullVersionList, hasFullVersionList} = goog.require('goog.labs.userAgent.highEntropy.highEntropyData');

// TODO(nnaze): Refactor to remove excessive exclusion logic in matching
// functions.

/**
 * A browser brand represents an opaque string that is used for making
 * brand-specific version checks in userAgentData.
 * @enum {string}
 */
const Brand = {
  /**
   * The browser brand for Android Browser.
   * Do not depend on the value of this string. Because Android Browser has not
   * implemented userAgentData yet, the value of this string is not guaranteed
   * to stay the same in future revisions.
   */
  ANDROID_BROWSER: 'Android Browser',
  /**
   * The browser brand for Chromium, including Chromium-based Edge and Opera.
   */
  CHROMIUM: 'Chromium',
  /**
   * The browser brand for Edge.
   * This brand can be used to get the version of both EdgeHTML and
   * Chromium-based Edge.
   */
  EDGE: 'Microsoft Edge',
  /**
   * The browser brand for Firefox.
   * Do not depend on the value of this string. Because Firefox has not
   * implemented userAgentData yet, the value of this string is not guaranteed
   * to stay the same in future revisions.
   */
  FIREFOX: 'Firefox',
  /**
   * The browser brand for Internet Explorer.
   * Do not depend on the value of this string. Because IE will never support
   * userAgentData, the value of this string should be treated as opaque (it's
   * used internally for legacy-userAgent fallback).
   */
  IE: 'Internet Explorer',
  /**
   * The browser brand for Opera.
   * This brand can be used to get the version of both Presto- and
   * Chromium-based Opera.
   */
  OPERA: 'Opera',
  /**
   * The browser brand for Safari.
   * Do not depend on the value of this string. Because Safari has not
   * implemented userAgentData yet, the value of this string is not guaranteed
   * to stay the same in future revisions.
   */
  SAFARI: 'Safari',
  /**
   * The browser brand for Silk.
   * See
   * https://docs.aws.amazon.com/silk/latest/developerguide/what-is-silk.html
   * Do not depend on the value of this string. Because Silk does not
   * identify itself in userAgentData yet, the value of this string is not
   * guaranteed to stay the same in future revisions.
   */
  SILK: 'Silk',
};
exports.Brand = Brand;

/**
 * @return {boolean} Whether to use navigator.userAgentData to determine
 * browser's brand.
 */
function useUserAgentDataBrand() {
  if (util.ASSUME_CLIENT_HINTS_SUPPORT) return true;
  const userAgentData = util.getUserAgentData();
  return !!userAgentData && userAgentData.brands.length > 0;
}

/**
 * @return {boolean} Whether the user's browser is Opera. Note: Chromium based
 *     Opera (Opera 15+) is detected as Chrome to avoid unnecessary special
 *     casing.
 */
function matchOpera() {
  if (useUserAgentDataBrand()) {
    // Pre-Chromium Edge doesn't support navigator.userAgentData.
    return false;
  }
  return util.matchUserAgent('Opera');
}

/** @return {boolean} Whether the user's browser is IE. */
function matchIE() {
  if (useUserAgentDataBrand()) {
    // IE doesn't support navigator.userAgentData.
    return false;
  }
  return util.matchUserAgent('Trident') || util.matchUserAgent('MSIE');
}

/**
 * @return {boolean} Whether the user's browser is Edge. This refers to
 *     EdgeHTML based Edge.
 */
function matchEdgeHtml() {
  if (useUserAgentDataBrand()) {
    // Pre-Chromium Edge doesn't support navigator.userAgentData.
    return false;
  }
  return util.matchUserAgent('Edge');
}

/** @return {boolean} Whether the user's browser is Chromium based Edge. */
function matchEdgeChromium() {
  if (useUserAgentDataBrand()) {
    return util.matchUserAgentDataBrand(Brand.EDGE);
  }
  return util.matchUserAgent('Edg/');
}

/** @return {boolean} Whether the user's browser is Chromium based Opera. */
function matchOperaChromium() {
  if (useUserAgentDataBrand()) {
    return util.matchUserAgentDataBrand(Brand.OPERA);
  }
  return util.matchUserAgent('OPR');
}

/** @return {boolean} Whether the user's browser is Firefox. */
function matchFirefox() {
  // Firefox doesn't support navigator.userAgentData yet, so use
  // navigator.userAgent.
  return util.matchUserAgent('Firefox') || util.matchUserAgent('FxiOS');
}

/** @return {boolean} Whether the user's browser is Safari. */
function matchSafari() {
  // Apple-based browsers don't support navigator.userAgentData yet, so use
  // navigator.userAgent.
  return util.matchUserAgent('Safari') &&
      !(matchChrome() || matchCoast() || matchOpera() || matchEdgeHtml() ||
        matchEdgeChromium() || matchOperaChromium() || matchFirefox() ||
        isSilk() || util.matchUserAgent('Android'));
}

/**
 * @return {boolean} Whether the user's browser is Coast (Opera's Webkit-based
 *     iOS browser).
 */
function matchCoast() {
  if (useUserAgentDataBrand()) {
    // Coast doesn't support navigator.userAgentData.
    return false;
  }
  return util.matchUserAgent('Coast');
}

/** @return {boolean} Whether the user's browser is iOS Webview. */
function matchIosWebview() {
  // Apple-based browsers don't support navigator.userAgentData yet, so use
  // navigator.userAgent.
  // iOS Webview does not show up as Chrome or Safari.
  return (util.matchUserAgent('iPad') || util.matchUserAgent('iPhone')) &&
      !matchSafari() && !matchChrome() && !matchCoast() && !matchFirefox() &&
      util.matchUserAgent('AppleWebKit');
}

/**
 * @return {boolean} Whether the user's browser is any Chromium browser. This
 *     returns true for Chrome, Opera 15+, and Edge Chromium.
 */
function matchChrome() {
  if (useUserAgentDataBrand()) {
    return util.matchUserAgentDataBrand(Brand.CHROMIUM);
  }
  return ((util.matchUserAgent('Chrome') || util.matchUserAgent('CriOS')) &&
          !matchEdgeHtml()) ||
      isSilk();
}

/** @return {boolean} Whether the user's browser is the Android browser. */
function matchAndroidBrowser() {
  // Android can appear in the user agent string for Chrome on Android.
  // This is not the Android standalone browser if it does.
  return util.matchUserAgent('Android') &&
      !(isChrome() || isFirefox() || isOpera() || isSilk());
}

/** @return {boolean} Whether the user's browser is Opera. */
const isOpera = matchOpera;
exports.isOpera = isOpera;

/** @return {boolean} Whether the user's browser is IE. */
const isIE = matchIE;
exports.isIE = isIE;

/** @return {boolean} Whether the user's browser is EdgeHTML based Edge. */
const isEdge = matchEdgeHtml;
exports.isEdge = isEdge;

/** @return {boolean} Whether the user's browser is Chromium based Edge. */
const isEdgeChromium = matchEdgeChromium;
exports.isEdgeChromium = isEdgeChromium;

/** @return {boolean} Whether the user's browser is Chromium based Opera. */
const isOperaChromium = matchOperaChromium;
exports.isOperaChromium = isOperaChromium;

/** @return {boolean} Whether the user's browser is Firefox. */
const isFirefox = matchFirefox;
exports.isFirefox = isFirefox;

/** @return {boolean} Whether the user's browser is Safari. */
const isSafari = matchSafari;
exports.isSafari = isSafari;

/**
 * @return {boolean} Whether the user's browser is Coast (Opera's Webkit-based
 *     iOS browser).
 */
const isCoast = matchCoast;
exports.isCoast = isCoast;

/** @return {boolean} Whether the user's browser is iOS Webview. */
const isIosWebview = matchIosWebview;
exports.isIosWebview = isIosWebview;

/**
 * @return {boolean} Whether the user's browser is any Chromium based browser (
 *     Chrome, Blink-based Opera (15+) and Edge Chromium).
 */
const isChrome = matchChrome;
exports.isChrome = isChrome;

/** @return {boolean} Whether the user's browser is the Android browser. */
const isAndroidBrowser = matchAndroidBrowser;
exports.isAndroidBrowser = isAndroidBrowser;

/**
 * For more information, see:
 * http://docs.aws.amazon.com/silk/latest/developerguide/user-agent.html
 * @return {boolean} Whether the user's browser is Silk.
 */
function isSilk() {
  // As of Silk 93, Silk does not identify itself in userAgentData.brands.
  // When Silk changes this behavior, update this method to call
  // matchUserAgentDataBrand (akin to isChrome, etc.)
  return util.matchUserAgent('Silk');
}
exports.isSilk = isSilk;

/**
 * A helper function that returns a function mapping a list of candidate
 * version tuple keys to the first version string present under a key.
 * Ex:
 * <code>
 * // Arg extracted from "Foo/1.2.3 Bar/0.2021"
 * const mapVersion = createVersionMap([["Foo", "1.2.3"], ["Bar", "0.2021"]]);
 * mapVersion(["Bar", "Foo"]); // returns "0.2021"
 * mapVersion(["Baz", "Foo"]); // returns "1.2.3"
 * mapVersion(["Baz", "???"]); // returns ""
 * </code>
 * @param {!Array<!Array<string>>} versionTuples Version tuples pre-extracted
 *     from a user agent string.
 * @return {function(!Array<string>): string} The version string, or empty
 * string if it doesn't exist under the given key.
 */
function createVersionMap(versionTuples) {
  // Construct a map for easy lookup.
  const versionMap = {};
  versionTuples.forEach((tuple) => {
    // Note that the tuple is of length three, but we only care about the
    // first two.
    const key = tuple[0];
    const value = tuple[1];
    versionMap[key] = value;
  });

  // Gives the value with the first key it finds, otherwise empty string.
  return (keys) => versionMap[keys.find((key) => key in versionMap)] || '';
}

/**
 * Returns the browser version.
 *
 * Note that for browsers with multiple brands, this function assumes a primary
 * brand and returns the version for that brand.
 *
 * Additionally, this function is not userAgentData-aware and will return
 * incorrect values when the User Agent string is frozen. The current status of
 * User Agent string freezing is available here:
 * https://www.chromestatus.com/feature/5704553745874944
 *
 * To mitigate both of these potential issues, use
 * getVersionStringForLogging() or fullVersionOf() instead.
 *
 * @return {string} The browser version or empty string if version cannot be
 *     determined. Note that for Internet Explorer, this returns the version of
 *     the browser, not the version of the rendering engine. (IE 8 in
 *     compatibility mode will return 8.0 rather than 7.0. To determine the
 *     rendering engine version, look at document.documentMode instead. See
 *     http://msdn.microsoft.com/en-us/library/cc196988(v=vs.85).aspx for more
 *     details.)
 */
function getVersion() {
  const userAgentString = util.getUserAgent();

  // Special case IE since IE's version is inside the parenthesis and
  // without the '/'.
  if (isIE()) {
    return getIEVersion(userAgentString);
  }

  const versionTuples = util.extractVersionTuples(userAgentString);
  const lookUpValueWithKeys = createVersionMap(versionTuples);

  // Check Opera before Chrome since Opera 15+ has "Chrome" in the string.
  // See
  // http://my.opera.com/ODIN/blog/2013/07/15/opera-user-agent-strings-opera-15-and-beyond
  if (isOpera()) {
    // Opera 10 has Version/10.0 but Opera/9.8, so look for "Version" first.
    // Opera uses 'OPR' for more recent UAs.
    return lookUpValueWithKeys(['Version', 'Opera']);
  }

  // Check Edge before Chrome since it has Chrome in the string.
  if (isEdge()) {
    return lookUpValueWithKeys(['Edge']);
  }

  // Check Chromium Edge before Chrome since it has Chrome in the string.
  if (isEdgeChromium()) {
    return lookUpValueWithKeys(['Edg']);
  }

  // Check Silk before Chrome since it may have Chrome in its string and be
  // treated as Chrome.
  if (isSilk()) {
    return lookUpValueWithKeys(['Silk']);
  }

  if (isChrome()) {
    return lookUpValueWithKeys(['Chrome', 'CriOS', 'HeadlessChrome']);
  }

  // Usually products browser versions are in the third tuple after "Mozilla"
  // and the engine.
  const tuple = versionTuples[2];
  return tuple && tuple[1] || '';
}
exports.getVersion = getVersion;

/**
 * Returns whether the current browser's version is at least as high as the
 * given one.
 *
 * Note that for browsers with multiple brands, this function assumes a primary
 * brand and checks the version for that brand.
 *
 * Additionally, this function is not userAgentData-aware and will return
 * incorrect values when the User Agent string is frozen. The current status of
 * User Agent string freezing is available here:
 * https://www.chromestatus.com/feature/5704553745874944
 *
 * To mitigate both of these potential issues, use isAtLeast()/isAtMost() or
 * fullVersionOf() instead.
 *
 * @param {string|number} version The version to check.
 * @return {boolean} Whether the browser version is higher or the same as the
 *     given version.
 * @deprecated Use isAtLeast()/isAtMost() instead.
 */
function isVersionOrHigher(version) {
  return compareVersions(getVersion(), version) >= 0;
}
exports.isVersionOrHigher = isVersionOrHigher;

/**
 * A helper function to determine IE version. More information:
 * http://msdn.microsoft.com/en-us/library/ie/bg182625(v=vs.85).aspx#uaString
 * http://msdn.microsoft.com/en-us/library/hh869301(v=vs.85).aspx
 * http://blogs.msdn.com/b/ie/archive/2010/03/23/introducing-ie9-s-user-agent-string.aspx
 * http://blogs.msdn.com/b/ie/archive/2009/01/09/the-internet-explorer-8-user-agent-string-updated-edition.aspx
 * @param {string} userAgent the User-Agent.
 * @return {string}
 */
function getIEVersion(userAgent) {
  // IE11 may identify itself as MSIE 9.0 or MSIE 10.0 due to an IE 11 upgrade
  // bug. Example UA:
  // Mozilla/5.0 (MSIE 9.0; Windows NT 6.1; WOW64; Trident/7.0; rv:11.0)
  // like Gecko.
  // See http://www.whatismybrowser.com/developers/unknown-user-agent-fragments.
  const rv = /rv: *([\d\.]*)/.exec(userAgent);
  if (rv && rv[1]) {
    return rv[1];
  }

  let version = '';
  const msie = /MSIE +([\d\.]+)/.exec(userAgent);
  if (msie && msie[1]) {
    // IE in compatibility mode usually identifies itself as MSIE 7.0; in this
    // case, use the Trident version to determine the version of IE. For more
    // details, see the links above.
    const tridentVersion = /Trident\/(\d.\d)/.exec(userAgent);
    if (msie[1] == '7.0') {
      if (tridentVersion && tridentVersion[1]) {
        switch (tridentVersion[1]) {
          case '4.0':
            version = '8.0';
            break;
          case '5.0':
            version = '9.0';
            break;
          case '6.0':
            version = '10.0';
            break;
          case '7.0':
            version = '11.0';
            break;
        }
      } else {
        version = '7.0';
      }
    } else {
      version = msie[1];
    }
  }
  return version;
}

/**
 * A helper function to return the navigator.userAgent-supplied full version
 * number of the current browser or an empty string, based on whether the
 * current browser is the one specified.
 * @param {string} browser The brand whose version should be returned.
 * @return {string}
 */
function getFullVersionFromUserAgentString(browser) {
  const userAgentString = util.getUserAgent();
  // Special case IE since IE's version is inside the parenthesis and
  // without the '/'.
  if (browser === Brand.IE) {
    return isIE() ? getIEVersion(userAgentString) : '';
  }

  const versionTuples = util.extractVersionTuples(userAgentString);
  const lookUpValueWithKeys = createVersionMap(versionTuples);
  switch (browser) {
    case Brand.OPERA:
      // Opera 10 has Version/10.0 but Opera/9.8, so look for "Version"
      // first. Opera uses 'OPR' for more recent UAs.
      if (isOpera()) {
        return lookUpValueWithKeys(['Version', 'Opera']);
      } else if (isOperaChromium()) {
        return lookUpValueWithKeys(['OPR']);
      }
      break;
    case Brand.EDGE:
      if (isEdge()) {
        return lookUpValueWithKeys(['Edge']);
      } else if (isEdgeChromium()) {
        return lookUpValueWithKeys(['Edg']);
      }
      break;
    case Brand.CHROMIUM:
      if (isChrome()) {
        return lookUpValueWithKeys(['Chrome', 'CriOS', 'HeadlessChrome']);
      }
      break;
  }

  // For the following browsers, the browser version is in the third tuple after
  // "Mozilla" and the engine.
  if ((browser === Brand.FIREFOX && isFirefox()) ||
      (browser === Brand.SAFARI && isSafari()) ||
      (browser === Brand.ANDROID_BROWSER && isAndroidBrowser()) ||
      (browser === Brand.SILK && isSilk())) {
    const tuple = versionTuples[2];
    return tuple && tuple[1] || '';
  }

  return '';
}

/**
 * Returns the major version of the given browser brand, or NaN if the current
 * browser is not the given brand.
 * Note that the major version number may be different depending on which
 * browser is specified. The returned value can be used to make browser version
 * comparisons using comparison operators.
 * @private
 * @param {!Brand} browser The brand whose version should be returned.
 * @return {number} The major version number associated with the current
 * browser under the given brand, or NaN if the current browser doesn't match
 * the given brand.
 */
function versionOf_(browser) {
  let versionParts;
  // Silk currently does not identify itself in its userAgentData.brands array,
  // so if checking its version, always fall back to the user agent string.
  if (useUserAgentDataBrand() && browser !== Brand.SILK) {
    const data = util.getUserAgentData();
    const matchingBrand = data.brands.find(({brand}) => brand === browser);
    if (!matchingBrand || !matchingBrand.version) {
      return NaN;
    }
    versionParts = matchingBrand.version.split('.');
  } else {
    const fullVersion = getFullVersionFromUserAgentString(browser);
    if (fullVersion === '') {
      return NaN;
    }
    versionParts = fullVersion.split('.');
  }
  if (versionParts.length === 0) {
    return NaN;
  }
  const majorVersion = versionParts[0];
  return Number(majorVersion);  // Returns NaN if it is not parseable.
}

/**
 * Returns true if the current browser matches the given brand and is at least
 * the given major version. The major version must be a whole number (i.e.
 * decimals should not be used to represent a minor version).
 * @param {!Brand} brand The brand whose version should be returned.
 * @param {number} majorVersion The major version number to compare against.
 *     This must be a whole number.
 * @return {boolean} Whether the current browser both matches the given brand
 *     and is at least the given version.
 */
function isAtLeast(brand, majorVersion) {
  googAsserts.assert(
      Math.floor(majorVersion) === majorVersion,
      'Major version must be an integer');
  return versionOf_(brand) >= majorVersion;
}
exports.isAtLeast = isAtLeast;

/**
 * Returns true if the current browser matches the given brand and is at most
 * the given version. The major version must be a whole number (i.e. decimals
 * should not be used to represent a minor version).
 * @param {!Brand} brand The brand whose version should be returned.
 * @param {number} majorVersion The major version number to compare against.
 *     This must be a whole number.
 * @return {boolean} Whether the current browser both matches the given brand
 *     and is at most the given version.
 */
function isAtMost(brand, majorVersion) {
  googAsserts.assert(
      Math.floor(majorVersion) === majorVersion,
      'Major version must be an integer');
  return versionOf_(brand) <= majorVersion;
}
exports.isAtMost = isAtMost;

/**
 * Loads the high-entropy browser brand/version data and wraps the correct
 * version string in a Version object.
 * @implements {AsyncValue<!Version>}
 */
class HighEntropyBrandVersion {
  /**
   * @param {string} brand The brand whose version is retrieved in this
   *     container.
   */
  constructor(brand) {
    /**
     * @const {string}
     * @private
     */
    this.brand_ = brand;
  }

  /**
   * @return {!Version|undefined}
   * @override
   */
  getIfLoaded() {
    const loadedVersionList = fullVersionList.getIfLoaded();
    if (loadedVersionList !== undefined) {
      const matchingBrand =
          loadedVersionList.find(({brand}) => this.brand_ === brand);
      googAsserts.assertExists(matchingBrand);
      return new Version(matchingBrand.version);
    }
    return;
  }

  /**
   * @return {!Promise<!Version>}
   * @override
   */
  async load() {
    const loadedVersionList = await fullVersionList.load();
    const matchingBrand =
        loadedVersionList.find(({brand}) => this.brand_ === brand);
    googAsserts.assertExists(matchingBrand);
    return new Version(matchingBrand.version);
  }
}

/**
 * Wraps a version string in a Version object.
 * @implements {AsyncValue<!Version>}
 */
class UserAgentStringFallbackBrandVersion {
  /**
   * @param {string} versionString
   */
  constructor(versionString) {
    /**
     * @const {!Version}
     * @private
     */
    this.version_ = new Version(versionString);
  }

  /**
   * @return {!Version|undefined}
   * @override
   */
  getIfLoaded() {
    return this.version_;
  }

  /**
   * @return {!Promise<!Version>}
   * @override
   */
  async load() {
    return this.version_;
  }
}

/**
 * Requests all full browser versions to be cached.  When the returned promise
 * resolves, subsequent calls to `fullVersionOf(...).getIfLoaded()` will return
 * a value.
 *
 * This method should be avoided in favor of directly awaiting
 * `fullVersionOf(...).load()` where it is used.
 *
 * @return {!Promise<void>}
 */
async function loadFullVersions() {
  if (useUserAgentDataBrand() && hasFullVersionList()) {
    await fullVersionList.load();
  }
}
exports.loadFullVersions = loadFullVersions;

/**
 * Returns an object that provides access to the full version string of the
 * current browser -- or undefined, based on whether the current browser matches
 * the requested browser brand. Note that the full version string is a
 * high-entropy value, and must be asynchronously loaded before it can be
 * accessed synchronously.
 * @param {!Brand} browser The brand whose version should be returned.
 * @return {!AsyncValue<!Version>|undefined} An object that can be used
 *     to get or load the full version string as a high-entropy value, or
 * undefined if the current browser doesn't match the given brand.
 */
function fullVersionOf(browser) {
  // Silk currently does not identify itself in its userAgentData.brands array,
  // so if checking its version, always fall back to the user agent string.
  if (useUserAgentDataBrand() && hasFullVersionList()) {
    const data = util.getUserAgentData();
    // Operate under the assumption that the low-entropy and high-entropy lists
    // of brand/version pairs contain an identical set of brands. Therefore, if
    // the low-entropy list doesn't contain the given brand, return undefined.
    if (!data.brands.find(({brand}) => brand === browser)) {
      return undefined;
    }
    return new HighEntropyBrandVersion(browser);
  } else {
    const fullVersionFromUserAgentString =
        getFullVersionFromUserAgentString(browser);
    if (fullVersionFromUserAgentString === '') {
      return undefined;
    }
    return new UserAgentStringFallbackBrandVersion(
        fullVersionFromUserAgentString);
  }
}
exports.fullVersionOf = fullVersionOf;

/**
 * Returns a version string for the current browser or undefined, based on
 * whether the current browser is the one specified.
 * This value should ONLY be used for logging/debugging purposes. Do not use it
 * to branch code paths. For comparing versions, use isAtLeast()/isAtMost() or
 * fullVersionOf() instead.
 * @param {!Brand} browser The brand whose version should be returned.
 * @return {string} The version as a string.
 */
function getVersionStringForLogging(browser) {
  if (useUserAgentDataBrand()) {
    const fullVersionObj = fullVersionOf(browser);
    if (fullVersionObj) {
      const fullVersion = fullVersionObj.getIfLoaded();
      if (fullVersion) {
        return fullVersion.toVersionStringForLogging();
      }
      // No full version, return the major version instead.
      const data = util.getUserAgentData();
      const matchingBrand = data.brands.find(({brand}) => brand === browser);
      // Checking for the existence of matchingBrand is not necessary because
      // the existence of fullVersionObj implies that there is already a
      // matching brand.
      googAsserts.assertExists(matchingBrand);
      return matchingBrand.version;
    }
    // If fullVersionObj is undefined, this doesn't mean that the full version
    // is unavailable, but rather that the current browser doesn't match the
    // input `browser` argument.
    return '';
  } else {
    return getFullVersionFromUserAgentString(browser);
  }
}
exports.getVersionStringForLogging = getVersionStringForLogging;

;return exports;});

//third_party/javascript/closure/html/safehtml.js
goog.loadModule(function(exports) {'use strict';/**
 * @license
 * Copyright The Closure Library Authors.
 * SPDX-License-Identifier: Apache-2.0
 */


/**
 * @fileoverview The SafeHtml type and its builders.
 *
 * TODO(xtof): Link to document stating type contract.
 */

goog.module('goog.html.SafeHtml');
goog.module.declareLegacyNamespace();

const Const = goog.require('goog.string.Const');
const SafeScript = goog.require('goog.html.SafeScript');
const SafeStyle = goog.require('goog.html.SafeStyle');
const SafeStyleSheet = goog.require('goog.html.SafeStyleSheet');
const SafeUrl = goog.require('goog.html.SafeUrl');
const TagName = goog.require('goog.dom.TagName');
const TrustedResourceUrl = goog.require('goog.html.TrustedResourceUrl');
const TypedString = goog.require('goog.string.TypedString');
const asserts = goog.require('goog.asserts');
const browser = goog.require('goog.labs.userAgent.browser');
const googArray = goog.require('goog.array');
const googObject = goog.require('goog.object');
const internal = goog.require('goog.string.internal');
const tags = goog.require('goog.dom.tags');
const trustedtypes = goog.require('goog.html.trustedtypes');


/**
 * Token used to ensure that object is created only from this file. No code
 * outside of this file can access this token.
 * @type {!Object}
 * @const
 */
const CONSTRUCTOR_TOKEN_PRIVATE = {};

/**
 * A string that is safe to use in HTML context in DOM APIs and HTML documents.
 *
 * A SafeHtml is a string-like object that carries the security type contract
 * that its value as a string will not cause untrusted script execution when
 * evaluated as HTML in a browser.
 *
 * Values of this type are guaranteed to be safe to use in HTML contexts,
 * such as, assignment to the innerHTML DOM property, or interpolation into
 * a HTML template in HTML PC_DATA context, in the sense that the use will not
 * result in a Cross-Site-Scripting vulnerability.
 *
 * Instances of this type must be created via the factory methods
 * (`SafeHtml.create`, `SafeHtml.htmlEscape`),
 * etc and not by invoking its constructor. The constructor intentionally takes
 * an extra parameter that cannot be constructed outside of this file and the
 * type is immutable; hence only a default instance corresponding to the empty
 * string can be obtained via constructor invocation.
 *
 * Creating SafeHtml objects HAS SIDE-EFFECTS due to calling Trusted Types Web
 * API.
 *
 * Note that there is no `SafeHtml.fromConstant`. The reason is that
 * the following code would create an unsafe HTML:
 *
 * ```
 * SafeHtml.concat(
 *     SafeHtml.fromConstant(Const.from('<script>')),
 *     SafeHtml.htmlEscape(userInput),
 *     SafeHtml.fromConstant(Const.from('<\/script>')));
 * ```
 *
 * There's `goog.dom.constHtmlToNode` to create a node from constant strings
 * only.
 *
 * @see SafeHtml.create
 * @see SafeHtml.htmlEscape
 * @final
 * @struct
 * @implements {TypedString}
 */
class SafeHtml {
  /**
   * @param {!TrustedHTML|string} value
   * @param {!Object} token package-internal implementation detail.
   */
  constructor(value, token) {
    /**
     * The contained value of this SafeHtml.  The field has a purposely ugly
     * name to make (non-compiled) code that attempts to directly access this
     * field stand out.
     * @private {!TrustedHTML|string}
     */
    this.privateDoNotAccessOrElseSafeHtmlWrappedValue_ =
        (token === CONSTRUCTOR_TOKEN_PRIVATE) ? value : '';

    /**
     * @override
     * @const {boolean}
     */
    this.implementsGoogStringTypedString = true;
  }


  /**
   * Returns this SafeHtml's value as string.
   *
   * IMPORTANT: In code where it is security relevant that an object's type is
   * indeed `SafeHtml`, use `SafeHtml.unwrap` instead of
   * this method. If in doubt, assume that it's security relevant. In
   * particular, note that goog.html functions which return a goog.html type do
   * not guarantee that the returned instance is of the right type. For example:
   *
   * <pre>
   * var fakeSafeHtml = new String('fake');
   * fakeSafeHtml.__proto__ = SafeHtml.prototype;
   * var newSafeHtml = SafeHtml.htmlEscape(fakeSafeHtml);
   * // newSafeHtml is just an alias for fakeSafeHtml, it's passed through by
   * // SafeHtml.htmlEscape() as fakeSafeHtml
   * // instanceof SafeHtml.
   * </pre>
   *
   * @return {string}
   * @see SafeHtml.unwrap
   * @override
   */
  getTypedStringValue() {
    return this.privateDoNotAccessOrElseSafeHtmlWrappedValue_.toString();
  }


  /**
   * Returns a string-representation of this value.
   *
   * To obtain the actual string value wrapped in a SafeHtml, use
   * `SafeHtml.unwrap`.
   *
   * @return {string}
   * @see SafeHtml.unwrap
   * @override
   */
  toString() {
    return this.privateDoNotAccessOrElseSafeHtmlWrappedValue_.toString();
  }

  /**
   * Performs a runtime check that the provided object is indeed a SafeHtml
   * object, and returns its value.
   * @param {!SafeHtml} safeHtml The object to extract from.
   * @return {string} The SafeHtml object's contained string, unless the
   *     run-time type check fails. In that case, `unwrap` returns an innocuous
   *     string, or, if assertions are enabled, throws
   *     `asserts.AssertionError`.
   */
  static unwrap(safeHtml) {
    return SafeHtml.unwrapTrustedHTML(safeHtml).toString();
  }


  /**
   * Unwraps value as TrustedHTML if supported or as a string if not.
   * @param {!SafeHtml} safeHtml
   * @return {!TrustedHTML|string}
   * @see SafeHtml.unwrap
   */
  static unwrapTrustedHTML(safeHtml) {
    // Perform additional run-time type-checking to ensure that safeHtml is
    // indeed an instance of the expected type.  This provides some additional
    // protection against security bugs due to application code that disables
    // type checks. Specifically, the following checks are performed:
    // 1. The object is an instance of the expected type.
    // 2. The object is not an instance of a subclass.
    if (safeHtml instanceof SafeHtml && safeHtml.constructor === SafeHtml) {
      return safeHtml.privateDoNotAccessOrElseSafeHtmlWrappedValue_;
    } else {
      asserts.fail(
          `expected object of type SafeHtml, got '${safeHtml}' of type ` +
          goog.typeOf(safeHtml));
      return 'type_error:SafeHtml';
    }
  }

  /**
   * Returns HTML-escaped text as a SafeHtml object.
   *
   * @param {!SafeHtml.TextOrHtml_} textOrHtml The text to escape. If
   *     the parameter is of type SafeHtml it is returned directly (no escaping
   *     is done).
   * @return {!SafeHtml} The escaped text, wrapped as a SafeHtml.
   */
  static htmlEscape(textOrHtml) {
    if (textOrHtml instanceof SafeHtml) {
      return textOrHtml;
    }
    const textIsObject = typeof textOrHtml == 'object';
    let textAsString;
    if (textIsObject &&
        /** @type {?} */ (textOrHtml).implementsGoogStringTypedString) {
      textAsString =
          /** @type {!TypedString} */ (textOrHtml).getTypedStringValue();
    } else {
      textAsString = String(textOrHtml);
    }
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(
        internal.htmlEscape(textAsString));
  }


  /**
   * Returns HTML-escaped text as a SafeHtml object, with newlines changed to
   * &lt;br&gt;.
   * @param {!SafeHtml.TextOrHtml_} textOrHtml The text to escape. If
   *     the parameter is of type SafeHtml it is returned directly (no escaping
   *     is done).
   * @return {!SafeHtml} The escaped text, wrapped as a SafeHtml.
   */
  static htmlEscapePreservingNewlines(textOrHtml) {
    if (textOrHtml instanceof SafeHtml) {
      return textOrHtml;
    }
    const html = SafeHtml.htmlEscape(textOrHtml);
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(
        internal.newLineToBr(SafeHtml.unwrap(html)));
  }


  /**
   * Returns HTML-escaped text as a SafeHtml object, with newlines changed to
   * &lt;br&gt; and escaping whitespace to preserve spatial formatting.
   * Character entity #160 is used to make it safer for XML.
   * @param {!SafeHtml.TextOrHtml_} textOrHtml The text to escape. If
   *     the parameter is of type SafeHtml it is returned directly (no escaping
   *     is done).
   * @return {!SafeHtml} The escaped text, wrapped as a SafeHtml.
   */
  static htmlEscapePreservingNewlinesAndSpaces(textOrHtml) {
    if (textOrHtml instanceof SafeHtml) {
      return textOrHtml;
    }
    const html = SafeHtml.htmlEscape(textOrHtml);
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(
        internal.whitespaceEscape(SafeHtml.unwrap(html)));
  }

  /**
   * Converts an arbitrary string into an HTML comment by HTML-escaping the
   * contents and embedding the result between HTML comment markers.
   *
   * Escaping is needed because Internet Explorer supports conditional comments
   * and so may render HTML markup within comments.
   *
   * @param {string} text
   * @return {!SafeHtml}
   */
  static comment(text) {
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(
        '<!--' + internal.htmlEscape(text) + '-->');
  }

  /**
   * Creates a SafeHtml content consisting of a tag with optional attributes and
   * optional content.
   *
   * For convenience tag names and attribute names are accepted as regular
   * strings, instead of Const. Nevertheless, you should not pass
   * user-controlled values to these parameters. Note that these parameters are
   * syntactically validated at runtime, and invalid values will result in
   * an exception.
   *
   * Example usage:
   *
   * SafeHtml.create('br');
   * SafeHtml.create('div', {'class': 'a'});
   * SafeHtml.create('p', {}, 'a');
   * SafeHtml.create('p', {}, SafeHtml.create('br'));
   *
   * SafeHtml.create('span', {
   *   'style': {'margin': '0'}
   * });
   *
   * To guarantee SafeHtml's type contract is upheld there are restrictions on
   * attribute values and tag names.
   *
   * - For attributes which contain script code (on*), a Const is
   *   required.
   * - For attributes which contain style (style), a SafeStyle or a
   *   SafeStyle.PropertyMap is required.
   * - For attributes which are interpreted as URLs (e.g. src, href) a
   *   SafeUrl, Const or string is required. If a string
   *   is passed, it will be sanitized with SafeUrl.sanitize().
   * - For tags which can load code or set security relevant page metadata,
   *   more specific SafeHtml.create*() functions must be used. Tags
   *   which are not supported by this function are applet, base, embed, iframe,
   *   link, math, meta, object, script, style, svg, and template.
   *
   * @param {!TagName|string} tagName The name of the tag. Only tag names
   *     consisting of [a-zA-Z0-9-] are allowed. Tag names documented above are
   *     disallowed.
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes  Mapping
   *     from attribute names to their values. Only attribute names consisting
   *     of [a-zA-Z0-9-] are allowed. Value of null or undefined causes the
   *     attribute to be omitted.
   * @param {!SafeHtml.TextOrHtml_|
   *     !Array<!SafeHtml.TextOrHtml_>=} content Content to HTML-escape and put
   * inside the tag. This must be empty for void tags like <br>. Array elements
   * are concatenated.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   * @throws {!Error} If invalid tag name, attribute name, or attribute value is
   *     provided.
   * @throws {!asserts.AssertionError} If content for void tag is provided.
   */
  static create(tagName, attributes = undefined, content = undefined) {
    SafeHtml.verifyTagName(String(tagName));
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        String(tagName), attributes, content);
  }


  /**
   * Verifies if the tag name is valid and if it doesn't change the context.
   * E.g. STRONG is fine but SCRIPT throws because it changes context. See
   * SafeHtml.create for an explanation of allowed tags.
   * @param {string} tagName
   * @return {void}
   * @throws {!Error} If invalid tag name is provided.
   * @package
   */
  static verifyTagName(tagName) {
    if (!VALID_NAMES_IN_TAG.test(tagName)) {
      throw new Error(
          SafeHtml.ENABLE_ERROR_MESSAGES ? `Invalid tag name <${tagName}>.` :
                                           '');
    }
    if (tagName.toUpperCase() in NOT_ALLOWED_TAG_NAMES) {
      throw new Error(
          SafeHtml.ENABLE_ERROR_MESSAGES ?

              `Tag name <${tagName}> is not allowed for SafeHtml.` :
              '');
    }
  }


  /**
   * Creates a SafeHtml representing an iframe tag.
   *
   * This by default restricts the iframe as much as possible by setting the
   * sandbox attribute to the empty string. If the iframe requires less
   * restrictions, set the sandbox attribute as tight as possible, but do not
   * rely on the sandbox as a security feature because it is not supported by
   * older browsers. If a sandbox is essential to security (e.g. for third-party
   * frames), use createSandboxIframe which checks for browser support.
   *
   * @see https://developer.mozilla.org/en/docs/Web/HTML/Element/iframe#attr-sandbox
   *
   * @param {?TrustedResourceUrl=} src The value of the src
   *     attribute. If null or undefined src will not be set.
   * @param {?SafeHtml=} srcdoc The value of the srcdoc attribute.
   *     If null or undefined srcdoc will not be set.
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes  Mapping
   *     from attribute names to their values. Only attribute names consisting
   *     of [a-zA-Z0-9-] are allowed. Value of null or undefined causes the
   *     attribute to be omitted.
   * @param {!SafeHtml.TextOrHtml_|
   *     !Array<!SafeHtml.TextOrHtml_>=} content Content to HTML-escape and put
   * inside the tag. Array elements are concatenated.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   * @throws {!Error} If invalid tag name, attribute name, or attribute value is
   *     provided. If attributes
   * contains the src or srcdoc attributes.
   */
  static createIframe(
      src = undefined, srcdoc = undefined, attributes = undefined,
      content = undefined) {
    if (src) {
      // Check whether this is really TrustedResourceUrl.
      TrustedResourceUrl.unwrap(src);
    }

    const fixedAttributes = {};
    fixedAttributes['src'] = src || null;
    fixedAttributes['srcdoc'] = srcdoc && SafeHtml.unwrap(srcdoc);
    const defaultAttributes = {'sandbox': ''};
    const combinedAttrs = SafeHtml.combineAttributes(
        fixedAttributes, defaultAttributes, attributes);
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        'iframe', combinedAttrs, content);
  }


  /**
   * Creates a SafeHtml representing a sandboxed iframe tag.
   *
   * The sandbox attribute is enforced in its most restrictive mode, an empty
   * string. Consequently, the security requirements for the src and srcdoc
   * attributes are relaxed compared to SafeHtml.createIframe. This function
   * will throw on browsers that do not support the sandbox attribute, as
   * determined by SafeHtml.canUseSandboxIframe.
   *
   * The SafeHtml returned by this function can trigger downloads with no
   * user interaction on Chrome (though only a few, further attempts are
   * blocked). Firefox and IE will block all downloads from the sandbox.
   *
   * @see https://developer.mozilla.org/en/docs/Web/HTML/Element/iframe#attr-sandbox
   * @see https://lists.w3.org/Archives/Public/public-whatwg-archive/2013Feb/0112.html
   *
   * @param {string|!SafeUrl=} src The value of the src
   *     attribute. If null or undefined src will not be set.
   * @param {string=} srcdoc The value of the srcdoc attribute.
   *     If null or undefined srcdoc will not be set. Will not be sanitized.
   * @param {!Object<string, ?SafeHtml.AttributeValue>=} attributes  Mapping
   *     from attribute names to their values. Only attribute names consisting
   *     of [a-zA-Z0-9-] are allowed. Value of null or undefined causes the
   *     attribute to be omitted.
   * @param {!SafeHtml.TextOrHtml_|
   *     !Array<!SafeHtml.TextOrHtml_>=} content Content to HTML-escape and put
   * inside the tag. Array elements are concatenated.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   * @throws {!Error} If invalid tag name, attribute name, or attribute value is
   *     provided. If attributes
   * contains the src, srcdoc or sandbox attributes. If browser does not support
   * the sandbox attribute on iframe.
   */
  static createSandboxIframe(
      src = undefined, srcdoc = undefined, attributes = undefined,
      content = undefined) {
    if (!SafeHtml.canUseSandboxIframe()) {
      throw new Error(
          SafeHtml.ENABLE_ERROR_MESSAGES ?
              'The browser does not support sandboxed iframes.' :
              '');
    }

    const fixedAttributes = {};
    if (src) {
      // Note that sanitize is a no-op on SafeUrl.
      fixedAttributes['src'] = SafeUrl.unwrap(SafeUrl.sanitize(src));
    } else {
      fixedAttributes['src'] = null;
    }
    fixedAttributes['srcdoc'] = srcdoc || null;
    fixedAttributes['sandbox'] = '';
    const combinedAttrs =
        SafeHtml.combineAttributes(fixedAttributes, {}, attributes);
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        'iframe', combinedAttrs, content);
  }


  /**
   * Checks if the user agent supports sandboxed iframes.
   * @return {boolean}
   */
  static canUseSandboxIframe() {
    return goog.global['HTMLIFrameElement'] &&
        ('sandbox' in goog.global['HTMLIFrameElement'].prototype);
  }


  /**
   * Creates a SafeHtml representing a script tag with the src attribute.
   * @param {!TrustedResourceUrl} src The value of the src
   * attribute.
   * @param {?Object<string, ?SafeHtml.AttributeValue>=}
   * attributes
   *     Mapping from attribute names to their values. Only attribute names
   *     consisting of [a-zA-Z0-9-] are allowed. Value of null or undefined
   *     causes the attribute to be omitted.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   * @throws {!Error} If invalid attribute name or value is provided. If
   *     attributes  contains the
   * src attribute.
   */
  static createScriptSrc(src, attributes = undefined) {
    // TODO(mlourenco): The charset attribute should probably be blocked. If
    // its value is attacker controlled, the script contains attacker controlled
    // sub-strings (even if properly escaped) and the server does not set
    // charset then XSS is likely possible.
    // https://html.spec.whatwg.org/multipage/scripting.html#dom-script-charset

    // Check whether this is really TrustedResourceUrl.
    TrustedResourceUrl.unwrap(src);

    const fixedAttributes = {'src': src};
    const defaultAttributes = {};
    const combinedAttrs = SafeHtml.combineAttributes(
        fixedAttributes, defaultAttributes, attributes);
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        'script', combinedAttrs);
  }

  /**
   * Creates a SafeHtml representing a script tag. Does not allow the language,
   * src, text or type attributes to be set.
   * @param {!SafeScript|!Array<!SafeScript>}
   *     script Content to put inside the tag. Array elements are
   *     concatenated.
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes  Mapping
   *     from attribute names to their values. Only attribute names consisting
   *     of [a-zA-Z0-9-] are allowed. Value of null or undefined causes the
   *     attribute to be omitted.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   * @throws {!Error} If invalid attribute name or attribute value is provided.
   *     If attributes  contains the
   *     language, src or text attribute.
   */
  static createScript(script, attributes = undefined) {
    for (let attr in attributes) {
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty#Using_hasOwnProperty_as_a_property_name
      if (Object.prototype.hasOwnProperty.call(attributes, attr)) {
        const attrLower = attr.toLowerCase();
        if (attrLower == 'language' || attrLower == 'src' ||
            attrLower == 'text') {
          throw new Error(
              SafeHtml.ENABLE_ERROR_MESSAGES ?
                  `Cannot set "${attrLower}" attribute` :
                  '');
        }
      }
    }

    let content = '';
    script = googArray.concat(script);
    for (let i = 0; i < script.length; i++) {
      content += SafeScript.unwrap(script[i]);
    }
    // Convert to SafeHtml so that it's not HTML-escaped. This is safe because
    // as part of its contract, SafeScript should have no dangerous '<'.
    const htmlContent =
        SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(content);
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        'script', attributes, htmlContent);
  }


  /**
   * Creates a SafeHtml representing a style tag. The type attribute is set
   * to "text/css".
   * @param {!SafeStyleSheet|!Array<!SafeStyleSheet>}
   *     styleSheet Content to put inside the tag. Array elements are
   *     concatenated.
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes  Mapping
   *     from attribute names to their values. Only attribute names consisting
   *     of [a-zA-Z0-9-] are allowed. Value of null or undefined causes the
   *     attribute to be omitted.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   * @throws {!Error} If invalid attribute name or attribute value is provided.
   *     If attributes  contains the
   *     type attribute.
   */
  static createStyle(styleSheet, attributes = undefined) {
    const fixedAttributes = {'type': 'text/css'};
    const defaultAttributes = {};
    const combinedAttrs = SafeHtml.combineAttributes(
        fixedAttributes, defaultAttributes, attributes);

    let content = '';
    styleSheet = googArray.concat(styleSheet);
    for (let i = 0; i < styleSheet.length; i++) {
      content += SafeStyleSheet.unwrap(styleSheet[i]);
    }
    // Convert to SafeHtml so that it's not HTML-escaped. This is safe because
    // as part of its contract, SafeStyleSheet should have no dangerous '<'.
    const htmlContent =
        SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(content);
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        'style', combinedAttrs, htmlContent);
  }


  /**
   * Creates a SafeHtml representing a meta refresh tag.
   * @param {!SafeUrl|string} url Where to redirect. If a string is
   *     passed, it will be sanitized with SafeUrl.sanitize().
   * @param {number=} secs Number of seconds until the page should be
   *     reloaded. Will be set to 0 if unspecified.
   * @return {!SafeHtml} The SafeHtml content with the tag.
   */
  static createMetaRefresh(url, secs = undefined) {
    // Note that sanitize is a no-op on SafeUrl.
    let unwrappedUrl = SafeUrl.unwrap(SafeUrl.sanitize(url));

    if (browser.isIE() || browser.isEdge()) {
      // IE/EDGE can't parse the content attribute if the url contains a
      // semicolon. We can fix this by adding quotes around the url, but then we
      // can't parse quotes in the URL correctly. Also, it seems that IE/EDGE
      // did not unescape semicolons in these URLs at some point in the past. We
      // take a best-effort approach.
      //
      // If the URL has semicolons (which may happen in some cases, see
      // http://www.w3.org/TR/1999/REC-html401-19991224/appendix/notes.html#h-B.2
      // for instance), wrap it in single quotes to protect the semicolons.
      // If the URL has semicolons and single quotes, url-encode the single
      // quotes as well.
      //
      // This is imperfect. Notice that both ' and ; are reserved characters in
      // URIs, so this could do the wrong thing, but at least it will do the
      // wrong thing in only rare cases.
      if (internal.contains(unwrappedUrl, ';')) {
        unwrappedUrl = '\'' + unwrappedUrl.replace(/'/g, '%27') + '\'';
      }
    }
    const attributes = {
      'http-equiv': 'refresh',
      'content': (secs || 0) + '; url=' + unwrappedUrl,
    };

    // This function will handle the HTML escaping for attributes.
    return SafeHtml.createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
        'meta', attributes);
  }

  /**
   * Creates a new SafeHtml object by joining the parts with separator.
   * @param {!SafeHtml.TextOrHtml_} separator
   * @param {!Array<!SafeHtml.TextOrHtml_|
   *     !Array<!SafeHtml.TextOrHtml_>>} parts Parts to join. If a part
   *     contains an array then each member of this array is also joined with
   * the separator.
   * @return {!SafeHtml}
   */
  static join(separator, parts) {
    const separatorHtml = SafeHtml.htmlEscape(separator);
    const content = [];

    /**
     * @param {!SafeHtml.TextOrHtml_|
     *     !Array<!SafeHtml.TextOrHtml_>} argument
     */
    const addArgument = (argument) => {
      if (Array.isArray(argument)) {
        argument.forEach(addArgument);
      } else {
        const html = SafeHtml.htmlEscape(argument);
        content.push(SafeHtml.unwrap(html));
      }
    };

    parts.forEach(addArgument);
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(
        content.join(SafeHtml.unwrap(separatorHtml)));
  }


  /**
   * Creates a new SafeHtml object by concatenating values.
   * @param {...(!SafeHtml.TextOrHtml_|
   *     !Array<!SafeHtml.TextOrHtml_>)} var_args Values to concatenate.
   * @return {!SafeHtml}
   */
  static concat(var_args) {
    return SafeHtml.join(SafeHtml.EMPTY, Array.prototype.slice.call(arguments));
  }

  /**
   * Package-internal utility method to create SafeHtml instances.
   *
   * @param {string} html The string to initialize the SafeHtml object with.
   * @return {!SafeHtml} The initialized SafeHtml object.
   * @package
   */
  static createSafeHtmlSecurityPrivateDoNotAccessOrElse(html) {
    /** @noinline */
    const noinlineHtml = html;
    const policy = trustedtypes.getPolicyPrivateDoNotAccessOrElse();
    const trustedHtml = policy ? policy.createHTML(noinlineHtml) : noinlineHtml;
    return new SafeHtml(trustedHtml, CONSTRUCTOR_TOKEN_PRIVATE);
  }


  /**
   * Like create() but does not restrict which tags can be constructed.
   *
   * @param {string} tagName Tag name. Set or validated by caller.
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes
   * @param {(!SafeHtml.TextOrHtml_|
   *     !Array<!SafeHtml.TextOrHtml_>)=} content
   * @return {!SafeHtml}
   * @throws {!Error} If invalid or unsafe attribute name or value is provided.
   * @throws {!asserts.AssertionError} If content for void tag is provided.
   * @package
   */
  static createSafeHtmlTagSecurityPrivateDoNotAccessOrElse(
      tagName, attributes = undefined, content = undefined) {
    let result = `<${tagName}`;
    result += SafeHtml.stringifyAttributes(tagName, attributes);

    if (content == null) {
      content = [];
    } else if (!Array.isArray(content)) {
      content = [content];
    }

    if (tags.isVoidTag(tagName.toLowerCase())) {
      asserts.assert(
          !content.length, `Void tag <${tagName}> does not allow content.`);
      result += '>';
    } else {
      const html = SafeHtml.concat(content);
      result += '>' + SafeHtml.unwrap(html) + '</' + tagName + '>';
    }

    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(result);
  }


  /**
   * Creates a string with attributes to insert after tagName.
   * @param {string} tagName
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes
   * @return {string} Returns an empty string if there are no attributes,
   *     returns a string starting with a space otherwise.
   * @throws {!Error} If attribute value is unsafe for the given tag and
   *     attribute.
   * @package
   */
  static stringifyAttributes(tagName, attributes = undefined) {
    let result = '';
    if (attributes) {
      for (let name in attributes) {
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty#Using_hasOwnProperty_as_a_property_name
        if (Object.prototype.hasOwnProperty.call(attributes, name)) {
          if (!VALID_NAMES_IN_TAG.test(name)) {
            throw new Error(
                SafeHtml.ENABLE_ERROR_MESSAGES ?
                    `Invalid attribute name "${name}".` :
                    '');
          }
          const value = attributes[name];
          if (value == null) {
            continue;
          }
          result += ' ' + getAttrNameAndValue(tagName, name, value);
        }
      }
    }
    return result;
  }


  /**
   * @param {!Object<string, ?SafeHtml.AttributeValue>} fixedAttributes
   * @param {!Object<string, string>} defaultAttributes
   * @param {?Object<string, ?SafeHtml.AttributeValue>=} attributes  Optional
   *     attributes passed to create*().
   * @return {!Object<string, ?SafeHtml.AttributeValue>}
   * @throws {!Error} If attributes contains an attribute with the same name as
   *     an attribute in fixedAttributes.
   * @package
   */
  static combineAttributes(
      fixedAttributes, defaultAttributes, attributes = undefined) {
    const combinedAttributes = {};

    for (const name in fixedAttributes) {
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty#Using_hasOwnProperty_as_a_property_name
      if (Object.prototype.hasOwnProperty.call(fixedAttributes, name)) {
        asserts.assert(name.toLowerCase() == name, 'Must be lower case');
        combinedAttributes[name] = fixedAttributes[name];
      }
    }
    for (const name in defaultAttributes) {
      if (Object.prototype.hasOwnProperty.call(defaultAttributes, name)) {
        asserts.assert(name.toLowerCase() == name, 'Must be lower case');
        combinedAttributes[name] = defaultAttributes[name];
      }
    }

    if (attributes) {
      for (const name in attributes) {
        if (Object.prototype.hasOwnProperty.call(attributes, name)) {
          const nameLower = name.toLowerCase();
          if (nameLower in fixedAttributes) {
            throw new Error(
                SafeHtml.ENABLE_ERROR_MESSAGES ?
                    `Cannot override "${nameLower}" attribute, got "` + name +
                        '" with value "' + attributes[name] + '"' :
                    '');
          }
          if (nameLower in defaultAttributes) {
            delete combinedAttributes[nameLower];
          }
          combinedAttributes[name] = attributes[name];
        }
      }
    }

    return combinedAttributes;
  }
}


/**
 * @define {boolean} Whether to strip out error messages or to leave them in.
 */
SafeHtml.ENABLE_ERROR_MESSAGES =
    goog.define('goog.html.SafeHtml.ENABLE_ERROR_MESSAGES', goog.DEBUG);


/**
 * Whether the `style` attribute is supported. Set to false to avoid the byte
 * weight of `SafeStyle` where unneeded. An error will be thrown if
 * the `style` attribute is used.
 * @define {boolean}
 */
SafeHtml.SUPPORT_STYLE_ATTRIBUTE =
    goog.define('goog.html.SafeHtml.SUPPORT_STYLE_ATTRIBUTE', true);


/**
 * Shorthand for union of types that can sensibly be converted to strings
 * or might already be SafeHtml (as SafeHtml is a TypedString).
 * @private
 * @typedef {string|number|boolean|!TypedString}
 */
SafeHtml.TextOrHtml_;


/**
 * Coerces an arbitrary object into a SafeHtml object.
 *
 * If `textOrHtml` is already of type `SafeHtml`, the same
 * object is returned. Otherwise, `textOrHtml` is coerced to string, and
 * HTML-escaped.
 *
 * @param {!SafeHtml.TextOrHtml_} textOrHtml The text or SafeHtml to
 *     coerce.
 * @return {!SafeHtml} The resulting SafeHtml object.
 * @deprecated Use SafeHtml.htmlEscape.
 */
SafeHtml.from = SafeHtml.htmlEscape;


/**
 * @const
 */
const VALID_NAMES_IN_TAG = /^[a-zA-Z0-9-]+$/;


/**
 * Set of attributes containing URL as defined at
 * http://www.w3.org/TR/html5/index.html#attributes-1.
 * @const {!Object<string,boolean>}
 */
const URL_ATTRIBUTES = googObject.createSet(
    'action', 'cite', 'data', 'formaction', 'href', 'manifest', 'poster',
    'src');


/**
 * Tags which are unsupported via create(). They might be supported via a
 * tag-specific create method. These are tags which might require a
 * TrustedResourceUrl in one of their attributes or a restricted type for
 * their content.
 * @const {!Object<string,boolean>}
 */
const NOT_ALLOWED_TAG_NAMES = googObject.createSet(
    TagName.APPLET, TagName.BASE, TagName.EMBED, TagName.IFRAME, TagName.LINK,
    TagName.MATH, TagName.META, TagName.OBJECT, TagName.SCRIPT, TagName.STYLE,
    TagName.SVG, TagName.TEMPLATE);


/**
 * @typedef {string|number|!TypedString|
 *     !SafeStyle.PropertyMap|undefined|null}
 */
SafeHtml.AttributeValue;


/**
 * @param {string} tagName The tag name.
 * @param {string} name The attribute name.
 * @param {!SafeHtml.AttributeValue} value The attribute value.
 * @return {string} A "name=value" string.
 * @throws {!Error} If attribute value is unsafe for the given tag and
 *     attribute.
 * @private
 */
function getAttrNameAndValue(tagName, name, value) {
  // If it's goog.string.Const, allow any valid attribute name.
  if (value instanceof Const) {
    value = Const.unwrap(value);
  } else if (name.toLowerCase() == 'style') {
    if (SafeHtml.SUPPORT_STYLE_ATTRIBUTE) {
      value = getStyleValue(value);
    } else {
      throw new Error(
          SafeHtml.ENABLE_ERROR_MESSAGES ? 'Attribute "style" not supported.' :
                                           '');
    }
  } else if (/^on/i.test(name)) {
    // TODO(jakubvrana): Disallow more attributes with a special meaning.
    throw new Error(
        SafeHtml.ENABLE_ERROR_MESSAGES ? `Attribute "${name}` +
                '" requires goog.string.Const value, "' + value + '" given.' :
                                         '');
    // URL attributes handled differently according to tag.
  } else if (name.toLowerCase() in URL_ATTRIBUTES) {
    if (value instanceof TrustedResourceUrl) {
      value = TrustedResourceUrl.unwrap(value);
    } else if (value instanceof SafeUrl) {
      value = SafeUrl.unwrap(value);
    } else if (typeof value === 'string') {
      value = SafeUrl.sanitize(value).getTypedStringValue();
    } else {
      throw new Error(
          SafeHtml.ENABLE_ERROR_MESSAGES ?
              `Attribute "${name}" on tag "${tagName}` +
                  '" requires goog.html.SafeUrl, goog.string.Const, or' +
                  ' string, value "' + value + '" given.' :
              '');
    }
  }

  // Accept SafeUrl, TrustedResourceUrl, etc. for attributes which only require
  // HTML-escaping.
  if (/** @type {?} */ (value).implementsGoogStringTypedString) {
    // Ok to call getTypedStringValue() since there's no reliance on the type
    // contract for security here.
    value =
        /** @type {!TypedString} */ (value).getTypedStringValue();
  }

  asserts.assert(
      typeof value === 'string' || typeof value === 'number',
      'String or number value expected, got ' + (typeof value) +
          ' with value: ' + value);
  return `${name}="` + internal.htmlEscape(String(value)) + '"';
}


/**
 * Gets value allowed in "style" attribute.
 * @param {!SafeHtml.AttributeValue} value It could be SafeStyle or a
 *     map which will be passed to SafeStyle.create.
 * @return {string} Unwrapped value.
 * @throws {!Error} If string value is given.
 * @private
 */
function getStyleValue(value) {
  if (!goog.isObject(value)) {
    throw new Error(
        SafeHtml.ENABLE_ERROR_MESSAGES ?
            'The "style" attribute requires goog.html.SafeStyle or map ' +
                'of style properties, ' + (typeof value) + ' given: ' + value :
            '');
  }
  if (!(value instanceof SafeStyle)) {
    // Process the property bag into a style object.
    value = SafeStyle.create(value);
  }
  return SafeStyle.unwrap(value);
}


/**
 * A SafeHtml instance corresponding to the HTML doctype: "<!DOCTYPE html>".
 * @const {!SafeHtml}
 */
SafeHtml.DOCTYPE_HTML = /** @type {!SafeHtml} */ ({
  // NOTE: this compiles to nothing, but hides the possible side effect of
  // SafeHtml creation (due to calling trustedTypes.createPolicy) from the
  // compiler so that the entire call can be removed if the result is not used.
  // MOE:begin_strip
  // TODO(b/155299094): Refactor after adding compiler support.
  // MOE:end_strip
  valueOf: function() {
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse(
        '<!DOCTYPE html>');
  },
}.valueOf());

/**
 * A SafeHtml instance corresponding to the empty string.
 * @const {!SafeHtml}
 */
SafeHtml.EMPTY = new SafeHtml(
    (goog.global.trustedTypes && goog.global.trustedTypes.emptyHTML) || '',
    CONSTRUCTOR_TOKEN_PRIVATE);

/**
 * A SafeHtml instance corresponding to the <br> tag.
 * @const {!SafeHtml}
 */
SafeHtml.BR = /** @type {!SafeHtml} */ ({
  // NOTE: this compiles to nothing, but hides the possible side effect of
  // SafeHtml creation (due to calling trustedTypes.createPolicy) from the
  // compiler so that the entire call can be removed if the result is not used.
  // MOE:begin_strip
  // TODO(b/155299094): Refactor after adding compiler support.
  // MOE:end_strip
  valueOf: function() {
    return SafeHtml.createSafeHtmlSecurityPrivateDoNotAccessOrElse('<br>');
  },
}.valueOf());


exports = SafeHtml;

;return exports;});

//third_party/javascript/angular/v1_6/goog_hardening/closureSceHelper.js
/**
 * @fileoverview Collection of helpers that link the Angular hardened build to
 *    the Closure goog.html types. This should be compiled alongside Closure,
 *    so that the functions defined here can be called in the hardened Angular
 *    {@code $sce} service.
 *
 * MOE:begin_intracomment_strip
 * @see go/angular-v15-migrate#dependency
 * MOE:end_intracomment_strip
 */

// MOE:begin_strip
// There is no goog.provide to keep JSCompiler from dead-code removing this.
// See http://google3/third_party/java_src/jscomp/java/com/google/javascript/jscomp/JSCompilerRunner.java&l=255&rcl=112285511
// Adding @license_presubmit_check_bypass (this helper is not open source).
// MOE:end_strip

goog.require('goog.html.SafeHtml');
goog.require('goog.html.SafeScript');
goog.require('goog.html.SafeStyle');
goog.require('goog.html.SafeUrl');
goog.require('goog.html.TrustedResourceUrl');


goog.exportSymbol(
    'ng.safehtml.googSceHelper.isGoogHtmlType',

    /**
     * @param {?} value
     * @return {*} true if value is a goog.html type.
     * @public
     */
    function isGoogHtmlType(value) {
      if (value && value.implementsGoogStringTypedString) {
        return true;
      } else {
        return false;
      }
    });

goog.exportSymbol(
    'ng.safehtml.googSceHelper.isCOMPILED',
    /**
     * @return {boolean} the value of COMPILED.
     * @public
     */
    function isCOMPILED() {
      return COMPILED;
    });

goog.exportSymbol(
    'ng.safehtml.googSceHelper.unwrapAny',
    /**
     * Unwraps the value given as a parameter, if it is a goog.html type.
     * Otherwise, returns the parameter. Note that this function will not try to
     * unwrap stock {@code $sce.trustAs} results, and that even though Angular
     * trusts by default  `null`, `undefined` and '', Closure does
     * not, so this function will throw on these values since they are not
     * `goog.html` types.
     * @param {*} value
     * @return {*} An unwrapped version of `value`.
     * @throws {!Error} If the value not of a type among the `goog.html`
     * supported types.
     * @public
     */
    function valueOf(value) {
      if (value instanceof goog.html.TrustedResourceUrl) {
        return goog.html.TrustedResourceUrl.unwrap(value);
      } else if (value instanceof goog.html.SafeHtml) {
        return goog.html.SafeHtml.unwrap(value);
      } else if (value instanceof goog.html.SafeUrl) {
        return goog.html.SafeUrl.unwrap(value);
      } else if (value instanceof goog.html.SafeStyle) {
        return goog.html.SafeStyle.unwrap(value);
      } else if (value instanceof goog.html.SafeScript) {
        return goog.html.SafeScript.unwrap(value);
      } else {
        throw new Error();  // should be caught by Angular
      }
    });

goog.exportSymbol(
    'ng.safehtml.googSceHelper.unwrapGivenContext',
    /**
     * Try to unwrap `maybeTrusted` as a `goog.html` type for {@code
     * type}, then return the value or throw if it failed.
     *
     * @param {string} type Either 'url', 'resourceUrl', 'html', 'js' or 'css'.
     * @param {!goog.html.SafeHtml|!goog.html.SafeUrl|
               !goog.html.TrustedResourceUrl|!goog.html.SafeScript|
               !goog.html.SafeStyle} maybeTrusted Instance of a goog.html type.
     * @return {string} `maybeTrusted` unwrapped to string.
     * @throws {!Error} If maybeTrusted cannot be unwrapped in the given context.
     * @public
     */
    function unwrapGivenContext(type, maybeTrusted) {
      // TODO(rjamet): Is there any good way to get to constants defined
      // in $sce? It seems like we'd need a circular dependency for that.
      if (type == 'html') {  // $sce.HTML
        return goog.html.SafeHtml.unwrap(
            /** @type {!goog.html.SafeHtml} */ (maybeTrusted));
      } else if (type == 'resourceUrl' || type == 'templateUrl') {
        // either $sce.RESOURCE_URL or our new $sce.TEMPLATE_URL
        return goog.html.TrustedResourceUrl.unwrap(
            /** @type {!goog.html.TrustedResourceUrl} */ (maybeTrusted));
      } else if (type == 'url') {  // $sce.URL
        // Angular allows $sce.RESOURCE_URL wherever $sce.URL is allowed.
        if (maybeTrusted instanceof goog.html.TrustedResourceUrl) {
          return goog.html.TrustedResourceUrl.unwrap(maybeTrusted);
        }  // Else assume it's a SafeUrl
        return goog.html.SafeUrl.unwrap(
            /** @type {!goog.html.SafeUrl} */ (maybeTrusted));
      } else if (type == 'css') {  // $sce.CSS
        return goog.html.SafeStyle.unwrap(
            /** @type {!goog.html.SafeStyle} */ (maybeTrusted));
      } else if (type == 'js') {  // $sce.JS
        return goog.html.SafeScript.unwrap(
            /** @type {!goog.html.SafeScript} */ (maybeTrusted));
      }
      throw new Error();  // should be caught by Angular
    });

//third_party/javascript/angular_ui/bootstrap/ui_bootstrap_min_0_13_2.js
/**
 * @license
 * The MIT License
 * 
 * Copyright (c) 2012-2013 the AngularUI Team, https://github.com/organizations/angular-ui/teams/291112
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/*
 * @license
 * angular-ui-bootstrap
 * http://angular-ui.github.io/bootstrap/

 * Version: 0.13.2 - 2015-08-05
 * License: MIT
 */
angular.module("ui.bootstrap",["ui.bootstrap.collapse","ui.bootstrap.accordion","ui.bootstrap.alert","ui.bootstrap.bindHtml","ui.bootstrap.buttons","ui.bootstrap.carousel","ui.bootstrap.dateparser","ui.bootstrap.position","ui.bootstrap.datepicker","ui.bootstrap.dropdown","ui.bootstrap.modal","ui.bootstrap.pagination","ui.bootstrap.tooltip","ui.bootstrap.popover","ui.bootstrap.progressbar","ui.bootstrap.rating","ui.bootstrap.tabs","ui.bootstrap.timepicker","ui.bootstrap.transition","ui.bootstrap.typeahead"]),angular.module("ui.bootstrap.collapse",[]).directive("collapse",["$animate",function(a){return{link:function(b,c,d){function e(){c.removeClass("collapse").addClass("collapsing").attr("aria-expanded",!0).attr("aria-hidden",!1),a.addClass(c,"in",{to:{height:c[0].scrollHeight+"px"}}).then(f)}function f(){c.removeClass("collapsing"),c.css({height:"auto"})}function g(){return c.hasClass("collapse")||c.hasClass("in")?(c.css({height:c[0].scrollHeight+"px"}).removeClass("collapse").addClass("collapsing").attr("aria-expanded",!1).attr("aria-hidden",!0),void a.removeClass(c,"in",{to:{height:"0"}}).then(h)):h()}function h(){c.css({height:"0"}),c.removeClass("collapsing"),c.addClass("collapse")}b.$watch(d.collapse,function(a){a?g():e()})}}}]),angular.module("ui.bootstrap.accordion",["ui.bootstrap.collapse"]).constant("accordionConfig",{closeOthers:!0}).controller("AccordionController",["$scope","$attrs","accordionConfig",function(a,b,c){this.groups=[],this.closeOthers=function(d){var e=angular.isDefined(b.closeOthers)?a.$eval(b.closeOthers):c.closeOthers;e&&angular.forEach(this.groups,function(a){a!==d&&(a.isOpen=!1)})},this.addGroup=function(a){var b=this;this.groups.push(a),a.$on("$destroy",function(){b.removeGroup(a)})},this.removeGroup=function(a){var b=this.groups.indexOf(a);-1!==b&&this.groups.splice(b,1)}}]).directive("accordion",function(){return{restrict:"EA",controller:"AccordionController",transclude:!0,replace:!1,templateUrl:"template/accordion/accordion.html"}}).directive("accordionGroup",function(){return{require:"^accordion",restrict:"EA",transclude:!0,replace:!0,templateUrl:"template/accordion/accordion-group.html",scope:{heading:"@",isOpen:"=?",isDisabled:"=?"},controller:function(){this.setHeading=function(a){this.heading=a}},link:function(a,b,c,d){d.addGroup(a),a.$watch("isOpen",function(b){b&&d.closeOthers(a)}),a.toggleOpen=function(){a.isDisabled||(a.isOpen=!a.isOpen)}}}}).directive("accordionHeading",function(){return{restrict:"EA",transclude:!0,template:"",replace:!0,require:"^accordionGroup",link:function(a,b,c,d,e){d.setHeading(e(a,angular.noop))}}}).directive("accordionTransclude",function(){return{require:"^accordionGroup",link:function(a,b,c,d){a.$watch(function(){return d[c.accordionTransclude]},function(a){a&&(b.find("span").html(""),b.find("span").append(a))})}}}),angular.module("ui.bootstrap.alert",[]).controller("AlertController",["$scope","$attrs",function(a,b){a.closeable=!!b.close,this.close=a.close}]).directive("alert",function(){return{restrict:"EA",controller:"AlertController",templateUrl:"template/alert/alert.html",transclude:!0,replace:!0,scope:{type:"@",close:"&"}}}).directive("dismissOnTimeout",["$timeout",function(a){return{require:"alert",link:function(b,c,d,e){a(function(){e.close()},parseInt(d.dismissOnTimeout,10))}}}]),angular.module("ui.bootstrap.bindHtml",[]).value("$bindHtmlUnsafeSuppressDeprecated",!1).directive("bindHtmlUnsafe",["$log","$bindHtmlUnsafeSuppressDeprecated",function(a,b){return function(c,d,e){b||a.warn("bindHtmlUnsafe is now deprecated. Use ngBindHtml instead"),d.addClass("ng-binding").data("$binding",e.bindHtmlUnsafe),c.$watch(e.bindHtmlUnsafe,function(a){d.html(a||"")})}}]),angular.module("ui.bootstrap.buttons",[]).constant("buttonConfig",{activeClass:"active",toggleEvent:"click"}).controller("ButtonsController",["buttonConfig",function(a){this.activeClass=a.activeClass||"active",this.toggleEvent=a.toggleEvent||"click"}]).directive("btnRadio",function(){return{require:["btnRadio","ngModel"],controller:"ButtonsController",link:function(a,b,c,d){var e=d[0],f=d[1];f.$render=function(){b.toggleClass(e.activeClass,angular.equals(f.$modelValue,a.$eval(c.btnRadio)))},b.bind(e.toggleEvent,function(){if(!("disabled"in c)){var d=b.hasClass(e.activeClass);(!d||angular.isDefined(c.uncheckable))&&a.$apply(function(){f.$setViewValue(d?null:a.$eval(c.btnRadio)),f.$render()})}})}}}).directive("btnCheckbox",function(){return{require:["btnCheckbox","ngModel"],controller:"ButtonsController",link:function(a,b,c,d){function e(){return g(c.btnCheckboxTrue,!0)}function f(){return g(c.btnCheckboxFalse,!1)}function g(b,c){var d=a.$eval(b);return angular.isDefined(d)?d:c}var h=d[0],i=d[1];i.$render=function(){b.toggleClass(h.activeClass,angular.equals(i.$modelValue,e()))},b.bind(h.toggleEvent,function(){"disabled"in c||a.$apply(function(){i.$setViewValue(b.hasClass(h.activeClass)?f():e()),i.$render()})})}}}),angular.module("ui.bootstrap.carousel",[]).constant("ANIMATE_CSS",angular.version.minor>=4).controller("CarouselController",["$scope","$element","$interval","$animate","ANIMATE_CSS",function(a,b,c,d,e){function f(b,c,f){r||(angular.extend(b,{direction:f,active:!0}),angular.extend(m.currentSlide||{},{direction:f,active:!1}),d.enabled()&&!a.noTransition&&!a.$currentTransition&&b.$element&&(b.$element.data(p,b.direction),a.$currentTransition=!0,e?d.on("addClass",b.$element,function(b){a.$currentTransition=null,a.$currentTransition||d.off("addClass",b)}):b.$element.one("$animate:close",function(){a.$currentTransition=null})),m.currentSlide=b,q=c,h())}function g(a){if(angular.isUndefined(n[a].index))return n[a];{var b;n.length}for(b=0;b<n.length;++b)if(n[b].index==a)return n[b]}function h(){i();var b=+a.interval;!isNaN(b)&&b>0&&(k=c(j,b))}function i(){k&&(c.cancel(k),k=null)}function j(){var b=+a.interval;l&&!isNaN(b)&&b>0&&n.length?a.next():a.pause()}var k,l,m=this,n=m.slides=a.slides=[],o="uib-noTransition",p="uib-slideDirection",q=-1;m.currentSlide=null;var r=!1;m.select=a.select=function(b,c){var d=m.indexOfSlide(b);void 0===c&&(c=d>m.getCurrentIndex()?"next":"prev"),b&&b!==m.currentSlide&&!a.$currentTransition&&f(b,d,c)},a.$on("$destroy",function(){r=!0}),m.getCurrentIndex=function(){return m.currentSlide&&angular.isDefined(m.currentSlide.index)?+m.currentSlide.index:q},m.indexOfSlide=function(a){return angular.isDefined(a.index)?+a.index:n.indexOf(a)},a.next=function(){var b=(m.getCurrentIndex()+1)%n.length;return 0===b&&a.noWrap()?void a.pause():m.select(g(b),"next")},a.prev=function(){var b=m.getCurrentIndex()-1<0?n.length-1:m.getCurrentIndex()-1;return a.noWrap()&&b===n.length-1?void a.pause():m.select(g(b),"prev")},a.isActive=function(a){return m.currentSlide===a},a.$watch("interval",h),a.$on("$destroy",i),a.play=function(){l||(l=!0,h())},a.pause=function(){a.noPause||(l=!1,i())},m.addSlide=function(b,c){!n.length&&c&&c.data(p,"next"),b.$element=c,n.push(b),1===n.length||b.active?(m.select(n[n.length-1]),1==n.length&&a.play()):b.active=!1},m.removeSlide=function(a){angular.isDefined(a.index)&&n.sort(function(a,b){return+a.index>+b.index});var b=n.indexOf(a);n.splice(b,1),n.length>0&&a.active?m.select(b>=n.length?n[b-1]:n[b]):q>b&&q--,0===n.length&&(m.currentSlide=null)},a.$watch("noTransition",function(a){b.data(o,a)})}]).directive("carousel",[function(){return{restrict:"EA",transclude:!0,replace:!0,controller:"CarouselController",require:"carousel",templateUrl:"template/carousel/carousel.html",scope:{interval:"=",noTransition:"=",noPause:"=",noWrap:"&"}}}]).directive("slide",function(){return{require:"^carousel",restrict:"EA",transclude:!0,replace:!0,templateUrl:"template/carousel/slide.html",scope:{active:"=?",index:"=?"},link:function(a,b,c,d){d.addSlide(a,b),a.$on("$destroy",function(){d.removeSlide(a)}),a.$watch("active",function(b){b&&d.select(a)})}}}).animation(".item",["$injector","$animate","ANIMATE_CSS",function(a,b,c){function d(a,b,c){a.removeClass(b),c&&c()}var e="uib-noTransition",f="uib-slideDirection",g=c?a.get("$animateCss"):null;return{beforeAddClass:function(a,c,h){if("active"==c&&a.parent()&&!a.parent().data(e)){var i=!1,j=a.data(f),k="next"==j?"left":"right",l=d.bind(this,a,k+" "+j,h);return a.addClass(j),g?g(a,{addClass:k}).start().done(l):b.addClass(a,k).then(function(){i||l(),h()}),function(){i=!0}}h()},beforeRemoveClass:function(a,c,h){if("active"===c&&a.parent()&&!a.parent().data(e)){var i=!1,j=a.data(f),k="next"==j?"left":"right",l=d.bind(this,a,k,h);return g?g(a,{addClass:k}).start().done(l):b.addClass(a,k).then(function(){i||l(),h()}),function(){i=!0}}h()}}}]),angular.module("ui.bootstrap.dateparser",[]).service("dateParser",["$log","$locale","orderByFilter",function(a,b,c){function d(a){var b=[],d=a.split("");return angular.forEach(g,function(c,e){var f=a.indexOf(e);if(f>-1){a=a.split(""),d[f]="("+c.regex+")",a[f]="$";for(var g=f+1,h=f+e.length;h>g;g++)d[g]="",a[g]="$";a=a.join(""),b.push({index:f,apply:c.apply})}}),{regex:new RegExp("^"+d.join("")+"$"),map:c(b,"index")}}function e(a,b,c){return 1>c?!1:1===b&&c>28?29===c&&(a%4===0&&a%100!==0||a%400===0):3===b||5===b||8===b||10===b?31>c:!0}var f=/[\\\^\$\*\+\?\|\[\]\(\)\.\{\}]/g;this.parsers={};var g={yyyy:{regex:"\\d{4}",apply:function(a){this.year=+a}},yy:{regex:"\\d{2}",apply:function(a){this.year=+a+2e3}},y:{regex:"\\d{1,4}",apply:function(a){this.year=+a}},MMMM:{regex:b.DATETIME_FORMATS.MONTH.join("|"),apply:function(a){this.month=b.DATETIME_FORMATS.MONTH.indexOf(a)}},MMM:{regex:b.DATETIME_FORMATS.SHORTMONTH.join("|"),apply:function(a){this.month=b.DATETIME_FORMATS.SHORTMONTH.indexOf(a)}},MM:{regex:"0[1-9]|1[0-2]",apply:function(a){this.month=a-1}},M:{regex:"[1-9]|1[0-2]",apply:function(a){this.month=a-1}},dd:{regex:"[0-2][0-9]{1}|3[0-1]{1}",apply:function(a){this.date=+a}},d:{regex:"[1-2]?[0-9]{1}|3[0-1]{1}",apply:function(a){this.date=+a}},EEEE:{regex:b.DATETIME_FORMATS.DAY.join("|")},EEE:{regex:b.DATETIME_FORMATS.SHORTDAY.join("|")},HH:{regex:"(?:0|1)[0-9]|2[0-3]",apply:function(a){this.hours=+a}},H:{regex:"1?[0-9]|2[0-3]",apply:function(a){this.hours=+a}},mm:{regex:"[0-5][0-9]",apply:function(a){this.minutes=+a}},m:{regex:"[0-9]|[1-5][0-9]",apply:function(a){this.minutes=+a}},sss:{regex:"[0-9][0-9][0-9]",apply:function(a){this.milliseconds=+a}},ss:{regex:"[0-5][0-9]",apply:function(a){this.seconds=+a}},s:{regex:"[0-9]|[1-5][0-9]",apply:function(a){this.seconds=+a}}};this.parse=function(c,g,h){if(!angular.isString(c)||!g)return c;g=b.DATETIME_FORMATS[g]||g,g=g.replace(f,"\\$&"),this.parsers[g]||(this.parsers[g]=d(g));var i=this.parsers[g],j=i.regex,k=i.map,l=c.match(j);if(l&&l.length){var m,n;angular.isDate(h)&&!isNaN(h.getTime())?m={year:h.getFullYear(),month:h.getMonth(),date:h.getDate(),hours:h.getHours(),minutes:h.getMinutes(),seconds:h.getSeconds(),milliseconds:h.getMilliseconds()}:(h&&a.warn("dateparser:","baseDate is not a valid date"),m={year:1900,month:0,date:1,hours:0,minutes:0,seconds:0,milliseconds:0});for(var o=1,p=l.length;p>o;o++){var q=k[o-1];q.apply&&q.apply.call(m,l[o])}return e(m.year,m.month,m.date)&&(n=new Date(m.year,m.month,m.date,m.hours,m.minutes,m.seconds,m.milliseconds||0)),n}}}]),angular.module("ui.bootstrap.position",[]).factory("$position",["$document","$window",function(a,b){function c(a,c){return a.currentStyle?a.currentStyle[c]:b.getComputedStyle?b.getComputedStyle(a)[c]:a.style[c]}function d(a){return"static"===(c(a,"position")||"static")}var e=function(b){for(var c=a[0],e=b.offsetParent||c;e&&e!==c&&d(e);)e=e.offsetParent;return e||c};return{position:function(b){var c=this.offset(b),d={top:0,left:0},f=e(b[0]);f!=a[0]&&(d=this.offset(angular.element(f)),d.top+=f.clientTop-f.scrollTop,d.left+=f.clientLeft-f.scrollLeft);var g=b[0].getBoundingClientRect();return{width:g.width||b.prop("offsetWidth"),height:g.height||b.prop("offsetHeight"),top:c.top-d.top,left:c.left-d.left}},offset:function(c){var d=c[0].getBoundingClientRect();return{width:d.width||c.prop("offsetWidth"),height:d.height||c.prop("offsetHeight"),top:d.top+(b.pageYOffset||a[0].documentElement.scrollTop),left:d.left+(b.pageXOffset||a[0].documentElement.scrollLeft)}},positionElements:function(a,b,c,d){var e,f,g,h,i=c.split("-"),j=i[0],k=i[1]||"center";e=d?this.offset(a):this.position(a),f=b.prop("offsetWidth"),g=b.prop("offsetHeight");var l={center:function(){return e.left+e.width/2-f/2},left:function(){return e.left},right:function(){return e.left+e.width}},m={center:function(){return e.top+e.height/2-g/2},top:function(){return e.top},bottom:function(){return e.top+e.height}};switch(j){case"right":h={top:m[k](),left:l[j]()};break;case"left":h={top:m[k](),left:e.left-f};break;case"bottom":h={top:m[j](),left:l[k]()};break;default:h={top:e.top-g,left:l[k]()}}return h}}}]),angular.module("ui.bootstrap.datepicker",["ui.bootstrap.dateparser","ui.bootstrap.position"]).constant("datepickerConfig",{formatDay:"dd",formatMonth:"MMMM",formatYear:"yyyy",formatDayHeader:"EEE",formatDayTitle:"MMMM yyyy",formatMonthTitle:"yyyy",datepickerMode:"day",minMode:"day",maxMode:"year",showWeeks:!0,startingDay:0,yearRange:20,minDate:null,maxDate:null,shortcutPropagation:!1}).controller("DatepickerController",["$scope","$attrs","$parse","$interpolate","$log","dateFilter","datepickerConfig",function(a,b,c,d,e,f,g){var h=this,i={$setViewValue:angular.noop};this.modes=["day","month","year"],angular.forEach(["formatDay","formatMonth","formatYear","formatDayHeader","formatDayTitle","formatMonthTitle","minMode","maxMode","showWeeks","startingDay","yearRange","shortcutPropagation"],function(c,e){h[c]=angular.isDefined(b[c])?8>e?d(b[c])(a.$parent):a.$parent.$eval(b[c]):g[c]}),angular.forEach(["minDate","maxDate"],function(d){b[d]?a.$parent.$watch(c(b[d]),function(a){h[d]=a?new Date(a):null,h.refreshView()}):h[d]=g[d]?new Date(g[d]):null}),a.datepickerMode=a.datepickerMode||g.datepickerMode,a.maxMode=h.maxMode,a.uniqueId="datepicker-"+a.$id+"-"+Math.floor(1e4*Math.random()),angular.isDefined(b.initDate)?(this.activeDate=a.$parent.$eval(b.initDate)||new Date,a.$parent.$watch(b.initDate,function(a){a&&(i.$isEmpty(i.$modelValue)||i.$invalid)&&(h.activeDate=a,h.refreshView())})):this.activeDate=new Date,a.isActive=function(b){return 0===h.compare(b.date,h.activeDate)?(a.activeDateId=b.uid,!0):!1},this.init=function(a){i=a,i.$render=function(){h.render()}},this.render=function(){if(i.$viewValue){var a=new Date(i.$viewValue),b=!isNaN(a);b?this.activeDate=a:e.error('Datepicker directive: "ng-model" value must be a Date object, a number of milliseconds since 01.01.1970 or a string representing an RFC2822 or ISO 8601 date.')}this.refreshView()},this.refreshView=function(){if(this.element){this._refreshView();var a=i.$viewValue?new Date(i.$viewValue):null;i.$setValidity("date-disabled",!a||this.element&&!this.isDisabled(a))}},this.createDateObject=function(a,b){var c=i.$viewValue?new Date(i.$viewValue):null;return{date:a,label:f(a,b),selected:c&&0===this.compare(a,c),disabled:this.isDisabled(a),current:0===this.compare(a,new Date),customClass:this.customClass(a)}},this.isDisabled=function(c){return this.minDate&&this.compare(c,this.minDate)<0||this.maxDate&&this.compare(c,this.maxDate)>0||b.dateDisabled&&a.dateDisabled({date:c,mode:a.datepickerMode})},this.customClass=function(b){return a.customClass({date:b,mode:a.datepickerMode})},this.split=function(a,b){for(var c=[];a.length>0;)c.push(a.splice(0,b));return c},this.fixTimeZone=function(a){var b=a.getHours();a.setHours(23===b?b+2:0)},a.select=function(b){if(a.datepickerMode===h.minMode){var c=i.$viewValue?new Date(i.$viewValue):new Date(0,0,0,0,0,0,0);c.setFullYear(b.getFullYear(),b.getMonth(),b.getDate()),i.$setViewValue(c),i.$render()}else h.activeDate=b,a.datepickerMode=h.modes[h.modes.indexOf(a.datepickerMode)-1]},a.move=function(a){var b=h.activeDate.getFullYear()+a*(h.step.years||0),c=h.activeDate.getMonth()+a*(h.step.months||0);h.activeDate.setFullYear(b,c,1),h.refreshView()},a.toggleMode=function(b){b=b||1,a.datepickerMode===h.maxMode&&1===b||a.datepickerMode===h.minMode&&-1===b||(a.datepickerMode=h.modes[h.modes.indexOf(a.datepickerMode)+b])},a.keys={13:"enter",32:"space",33:"pageup",34:"pagedown",35:"end",36:"home",37:"left",38:"up",39:"right",40:"down"};var j=function(){h.element[0].focus()};a.$on("datepicker.focus",j),a.keydown=function(b){var c=a.keys[b.which];if(c&&!b.shiftKey&&!b.altKey)if(b.preventDefault(),h.shortcutPropagation||b.stopPropagation(),"enter"===c||"space"===c){if(h.isDisabled(h.activeDate))return;a.select(h.activeDate),j()}else!b.ctrlKey||"up"!==c&&"down"!==c?(h.handleKeyDown(c,b),h.refreshView()):(a.toggleMode("up"===c?1:-1),j())}}]).directive("datepicker",function(){return{restrict:"EA",replace:!0,templateUrl:"template/datepicker/datepicker.html",scope:{datepickerMode:"=?",dateDisabled:"&",customClass:"&",shortcutPropagation:"&?"},require:["datepicker","?^ngModel"],controller:"DatepickerController",link:function(a,b,c,d){var e=d[0],f=d[1];f&&e.init(f)}}}).directive("daypicker",["dateFilter",function(a){return{restrict:"EA",replace:!0,templateUrl:"template/datepicker/day.html",require:"^datepicker",link:function(b,c,d,e){function f(a,b){return 1!==b||a%4!==0||a%100===0&&a%400!==0?i[b]:29}function g(a,b){for(var c,d=new Array(b),f=new Date(a),g=0;b>g;)c=new Date(f),e.fixTimeZone(c),d[g++]=c,f.setDate(f.getDate()+1);return d}function h(a){var b=new Date(a);b.setDate(b.getDate()+4-(b.getDay()||7));var c=b.getTime();return b.setMonth(0),b.setDate(1),Math.floor(Math.round((c-b)/864e5)/7)+1}b.showWeeks=e.showWeeks,e.step={months:1},e.element=c;var i=[31,28,31,30,31,30,31,31,30,31,30,31];e._refreshView=function(){var c=e.activeDate.getFullYear(),d=e.activeDate.getMonth(),f=new Date(c,d,1),i=e.startingDay-f.getDay(),j=i>0?7-i:-i,k=new Date(f);j>0&&k.setDate(-j+1);for(var l=g(k,42),m=0;42>m;m++)l[m]=angular.extend(e.createDateObject(l[m],e.formatDay),{secondary:l[m].getMonth()!==d,uid:b.uniqueId+"-"+m});b.labels=new Array(7);for(var n=0;7>n;n++)b.labels[n]={abbr:a(l[n].date,e.formatDayHeader),full:a(l[n].date,"EEEE")};if(b.title=a(e.activeDate,e.formatDayTitle),b.rows=e.split(l,7),b.showWeeks){b.weekNumbers=[];for(var o=(11-e.startingDay)%7,p=b.rows.length,q=0;p>q;q++)b.weekNumbers.push(h(b.rows[q][o].date))}},e.compare=function(a,b){return new Date(a.getFullYear(),a.getMonth(),a.getDate())-new Date(b.getFullYear(),b.getMonth(),b.getDate())},e.handleKeyDown=function(a){var b=e.activeDate.getDate();if("left"===a)b-=1;else if("up"===a)b-=7;else if("right"===a)b+=1;else if("down"===a)b+=7;else if("pageup"===a||"pagedown"===a){var c=e.activeDate.getMonth()+("pageup"===a?-1:1);e.activeDate.setMonth(c,1),b=Math.min(f(e.activeDate.getFullYear(),e.activeDate.getMonth()),b)}else"home"===a?b=1:"end"===a&&(b=f(e.activeDate.getFullYear(),e.activeDate.getMonth()));e.activeDate.setDate(b)},e.refreshView()}}}]).directive("monthpicker",["dateFilter",function(a){return{restrict:"EA",replace:!0,templateUrl:"template/datepicker/month.html",require:"^datepicker",link:function(b,c,d,e){e.step={years:1},e.element=c,e._refreshView=function(){for(var c,d=new Array(12),f=e.activeDate.getFullYear(),g=0;12>g;g++)c=new Date(f,g,1),e.fixTimeZone(c),d[g]=angular.extend(e.createDateObject(c,e.formatMonth),{uid:b.uniqueId+"-"+g});b.title=a(e.activeDate,e.formatMonthTitle),b.rows=e.split(d,3)},e.compare=function(a,b){return new Date(a.getFullYear(),a.getMonth())-new Date(b.getFullYear(),b.getMonth())},e.handleKeyDown=function(a){var b=e.activeDate.getMonth();if("left"===a)b-=1;else if("up"===a)b-=3;else if("right"===a)b+=1;else if("down"===a)b+=3;else if("pageup"===a||"pagedown"===a){var c=e.activeDate.getFullYear()+("pageup"===a?-1:1);e.activeDate.setFullYear(c)}else"home"===a?b=0:"end"===a&&(b=11);e.activeDate.setMonth(b)},e.refreshView()}}}]).directive("yearpicker",["dateFilter",function(){return{restrict:"EA",replace:!0,templateUrl:"template/datepicker/year.html",require:"^datepicker",link:function(a,b,c,d){function e(a){return parseInt((a-1)/f,10)*f+1}var f=d.yearRange;d.step={years:f},d.element=b,d._refreshView=function(){for(var b,c=new Array(f),g=0,h=e(d.activeDate.getFullYear());f>g;g++)b=new Date(h+g,0,1),d.fixTimeZone(b),c[g]=angular.extend(d.createDateObject(b,d.formatYear),{uid:a.uniqueId+"-"+g});a.title=[c[0].label,c[f-1].label].join(" - "),a.rows=d.split(c,5)},d.compare=function(a,b){return a.getFullYear()-b.getFullYear()},d.handleKeyDown=function(a){var b=d.activeDate.getFullYear();"left"===a?b-=1:"up"===a?b-=5:"right"===a?b+=1:"down"===a?b+=5:"pageup"===a||"pagedown"===a?b+=("pageup"===a?-1:1)*d.step.years:"home"===a?b=e(d.activeDate.getFullYear()):"end"===a&&(b=e(d.activeDate.getFullYear())+f-1),d.activeDate.setFullYear(b)},d.refreshView()}}}]).constant("datepickerPopupConfig",{datepickerPopup:"yyyy-MM-dd",html5Types:{date:"yyyy-MM-dd","datetime-local":"yyyy-MM-ddTHH:mm:ss.sss",month:"yyyy-MM"},currentText:"Today",clearText:"Clear",closeText:"Done",closeOnDateSelection:!0,appendToBody:!1,showButtonBar:!0}).directive("datepickerPopup",["$compile","$parse","$document","$position","dateFilter","dateParser","datepickerPopupConfig","$timeout",function(a,b,c,d,e,f,g,h){return{restrict:"EA",require:"ngModel",scope:{isOpen:"=?",currentText:"@",clearText:"@",closeText:"@",dateDisabled:"&",customClass:"&"},link:function(i,j,k,l){function m(a){return a.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()})}function n(a){if(angular.isNumber(a)&&(a=new Date(a)),a){if(angular.isDate(a)&&!isNaN(a))return a;if(angular.isString(a)){var b=f.parse(a,p,i.date);return isNaN(b)?void 0:b}return void 0}return null}function o(a,b){var c=a||b;if(!k.ngRequired&&!c)return!0;if(angular.isNumber(c)&&(c=new Date(c)),c){if(angular.isDate(c)&&!isNaN(c))return!0;if(angular.isString(c)){var d=f.parse(c,p);return!isNaN(d)}return!1}return!0}var p,q=angular.isDefined(k.closeOnDateSelection)?i.$parent.$eval(k.closeOnDateSelection):g.closeOnDateSelection,r=angular.isDefined(k.datepickerAppendToBody)?i.$parent.$eval(k.datepickerAppendToBody):g.appendToBody;i.showButtonBar=angular.isDefined(k.showButtonBar)?i.$parent.$eval(k.showButtonBar):g.showButtonBar,i.getText=function(a){return i[a+"Text"]||g[a+"Text"]};var s=!1;if(g.html5Types[k.type]?(p=g.html5Types[k.type],s=!0):(p=k.datepickerPopup||g.datepickerPopup,k.$observe("datepickerPopup",function(a){var b=a||g.datepickerPopup;if(b!==p&&(p=b,l.$modelValue=null,!p))throw new Error("datepickerPopup must have a date format specified.")})),!p)throw new Error("datepickerPopup must have a date format specified.");if(s&&k.datepickerPopup)throw new Error("HTML5 date input types do not support custom formats.");var t=angular.element("<div datepicker-popup-wrap><div datepicker></div></div>");t.attr({"ng-model":"date","ng-change":"dateSelection(date)"});var u=angular.element(t.children()[0]);if(s&&"month"==k.type&&(u.attr("datepicker-mode",'"month"'),u.attr("min-mode","month")),k.datepickerOptions){var v=i.$parent.$eval(k.datepickerOptions);v&&v.initDate&&(i.initDate=v.initDate,u.attr("init-date","initDate"),delete v.initDate),angular.forEach(v,function(a,b){u.attr(m(b),a)})}i.watchData={},angular.forEach(["minDate","maxDate","datepickerMode","initDate","shortcutPropagation"],function(a){if(k[a]){var c=b(k[a]);if(i.$parent.$watch(c,function(b){i.watchData[a]=b}),u.attr(m(a),"watchData."+a),"datepickerMode"===a){var d=c.assign;i.$watch("watchData."+a,function(a,b){angular.isFunction(d)&&a!==b&&d(i.$parent,a)})}}}),k.dateDisabled&&u.attr("date-disabled","dateDisabled({ date: date, mode: mode })"),k.showWeeks&&u.attr("show-weeks",k.showWeeks),k.customClass&&u.attr("custom-class","customClass({ date: date, mode: mode })"),s?l.$formatters.push(function(a){return i.date=a,a}):(l.$$parserName="date",l.$validators.date=o,l.$parsers.unshift(n),l.$formatters.push(function(a){return i.date=a,l.$isEmpty(a)?a:e(a,p)})),i.dateSelection=function(a){angular.isDefined(a)&&(i.date=a);var b=i.date?e(i.date,p):null;j.val(b),l.$setViewValue(b),q&&(i.isOpen=!1,j[0].focus())},l.$viewChangeListeners.push(function(){i.date=f.parse(l.$viewValue,p,i.date)});var w=function(a){i.isOpen&&!j[0].contains(a.target)&&i.$apply(function(){i.isOpen=!1})},x=function(a){27===a.which&&i.isOpen?(a.preventDefault(),a.stopPropagation(),i.$apply(function(){i.isOpen=!1}),j[0].focus()):40!==a.which||i.isOpen||(a.preventDefault(),a.stopPropagation(),i.$apply(function(){i.isOpen=!0}))};j.bind("keydown",x),i.keydown=function(a){27===a.which&&(i.isOpen=!1,j[0].focus())},i.$watch("isOpen",function(a){a?(i.position=r?d.offset(j):d.position(j),i.position.top=i.position.top+j.prop("offsetHeight"),h(function(){i.$broadcast("datepicker.focus"),c.bind("click",w)},0,!1)):c.unbind("click",w)}),i.select=function(a){if("today"===a){var b=new Date;angular.isDate(i.date)?(a=new Date(i.date),a.setFullYear(b.getFullYear(),b.getMonth(),b.getDate())):a=new Date(b.setHours(0,0,0,0))}i.dateSelection(a)},i.close=function(){i.isOpen=!1,j[0].focus()};var y=a(t)(i);t.remove(),r?c.find("body").append(y):j.after(y),i.$on("$destroy",function(){i.isOpen===!0&&i.$apply(function(){i.isOpen=!1}),y.remove(),j.unbind("keydown",x),c.unbind("click",w)})}}}]).directive("datepickerPopupWrap",function(){return{restrict:"EA",replace:!0,transclude:!0,templateUrl:"template/datepicker/popup.html"}}),angular.module("ui.bootstrap.dropdown",["ui.bootstrap.position"]).constant("dropdownConfig",{openClass:"open"}).service("dropdownService",["$document","$rootScope",function(a,b){var c=null;this.open=function(b){c||(a.bind("click",d),a.bind("keydown",e)),c&&c!==b&&(c.isOpen=!1),c=b},this.close=function(b){c===b&&(c=null,a.unbind("click",d),a.unbind("keydown",e))};var d=function(a){if(c&&(!a||"disabled"!==c.getAutoClose())){var d=c.getToggleElement();if(!(a&&d&&d[0].contains(a.target))){var e=c.getDropdownElement();a&&"outsideClick"===c.getAutoClose()&&e&&e[0].contains(a.target)||(c.isOpen=!1,b.$$phase||c.$apply())}}},e=function(a){27===a.which?(c.focusToggleElement(),d()):c.isKeynavEnabled()&&/(38|40)/.test(a.which)&&c.isOpen&&(a.preventDefault(),a.stopPropagation(),c.focusDropdownEntry(a.which))}}]).controller("DropdownController",["$scope","$attrs","$parse","dropdownConfig","dropdownService","$animate","$position","$document","$compile","$templateRequest",function(a,b,c,d,e,f,g,h,i,j){var k,l,m=this,n=a.$new(),o=d.openClass,p=angular.noop,q=b.onToggle?c(b.onToggle):angular.noop,r=!1,s=!1;this.init=function(d){m.$element=d,b.isOpen&&(l=c(b.isOpen),p=l.assign,a.$watch(l,function(a){n.isOpen=!!a})),r=angular.isDefined(b.dropdownAppendToBody),s=angular.isDefined(b.keyboardNav),r&&m.dropdownMenu&&(h.find("body").append(m.dropdownMenu),d.on("$destroy",function(){m.dropdownMenu.remove()}))},this.toggle=function(a){return n.isOpen=arguments.length?!!a:!n.isOpen},this.isOpen=function(){return n.isOpen},n.getToggleElement=function(){return m.toggleElement},n.getAutoClose=function(){return b.autoClose||"always"},n.getElement=function(){return m.$element},n.isKeynavEnabled=function(){return s},n.focusDropdownEntry=function(a){var b=m.dropdownMenu?angular.element(m.dropdownMenu).find("a"):angular.element(m.$element).find("ul").eq(0).find("a");switch(a){case 40:m.selectedOption=angular.isNumber(m.selectedOption)?m.selectedOption===b.length-1?m.selectedOption:m.selectedOption+1:0;break;case 38:if(!angular.isNumber(m.selectedOption))return;m.selectedOption=0===m.selectedOption?0:m.selectedOption-1}b[m.selectedOption].focus()},n.getDropdownElement=function(){return m.dropdownMenu},n.focusToggleElement=function(){m.toggleElement&&m.toggleElement[0].focus()},n.$watch("isOpen",function(b,c){if(r&&m.dropdownMenu){var d=g.positionElements(m.$element,m.dropdownMenu,"bottom-left",!0),h={top:d.top+"px",display:b?"block":"none"},l=m.dropdownMenu.hasClass("dropdown-menu-right");l?(h.left="auto",h.right=window.innerWidth-(d.left+m.$element.prop("offsetWidth"))+"px"):(h.left=d.left+"px",h.right="auto"),m.dropdownMenu.css(h)}if(f[b?"addClass":"removeClass"](m.$element,o).then(function(){angular.isDefined(b)&&b!==c&&q(a,{open:!!b})}),b)m.dropdownMenuTemplateUrl&&j(m.dropdownMenuTemplateUrl).then(function(a){k=n.$new(),i(a.trim())(k,function(a){var b=a;m.dropdownMenu.replaceWith(b),m.dropdownMenu=b})}),n.focusToggleElement(),e.open(n);else{if(m.dropdownMenuTemplateUrl){k&&k.$destroy();var s=angular.element('<ul class="dropdown-menu"></ul>');m.dropdownMenu.replaceWith(s),m.dropdownMenu=s}e.close(n),m.selectedOption=null}angular.isFunction(p)&&p(a,b)}),a.$on("$locationChangeSuccess",function(){"disabled"!==n.getAutoClose()&&(n.isOpen=!1)}),a.$on("$destroy",function(){n.$destroy()})}]).directive("dropdown",function(){return{controller:"DropdownController",link:function(a,b,c,d){d.init(b),b.addClass("dropdown")}}}).directive("dropdownMenu",function(){return{restrict:"AC",require:"?^dropdown",link:function(a,b,c,d){if(d){var e=c.templateUrl;e&&(d.dropdownMenuTemplateUrl=e),d.dropdownMenu||(d.dropdownMenu=b)}}}}).directive("keyboardNav",function(){return{restrict:"A",require:"?^dropdown",link:function(a,b,c,d){b.bind("keydown",function(a){if(-1!==[38,40].indexOf(a.which)){a.preventDefault(),a.stopPropagation();var c=angular.element(b).find("a");switch(a.keyCode){case 40:d.selectedOption=angular.isNumber(d.selectedOption)?d.selectedOption===c.length-1?d.selectedOption:d.selectedOption+1:0;break;case 38:d.selectedOption=0===d.selectedOption?0:d.selectedOption-1}c[d.selectedOption].focus()}})}}}).directive("dropdownToggle",function(){return{require:"?^dropdown",link:function(a,b,c,d){if(d){b.addClass("dropdown-toggle"),d.toggleElement=b;var e=function(e){e.preventDefault(),b.hasClass("disabled")||c.disabled||a.$apply(function(){d.toggle()})};b.bind("click",e),b.attr({"aria-haspopup":!0,"aria-expanded":!1}),a.$watch(d.isOpen,function(a){b.attr("aria-expanded",!!a)}),a.$on("$destroy",function(){b.unbind("click",e)})}}}}),angular.module("ui.bootstrap.modal",[]).factory("$$stackedMap",function(){return{createNew:function(){var a=[];return{add:function(b,c){a.push({key:b,value:c})},get:function(b){for(var c=0;c<a.length;c++)if(b==a[c].key)return a[c]},keys:function(){for(var b=[],c=0;c<a.length;c++)b.push(a[c].key);return b},top:function(){return a[a.length-1]},remove:function(b){for(var c=-1,d=0;d<a.length;d++)if(b==a[d].key){c=d;break}return a.splice(c,1)[0]},removeTop:function(){return a.splice(a.length-1,1)[0]},length:function(){return a.length}}}}}).directive("modalBackdrop",["$animate","$modalStack",function(a,b){function c(c,d,e){e.modalInClass&&(a.addClass(d,e.modalInClass),c.$on(b.NOW_CLOSING_EVENT,function(b,c){var f=c();a.removeClass(d,e.modalInClass).then(f)}))}return{restrict:"EA",replace:!0,templateUrl:"template/modal/backdrop.html",compile:function(a,b){return a.addClass(b.backdropClass),c}}}]).directive("modalWindow",["$modalStack","$q","$animate",function(a,b,c){return{restrict:"EA",scope:{index:"@"},replace:!0,transclude:!0,templateUrl:function(a,b){return b.templateUrl||"template/modal/window.html"},link:function(d,e,f){e.addClass(f.windowClass||""),d.size=f.size,d.close=function(b){var c=a.getTop();c&&c.value.backdrop&&"static"!=c.value.backdrop&&b.target===b.currentTarget&&(b.preventDefault(),b.stopPropagation(),a.dismiss(c.key,"backdrop click"))},d.$isRendered=!0;var g=b.defer();f.$observe("modalRender",function(a){"true"==a&&g.resolve()}),g.promise.then(function(){f.modalInClass&&(c.addClass(e,f.modalInClass),d.$on(a.NOW_CLOSING_EVENT,function(a,b){var d=b();c.removeClass(e,f.modalInClass).then(d)}));var b=e[0].querySelectorAll("[autofocus]");b.length?b[0].focus():e[0].focus();var g=a.getTop();g&&a.modalRendered(g.key)})}}}]).directive("modalAnimationClass",[function(){return{compile:function(a,b){b.modalAnimation&&a.addClass(b.modalAnimationClass)}}}]).directive("modalTransclude",function(){return{link:function(a,b,c,d,e){e(a.$parent,function(a){b.empty(),b.append(a)})}}}).factory("$modalStack",["$animate","$timeout","$document","$compile","$rootScope","$q","$$stackedMap",function(a,b,c,d,e,f,g){function h(){for(var a=-1,b=q.keys(),c=0;c<b.length;c++)q.get(b[c]).value.backdrop&&(a=c);

return a}function i(a,b){var d=c.find("body").eq(0),e=q.get(a).value;q.remove(a),k(e.modalDomEl,e.modalScope,function(){d.toggleClass(p,q.length()>0)}),j(),b&&b.focus?b.focus():d.focus()}function j(){if(m&&-1==h()){var a=n;k(m,n,function(){a=null}),m=void 0,n=void 0}}function k(b,c,d){function e(){e.done||(e.done=!0,a.leave(b),c.$destroy(),d&&d())}var g,h=null,i=function(){return g||(g=f.defer(),h=g.promise),function(){g.resolve()}};return c.$broadcast(r.NOW_CLOSING_EVENT,i),f.when(h).then(e)}function l(a,b,c){return!a.value.modalScope.$broadcast("modal.closing",b,c).defaultPrevented}var m,n,o,p="modal-open",q=g.createNew(),r={NOW_CLOSING_EVENT:"modal.stack.now-closing"},s=0,t="a[href], area[href], input:not([disabled]), button:not([disabled]),select:not([disabled]), textarea:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable=true]";return e.$watch(h,function(a){n&&(n.index=a)}),c.bind("keydown",function(a){var b=q.top();if(b&&b.value.keyboard)switch(a.which){case 27:a.preventDefault(),e.$apply(function(){r.dismiss(b.key,"escape key press")});break;case 9:r.loadFocusElementList(b);var c=!1;a.shiftKey?r.isFocusInFirstItem(a)&&(c=r.focusLastFocusableElement()):r.isFocusInLastItem(a)&&(c=r.focusFirstFocusableElement()),c&&(a.preventDefault(),a.stopPropagation())}}),r.open=function(a,b){var f=c[0].activeElement;q.add(a,{deferred:b.deferred,renderDeferred:b.renderDeferred,modalScope:b.scope,backdrop:b.backdrop,keyboard:b.keyboard});var g=c.find("body").eq(0),i=h();if(i>=0&&!m){n=e.$new(!0),n.index=i;var j=angular.element('<div modal-backdrop="modal-backdrop"></div>');j.attr("backdrop-class",b.backdropClass),b.animation&&j.attr("modal-animation","true"),m=d(j)(n),g.append(m)}var k=angular.element('<div modal-window="modal-window"></div>');k.attr({"template-url":b.windowTemplateUrl,"window-class":b.windowClass,size:b.size,index:q.length()-1,animate:"animate"}).html(b.content),b.animation&&k.attr("modal-animation","true");var l=d(k)(b.scope);q.top().value.modalDomEl=l,q.top().value.modalOpener=f,g.append(l),g.addClass(p),r.clearFocusListCache()},r.close=function(a,b){var c=q.get(a);return c&&l(c,b,!0)?(c.value.deferred.resolve(b),i(a,c.value.modalOpener),!0):!c},r.dismiss=function(a,b){var c=q.get(a);return c&&l(c,b,!1)?(c.value.deferred.reject(b),i(a,c.value.modalOpener),!0):!c},r.dismissAll=function(a){for(var b=this.getTop();b&&this.dismiss(b.key,a);)b=this.getTop()},r.getTop=function(){return q.top()},r.modalRendered=function(a){var b=q.get(a);b&&b.value.renderDeferred.resolve()},r.focusFirstFocusableElement=function(){return o.length>0?(o[0].focus(),!0):!1},r.focusLastFocusableElement=function(){return o.length>0?(o[o.length-1].focus(),!0):!1},r.isFocusInFirstItem=function(a){return o.length>0?(a.target||a.srcElement)==o[0]:!1},r.isFocusInLastItem=function(a){return o.length>0?(a.target||a.srcElement)==o[o.length-1]:!1},r.clearFocusListCache=function(){o=[],s=0},r.loadFocusElementList=function(a){if((void 0===o||!o.length0)&&a){var b=a.value.modalDomEl;b&&b.length&&(o=b[0].querySelectorAll(t))}},r}]).provider("$modal",function(){var a={options:{animation:!0,backdrop:!0,keyboard:!0},$get:["$injector","$rootScope","$q","$templateRequest","$controller","$modalStack",function(b,c,d,e,f,g){function h(a){return a.template?d.when(a.template):e(angular.isFunction(a.templateUrl)?a.templateUrl():a.templateUrl)}function i(a){var c=[];return angular.forEach(a,function(a){(angular.isFunction(a)||angular.isArray(a))&&c.push(d.when(b.invoke(a)))}),c}var j={};return j.open=function(b){var e=d.defer(),j=d.defer(),k=d.defer(),l={result:e.promise,opened:j.promise,rendered:k.promise,close:function(a){return g.close(l,a)},dismiss:function(a){return g.dismiss(l,a)}};if(b=angular.extend({},a.options,b),b.resolve=b.resolve||{},!b.template&&!b.templateUrl)throw new Error("One of template or templateUrl options is required.");var m=d.all([h(b)].concat(i(b.resolve)));return m.then(function(a){var d=(b.scope||c).$new();d.$close=l.close,d.$dismiss=l.dismiss;var h,i={},j=1;b.controller&&(i.$scope=d,i.$modalInstance=l,angular.forEach(b.resolve,function(b,c){i[c]=a[j++]}),h=f(b.controller,i),b.controllerAs&&(b.bindToController&&angular.extend(h,d),d[b.controllerAs]=h)),g.open(l,{scope:d,deferred:e,renderDeferred:k,content:a[0],animation:b.animation,backdrop:b.backdrop,keyboard:b.keyboard,backdropClass:b.backdropClass,windowClass:b.windowClass,windowTemplateUrl:b.windowTemplateUrl,size:b.size})},function(a){e.reject(a)}),m.then(function(){j.resolve(!0)},function(a){j.reject(a)}),l},j}]};return a}),angular.module("ui.bootstrap.pagination",[]).controller("PaginationController",["$scope","$attrs","$parse",function(a,b,c){var d=this,e={$setViewValue:angular.noop},f=b.numPages?c(b.numPages).assign:angular.noop;this.init=function(g,h){e=g,this.config=h,e.$render=function(){d.render()},b.itemsPerPage?a.$parent.$watch(c(b.itemsPerPage),function(b){d.itemsPerPage=parseInt(b,10),a.totalPages=d.calculateTotalPages()}):this.itemsPerPage=h.itemsPerPage,a.$watch("totalItems",function(){a.totalPages=d.calculateTotalPages()}),a.$watch("totalPages",function(b){f(a.$parent,b),a.page>b?a.selectPage(b):e.$render()})},this.calculateTotalPages=function(){var b=this.itemsPerPage<1?1:Math.ceil(a.totalItems/this.itemsPerPage);return Math.max(b||0,1)},this.render=function(){a.page=parseInt(e.$viewValue,10)||1},a.selectPage=function(b,c){var d=!a.ngDisabled||!c;d&&a.page!==b&&b>0&&b<=a.totalPages&&(c&&c.target&&c.target.blur(),e.$setViewValue(b),e.$render())},a.getText=function(b){return a[b+"Text"]||d.config[b+"Text"]},a.noPrevious=function(){return 1===a.page},a.noNext=function(){return a.page===a.totalPages}}]).constant("paginationConfig",{itemsPerPage:10,boundaryLinks:!1,directionLinks:!0,firstText:"First",previousText:"Previous",nextText:"Next",lastText:"Last",rotate:!0}).directive("pagination",["$parse","paginationConfig",function(a,b){return{restrict:"EA",scope:{totalItems:"=",firstText:"@",previousText:"@",nextText:"@",lastText:"@",ngDisabled:"="},require:["pagination","?ngModel"],controller:"PaginationController",templateUrl:"template/pagination/pagination.html",replace:!0,link:function(c,d,e,f){function g(a,b,c){return{number:a,text:b,active:c}}function h(a,b){var c=[],d=1,e=b,f=angular.isDefined(k)&&b>k;f&&(l?(d=Math.max(a-Math.floor(k/2),1),e=d+k-1,e>b&&(e=b,d=e-k+1)):(d=(Math.ceil(a/k)-1)*k+1,e=Math.min(d+k-1,b)));for(var h=d;e>=h;h++){var i=g(h,h,h===a);c.push(i)}if(f&&!l){if(d>1){var j=g(d-1,"...",!1);c.unshift(j)}if(b>e){var m=g(e+1,"...",!1);c.push(m)}}return c}var i=f[0],j=f[1];if(j){var k=angular.isDefined(e.maxSize)?c.$parent.$eval(e.maxSize):b.maxSize,l=angular.isDefined(e.rotate)?c.$parent.$eval(e.rotate):b.rotate;c.boundaryLinks=angular.isDefined(e.boundaryLinks)?c.$parent.$eval(e.boundaryLinks):b.boundaryLinks,c.directionLinks=angular.isDefined(e.directionLinks)?c.$parent.$eval(e.directionLinks):b.directionLinks,i.init(j,b),e.maxSize&&c.$parent.$watch(a(e.maxSize),function(a){k=parseInt(a,10),i.render()});var m=i.render;i.render=function(){m(),c.page>0&&c.page<=c.totalPages&&(c.pages=h(c.page,c.totalPages))}}}}}]).constant("pagerConfig",{itemsPerPage:10,previousText:"« Previous",nextText:"Next »",align:!0}).directive("pager",["pagerConfig",function(a){return{restrict:"EA",scope:{totalItems:"=",previousText:"@",nextText:"@"},require:["pager","?ngModel"],controller:"PaginationController",templateUrl:"template/pagination/pager.html",replace:!0,link:function(b,c,d,e){var f=e[0],g=e[1];g&&(b.align=angular.isDefined(d.align)?b.$parent.$eval(d.align):a.align,f.init(g,a))}}}]),angular.module("ui.bootstrap.tooltip",["ui.bootstrap.position","ui.bootstrap.bindHtml"]).provider("$tooltip",function(){function a(a){var b=/[A-Z]/g,c="-";return a.replace(b,function(a,b){return(b?c:"")+a.toLowerCase()})}var b={placement:"top",animation:!0,popupDelay:0,useContentExp:!1},c={mouseenter:"mouseleave",click:"click",focus:"blur"},d={};this.options=function(a){angular.extend(d,a)},this.setTriggers=function(a){angular.extend(c,a)},this.$get=["$window","$compile","$timeout","$document","$position","$interpolate",function(e,f,g,h,i,j){return function(e,k,l,m){function n(a){var b=a||m.trigger||l,d=c[b]||b;return{show:b,hide:d}}m=angular.extend({},b,d,m);var o=a(e),p=j.startSymbol(),q=j.endSymbol(),r="<div "+o+'-popup title="'+p+"title"+q+'" '+(m.useContentExp?'content-exp="contentExp()" ':'content="'+p+"content"+q+'" ')+'placement="'+p+"placement"+q+'" popup-class="'+p+"popupClass"+q+'" animation="animation" is-open="isOpen"origin-scope="origScope" ></div>';return{restrict:"EA",compile:function(){var a=f(r);return function(b,c,d){function f(){E.isOpen?l():j()}function j(){(!D||b.$eval(d[k+"Enable"]))&&(s(),E.popupDelay?A||(A=g(o,E.popupDelay,!1),A.then(function(a){a()})):o()())}function l(){b.$apply(function(){p()})}function o(){return A=null,z&&(g.cancel(z),z=null),(m.useContentExp?E.contentExp():E.content)?(q(),x.css({top:0,left:0,display:"block"}),E.$digest(),F(),E.isOpen=!0,E.$apply(),F):angular.noop}function p(){E.isOpen=!1,g.cancel(A),A=null,E.animation?z||(z=g(r,500)):r()}function q(){x&&r(),y=E.$new(),x=a(y,function(a){B?h.find("body").append(a):c.after(a)}),m.useContentExp&&y.$watch("contentExp()",function(a){G(),!a&&E.isOpen&&p()})}function r(){z=null,x&&(x.remove(),x=null),y&&(y.$destroy(),y=null)}function s(){t(),u(),v()}function t(){E.popupClass=d[k+"Class"]}function u(){var a=d[k+"Placement"];E.placement=angular.isDefined(a)?a:m.placement}function v(){var a=d[k+"PopupDelay"],b=parseInt(a,10);E.popupDelay=isNaN(b)?m.popupDelay:b}function w(){var a=d[k+"Trigger"];H(),C=n(a),C.show===C.hide?c.bind(C.show,f):(c.bind(C.show,j),c.bind(C.hide,l))}var x,y,z,A,B=angular.isDefined(m.appendToBody)?m.appendToBody:!1,C=n(void 0),D=angular.isDefined(d[k+"Enable"]),E=b.$new(!0),F=function(){if(x){var a=i.positionElements(c,x,E.placement,B);a.top+="px",a.left+="px",x.css(a)}},G=function(){g(F,0,!1)};E.origScope=b,E.isOpen=!1,E.contentExp=function(){return b.$eval(d[e])},m.useContentExp||d.$observe(e,function(a){E.content=a,G(),!a&&E.isOpen&&p()}),d.$observe("disabled",function(a){a&&E.isOpen&&p()}),d.$observe(k+"Title",function(a){E.title=a,G()}),d.$observe(k+"Placement",function(){E.isOpen&&g(function(){u(),o()()},0,!1)});var H=function(){c.unbind(C.show,j),c.unbind(C.hide,l)};w();var I=b.$eval(d[k+"Animation"]);E.animation=angular.isDefined(I)?!!I:m.animation;var J=b.$eval(d[k+"AppendToBody"]);B=angular.isDefined(J)?J:B,B&&b.$on("$locationChangeSuccess",function(){E.isOpen&&p()}),b.$on("$destroy",function(){g.cancel(z),g.cancel(A),H(),r(),E=null})}}}}}]}).directive("tooltipTemplateTransclude",["$animate","$sce","$compile","$templateRequest",function(a,b,c,d){return{link:function(e,f,g){var h,i,j,k=e.$eval(g.tooltipTemplateTranscludeScope),l=0,m=function(){i&&(i.remove(),i=null),h&&(h.$destroy(),h=null),j&&(a.leave(j).then(function(){i=null}),i=j,j=null)};e.$watch(b.parseAsResourceUrl(g.tooltipTemplateTransclude),function(b){var g=++l;b?(d(b,!0).then(function(d){if(g===l){var e=k.$new(),i=d,n=c(i)(e,function(b){m(),a.enter(b,f)});h=e,j=n,h.$emit("$includeContentLoaded",b)}},function(){g===l&&(m(),e.$emit("$includeContentError",b))}),e.$emit("$includeContentRequested",b)):m()}),e.$on("$destroy",m)}}}]).directive("tooltipClasses",function(){return{restrict:"A",link:function(a,b,c){a.placement&&b.addClass(a.placement),a.popupClass&&b.addClass(a.popupClass),a.animation()&&b.addClass(c.tooltipAnimationClass)}}}).directive("tooltipPopup",function(){return{restrict:"EA",replace:!0,scope:{content:"@",placement:"@",popupClass:"@",animation:"&",isOpen:"&"},templateUrl:"template/tooltip/tooltip-popup.html"}}).directive("tooltip",["$tooltip",function(a){return a("tooltip","tooltip","mouseenter")}]).directive("tooltipTemplatePopup",function(){return{restrict:"EA",replace:!0,scope:{contentExp:"&",placement:"@",popupClass:"@",animation:"&",isOpen:"&",originScope:"&"},templateUrl:"template/tooltip/tooltip-template-popup.html"}}).directive("tooltipTemplate",["$tooltip",function(a){return a("tooltipTemplate","tooltip","mouseenter",{useContentExp:!0})}]).directive("tooltipHtmlPopup",function(){return{restrict:"EA",replace:!0,scope:{contentExp:"&",placement:"@",popupClass:"@",animation:"&",isOpen:"&"},templateUrl:"template/tooltip/tooltip-html-popup.html"}}).directive("tooltipHtml",["$tooltip",function(a){return a("tooltipHtml","tooltip","mouseenter",{useContentExp:!0})}]).directive("tooltipHtmlUnsafePopup",function(){return{restrict:"EA",replace:!0,scope:{content:"@",placement:"@",popupClass:"@",animation:"&",isOpen:"&"},templateUrl:"template/tooltip/tooltip-html-unsafe-popup.html"}}).value("tooltipHtmlUnsafeSuppressDeprecated",!1).directive("tooltipHtmlUnsafe",["$tooltip","tooltipHtmlUnsafeSuppressDeprecated","$log",function(a,b,c){return b||c.warn("tooltip-html-unsafe is now deprecated. Use tooltip-html or tooltip-template instead."),a("tooltipHtmlUnsafe","tooltip","mouseenter")}]),angular.module("ui.bootstrap.popover",["ui.bootstrap.tooltip"]).directive("popoverTemplatePopup",function(){return{restrict:"EA",replace:!0,scope:{title:"@",contentExp:"&",placement:"@",popupClass:"@",animation:"&",isOpen:"&",originScope:"&"},templateUrl:"template/popover/popover-template.html"}}).directive("popoverTemplate",["$tooltip",function(a){return a("popoverTemplate","popover","click",{useContentExp:!0})}]).directive("popoverHtmlPopup",function(){return{restrict:"EA",replace:!0,scope:{contentExp:"&",title:"@",placement:"@",popupClass:"@",animation:"&",isOpen:"&"},templateUrl:"template/popover/popover-html.html"}}).directive("popoverHtml",["$tooltip",function(a){return a("popoverHtml","popover","click",{useContentExp:!0})}]).directive("popoverPopup",function(){return{restrict:"EA",replace:!0,scope:{title:"@",content:"@",placement:"@",popupClass:"@",animation:"&",isOpen:"&"},templateUrl:"template/popover/popover.html"}}).directive("popover",["$tooltip",function(a){return a("popover","popover","click")}]),angular.module("ui.bootstrap.progressbar",[]).constant("progressConfig",{animate:!0,max:100}).controller("ProgressController",["$scope","$attrs","progressConfig",function(a,b,c){var d=this,e=angular.isDefined(b.animate)?a.$parent.$eval(b.animate):c.animate;this.bars=[],a.max=angular.isDefined(a.max)?a.max:c.max,this.addBar=function(b,c){e||c.css({transition:"none"}),this.bars.push(b),b.max=a.max,b.$watch("value",function(){b.recalculatePercentage()}),b.recalculatePercentage=function(){b.percent=+(100*b.value/b.max).toFixed(2);var a=0;d.bars.forEach(function(b){a+=b.percent}),a>100&&(b.percent-=a-100)},b.$on("$destroy",function(){c=null,d.removeBar(b)})},this.removeBar=function(a){this.bars.splice(this.bars.indexOf(a),1)},a.$watch("max",function(){d.bars.forEach(function(b){b.max=a.max,b.recalculatePercentage()})})}]).directive("progress",function(){return{restrict:"EA",replace:!0,transclude:!0,controller:"ProgressController",require:"progress",scope:{max:"=?"},templateUrl:"template/progressbar/progress.html"}}).directive("bar",function(){return{restrict:"EA",replace:!0,transclude:!0,require:"^progress",scope:{value:"=",type:"@"},templateUrl:"template/progressbar/bar.html",link:function(a,b,c,d){d.addBar(a,b)}}}).directive("progressbar",function(){return{restrict:"EA",replace:!0,transclude:!0,controller:"ProgressController",scope:{value:"=",max:"=?",type:"@"},templateUrl:"template/progressbar/progressbar.html",link:function(a,b,c,d){d.addBar(a,angular.element(b.children()[0]))}}}),angular.module("ui.bootstrap.rating",[]).constant("ratingConfig",{max:5,stateOn:null,stateOff:null,titles:["one","two","three","four","five"]}).controller("RatingController",["$scope","$attrs","ratingConfig",function(a,b,c){var d={$setViewValue:angular.noop};this.init=function(e){d=e,d.$render=this.render,d.$formatters.push(function(a){return angular.isNumber(a)&&a<<0!==a&&(a=Math.round(a)),a}),this.stateOn=angular.isDefined(b.stateOn)?a.$parent.$eval(b.stateOn):c.stateOn,this.stateOff=angular.isDefined(b.stateOff)?a.$parent.$eval(b.stateOff):c.stateOff;var f=angular.isDefined(b.titles)?a.$parent.$eval(b.titles):c.titles;this.titles=angular.isArray(f)&&f.length>0?f:c.titles;var g=angular.isDefined(b.ratingStates)?a.$parent.$eval(b.ratingStates):new Array(angular.isDefined(b.max)?a.$parent.$eval(b.max):c.max);a.range=this.buildTemplateObjects(g)},this.buildTemplateObjects=function(a){for(var b=0,c=a.length;c>b;b++)a[b]=angular.extend({index:b},{stateOn:this.stateOn,stateOff:this.stateOff,title:this.getTitle(b)},a[b]);return a},this.getTitle=function(a){return a>=this.titles.length?a+1:this.titles[a]},a.rate=function(b){!a.readonly&&b>=0&&b<=a.range.length&&(d.$setViewValue(d.$viewValue===b?0:b),d.$render())},a.enter=function(b){a.readonly||(a.value=b),a.onHover({value:b})},a.reset=function(){a.value=d.$viewValue,a.onLeave()},a.onKeydown=function(b){/(37|38|39|40)/.test(b.which)&&(b.preventDefault(),b.stopPropagation(),a.rate(a.value+(38===b.which||39===b.which?1:-1)))},this.render=function(){a.value=d.$viewValue}}]).directive("rating",function(){return{restrict:"EA",require:["rating","ngModel"],scope:{readonly:"=?",onHover:"&",onLeave:"&"},controller:"RatingController",templateUrl:"template/rating/rating.html",replace:!0,link:function(a,b,c,d){var e=d[0],f=d[1];e.init(f)}}}),angular.module("ui.bootstrap.tabs",[]).controller("TabsetController",["$scope",function(a){var b=this,c=b.tabs=a.tabs=[];b.select=function(a){angular.forEach(c,function(b){b.active&&b!==a&&(b.active=!1,b.onDeselect())}),a.active=!0,a.onSelect()},b.addTab=function(a){c.push(a),1===c.length&&a.active!==!1?a.active=!0:a.active?b.select(a):a.active=!1},b.removeTab=function(a){var e=c.indexOf(a);if(a.active&&c.length>1&&!d){var f=e==c.length-1?e-1:e+1;b.select(c[f])}c.splice(e,1)};var d;a.$on("$destroy",function(){d=!0})}]).directive("tabset",function(){return{restrict:"EA",transclude:!0,replace:!0,scope:{type:"@"},controller:"TabsetController",templateUrl:"template/tabs/tabset.html",link:function(a,b,c){a.vertical=angular.isDefined(c.vertical)?a.$parent.$eval(c.vertical):!1,a.justified=angular.isDefined(c.justified)?a.$parent.$eval(c.justified):!1}}}).directive("tab",["$parse","$log",function(a,b){return{require:"^tabset",restrict:"EA",replace:!0,templateUrl:"template/tabs/tab.html",transclude:!0,scope:{active:"=?",heading:"@",onSelect:"&select",onDeselect:"&deselect"},controller:function(){},link:function(c,d,e,f,g){c.$watch("active",function(a){a&&f.select(c)}),c.disabled=!1,e.disable&&c.$parent.$watch(a(e.disable),function(a){c.disabled=!!a}),e.disabled&&(b.warn('Use of "disabled" attribute has been deprecated, please use "disable"'),c.$parent.$watch(a(e.disabled),function(a){c.disabled=!!a})),c.select=function(){c.disabled||(c.active=!0)},f.addTab(c),c.$on("$destroy",function(){f.removeTab(c)}),c.$transcludeFn=g}}}]).directive("tabHeadingTransclude",[function(){return{restrict:"A",require:"^tab",link:function(a,b){a.$watch("headingElement",function(a){a&&(b.html(""),b.append(a))})}}}]).directive("tabContentTransclude",function(){function a(a){return a.tagName&&(a.hasAttribute("tab-heading")||a.hasAttribute("data-tab-heading")||"tab-heading"===a.tagName.toLowerCase()||"data-tab-heading"===a.tagName.toLowerCase())}return{restrict:"A",require:"^tabset",link:function(b,c,d){var e=b.$eval(d.tabContentTransclude);e.$transcludeFn(e.$parent,function(b){angular.forEach(b,function(b){a(b)?e.headingElement=b:c.append(b)})})}}}),angular.module("ui.bootstrap.timepicker",[]).constant("timepickerConfig",{hourStep:1,minuteStep:1,showMeridian:!0,meridians:null,readonlyInput:!1,mousewheel:!0,arrowkeys:!0,showSpinners:!0}).controller("TimepickerController",["$scope","$attrs","$parse","$log","$locale","timepickerConfig",function(a,b,c,d,e,f){function g(){var b=parseInt(a.hours,10),c=a.showMeridian?b>0&&13>b:b>=0&&24>b;return c?(a.showMeridian&&(12===b&&(b=0),a.meridian===p[1]&&(b+=12)),b):void 0}function h(){var b=parseInt(a.minutes,10);return b>=0&&60>b?b:void 0}function i(a){return angular.isDefined(a)&&a.toString().length<2?"0"+a:a.toString()}function j(a){k(),o.$setViewValue(new Date(n)),l(a)}function k(){o.$setValidity("time",!0),a.invalidHours=!1,a.invalidMinutes=!1}function l(b){var c=n.getHours(),d=n.getMinutes();a.showMeridian&&(c=0===c||12===c?12:c%12),a.hours="h"===b?c:i(c),"m"!==b&&(a.minutes=i(d)),a.meridian=n.getHours()<12?p[0]:p[1]}function m(a){var b=new Date(n.getTime()+6e4*a);n.setHours(b.getHours(),b.getMinutes()),j()}var n=new Date,o={$setViewValue:angular.noop},p=angular.isDefined(b.meridians)?a.$parent.$eval(b.meridians):f.meridians||e.DATETIME_FORMATS.AMPMS;this.init=function(c,d){o=c,o.$render=this.render,o.$formatters.unshift(function(a){return a?new Date(a):null});var e=d.eq(0),g=d.eq(1),h=angular.isDefined(b.mousewheel)?a.$parent.$eval(b.mousewheel):f.mousewheel;h&&this.setupMousewheelEvents(e,g);var i=angular.isDefined(b.arrowkeys)?a.$parent.$eval(b.arrowkeys):f.arrowkeys;i&&this.setupArrowkeyEvents(e,g),a.readonlyInput=angular.isDefined(b.readonlyInput)?a.$parent.$eval(b.readonlyInput):f.readonlyInput,this.setupInputEvents(e,g)};var q=f.hourStep;b.hourStep&&a.$parent.$watch(c(b.hourStep),function(a){q=parseInt(a,10)});var r=f.minuteStep;b.minuteStep&&a.$parent.$watch(c(b.minuteStep),function(a){r=parseInt(a,10)}),a.showMeridian=f.showMeridian,b.showMeridian&&a.$parent.$watch(c(b.showMeridian),function(b){if(a.showMeridian=!!b,o.$error.time){var c=g(),d=h();angular.isDefined(c)&&angular.isDefined(d)&&(n.setHours(c),j())}else l()}),this.setupMousewheelEvents=function(b,c){var d=function(a){a.originalEvent&&(a=a.originalEvent);var b=a.wheelDelta?a.wheelDelta:-a.deltaY;return a.detail||b>0};b.bind("mousewheel wheel",function(b){a.$apply(d(b)?a.incrementHours():a.decrementHours()),b.preventDefault()}),c.bind("mousewheel wheel",function(b){a.$apply(d(b)?a.incrementMinutes():a.decrementMinutes()),b.preventDefault()})},this.setupArrowkeyEvents=function(b,c){b.bind("keydown",function(b){38===b.which?(b.preventDefault(),a.incrementHours(),a.$apply()):40===b.which&&(b.preventDefault(),a.decrementHours(),a.$apply())}),c.bind("keydown",function(b){38===b.which?(b.preventDefault(),a.incrementMinutes(),a.$apply()):40===b.which&&(b.preventDefault(),a.decrementMinutes(),a.$apply())})},this.setupInputEvents=function(b,c){if(a.readonlyInput)return a.updateHours=angular.noop,void(a.updateMinutes=angular.noop);var d=function(b,c){o.$setViewValue(null),o.$setValidity("time",!1),angular.isDefined(b)&&(a.invalidHours=b),angular.isDefined(c)&&(a.invalidMinutes=c)};a.updateHours=function(){var a=g();angular.isDefined(a)?(n.setHours(a),j("h")):d(!0)},b.bind("blur",function(){!a.invalidHours&&a.hours<10&&a.$apply(function(){a.hours=i(a.hours)})}),a.updateMinutes=function(){var a=h();angular.isDefined(a)?(n.setMinutes(a),j("m")):d(void 0,!0)},c.bind("blur",function(){!a.invalidMinutes&&a.minutes<10&&a.$apply(function(){a.minutes=i(a.minutes)})})},this.render=function(){var a=o.$viewValue;isNaN(a)?(o.$setValidity("time",!1),d.error('Timepicker directive: "ng-model" value must be a Date object, a number of milliseconds since 01.01.1970 or a string representing an RFC2822 or ISO 8601 date.')):(a&&(n=a),k(),l())},a.showSpinners=angular.isDefined(b.showSpinners)?a.$parent.$eval(b.showSpinners):f.showSpinners,a.incrementHours=function(){m(60*q)},a.decrementHours=function(){m(60*-q)},a.incrementMinutes=function(){m(r)},a.decrementMinutes=function(){m(-r)},a.toggleMeridian=function(){m(720*(n.getHours()<12?1:-1))}}]).directive("timepicker",function(){return{restrict:"EA",require:["timepicker","?^ngModel"],controller:"TimepickerController",replace:!0,scope:{},templateUrl:"template/timepicker/timepicker.html",link:function(a,b,c,d){var e=d[0],f=d[1];f&&e.init(f,b.find("input"))}}}),angular.module("ui.bootstrap.transition",[]).value("$transitionSuppressDeprecated",!1).factory("$transition",["$q","$timeout","$rootScope","$log","$transitionSuppressDeprecated",function(a,b,c,d,e){function f(a){for(var b in a)if(void 0!==h.style[b])return a[b]}e||d.warn("$transition is now deprecated. Use $animate from ngAnimate instead.");var g=function(d,e,f){f=f||{};var h=a.defer(),i=g[f.animation?"animationEndEventName":"transitionEndEventName"],j=function(){c.$apply(function(){d.unbind(i,j),h.resolve(d)})};return i&&d.bind(i,j),b(function(){angular.isString(e)?d.addClass(e):angular.isFunction(e)?e(d):angular.isObject(e)&&d.css(e),i||h.resolve(d)}),h.promise.cancel=function(){i&&d.unbind(i,j),h.reject("Transition cancelled")},h.promise},h=document.createElement("trans"),i={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd",transition:"transitionend"},j={WebkitTransition:"webkitAnimationEnd",MozTransition:"animationend",OTransition:"oAnimationEnd",transition:"animationend"};return g.transitionEndEventName=f(i),g.animationEndEventName=f(j),g}]),angular.module("ui.bootstrap.typeahead",["ui.bootstrap.position","ui.bootstrap.bindHtml"]).factory("typeaheadParser",["$parse",function(a){var b=/^\s*([\s\S]+?)(?:\s+as\s+([\s\S]+?))?\s+for\s+(?:([\$\w][\$\w\d]*))\s+in\s+([\s\S]+?)$/;return{parse:function(c){var d=c.match(b);if(!d)throw new Error('Expected typeahead specification in form of "_modelValue_ (as _label_)? for _item_ in _collection_" but got "'+c+'".');return{itemName:d[3],source:a(d[4]),viewMapper:a(d[2]||d[1]),modelMapper:a(d[1])}}}}]).directive("typeahead",["$compile","$parse","$q","$timeout","$document","$window","$rootScope","$position","typeaheadParser",function(a,b,c,d,e,f,g,h,i){var j=[9,13,27,38,40],k=200;return{require:"ngModel",link:function(l,m,n,o){function p(){G.moveInProgress||(G.moveInProgress=!0,G.$digest()),N&&d.cancel(N),N=d(function(){G.matches.length&&q(),G.moveInProgress=!1,G.$digest()},k)}function q(){G.position=B?h.offset(m):h.position(m),G.position.top+=m.prop("offsetHeight")}var r=l.$eval(n.typeaheadMinLength);r||0===r||(r=1);var s,t,u=l.$eval(n.typeaheadWaitMs)||0,v=l.$eval(n.typeaheadEditable)!==!1,w=b(n.typeaheadLoading).assign||angular.noop,x=b(n.typeaheadOnSelect),y=angular.isDefined(n.typeaheadSelectOnBlur)?l.$eval(n.typeaheadSelectOnBlur):!1,z=b(n.typeaheadNoResults).assign||angular.noop,A=n.typeaheadInputFormatter?b(n.typeaheadInputFormatter):void 0,B=n.typeaheadAppendToBody?l.$eval(n.typeaheadAppendToBody):!1,C=l.$eval(n.typeaheadFocusFirst)!==!1,D=n.typeaheadSelectOnExact?l.$eval(n.typeaheadSelectOnExact):!1,E=b(n.ngModel).assign,F=i.parse(n.typeahead),G=l.$new();l.$on("$destroy",function(){G.$destroy()});var H="typeahead-"+G.$id+"-"+Math.floor(1e4*Math.random());m.attr({"aria-autocomplete":"list","aria-expanded":!1,"aria-owns":H});var I=angular.element("<div typeahead-popup></div>");I.attr({id:H,matches:"matches",active:"activeIdx",select:"select(activeIdx)","move-in-progress":"moveInProgress",query:"query",position:"position"}),angular.isDefined(n.typeaheadTemplateUrl)&&I.attr("template-url",n.typeaheadTemplateUrl);var J=function(){G.matches=[],G.activeIdx=-1,m.attr("aria-expanded",!1)},K=function(a){return H+"-option-"+a};G.$watch("activeIdx",function(a){0>a?m.removeAttr("aria-activedescendant"):m.attr("aria-activedescendant",K(a))});var L=function(a,b){return G.matches.length>b&&a?a.toUpperCase()===G.matches[b].label.toUpperCase():!1},M=function(a){var b={$viewValue:a};w(l,!0),z(l,!1),c.when(F.source(l,b)).then(function(c){var d=a===o.$viewValue;if(d&&s)if(c&&c.length>0){G.activeIdx=C?0:-1,z(l,!1),G.matches.length=0;for(var e=0;e<c.length;e++)b[F.itemName]=c[e],G.matches.push({id:K(e),label:F.viewMapper(G,b),model:c[e]});G.query=a,q(),m.attr("aria-expanded",!0),D&&1===G.matches.length&&L(a,0)&&G.select(0)}else J(),z(l,!0);d&&w(l,!1)},function(){J(),w(l,!1),z(l,!0)})};B&&(angular.element(f).bind("resize",p),e.find("body").bind("scroll",p));var N;G.moveInProgress=!1,J(),G.query=void 0;var O,P=function(a){O=d(function(){M(a)},u)},Q=function(){O&&d.cancel(O)};o.$parsers.unshift(function(a){return s=!0,0===r||a&&a.length>=r?u>0?(Q(),P(a)):M(a):(w(l,!1),Q(),J()),v?a:a?void o.$setValidity("editable",!1):(o.$setValidity("editable",!0),a)}),o.$formatters.push(function(a){var b,c,d={};return v||o.$setValidity("editable",!0),A?(d.$model=a,A(l,d)):(d[F.itemName]=a,b=F.viewMapper(l,d),d[F.itemName]=void 0,c=F.viewMapper(l,d),b!==c?b:a)}),G.select=function(a){var b,c,e={};t=!0,e[F.itemName]=c=G.matches[a].model,b=F.modelMapper(l,e),E(l,b),o.$setValidity("editable",!0),o.$setValidity("parse",!0),x(l,{$item:c,$model:b,$label:F.viewMapper(l,e)}),J(),d(function(){m[0].focus()},0,!1)},m.bind("keydown",function(a){if(0!==G.matches.length&&-1!==j.indexOf(a.which)){if(-1===G.activeIdx&&(9===a.which||13===a.which))return J(),void G.$digest();a.preventDefault(),40===a.which?(G.activeIdx=(G.activeIdx+1)%G.matches.length,G.$digest()):38===a.which?(G.activeIdx=(G.activeIdx>0?G.activeIdx:G.matches.length)-1,G.$digest()):13===a.which||9===a.which?G.$apply(function(){G.select(G.activeIdx)}):27===a.which&&(a.stopPropagation(),J(),G.$digest())}}),m.bind("blur",function(){y&&G.matches.length&&-1!==G.activeIdx&&!t&&(t=!0,G.$apply(function(){G.select(G.activeIdx)})),s=!1,t=!1});var R=function(a){m[0]!==a.target&&3!==a.which&&0!==G.matches.length&&(J(),g.$$phase||G.$digest())};e.bind("click",R),l.$on("$destroy",function(){e.unbind("click",R),B&&S.remove(),I.remove()});var S=a(I)(G);B?e.find("body").append(S):m.after(S)}}}]).directive("typeaheadPopup",function(){return{restrict:"EA",scope:{matches:"=",query:"=",active:"=",position:"&",moveInProgress:"=",select:"&"},replace:!0,templateUrl:"template/typeahead/typeahead-popup.html",link:function(a,b,c){a.templateUrl=c.templateUrl,a.isOpen=function(){return a.matches.length>0},a.isActive=function(b){return a.active==b},a.selectActive=function(b){a.active=b},a.selectMatch=function(b){a.select({activeIdx:b})}}}}).directive("typeaheadMatch",["$templateRequest","$compile","$parse",function(a,b,c){return{restrict:"EA",scope:{index:"=",match:"=",query:"="},link:function(d,e,f){var g=c(f.templateUrl)(d.$parent)||"template/typeahead/typeahead-match.html";a(g).then(function(a){b(a.trim())(d,function(a){e.replaceWith(a)})})}}}]).filter("typeaheadHighlight",function(){function a(a){return a.replace(/([.?*+^$[\]\\(){}|-])/g,"\\$1")}return function(b,c){return c?(""+b).replace(new RegExp(a(c),"gi"),"<strong>$&</strong>"):b}}),!angular.$$csp()&&angular.element(document).find("head").prepend('<style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style>');

